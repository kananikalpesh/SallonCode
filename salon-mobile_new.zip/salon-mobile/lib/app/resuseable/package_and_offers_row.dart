import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'offer_item_widget.dart';

class PackageAndOfferRow extends GetView<DashboardItemController> {
  //late DashboardItem dashboardItem ;
  //bool isPopular = true;
  static String SALOON_ID = '';

  //SaloonRowItem({required this.dashboardItem, required this.isPopular});
  //SaloonRowItem({ required this.isPopular});

  @override
  Widget build(BuildContext context) {
    // var data = isPopular?dashboardItem.popular:dashboardItem.favorite;
    return Container(
      height: SizeConfig.screenHeight * 0.32,
      //color: Colors.red,
      margin: EdgeInsets.only(
        left: 15,
        right: 15,
      ),
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: controller.saloonItemsModel?.deals?.length ?? 0,
          itemBuilder: (BuildContext context, int index) {
            //print('APIDATA${dashboardItem.popular}');
            return Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    OfferItemWidget(
                      index: index.toString(),
                        image: AppImages.Packages_img,
                        dealID: controller
                            .saloonItemsModel?.deals?[index].couponCode,
                        dealName: controller
                            .saloonItemsModel?.deals?[index].couponName,
                        serviceName: controller
                            .saloonItemsModel?.deals?[index].service!.name,
                        originalPrice: controller
                                    .saloonItemsModel?.deals?[index].price
                                    .toString() ==
                                "0"
                            ? ""
                            : controller.saloonItemsModel?.deals?[index].price
                                .toString(),
                        discountedPrice: controller
                                    .saloonItemsModel?.deals?[index].price
                                    .toString() ==
                                "0"
                            ? ""
                            : controller.saloonItemsModel?.deals?[index].price
                                .toString(),
                        discount:
                            "${controller.saloonItemsModel?.deals?[index].percentage}",
                        validDate:
                            "${controller.saloonItemsModel?.deals?[index].endDate.toString().split(' ')[0]??''}",
                        status:
                            "${controller.saloonItemsModel?.deals?[index].status}")

                    // _PopularItemView(
                    //     context, "assets/images/popular.png", "New",
                    //     "Nails Saloon", "4", "288 Empola Street, NewYork"),
                  ],
                ),
              ],
            );
          }),
    );
  }

  Widget _myLocationText(
    BuildContext context,
    String text,
    int colorCode,
    double left,
    double top,
    double right,
    FontWeight fontWeight,
    double fontSize,
    String status,
  ) {
    return Container(
      margin: EdgeInsets.only(left: left, top: top, right: right),
      child: Text(
        text,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: FontWeight.w600,
            fontSize: fontSize),
      ),
    );
  }
}
