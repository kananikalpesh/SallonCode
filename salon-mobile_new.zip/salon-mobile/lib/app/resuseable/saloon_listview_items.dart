import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/data/model/customer/saloon-item-model.dart';
import 'package:saloon_app/app/resuseable/saloon_item_widget.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SaloonListViewItem extends StatelessWidget {
  //late DashboardItem dashboardItem ;
  //bool isPopular = true;
  SaloonItemsModel saloonItemsModel;
  static String SALOON_ID = '';
  SaloonListViewItem({required this.saloonItemsModel});
  //SaloonRowItem({required this.isHorizontal});

  @override
  Widget build(BuildContext context) {
    // var data = isPopular?dashboardItem.popular:dashboardItem.favorite;
    return Expanded(
      child: Container(
        margin: EdgeInsets.only(
          left: 20,
          right: 5,
        ),
        child:(saloonItemsModel.top?.isNotEmpty??false)? ListView.builder(
            //shrinkWrap: true,
            scrollDirection: Axis.vertical,
            itemCount:saloonItemsModel.top?.length,
            itemBuilder: (BuildContext context, int index) {
              //print('APIDATA${dashboardItem.popular}');
              return   SaloonItemWidget(
                  image: saloonItemsModel.top?[index].profilePic??"" ,
                  buttonText: "New",
                  saloonName: saloonItemsModel.top?[index].name??"",
                  rating:'${saloonItemsModel.top?[index].rating.toString()}',
                  address: saloonItemsModel.top?[index].address?.address??"",
                  saloonId: saloonItemsModel.top?[index].id??"" ,
                  days: "All Days",
                  distance: "12",
                  time:
                  "${saloonItemsModel.top?[index].openTime} - ${saloonItemsModel.top?[index].closeTime}");
            }):Center(child: Text('No Saloon Found'),),
      ),
    );
  }

  Widget _myLocationText(
      BuildContext context,
      String text,
      int colorCode,
      double left,
      double top,
      double right,
      FontWeight fontWeight,
      double fontSize) {
    return Container(
      margin: EdgeInsets.only(left: left, top: top, right: right),
      child: Text(
        text,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: FontWeight.w600,
            fontSize: fontSize),
      ),
    );
  }

  Widget _PopularItemView(
      BuildContext context,
      String? imageOne,
      String buttonText,
      String? bottomContainerRowValue1,
      String? bottomContainerRowValue2,
      String bottomContainerRowValue3,
      String? saloonId,
      String days,
      String distance,
      String time) {
    return GestureDetector(
      onTap: () {
        SALOON_ID = saloonId!;
        // Navigator.pushNamed(context, '/aboutSaloon');

        // Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomSheetReusable(value: "aboutSaloon")));
      },
      child: Container(
        margin: EdgeInsets.only(
            top: 15, right: SizeConfig.blockSizeHorizontal * .5),
        height: SizeConfig.screenHeight * .33,
        width: SizeConfig.screenWidth * .88,
        child: Stack(
          children: <Widget>[
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                height: 160,

                // width: ,
                child: ClipRRect(
                    borderRadius: new BorderRadius.circular(10.0),
                    child: Image.asset(
                      imageOne!,
                      fit: BoxFit.cover,
                      width: SizeConfig.screenWidth,
                      height: 160.0,
                    )
                    // CachedNetworkImage(
                    //   imageUrl: Constants.BASE_URL_IMAGE+'${imageOne}',
                    //   errorWidget: (context, url, error) => Icon(Icons.error),
                    //   fit: BoxFit.cover,width: SizeConfig.screenWidth, height: 160.0,
                    //   placeholder: (context, url) => Container(
                    //       height: 30,
                    //       width: 30,
                    //       child: Center(child: CircularProgressIndicator())),
                    // ),
                    // child : Image(fit: BoxFit.cover, image: cachedImage(imageOne), width: SizeConfig.screenWidth,  height: 160.0,),
                    ),
              ),
              // child: Image.asset(imageOne, fit: BoxFit.contain,),),
            ),
            Align(
                alignment: Alignment.topLeft,
                child: GestureDetector(
                  onTap: () {
                    // Navigator.pushNamed(context, '/verify');
                  },
                  child: Container(
                    width: 50,
                    margin: EdgeInsets.only(top: 0, left: 0, right: 0),
                    padding: EdgeInsets.symmetric(vertical: 5),
                    decoration: new BoxDecoration(
                      color: ColorsX.greenish,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                          topRight: Radius.circular(3)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(buttonText,
                            style: TextStyle(
                              fontSize: 12,
                              color: ColorsX.white,
                              fontWeight: FontWeight.w700,
                            )),
                      ],
                    ),
                  ),
                )),
            _containerStyling(
                bottomContainerRowValue1,
                4.0,
                14,
                FontWeight.w700,
                bottomContainerRowValue2,
                bottomContainerRowValue3,
                days,
                distance,
                time),
            // _containerStyling("4.0",4.0,14, FontWeight.w400),
          ],
        ),
      ),
    );
  }

  Widget _containerStyling(
      String? text,
      double rating,
      double fontSize,
      FontWeight fontWeight,
      String? ratings,
      String address,
      String days,
      String distance,
      String time) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        height: SizeConfig.blockSizeVertical * 13,
        margin: EdgeInsets.only(top: 150),
        decoration: BoxDecoration(
          color: ColorsX.white,
          border: Border.all(color: ColorsX.greyBackground, width: 2),
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(10),
              bottomRight: Radius.circular(10)),
        ), // _PopularRowItemOfText("Looks Unisex Saloon", 4.0, 14, FontWeight.w700),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              // height: 40,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _PopularRowItemOfText(text, fontSize, fontWeight),
                  Expanded(child: SizedBox()),
                  _starIcon(),
                  _PopularRowItemOfText(ratings, fontSize, FontWeight.w400),
                  SizedBox(
                    width: 5,
                  )
                ],
              ),
            ),
            // Container(
            //   height: 20,
            //   margin: EdgeInsets.only(left: 10),
            //   child: Text(
            //     '$bottomContainerRowValue3',
            //     style: TextStyle(
            //         color: ColorsX.subBlack,
            //         fontSize: 12,
            //         fontWeight: FontWeight.w400),
            //   ),
            // ),

            Container(
              //height: 40,
              //color: Colors.red,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Location_color_ic)),
                        _PopularRowItemOfText(address, fontSize, fontWeight),
                      ],
                    ),
                  ),
                  // Expanded(child: SizedBox()),
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Date_color_ic)),
                        _PopularRowItemOfText(days, fontSize, FontWeight.w400),
                      ],
                    ),
                  ),
                  // SizedBox(
                  //   width: 5,
                  // )
                ],
              ),
            ),
            Container(
              //height: 40,
              //color: Colors.red,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Distance_color_ic)),
                        _PopularRowItemOfText(
                            distance + "km away", fontSize, fontWeight),
                      ],
                    ),
                  ),
                  // Expanded(child: SizedBox()),
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Clock_color_ic)),
                        _PopularRowItemOfText(time, fontSize, FontWeight.w400),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _starIcon() {
    return Container(
      margin: EdgeInsets.only(top: 0),
      child: Icon(
        Icons.star,
        color: ColorsX.yellow,
      ),
    );
  }

  Widget _PopularRowItemOfText(
      String? text1, double fontSize, FontWeight fontWeight) {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: SizeConfig.marginVerticalXsmall,
          vertical: SizeConfig.marginVerticalXsmall),
      child: Text(
        '${text1}',
        style: TextStyle(
            color: ColorsX.subBlack,
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }
  // void cachedImage(String url){
  //   CachedNetworkImage(
  //     imageUrl: "http://via.placeholder.com/200x150",
  //     imageBuilder: (context, imageProvider) => Container(
  //       decoration: BoxDecoration(
  //         image: DecorationImage(
  //             image: imageProvider,
  //             fit: BoxFit.cover,
  //             colorFilter:
  //             ColorFilter.mode(Colors.red, BlendMode.colorBurn)),
  //       ),
  //     ),
  //     placeholder: (context, url) => CircularProgressIndicator(),
  //     errorWidget: (context, url, error) => Icon(Icons.error),
  //   );
  // }
}
