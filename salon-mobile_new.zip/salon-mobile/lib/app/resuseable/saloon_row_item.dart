import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/saloon-item-model.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/resuseable/saloon_item_widget.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SaloonRowItem extends GetView<DashboardItemController> {
  bool isHorizontal;
  SaloonItemsModel saloonItemsModel;
  static String SALOON_ID = '';

  SaloonRowItem({required this.isHorizontal, required this.saloonItemsModel});

  @override
  Widget build(BuildContext context) {
    // var data = isPopular?dashboardItem.popular:dashboardItem.favorite;
    return Container(
      height: SizeConfig.screenHeight * 0.36,
      //color: Colors.red,
      margin: EdgeInsets.only(
        left: 15,
        right: 15,
      ),
      child: ListView.builder(
          //shrinkWrap: true,
          scrollDirection: isHorizontal ? Axis.horizontal : Axis.vertical,
          itemCount: saloonItemsModel.top?.length,
          itemBuilder: (BuildContext context, int index) {
            //print('APIDATA${dashboardItem.popular}');


            return Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SaloonItemWidget(
                        image: saloonItemsModel.top?[index].profilePic??"",
                        buttonText: "New",
                        saloonName: saloonItemsModel.top?[index].name??"",
                        rating:'${
                            saloonItemsModel.top?[index].rating.toString()}' ,
                        address: '${saloonItemsModel.top?[index].address?.address??''}',
                        saloonId: saloonItemsModel.top?[index].id??"" ,
                        days: "All Days",
                        distance: "12",
                        time:
                            "${saloonItemsModel.top?[index].openTime??''} - ${saloonItemsModel.top?[index].closeTime??''}")
                  ],
                ),
              ],
            );
          }),
    );
  }
}
