import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class LeftList extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(top: 15, left: 10),
          height: 120,// SizeConfig.screenHeight,
          width: SizeConfig.screenWidth*.14,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _getImageOfIcon(context, AppImages.avatar, 0xff9aaec9),
              _getImageOfIcon(context, AppImages.home_dash, 0xff6917e5),
              // _getImageOfIcon(context, "assets/images/appoint_white.png", 0xff70b4ff),
              // _getImageOfIcon(context, "assets/images/cart.png", 0xff70b4ff),
              // _getImageOfIcon(context, "assets/images/group.png", 0xff70b4ff),
              // _getImageOfIcon(context, "assets/images/user_white.png", 0xff70b4ff),
              // _getImageOfIcon(context, "assets/images/disk.png", 0xff70b4ff),
              // _getImageOfIcon(context, "assets/images/chat.png", 0xff70b4ff),
              // _getImageOfIcon(context, "assets/images/bell_simple.png", 0xff70b4ff),
              // _getImageOfIcon(context, "assets/images/stop.png", 0xff70b4ff),
              // _getImageOfIcon(context, "assets/images/info.png", 0xff70b4ff),
              // _getImageOfIcon(context, "assets/images/back_logout.png", 0xff70b4ff),
            ],
          ),
        )
      ],
    );
  }
  Widget _getImageOfIcon(BuildContext context, String imagePath, int colorCode){
    return GestureDetector(
        onTap: (){
          if(imagePath==AppImages.disk) {
            Navigator.pushNamed(context, '/saloonRequestDetail');
          }
          else if(imagePath == AppImages.home_dash){
            Navigator.pushNamed(context, '/analyticsReports');
          }
          else
            // Navigator.pushNamed(context, '/allGraphs');
            Get.toNamed(Routes.all_graphs);
        },
        child: Container(
          height: 50,
          width: 50,
          decoration: new BoxDecoration(
            color: Color(colorCode),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          margin: EdgeInsets.only(top: 10),
          child: Stack(
            children: <Widget>[
              Center(
                child: Image.asset(imagePath),
              ),
              imagePath=="assets/images/avatar.png"?Align(
                alignment: Alignment.bottomRight,
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                  margin: EdgeInsets.only(left: 2, top: 2),
                  decoration: new BoxDecoration(
                    color: ColorsX.rating_dashboard,
                    borderRadius: BorderRadius.only(topLeft: Radius.circular(50)),
                  ),
                  child: _rowItemForHeaderText(" 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
                ),
              ):Container(),
            ],
          ),
        )
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
}