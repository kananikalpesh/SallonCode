import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/resuseable/saloon_row_item.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SaloonItemWidget extends GetView<DashboardItemController> {
  String image,
      buttonText,
      saloonName,
      rating,
      address,
      saloonId,
      days,
      distance,
      time;

  SaloonItemWidget(
      {required this.image,
      required this.buttonText,
      required this.saloonName,
      required this.rating,
      required this.saloonId,
      required this.address,
      required this.time,
      required this.days,
      required this.distance});

  @override
  Widget build(BuildContext context) {
    return _PopularItemView(context);
  }

  Widget _PopularItemView(BuildContext context) {
    return GestureDetector(
      onTap: () {
        SaloonRowItem.SALOON_ID = saloonId;
        // print(SALOON_ID);
        // Navigator.pushNamed(context, Routes.WELCOME_aboutSaloon);
        Get.toNamed(Routes.WELCOME_aboutSaloon);
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(builder: (context) => Saloon()),
        // );

        // Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomSheetReusable(value: "aboutSaloon")));
      },
      child: Container(
        margin: EdgeInsets.only(top: 15, right: 20),
        height: SizeConfig.screenHeight * .33,
        width: SizeConfig.eightyPercentWidth,
        child: Stack(
          children: <Widget>[
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                height: 160,
                // width: ,
                child: ClipRRect(
                  borderRadius: new BorderRadius.circular(10.0),
                  // child: Image.asset(
                  //   imageOne!,
                  //   fit: BoxFit.cover,
                  //   width: SizeConfig.screenWidth,
                  //   height: 160.0,
                  // )
                  child: CachedNetworkImage(
                    imageUrl: AppUrls.BASE_URL_IMAGE + '${image}',
                    errorWidget: (context, url, error) => Icon(Icons.error),
                    fit: BoxFit.none,
                    width: SizeConfig.screenWidth,
                    height: 160.0,
                    placeholder: (context, url) => Container(
                        height: 30,
                        width: 30,
                        child: Center(child: CircularProgressIndicator())),
                  ),
                ),
              ),
              // child: Image.asset(imageOne, fit: BoxFit.contain,),),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                height: 160,
                decoration: BoxDecoration(
                    color: Color(0xFF0E3311).withOpacity(0.4),
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(10))
                ),
              ),
            ),
            Align(
                alignment: Alignment.topLeft,
                child: GestureDetector(
                  onTap: () {
                    // Navigator.pushNamed(context, '/verify');
                  },
                  child: Container(
                    width: 50,
                    margin: EdgeInsets.only(top: 0, left: 0, right: 0),
                    padding: EdgeInsets.symmetric(vertical: 5),
                    decoration: new BoxDecoration(
                      color: ColorsX.blue_button_color,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                          topRight: Radius.circular(3)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(buttonText,
                            style: TextStyle(
                              fontSize: 12,
                              color: ColorsX.white,
                              fontWeight: FontWeight.w700,
                            )),
                      ],
                    ),
                  ),
                )
            ),
            Align(
                alignment: Alignment.topRight,
                child: GestureDetector(
                  onTap: () {
                    print("heart icon clicked" '${saloonId}');
                    controller.addFavouriteSaloons(id: '${saloonId}', context: context);
                    // Navigator.pushNamed(context, '/verify');
                  },
                  child: Container(
                    margin: EdgeInsets.only(right: 20,top: 20),
                    child: Image.asset("assets/images/heart.png", height: 30,width: 30,),
                  )
                )
            ),
            getstatus("OPEN"),
            _containerStyling(saloonName, 4.0, 11, FontWeight.w700, rating,
                address, days, distance, time),
            // _containerStyling("4.0",4.0,14, FontWeight.w400),
          ],
        ),
      ),
    );
  }

  Widget getstatus(String status) {
    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        margin: EdgeInsets.only(right: 20),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: status == "OPEN" ? Color(0xff00ff00) : Color(0xffff0000),
        ),
        child: Text(
          status,
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Color(0xffffffff)),
        ),
      ),
    );
  }

  Widget _containerStyling(
      String? text,
      double rating,
      double fontSize,
      FontWeight fontWeight,
      String? ratings,
      String? address,
      String days,
      String distance,
      String time) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        height: SizeConfig.blockSizeVertical * 13,
        margin: EdgeInsets.only(top: 150),
        decoration: BoxDecoration(
          color: ColorsX.white,
          border: Border.all(color: ColorsX.greyBackground, width: 2),
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(10),
              bottomRight: Radius.circular(10)),
        ),
        // _PopularRowItemOfText("Looks Unisex Saloon", 4.0, 14, FontWeight.w700),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              // height: 40,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(child: _PopularRowItemOfText(text, fontSize, fontWeight)),
                  _starIcon(),
                  _PopularRowItemOfText(ratings, fontSize, FontWeight.w400),
                  SizedBox(
                    width: 5,
                  )
                ],
              ),
            ),
            // Container(
            //   height: 20,
            //   margin: EdgeInsets.only(left: 10),
            //   child: Text(
            //     '$bottomContainerRowValue3',
            //     style: TextStyle(
            //         color: ColorsX.subBlack,
            //         fontSize: 12,
            //         fontWeight: FontWeight.w400),
            //   ),
            // ),

            Container(
              //height: 40,
              //color: Colors.red,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Location_color_ic)),
                        Expanded(child: _PopularRowItemOfText(address, fontSize, fontWeight)),
                      ],
                    ),
                  ),
                  // Expanded(child: SizedBox()),
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Date_color_ic)),
                        _PopularRowItemOfText(days, fontSize, FontWeight.w400),
                      ],
                    ),
                  ),
                  // SizedBox(
                  //   width: 5,
                  // )
                ],
              ),
            ),
            Container(
              //height: 40,
              //color: Colors.red,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Distance_color_ic)),
                        _PopularRowItemOfText(
                            // distance + "km away", fontSize, fontWeight),
                            "" + "", fontSize, fontWeight),
                      ],
                    ),
                  ),
                  // Expanded(child: SizedBox()),
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Clock_color_ic)),
                        _PopularRowItemOfText(time, fontSize, FontWeight.w400),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _starIcon() {
    return Container(
      margin: EdgeInsets.only(top: 0),
      child: Icon(
        Icons.star,
        color: ColorsX.yellow,
      ),
    );
  }

  Widget _PopularRowItemOfText(
      String? text1, double fontSize, FontWeight fontWeight) {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: SizeConfig.marginVerticalXsmall,
          vertical: SizeConfig.marginVerticalXsmall),
      child: Text(
        '${text1}',
        style: TextStyle(
            color: ColorsX.subBlack,
            fontWeight: fontWeight,
            fontSize: fontSize),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }
}
