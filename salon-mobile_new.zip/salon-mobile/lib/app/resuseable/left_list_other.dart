import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';
class LeftListOther extends StatefulWidget{
  @override
  _LeftListOthers createState() => _LeftListOthers();
}
class _LeftListOthers extends State<LeftListOther>{
  @override
  Widget build(BuildContext context) {

    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          margin: EdgeInsets.only( left: 10),
          // height: SizeConfig.screenHeight,
          width: SizeConfig.screenWidth*.14,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // _getImageOfIcon(context, "assets/images/avatar.png", 0xff9aaec9),
              // _getImageOfIcon(context, "assets/images/home_dash.png", 0xff6917e5),
              _getImageOfIcon(context, AppImages.appoint_white, 0xff70b4ff),
              _getImageOfIcon(context, AppImages.cart, 0xff70b4ff),
              _getImageOfIcon(context, AppImages.group, 0xff70b4ff),
              _getImageOfIcon(context, AppImages.user_white, 0xff70b4ff),
              _getImageOfIcon(context, AppImages.disk, 0xff70b4ff),
              _getImageOfIcon(context, AppImages.chat, 0xff70b4ff),
              _getImageOfIcon(context, AppImages.bell_simple, 0xff70b4ff),
              _getImageOfIcon(context, AppImages.stop, 0xff70b4ff),
              _getImageOfIcon(context, AppImages.info, 0xff70b4ff),
              _getImageOfIcon(context, AppImages.back_logout, 0xff70b4ff),
            ],
          ),
        )
      ],
    );
  }

  Widget _getImageOfIcon(BuildContext context, String imagePath, int colorCode){
    return GestureDetector(
        onTap: (){
          if(imagePath=="assets/images/disk.png") {
            // value = "disk";
            // Navigator.push(context, MaterialPageRoute(builder: (context) => Requests(imagePath: "assets/images/disk.png"),));
            Navigator.pushNamed(context, '/requests');
          }
          else if(imagePath=="assets/images/cart.png") {
            Navigator.pushNamed(context, '/products');
          }
          else if(imagePath=="assets/images/group.png") {
            Navigator.pushNamed(context, '/manageStaff');
          }
          else if(imagePath=="assets/images/stop.png") {
            Navigator.pushNamed(context, '/dealsOffers');
          }
          else if(imagePath=="assets/images/appoint_white.png") {
            Get.toNamed(Routes.caledar_settings);
            // Navigator.pushNamed(context, '/calenderSettings');
          }
          else if(imagePath=="assets/images/chat.png") {
            Get.toNamed(Routes.appointments);
            // Navigator.pushNamed(context, '/calenderSettings');
          }
          else if(imagePath=="assets/images/back_logout.png") {
            Navigator.pushNamed(context, '/calender');
          }
          else {
            // Navigator.pushNamed(context, '/allGraphs');
            Get.toNamed(Routes.all_graphs);
          }
        },
        child: Container(
          height: 50,
          width: 50,
          decoration: new BoxDecoration(
            color: Color(colorCode),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          margin: EdgeInsets.only(top: 10),
          child: Stack(
            children: <Widget>[
              Center(
                child: Image.asset(imagePath),
              ),
              // value=="disk"?Align(
              //   alignment: Alignment.bottomRight,
              //   child: Container(
              //     padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
              //     margin: EdgeInsets.only(left: 2, top: 2),
              //     decoration: new BoxDecoration(
              //       color: ColorsX.rating_dashboard,
              //       borderRadius: BorderRadius.only(topLeft: Radius.circular(50)),
              //     ),
              //     child: _rowItemForHeaderText(" 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
              //   ),
              // ):Container(),
            ],
          ),
        )
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
}

// class LeftListOther extends StatelessWidget{
//   @override
//   Widget build(BuildContext context) {
//
//     return Column(
//       mainAxisAlignment: MainAxisAlignment.start,
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: <Widget>[
//         Container(
//           margin: EdgeInsets.only(top: 135, left: 10),
//           // height: SizeConfig.screenHeight,
//           width: SizeConfig.screenWidth*.14,
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: <Widget>[
//               // _getImageOfIcon(context, "assets/images/avatar.png", 0xff9aaec9),
//               // _getImageOfIcon(context, "assets/images/home_dash.png", 0xff6917e5),
//               _getImageOfIcon(context, "assets/images/appoint_white.png", 0xff70b4ff),
//               _getImageOfIcon(context, "assets/images/cart.png", 0xff70b4ff),
//               _getImageOfIcon(context, "assets/images/group.png", 0xff70b4ff),
//               _getImageOfIcon(context, "assets/images/user_white.png", 0xff70b4ff),
//               _getImageOfIcon(context, "assets/images/disk.png", 0xff70b4ff),
//               _getImageOfIcon(context, "assets/images/chat.png", 0xff70b4ff),
//               _getImageOfIcon(context, "assets/images/bell_simple.png", 0xff70b4ff),
//               _getImageOfIcon(context, "assets/images/stop.png", 0xff70b4ff),
//               _getImageOfIcon(context, "assets/images/info.png", 0xff70b4ff),
//               _getImageOfIcon(context, "assets/images/back_logout.png", 0xff70b4ff),
//             ],
//           ),
//         )
//       ],
//     );
//   }
//   Widget _getImageOfIcon(BuildContext context, String imagePath, int colorCode){
//     return GestureDetector(
//         onTap: (){
//           if(imagePath=="assets/images/disk.png") {
//             Navigator.pushNamed(context, '/requests');
//           }
//           else if(imagePath=="assets/images/cart.png") {
//             Navigator.pushNamed(context, '/products');
//           }
//           else if(imagePath=="assets/images/group.png") {
//             Navigator.pushNamed(context, '/manageStaff');
//           }
//           else if(imagePath=="assets/images/stop.png") {
//             Navigator.pushNamed(context, '/dealsOffers');
//           }
//           else if(imagePath=="assets/images/appoint_white.png") {
//             Navigator.pushNamed(context, '/calenderSettings');
//           }
//           else if(imagePath=="assets/images/back_logout.png") {
//             Navigator.pushNamed(context, '/calender');
//           }
//           else {
//             Navigator.pushNamed(context, '/allGraphs');
//           }
//         },
//         child: Container(
//           height: 50,
//           width: 50,
//           decoration: new BoxDecoration(
//             color: Color(colorCode),
//             borderRadius: BorderRadius.all(Radius.circular(10)),
//           ),
//           margin: EdgeInsets.only(top: 10),
//           child: Stack(
//             children: <Widget>[
//               Center(
//                 child: Image.asset(imagePath),
//               ),
//               imagePath=="assets/images/avatar.png"?Align(
//                 alignment: Alignment.bottomRight,
//                 child: Container(
//                   padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
//                   margin: EdgeInsets.only(left: 2, top: 2),
//                   decoration: new BoxDecoration(
//                     color: ColorsX.rating_dashboard,
//                     borderRadius: BorderRadius.only(topLeft: Radius.circular(50)),
//                   ),
//                   child: _rowItemForHeaderText(" 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
//                 ),
//               ):Container(),
//             ],
//           ),
//         )
//     );
//   }
//   Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
//     return Container(
//       margin: EdgeInsets.only(top: top, left: left, right: right),
//       child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
//     );
//   }
// }