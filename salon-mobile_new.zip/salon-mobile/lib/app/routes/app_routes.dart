// ignore_for_file: constant_identifier_names

part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();

  //static const HOME = _Paths.HOME;
  static const SPLASH_SCREEN = _Paths.SPLASH_SCREEN;
  static const INTRO_SCREEN = _Paths.INTRO_SCREEN;
  static const CONNECT_WITH = _Paths.CONNECT_WITH;
  static const LOGIN_SCREEN = _Paths.LOGIN_SCREEN;
  static const FORGOT_PASSWORD_SCREEN = _Paths.FORGOT_PASSWORD_SCREEN;
  static const SIGNUP_SCREEN = _Paths.SIGNUP_SCREEN;
  static const OTP_SCREEN = _Paths.OTP_SCREEN;
  static const MAIN_CONTINUE_AS_SCREEN = _Paths.MAIN_CONTINUE_AS_SCREEN;
  static const SALOON_CONTINUE_AS_SCREEN = _Paths.SALOON_CONTINUE_AS_SCREEN;
  static const WELCOME_CUSTOMER_SCREEN = _Paths.WELCOME_CUSTOMER_SCREEN;
  static const WELCOME_aboutSaloon = _Paths.WELCOME_aboutSaloon;
  static const appointment_content_two = _Paths.appointment_content_two;
  static const all_graphs = _Paths.all_graphs;
  static const CHAT_DETAIL = _Paths.CHAT_DETAIL;
  static const CUSTOMER_FILTER = _Paths.CUSTOMER_FILTER;
  static const NOTIFICATION_SCREEN = _Paths.NOTIFICATION_SCREEN;
  static const BOOKING_DETAIL_FIRST = _Paths.BOOKING_DETAIL_FIRST;
  static const BOOKING_DETAIL_SECOND = _Paths.BOOKING_DETAIL_SECOND;
  static const PAYEMENT_METHODS = _Paths.PAYEMENT_METHODS;
  static const TRANSECTION_DETAIL = _Paths.TRANSECTION_DETAIL;
  static const TRANSECTION_LIST = _Paths.TRANSECTION_LIST;
  static const SELECT_SERVICES = _Paths.SELECT_SERVICES;
  static const caledar_settings = _Paths.caledar_settings;
  static const SELECT_ADD_ONS = _Paths.SELECT_ADD_ONS;
  static const VIEW_ALL_SALOONS_SCREEN = _Paths.VIEW_ALL_SALOONS_SCREEN;
  static const VIEW_ALL_OFFER_SCREEN = _Paths.VIEW_ALL_OFFER_SCREEN;


  //Admin Pages
  static const ADMIN_MAIN_DAISHBOARD = _Paths.ADMIN_MAIN_DAISHBOARD;
  static const STAFF_MAIN_DAISHBOARD = _Paths.STAFF_MAIN_DAISHBOARD;
  static const STAFF_ALL_BOOKING = _Paths.STAFF_ALL_BOOKING;
  static const STAFF_BOOKING_DETAILS = _Paths.STAFF_BOOKING_DETAILS;
  static const SIGNUP_SCREEN_ADMIN = _Paths.SIGNUP_SCREEN_ADMIN;
  static const LOGIN_SCREEN_ADMIN = _Paths.LOGIN_SCREEN_ADMIN;
  static const appointments = _Paths.appointments;
  static const saloon_request_detail = _Paths.saloon_request_detail;
  static const add_ons_screen = _Paths.add_ons_screen;
  static const add_ons_detail = _Paths.add_ons_detail;
  static const new_add_on = _Paths.new_add_on;
  static const my_profile = _Paths.my_profile;
  static const edit_my_profile = _Paths.edit_my_profile;
  static const choose_customer = _Paths.choose_customer;
  static const add_customer= _Paths.add_customer;
  static const AdminSelectServices= _Paths.AdminSelectServices;
  static const AdminSelectAddOns= _Paths.AdminSelectAddOns;
  static const AdminBookAppointmentTwo= _Paths.AdminBookAppointmentTwo;
  static const AdminBookingDetailsFirst= _Paths.AdminBookingDetailsFirst;
  static const AdminBookingDetailsSecond= _Paths.AdminBookingDetailsSecond;

  //staff pages
  static const StaffLogin= _Paths.StaffLogin;

}

abstract class _Paths {
  static const SPLASH_SCREEN = '/splash-screen';
  
  static const INTRO_SCREEN = '/intro-screen';
  static const CONNECT_WITH = '/connect-with';
  static const LOGIN_SCREEN = '/login-screen';
  static const VIEW_ALL_SALOONS_SCREEN = '/viewAllSaloon';
  static const VIEW_ALL_OFFER_SCREEN = '/viewAllOffer';
  static const FORGOT_PASSWORD_SCREEN = '/forgot-password-screen';
  static const SIGNUP_SCREEN = '/signup-screen';
  static const OTP_SCREEN = '/otp-screen';
  static const MAIN_CONTINUE_AS_SCREEN = '/main-continue-as-screen';
  static const SALOON_CONTINUE_AS_SCREEN = '/saloon-continue-as-screen';
  static const WELCOME_CUSTOMER_SCREEN = '/welcome-customer-screen';
  static const WELCOME_aboutSaloon = '/aboutSaloon';
  static const appointment_content_two = '/appointmentTwo';
  static const all_graphs = '/all-graphs';
  static const CHAT_DETAIL = '/chat-detail';
  static const CUSTOMER_FILTER = '/customer-filter';
  static const NOTIFICATION_SCREEN = '/notification-screen';
  static const BOOKING_DETAIL_FIRST = '/booking-detail-first';
  static const BOOKING_DETAIL_SECOND = '/booking-detail-second';
  static const PAYEMENT_METHODS = '/payement-methods';
  static const TRANSECTION_DETAIL = '/transection-detail';
  static const TRANSECTION_LIST = '/transection-list';
  static const SELECT_SERVICES = '/select-services';
  static const SELECT_ADD_ONS = '/select-add-ons';
  static const my_profile = '/my-profile';
  static const edit_my_profile = '/edit-my-profile';


  //Admin Pages
  static const LOGIN_SCREEN_ADMIN = '/login-screen-admin';
  static const SIGNUP_SCREEN_ADMIN = '/signup-screen-admin';
  static const ADMIN_MAIN_DAISHBOARD = '/admin-main-daishboard';
  static const STAFF_MAIN_DAISHBOARD = '/staff-main-daishboard';
  static const STAFF_ALL_BOOKING = '/staff-all-booking';
  static const STAFF_BOOKING_DETAILS = '/staff-booking_details';
  static const caledar_settings = '/caledar_settings';
  static const appointments = '/appointments';
  static const saloon_request_detail = '/saloon_request_detail';
  static const add_ons_screen = '/AddOnsScreen';
  static const add_ons_detail = '/AddOnDetail';
  static const new_add_on = '/NewAddOn';
  static const choose_customer = '/choose_customer';
  static const add_customer = '/add_customer';
  static const AdminSelectServices = '/AdminSelectServices';
  static const AdminSelectAddOns = '/AdminSelectAddOns';
  static const AdminBookAppointmentTwo = '/AdminBookAppointmentTwo';
  static const AdminBookingDetailsFirst = '/AdminBookingDetailsFirst';
  static const AdminBookingDetailsSecond = '/AdminBookingDetailsSecond';


  //Staff Login
  static const StaffLogin = '/StaffLogin';
}
