import 'dart:async';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/staff/staff_bookings.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/app_urls.dart';

class SaloonStaffApi {
  Future<dynamic> getStaffAllBookings() async {
    var res;
    int timeout = 40;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/getstaffallbookings'),
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('getstaffallbookings: ${response.statusCode}');
      print('getstaffallbookings: ${response.body}');
      if (response.statusCode == 200) {
        res = staffAllBookingFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }
}