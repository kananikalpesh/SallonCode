import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:async/async.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart';
import 'package:saloon_app/app/data/model/admin/add_ons/add_ons_by_category_res.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class AddOnApi {
  Future<dynamic> addNewAddOn(
      {required Map<String, String> apiParams,
      required List<File> image}) async {
    try {
      print('Sending Data : $apiParams');
      print('Sending Data : ${image.length}');
      print('Token ${AppStrings.tokenOfCurrentUser}');
      Map<String, String> headers = {
        HttpHeaders.authorizationHeader:
            "Bearer ${AppStrings.tokenOfCurrentUser}"
      }; // ignore this headers if there is no authentication
      // create multipart request
      var request = http.MultipartRequest(
          "POST", Uri.parse('${AppUrls.BASE_URL}/adminaddproduct'));

      var imageStream, imageLength, multipartFile;
      List imageList;
      String file_path;
      if(image.isNotEmpty) {

        imageStream =
            http.ByteStream(DelegatingStream.typed(image[0].openRead()));
        // get file length
        imageLength = await image[0].length();
        file_path = basename(image[0].path);
        // multipart that takes file
        multipartFile =
            http.MultipartFile('Profile_Pic', imageStream, imageLength,
                filename: file_path);
        request.files.add(multipartFile);

        for (File img in image) {
          imageStream =
              http.ByteStream(DelegatingStream.typed(img.openRead()));
          // get file length
          imageLength = await img.length();
          file_path = basename(img.path);
          // multipart that takes file
          multipartFile =
              http.MultipartFile('Photos', imageStream, imageLength,
                  filename: file_path);
          request.files.add(multipartFile);
        }
      }
      //imageFile is your image file

      request.headers.addAll(headers);
      request.fields.addAll(apiParams);
      //add headers
      // send
      var res = await http.Response.fromStream(
        await request.send().timeout(
              Duration(seconds: 120),
            ),
      );

      print('API RESPONSE ${res.statusCode}');
      print('API RESPONSE ${res.body}');

      if (res.statusCode == 200) {
        print("200 status code");
        print(res);
        return ExceptionCode.success;
      } else if (res.statusCode == 400) {
        print("401 status code");
        print(res.body);
        return errorResponseFromJson(res.body);
      }
    } on TimeoutException catch (e) {
      print(e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print(e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print(e);
      return ExceptionCode.error;
    }
  }

  Future<dynamic> getAddOnsByCategoryRes(
      {required int page, String catID = '', String search = ''}) async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getallproductsbycategory'),
        body: jsonEncode({'page': page, 'id': catID, 'Search': search}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          HttpHeaders.authorizationHeader:
              'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getallproductsbycategory: ${response.statusCode}');
      print('getallproductsbycategory: ${response.body}');
      if (response.statusCode == 200) {
        res = addOnsByCategoryResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> deleteAddOn(
      {required String pId,}) async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/deleteproduct'),
        body: {
          'id':pId
        },
        headers: <String, String>{
          HttpHeaders.authorizationHeader:
              'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('deleteproduct: ${response.statusCode}');
      print('deleteproduct: ${response.body}');
      if (response.statusCode == 200) {
       return ExceptionCode.success;
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }


  Future<dynamic> updateAddOn(
      {required Map<String, String> apiParams,
        required List<File> image}) async {
    try {
      print('updateAddOn Data : $apiParams');
      print('updateAddOn Data : ${image.length}');
      print('Token ${AppStrings.tokenOfCurrentUser}');
      Map<String, String> headers = {
        HttpHeaders.authorizationHeader:
        "Bearer ${AppStrings.tokenOfCurrentUser}"
      }; // ignore this headers if there is no authentication
      // create multipart request
      var request = http.MultipartRequest(
          "POST", Uri.parse('${AppUrls.BASE_URL}/updateproductdetail'));

      var imageStream, imageLength, multipartFile;
      List imageList;
      String file_path;
       if(image.isNotEmpty) {

         imageStream =
             http.ByteStream(DelegatingStream.typed(image[0].openRead()));
         // get file length
         imageLength = await image[0].length();
         file_path = basename(image[0].path);
         // multipart that takes file
         multipartFile =
             http.MultipartFile('Profile_Pic', imageStream, imageLength,
                 filename: file_path);
         request.files.add(multipartFile);

         for (File img in image) {
           imageStream =
               http.ByteStream(DelegatingStream.typed(img.openRead()));
           // get file length
           imageLength = await img.length();
           file_path = basename(img.path);
           // multipart that takes file
           multipartFile =
               http.MultipartFile('Photos', imageStream, imageLength,
                   filename: file_path);
           request.files.add(multipartFile);
         }
       }

      //imageFile is your image file

      request.headers.addAll(headers);
      request.fields.addAll(apiParams);
      //add headers
      // send
      var res = await http.Response.fromStream(
        await request.send().timeout(
          Duration(seconds: 120),
        ),
      );

      print('API RESPONSE ${res.statusCode}');
      print('API RESPONSE ${res.body}');

      if (res.statusCode == 200) {
        print("200 status code");
        print(res);
        return ExceptionCode.success;
      } else if (res.statusCode == 400) {
        print("401 status code");
        print(res.body);
        return errorResponseFromJson(res.body);
      }
    } on TimeoutException catch (e) {
      print(e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print(e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print(e);
      return ExceptionCode.error;
    }
  }

}
