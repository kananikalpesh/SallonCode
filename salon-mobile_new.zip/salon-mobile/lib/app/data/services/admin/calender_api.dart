import 'dart:async';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:saloon_app/app/data/model/admin/appointment/saloon_all_booking.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';


class CalenderApi{

  Future<dynamic> getConfirmedBookings() async {
    print('getConfirmedBookings: started...');
    var res;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/confirmedbookings'),
        headers: <String, String>{
          // 'Content-Type': 'application/json; charset=UTF-8',
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('confirmedbookings: ${response.statusCode}');
      print('confirmedbookings: ${response.body}');
      if (response.statusCode == 200) {
        res = saloonBookingResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }



}