import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:saloon_app/app/data/model/admin/appointment/saloon_all_booking.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'dart:io';

import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class SaloonAppointmentApi{
  Future<dynamic> getSaloonAllBookings(
      {required int page, String status = 'New'}) async {
    print('getCustomerallBookings: started...');

    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getSaloonAllBookings'),
        body: jsonEncode({'page': page, 'Status': status}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getCustomerallBookings: ${response.statusCode}');
      print('getCustomerallBookings: ${response.body}');
      if (response.statusCode == 200) {
        res = saloonBookingResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> cancelOrAcceptBooking(
      {required String id,required String status}) async {
    print('ADMIN TOKEN: ${AppStrings.tokenOfCurrentUser}');

    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/salooncancelbooking'),
        body: {'id': id, 'Status': status},
        headers: <String, String>{
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('cancelOrAcceptBooking: ${response.statusCode}');
      print('cancelOrAcceptBooking: ${response.body}');
      if (response.statusCode == 200) {
        res = ExceptionCode.success;
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }


}