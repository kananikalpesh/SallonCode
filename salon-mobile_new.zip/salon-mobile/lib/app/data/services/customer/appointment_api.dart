import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:saloon_app/app/data/model/customer/appointment/my_appointment.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class AppointmentApi {
  Future<dynamic> getAllAppointment(
      {required int page, String status = 'All'}) async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getCustomerallBookings'),
        body: jsonEncode({'page': page, 'Status': status}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getCustomerallBookings: ${response.statusCode}');
      print('getCustomerallBookings: ${response.body}');
      if (response.statusCode == 200) {
        res = myAppointmentFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(res);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print(res);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }


  Future<dynamic> cancelBooking(
      {required String id}) async {
    print('cancelbooking ID : ${id}');
    print('cancelbooking ID : ${AppStrings.tokenOfCurrentUser}');

    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/cancelbooking'),
        body: {
          'id':id
        },
        headers: <String, String>{
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('cancelbooking: ${response.statusCode}');
      print('cancelbooking: ${response.body}');
      if (response.statusCode == 200) {
        res = errorResponseFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }
}
