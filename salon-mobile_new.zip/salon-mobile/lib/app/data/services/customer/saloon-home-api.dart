import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:async/async.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart';
import 'package:saloon_app/app/data/model/admin/send-review.dart';
import 'package:saloon_app/app/data/model/customer/appointment/add-booking-via-staff.dart';
import 'package:saloon_app/app/data/model/customer/coupon-verify.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/filter_category_res.dart';
import 'package:saloon_app/app/data/model/customer/get-saloon-details-model.dart';
import 'package:saloon_app/app/data/model/customer/saloon-item-model.dart';
import 'package:saloon_app/app/data/model/customer/saloon/all_favorite_saloon.dart';
import 'package:saloon_app/app/data/model/customer/saloon/all_top_saloon.dart';
import 'package:saloon_app/app/data/model/customer/saloon/salon-by-category.dart';
import 'package:saloon_app/app/data/model/customer/saloon/staff-detail-model.dart';
import 'package:saloon_app/app/data/model/customer/special_offer.dart';
import 'package:saloon_app/app/data/model/customer/user-profile-edit.dart';
import 'package:saloon_app/app/data/model/customer/user-profile.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class HomeApi {
  Future<dynamic> saloonDashboardItem(String search) async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getDashboardItem'),
        body: {"Search": search},
        headers: {
          HttpHeaders.authorizationHeader:
              'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      // 1458
      print('DASHBOARD ITEM: ${response.statusCode}');
      print('DASHBOARD ITEM: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = saloonItemsModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/getDashboardItem");
      return res;
    } on TimeoutException catch (e) {
      return ('Slow Internet try again');
    } on SocketException {
      return ('No internet');
    } on Error catch (e) {
      return ('$e');
    }
  }
  Future<dynamic> addFavouriteSaloons({required String id}) async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/addfavouritesaloon'),
        body: {
          "Saloon_Id": id
        },
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      // 1458
      print('Favourite Saloon: ${response.statusCode}');
      print('Favourite Saloon: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = errorResponseFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/addfavouritesaloon");
      return res;
    } on TimeoutException catch (e) {
      return ('Slow Internet try again');
    } on SocketException {
      return ('No internet');
    } on Error catch (e) {
      return ('$e');
    }
  }

  Future<dynamic> getSpecificSaloonDetails(String saloon) async {
    print(saloon);
    var res;
    int timeout = 40;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/getsaloon/$saloon'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      ).timeout(Duration(seconds: timeout));
      print('getSpecificSaloonDetails: ${response.statusCode}');
      print('getSpecificSaloonDetails: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = saloonDetailsModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/getsaloon/$saloon");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getSpecificUserDetails() async {
    var res;
    int timeout = 40;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/getuserdetails'),
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('getSpecificSaloonDetails: ${response.statusCode}');
      print('getSpecificSaloonDetails: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = userProfileModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/getuserdetails");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> editSpecificUserDetails({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/updateuserdetails'),
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },body: (apiParams)
      ).timeout(Duration(seconds: timeout));
      print('getSpecificSaloonDetails: ${response.statusCode}');
      print('getSpecificSaloonDetails: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = editUserProfileModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/updateuserdetails");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> editSpecificUserDetailswithImages({required Map<String, String> apiParams, required var image}) async {
    try {

      print('Sending Data : $apiParams');
      print('Token ${AppStrings.tokenOfCurrentUser}');
      var stream = http.ByteStream(DelegatingStream.typed(image.openRead()));
      // get file length
      var length = await image.length(); //imageFile is your image file
      Map<String, String> headers = {
        HttpHeaders.authorizationHeader:
        "Bearer ${AppStrings.tokenOfCurrentUser}"
      }; // ignore this headers if there is no authentication
      // create multipart request
      var request = http.MultipartRequest("POST", Uri.parse('${AppUrls.BASE_URL}/updateuserdetails'));
      // multipart that takes file
      String file_path = basename(image.path);
      var multipartFileSign =
      http.MultipartFile('Profile_Pic', stream, length, filename: file_path);

      request.headers.addAll(headers);
      request.files.add(multipartFileSign);
      request.fields.addAll(apiParams);
      //add headers
      // send
      var res = await http.Response.fromStream(
        await request.send().timeout(
          Duration(seconds: 60),
        ),
      );

      print('API RESPONSE ${res.body}');

      if (res.statusCode == 200) {
        print("200 status code");
        print (res);
        return editUserProfileModelFromJson(res.body);
      } else if (res.statusCode == 401) {
        print("401 status code");
        print (res.body);
        return errorResponseFromJson(res.body);
      }

    } on TimeoutException catch (e) {
      print(e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print(e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print(e);
      return ExceptionCode.error;
    }
  }

  Future<dynamic> saloonAddBookingViaStaff({required Map<String, dynamic> apiParams, required BuildContext context}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(apiParams)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/addbooking'),
          headers: {
            HttpHeaders.authorizationHeader:
            'Bearer ${AppStrings.tokenOfCurrentUser}'
          },body: apiParams
      ).timeout(Duration(seconds: timeout));
      print('saloonAddBookingViaStaffResponse: ${response.statusCode}');
      print('saloonAddBookingViaStaffResponse: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = addBookingViaStaffFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/addbooking");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }


  Future<dynamic> verifyCoupon({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(apiParams)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/checkcoupon'),
          headers: {
            HttpHeaders.authorizationHeader:
            'Bearer ${AppStrings.tokenOfCurrentUser}'
          },body: apiParams
      ).timeout(Duration(seconds: timeout));
      print('checkcoupon: ${response.statusCode}');
      print('checkcoupon: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = couponVerificationResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/checkcoupon");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }



  Future<dynamic> sendReview({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(apiParams)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/addreview'),
          headers: {
            HttpHeaders.authorizationHeader:
            'Bearer ${AppStrings.tokenOfCurrentUser}'
          },body: (apiParams)
      ).timeout(Duration(seconds: timeout));
      print('addreview: ${response.statusCode}');
      print('addreview: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = sendReviewFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/addreview");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }


  Future<dynamic> saloonAddBookingViaAdmin({required Map<String, dynamic> apiParams, required BuildContext context}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(apiParams)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/adminaddbooking'),
          headers: {
            HttpHeaders.authorizationHeader:
            'Bearer ${AppStrings.tokenOfCurrentUser}'
          },body: apiParams
      ).timeout(Duration(seconds: timeout));
      print('saloonAddBookingViaStaffResponse: ${response.statusCode}');
      print('saloonAddBookingViaStaffResponse: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = addBookingViaStaffFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/addbooking");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getAllTopSaloon(int page) async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getalltopsaloons'),
        body: jsonEncode({'page': page}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getalltopsaloons: ${response.statusCode}');
      print('getalltopsaloons: ${response.body}');
      if (response.statusCode == 200) {
        res = topSaloonModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> getAllOffers(int page) async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getcoupons'),
        body: jsonEncode({'page': page}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getalltopsaloons: ${response.statusCode}');
      print('getalltopsaloons: ${response.body}');
      if (response.statusCode == 200) {
        res = specialOfferModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> getFavoriteSaloon(int page) async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getfavsaloons'),
        body: jsonEncode({'page': page}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          HttpHeaders.authorizationHeader:
              'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getalltopsaloons: ${response.statusCode}');
      print('getalltopsaloons: ${response.body}');
      if (response.statusCode == 200) {
        res = favoriteSaloonModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }





  Future<dynamic> getSalonsByCategory() async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getsaloonsbycategory'),
        body: jsonEncode({'category': AppStrings.categoryID}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          // HttpHeaders.authorizationHeader:
          // 'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getsaloonsbycategory: ${response.statusCode}');
      print('getsaloonsbycategory: ${response.body}');
      if (response.statusCode == 200) {
        res = saloonsByCategoryFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> getSpecificStaffDetails({required String date, required String id}) async {
    // print(staffId);
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/staffdetail'),
        body: {
          "id" : id,
          "date" : date
        },
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('getSpecificStaffDetails: ${response.statusCode}');
      print('getSpecificStaffDetails: ${response.body}');
      if (response.statusCode == 200) {
        // print(response.body.toString());
        res = staffDetailModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/staffdetail");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }


  Future<dynamic> getFilterCategories() async {
    var res;
    int timeout = 40;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/getcategories'),
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('getcategories: ${response.statusCode}');
      print('getcategories: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = filterCategoryResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getFilteredSaloon({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/saloonfilter'),
        body: jsonEncode(apiParams),
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      // 1458
      print('saloonfilter ITEM: ${response.statusCode}');
      print('saloonfilter ITEM: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = saloonItemsModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/getDashboardItem");
      return res;
    } on TimeoutException catch (e) {
      return ('Slow Internet try again');
    } on SocketException {
      return ('No internet');
    } on Error catch (e) {
      return ('$e');
    }
  }




// Future<dynamic> saloonReviewsItem(String saloon) async {
//   var res;
//   int timeout = 40;
//   try {
//     final response = await http.post(
//       Uri.parse('${Constants.BASE_URL}/getreviews'),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',},
//       body: jsonEncode(<String, String>{
//         "Saloon": saloon,
//       }),
//     ).timeout(Duration(seconds: timeout));
//     // 1458
//     print('REVIEW ITEM: ${response.statusCode}');
//     print('REVIEW ITEM: ${response.body.toString()}');
//     if (response.statusCode == 200) {
//       print(response.body.toString());
//       res = saloonReviewsItemFromJson(response.body);
//     } else {
//       res = errorMessageFromJson(response.body);
//     }
//
//     print("this is url ${Constants.BASE_URL}/getreviews");
//     return res;
//   } on TimeoutException catch (e) {
//     return ('Slow Internet try again');
//   } on SocketException {
//     return ('No internet');
//   } on Error catch (e) {
//     return ('$e');
//   }
// }
//
// Future<dynamic> getSaloonDetails(String saloon) async {
//   var res;
//   int timeout = 40;
//   try {
//     final response = await http.get(
//       Uri.parse('${Constants.BASE_URL}/getsaloon/$saloon'),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',},).timeout(
//         Duration(seconds: timeout));
//     // 1458
//     print('My DETAIL ITEM: ${response.statusCode}');
//     print('SALOON DETAIL ITEM: ${response.body}');
//     if (response.statusCode == 200) {
//       print('status code is 200');
//       res = getSaloonDetailsModelFromJson(response.body);
//     } else {
//       res = errorMessageFromJson(response.body);
//     }
//
//     print("this is url ${Constants.BASE_URL}/getsaloon/$saloon");
//     return res;
//   } on TimeoutException catch (e) {
//     return ('Slow Internet try again');
//   } on SocketException {
//     return ('No internet');
//   } on Error catch (e) {
//     return ('$e');
//   }
// }
//
// Future<dynamic> getSaloonByCategory(String categoryId) async {
//   var res;
//   int timeout = 40;
//   try {
//     final response = await http.post(
//       Uri.parse('${Constants.BASE_URL}/getsaloonsbycategory'),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',},
//       body: jsonEncode(<String, String>{
//         "category": categoryId,
//       }),
//     ).timeout(Duration(seconds: timeout));
//     // 1458
//     print('REVIEW ITEM: ${response.statusCode}');
//     print('REVIEW ITEM: ${response.body.toString()}');
//     if (response.statusCode == 200) {
//       print(response.body.toString());
//       res = allSaloonsByCategoryFromJson(response.body);
//     } else {
//       res = errorMessageFromJson(response.body);
//     }
//
//     print("this is url ${Constants.BASE_URL}/getsaloonsbycategory");
//     return res;
//   } on TimeoutException catch (e) {
//     return ('Slow Internet try again');
//   } on SocketException {
//     return ('No internet');
//   } on Error catch (e) {
//     return ('$e');
//   }
// }
//
// Future<dynamic> getProductItemDetail(String id) async {
//   var res;
//   int timeout = 40;
//   try {
//     final response = await http.post(
//       Uri.parse('${Constants.BASE_URL}/productdetail'),
//       headers: <String, String>{
//         'Content-Type': 'application/json; charset=UTF-8',},
//       body: jsonEncode(<String, String>{
//         "id": id,
//       }),
//     ).timeout(Duration(seconds: timeout));
//     // 1458
//     print('REVIEW ITEM: ${response.statusCode}');
//     print('REVIEW ITEM: ${response.body.toString()}');
//     if (response.statusCode == 200) {
//       print(response.body.toString());
//       res = productItemDetailFromJson(response.body);
//     } else {
//       res = errorMessageFromJson(response.body);
//     }
//
//     print("this is url ${Constants.BASE_URL}/productdetail");
//     return res;
//   } on TimeoutException catch (e) {
//     return ('Slow Internet try again');
//   } on SocketException {
//     return ('No internet');
//   } on Error catch (e) {
//     return ('$e');
//   }
}

