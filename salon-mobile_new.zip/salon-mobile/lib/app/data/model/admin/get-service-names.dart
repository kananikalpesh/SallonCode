// To parse this JSON data, do
//
//     final getServiceNames = getServiceNamesFromJson(jsonString);

import 'dart:convert';

GetServiceNames getServiceNamesFromJson(String str) => GetServiceNames.fromJson(json.decode(str));

String getServiceNamesToJson(GetServiceNames data) => json.encode(data.toJson());

class GetServiceNames {
  GetServiceNames({
    required this.data,
    required this.error,
  });

  List<Datum> data;
  bool error;

  factory GetServiceNames.fromJson(Map<String, dynamic> json) => GetServiceNames(
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    error: json["Error"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "Error": error,
  };
}

class Datum {
  Datum({
    required this.prefix,
    required this.profilePic,
    required this.status,
    required this.id,
    required this.saloon,
    required this.name,
    required this.category,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  String prefix;
  String profilePic;
  bool status;
  String id;
  String saloon;
  String name;
  String category;
  String description;
  String timeRequired;
  dynamic price;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    prefix: json["Prefix"],
    profilePic: json["Profile_pic"],
    status: json["Status"],
    id: json["_id"],
    saloon: json["Saloon"],
    name: json["Name"],
    category: json["Category"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "Prefix": prefix,
    "Profile_pic": profilePic,
    "Status": status,
    "_id": id,
    "Saloon": saloon,
    "Name": name,
    "Category": category,
    "Description": description,
    "Time_required": timeRequired,
    "Price": price,
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
  };
}
