// To parse this JSON data, do
//
//     final adminOtpVerifyResponse = adminOtpVerifyResponseFromJson(jsonString);

import 'dart:convert';

AdminOtpVerifyResponse adminOtpVerifyResponseFromJson(String str) => AdminOtpVerifyResponse.fromJson(json.decode(str));

String adminOtpVerifyResponseToJson(AdminOtpVerifyResponse data) => json.encode(data.toJson());

class AdminOtpVerifyResponse {
  AdminOtpVerifyResponse({
    required this.error,
    required this.data,
    required this.token,
  });

  bool error;
  Data data;
  String token;

  factory AdminOtpVerifyResponse.fromJson(Map<String, dynamic> json) => AdminOtpVerifyResponse(
    error: json["Error"],
    data: Data.fromJson(json["data"]),
    token: json["token"],
  );

  Map<String, dynamic> toJson() => {
    "Error": error,
    "data": data.toJson(),
    "token": token,
  };
}

class Data {
  Data({
    required this.profilePic,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.companyRegistrationNumber,
    required this.password,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.otp,
  });

  String profilePic;
  List<dynamic> photos;
  List<dynamic> services;
  int rating;
  int reviews;
  int bookingsLeft;
  int bookingsUsed;
  bool status;
  bool approved;
  String id;
  String name;
  String email;
  String mobileNumber;
  String companyRegistrationNumber;
  String password;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  int otp;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    profilePic: json["Profile_Pic"],
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    services: List<dynamic>.from(json["Services"].map((x) => x)),
    rating: json["Rating"],
    reviews: json["Reviews"],
    bookingsLeft: json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"],
    status: json["status"],
    approved: json["approved"],
    id: json["_id"],
    name: json["Name"],
    email: json["Email"],
    mobileNumber: json["Mobile_number"],
    companyRegistrationNumber: json["Company_Registration_Number"],
    password: json["Password"],
    registerDate: DateTime.parse(json["Register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    otp: json["otp"],
  );

  Map<String, dynamic> toJson() => {
    "Profile_Pic": profilePic,
    "Photos": List<dynamic>.from(photos.map((x) => x)),
    "Services": List<dynamic>.from(services.map((x) => x)),
    "Rating": rating,
    "Reviews": reviews,
    "Bookings_Left": bookingsLeft,
    "Bookings_Used": bookingsUsed,
    "status": status,
    "approved": approved,
    "_id": id,
    "Name": name,
    "Email": email,
    "Mobile_number": mobileNumber,
    "Company_Registration_Number": companyRegistrationNumber,
    "Password": password,
    "Register_date": registerDate.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
    "otp": otp,
  };
}
