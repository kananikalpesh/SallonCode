// To parse this JSON data, do
//
//     final getCategorizedServicesRes = getCategorizedServicesResFromJson(jsondynamic);

import 'dart:convert';

GetCategorizedServicesRes getCategorizedServicesResFromJson(dynamic str) => GetCategorizedServicesRes.fromJson(json.decode(str));

class GetCategorizedServicesRes {
  GetCategorizedServicesRes({
    required this.msg,
    required this.success,
    required this.result,
  });

  dynamic msg;
  bool success;
  List<Result> result;

  factory GetCategorizedServicesRes.fromJson(Map<dynamic, dynamic> json) => GetCategorizedServicesRes(
    msg: json["msg"],
    success: json["success"],
    result: List<Result>.from(json["result"].map((x) => Result.fromJson(x))),
  );

}

class Result {
  Result({
    required this.services,
    required this.category,
  });

  List<Service> services;
  Category category;

  factory Result.fromJson(Map<dynamic, dynamic> json) => Result(
    services: List<Service>.from(json["services"].map((x) => Service.fromJson(x))),
    category: Category.fromJson(json["Category"]),
  );

}

class Category {
  Category({
    required this.status,
    required this.id,
    required this.title,
    required this.description,
    required this.backgroundPic,
    required this.icon,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  bool status;
  dynamic id;
  dynamic title;
  dynamic description;
  dynamic backgroundPic;
  dynamic icon;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Category.fromJson(Map<dynamic, dynamic> json) => Category(
    status: json["status"],
    id: json["_id"],
    title: json["title"],
    description: json["description"],
    backgroundPic: json["Background_Pic"],
    icon: json["Icon"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}

class Service {
  Service({
    required this.prefix,
    required this.status,
    required this.id,
    required this.saloon,
    required this.name,
    required this.category,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.profilePic,
  });

  dynamic prefix;
  bool status;
  dynamic id;
  dynamic saloon;
  dynamic name;
  dynamic category;
  dynamic description;
  dynamic timeRequired;
  int price;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic profilePic;

  factory Service.fromJson(Map<dynamic, dynamic> json) => Service(
    prefix: json["Prefix"],
    status: json["Status"],
    id: json["_id"],
    saloon: json["Saloon"],
    name: json["Name"],
    category: json["Category"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    profilePic: json["Profile_pic"] == null ? null : json["Profile_pic"],
  );

}
