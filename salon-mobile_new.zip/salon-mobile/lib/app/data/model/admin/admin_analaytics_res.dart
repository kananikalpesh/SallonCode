// To parse this JSON data, do
//
//     final adminAnalayticsRes = adminAnalayticsResFromJson(jsonString?);

import 'dart:convert';

import 'package:saloon_app/app/data/model/admin/staff/salon_all_staff_res.dart';

import 'appointment/saloon_all_booking.dart';

AdminAnalyticsRes adminAnalyticsResFromJson(String str) =>
    AdminAnalyticsRes.fromJson(json.decode(str));

class AdminAnalyticsRes {
  AdminAnalyticsRes({
    this.error,
    this.bookings,
    this.staffs,
    this.staffcount,
    this.products,
    this.categories,
    this.totalclients,
    this.coupons,
    this.services,
    this.totalsales,
    this.appointments,
  });

  bool? error;
  int? bookings;
  List<Staff>? staffs;
  int? staffcount;
  int? products;
  int? categories;
  int? totalclients;
  int? coupons;
  int? services;
  List<Totalsale>? totalsales;
  List<Appointment>? appointments;

  factory AdminAnalyticsRes.fromJson(Map<String?, dynamic> json) =>
      AdminAnalyticsRes(
        error: json["Error"] == null ? null : json["Error"],
        bookings: json["bookings"] == null ? null : json["bookings"],
        staffs: json["staffs"] == null
            ? null
            : List<Staff>.from(json["staffs"].map((x) => Staff.fromJson(x))),
        staffcount: json["staffcount"] == null ? null : json["staffcount"],
        products: json["products"] == null ? null : json["products"],
        categories: json["categories"] == null ? null : json["categories"],
        totalclients:
            json["totalclients"] == null ? null : json["totalclients"],
        coupons: json["coupons"] == null ? null : json["coupons"],
        services: json["services"] == null ? null : json["services"],
        totalsales: json["totalsales"] == null
            ? null
            : List<Totalsale>.from(
                json["totalsales"].map((x) => Totalsale.fromJson(x))),
        appointments: json["appointments"] == null
            ? null
            : List<Appointment>.from(
                json["appointments"].map((x) => Appointment.fromJson(x))),
      );
}

class Appointment {
  Appointment({
    this.status,
    this.payment,
    this.paymentType,
    this.id,
    this.saloon,
    this.services,
    this.products,
    this.appointmentStaff,
    this.appointmentDate,
    this.appointmentUser,
    this.timeSlot,
    this.totalPrice,
    this.appointmentId,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  String? status;
  String? payment;
  String? paymentType;
  String? id;
  String? saloon;
  Services? services;
  List<ProductElement>? products;
  AppointmentStaff? appointmentStaff;
  dynamic? appointmentDate;
  AppointmentUser? appointmentUser;
  String? timeSlot;
  int? totalPrice;
  String? appointmentId;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  factory Appointment.fromJson(Map<String?, dynamic> json) => Appointment(
        status: json["Status"] == null ? null : json["Status"],
        payment: json["Payment"] == null ? null : json["Payment"],
        paymentType: json["Payment_Type"] == null ? null : json["Payment_Type"],
        id: json["_id"] == null ? null : json["_id"],
        saloon: json["Saloon"] == null ? null : json["Saloon"],
        services: json["Services"] == null
            ? null
            : Services.fromJson(json["Services"]),
        products: json["Products"] == null
            ? null
            : List<ProductElement>.from(
                json["Products"].map((x) => ProductElement.fromJson(x))),
        appointmentStaff: json["Staff"] == null
            ? null
            : AppointmentStaff.fromJson(json["Staff"]),
        appointmentDate: json["Appointment_Date"] == null
            ? null
            : DateTime?.parse(json["Appointment_Date"]),
        appointmentUser: json["User"] == null
            ? null
            : AppointmentUser.fromJson(json["User"]),
        timeSlot: json["Time_Slot"] == null ? null : json["Time_Slot"],
        totalPrice: json["Total_Price"] == null ? null : json["Total_Price"],
        appointmentId:
            json["Appointment_Id"] == null ? null : json["Appointment_Id"],
        createdAt: json["createdAt"] == null
            ? null
            : DateTime?.parse(json["createdAt"]),
        updatedAt: json["updatedAt"] == null
            ? null
            : DateTime?.parse(json["updatedAt"]),
        v: json["__v"] == null ? null : json["__v"],
      );
}

class Services {
  Services({
    this.prefix,
    this.profilePic,
    this.status,
    this.id,
    this.saloon,
    this.name,
    this.category,
    this.description,
    this.timeRequired,
    this.price,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  String? prefix;
  String? profilePic;
  bool? status;
  String? id;
  String? saloon;
  String? name;
  String? category;
  String? description;
  String? timeRequired;
  int? price;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  factory Services.fromJson(Map<String?, dynamic> json) => Services(
        prefix: json["Prefix"] == null ? null : json["Prefix"],
        profilePic: json["Profile_pic"] == null ? null : json["Profile_pic"],
        status: json["Status"] == null ? null : json["Status"],
        id: json["_id"] == null ? null : json["_id"],
        saloon: json["Saloon"] == null ? null : json["Saloon"],
        name: json["Name"] == null ? null : json["Name"],
        category: json["Category"] == null ? null : json["Category"],
        description: json["Description"] == null ? null : json["Description"],
        timeRequired:
            json["Time_required"] == null ? null : json["Time_required"],
        price: json["Price"] == null ? null : json["Price"],
        createdAt: json["createdAt"] == null
            ? null
            : DateTime?.parse(json["createdAt"]),
        updatedAt: json["updatedAt"] == null
            ? null
            : DateTime?.parse(json["updatedAt"]),
        v: json["__v"] == null ? null : json["__v"],
      );
}

class Staff {
  Staff({
    this.photos,
    this.rating,
    this.services,
    this.deleted,
    this.id,
    this.name,
    this.email,
    this.password,
    this.age,
    this.gender,
    this.designation,
    this.saloon,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.timeSlots,
  });

  List<String?>? photos;
  int? rating;
  List<String?>? services;
  bool? deleted;
  String? id;
  String? name;
  String? email;
  String? password;
  String? age;
  String? gender;
  String? designation;
  String? saloon;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  List<TimeSlot>? timeSlots;

  factory Staff.fromJson(Map<String?, dynamic> json) => Staff(
        photos: json["Photos"] == null
            ? null
            : List<String?>.from(json["Photos"].map((x) => x)),
        rating: json["Rating"] == null ? null : json["Rating"],
        services: json["Services"] == null
            ? null
            : List<String?>.from(json["Services"].map((x) => x)),
        deleted: json["Deleted"] == null ? null : json["Deleted"],
        id: json["_id"] == null ? null : json["_id"],
        name: json["Name"] == null ? null : json["Name"],
        email: json["Email"] == null ? null : json["Email"],
        password: json["Password"] == null ? null : json["Password"],
        age: json["Age"] == null ? null : json["Age"],
        gender: json["Gender"] == null ? null : json["Gender"],
        designation: json["Designation"] == null ? null : json["Designation"],
        saloon: json["Saloon"] == null ? null : json["Saloon"],
        createdAt: json["createdAt"] == null
            ? null
            : DateTime?.parse(json["createdAt"]),
        updatedAt: json["updatedAt"] == null
            ? null
            : DateTime?.parse(json["updatedAt"]),
        v: json["__v"] == null ? null : json["__v"],
        timeSlots: json["Time_Slots"] == null
            ? null
            : List<TimeSlot>.from(
                json["Time_Slots"].map((x) => TimeSlot.fromJson(x))),
      );
}

class AppointmentStaff {
  AppointmentStaff({
    this.name,
  });

  String? name;

  factory AppointmentStaff.fromJson(Map<String, dynamic> json) =>
      AppointmentStaff(
        name: json["Name"] == null ? null : json["Name"],
      );
}

class AppointmentUser {
  AppointmentUser({
    this.name,
  });

  String? name;

  factory AppointmentUser.fromJson(Map<String, dynamic> json) =>
      AppointmentUser(
        name: json["name"] == null ? null : json["name"],
      );
}

class Totalsale {
  Totalsale({
    this.totalAmount,
  });

  int? totalAmount;

  factory Totalsale.fromJson(Map<String?, dynamic> json) => Totalsale(
        totalAmount: json["TotalAmount"] == null ? null : json["TotalAmount"],
      );

  Map<String?, dynamic> toJson() => {
        "TotalAmount": totalAmount == null ? null : totalAmount,
      };
}
