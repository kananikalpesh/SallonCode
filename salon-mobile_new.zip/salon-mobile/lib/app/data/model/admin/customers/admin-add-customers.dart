// To parse this JSON data, do
//
//     final adminAddCustomersRes = adminAddCustomersResFromJson(jsonString);

import 'dart:convert';

AdminAddCustomersRes adminAddCustomersResFromJson(String str) => AdminAddCustomersRes.fromJson(json.decode(str));

String adminAddCustomersResToJson(AdminAddCustomersRes data) => json.encode(data.toJson());

class AdminAddCustomersRes {
  AdminAddCustomersRes({
    required this.error,
    required this.data,
    required this.msg,
  });

  bool error;
  Data data;
  String msg;

  factory AdminAddCustomersRes.fromJson(Map<String, dynamic> json) => AdminAddCustomersRes(
    error: json["Error"],
    data: Data.fromJson(json["data"]),
    msg: json["msg"],
  );

  Map<String, dynamic> toJson() => {
    "Error": error,
    "data": data.toJson(),
    "msg": msg,
  };
}

class Data {
  Data({
    required this.rating,
    required this.role,
    required this.favouriteProducts,
    required this.favouriteSaloons,
    required this.status,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.password,
    required this.v,
  });

  int rating;
  String role;
  List<dynamic> favouriteProducts;
  List<dynamic> favouriteSaloons;
  bool status;
  String id;
  String name;
  String email;
  String mobileNumber;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  String password;
  int v;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    rating: json["Rating"],
    role: json["role"],
    favouriteProducts: List<dynamic>.from(json["FavouriteProducts"].map((x) => x)),
    favouriteSaloons: List<dynamic>.from(json["FavouriteSaloons"].map((x) => x)),
    status: json["status"],
    id: json["_id"],
    name: json["name"],
    email: json["email"],
    mobileNumber: json["mobile_number"],
    registerDate: DateTime.parse(json["register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    password: json["password"],
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "Rating": rating,
    "role": role,
    "FavouriteProducts": List<dynamic>.from(favouriteProducts.map((x) => x)),
    "FavouriteSaloons": List<dynamic>.from(favouriteSaloons.map((x) => x)),
    "status": status,
    "_id": id,
    "name": name,
    "email": email,
    "mobile_number": mobileNumber,
    "register_date": registerDate.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "password": password,
    "__v": v,
  };
}
