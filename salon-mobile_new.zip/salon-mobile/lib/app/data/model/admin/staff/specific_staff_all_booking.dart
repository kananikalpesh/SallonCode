// To parse this JSON data, do
//
//     final specificStaffAllBookingRes = specificStaffAllBookingResFromJson(jsonString?);

import 'dart:convert';

SpecificStaffAllBookingRes specificStaffAllBookingResFromJson(String str) =>
    SpecificStaffAllBookingRes.fromJson(json.decode(str));

class SpecificStaffAllBookingRes {
  SpecificStaffAllBookingRes({
    this.error,
    this.data,
  });

  bool? error;
  List<Booking>? data;

  factory SpecificStaffAllBookingRes.fromJson(Map<String?, dynamic> json) =>
      SpecificStaffAllBookingRes(
        error: json["Error"] == null ? null : json["Error"],
        data: json["Data"] == null
            ? null
            : List<Booking>.from(json["Data"].map((x) => Booking.fromJson(x))),
      );
}

class Booking {
  Booking({
    this.status,
    this.payment,
    this.paymentType,
    this.id,
    this.saloon,
    this.services,
    this.products,
    this.staff,
    this.appointmentDate,
    this.timeSlot,
    this.totalPrice,
    this.appointmentId,
    this.user,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  String? status;
  String? payment;
  String? paymentType;
  String? id;
  String? saloon;
  Services? services;
  List<Product>? products;
  String? staff;
  DateTime? appointmentDate;
  String? timeSlot;
  int? totalPrice;
  String? appointmentId;
  User? user;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  factory Booking.fromJson(Map<String?, dynamic> json) => Booking(
        status: json["Status"] == null ? null : json["Status"],
        payment: json["Payment"] == null ? null : json["Payment"],
        paymentType: json["Payment_Type"] == null ? null : json["Payment_Type"],
        id: json["_id"] == null ? null : json["_id"],
        saloon: json["Saloon"] == null ? null : json["Saloon"],
        services: json["Services"] == null
            ? null
            : Services.fromJson(json["Services"]),
        products: json["Products"] == null
            ? null
            : List<Product>.from(
                json["Products"].map((x) => Product.fromJson(x))),
        staff: json["Staff"] == null ? null : json["Staff"],
        appointmentDate: json["Appointment_Date"] == null
            ? null
            : DateTime.parse(json["Appointment_Date"]),
        timeSlot: json["Time_Slot"] == null ? null : json["Time_Slot"],
        totalPrice: json["Total_Price"] == null ? null : json["Total_Price"],
        appointmentId:
            json["Appointment_Id"] == null ? null : json["Appointment_Id"],
        user: json["User"] == null ? null : User.fromJson(json["User"]),
        createdAt: json["createdAt"] == null
            ? null
            : DateTime.parse(json["createdAt"]),
        updatedAt: json["updatedAt"] == null
            ? null
            : DateTime.parse(json["updatedAt"]),
        v: json["__v"] == null ? null : json["__v"],
      );
}

class Product {
  Product({
    this.id,
    this.product,
    this.quantity,
  });

  String? id;
  String? product;
  int? quantity;

  factory Product.fromJson(Map<String?, dynamic> json) => Product(
        id: json["_id"] == null ? null : json["_id"],
        product: json["Product"] == null ? null : json["Product"],
        quantity: json["Quantity"] == null ? null : json["Quantity"],
      );

  Map<String?, dynamic> toJson() => {
        "_id": id == null ? null : id,
        "Product": product == null ? null : product,
        "Quantity": quantity == null ? null : quantity,
      };
}

class Services {
  Services({
    this.id,
    this.name,
  });

  String? id;
  String? name;

  factory Services.fromJson(Map<String?, dynamic> json) => Services(
        id: json["_id"] == null ? null : json["_id"],
        name: json["Name"] == null ? null : json["Name"],
      );
}

class User {
  User({
    this.id,
    this.name,
  });

  String? id;
  String? name;

  factory User.fromJson(Map<String?, dynamic> json) => User(
        id: json["_id"] == null ? null : json["_id"],
        name: json["name"] == null ? null : json["name"],
      );
}
