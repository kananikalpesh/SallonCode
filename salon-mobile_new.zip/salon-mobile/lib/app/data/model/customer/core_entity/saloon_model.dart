// To parse this JSON data, do
//
//     final saloonModel = saloonModelFromJson(jsonString);

import 'dart:convert';

SaloonModel saloonModelFromJson(String str) => SaloonModel.fromJson(json.decode(str));

String saloonModelToJson(SaloonModel data) => json.encode(data.toJson());

class SaloonModel {
  SaloonModel({
    this.address,
    this.profilePic,
    this.photos,
    this.services,
    this.rating,
    this.reviews,
    this.bookingsLeft,
    this.bookingsUsed,
    this.status,
    this.approved,
    this.id,
    this.name,
    this.email,
    this.mobileNumber,
    this.category,
    this.password,
    this.registerDate,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.aboutUs,
    this.description,
    this.businessType,
    this.closeTime,
    this.openTime,
  });

  Address? address;
  String? profilePic;
  List<String>? photos;
  List<String>? services;
  int? rating;
  int? reviews;
  int? bookingsLeft;
  int? bookingsUsed;
  bool? status;
  bool? approved;
  String? id;
  String? name;
  String? email;
  String? mobileNumber;
  String? category;
  String? password;
  DateTime? registerDate;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  String? aboutUs;
  String? description;
  String? businessType;
  String? closeTime;
  String? openTime;

  factory SaloonModel.fromJson(Map<String, dynamic> json) => SaloonModel(
    address: json["Address"] == null ? null : Address.fromJson(json["Address"]),
    profilePic: json["Profile_Pic"] == null ? null : json["Profile_Pic"],
    photos: json["Photos"] == null ? null : List<String>.from(json["Photos"].map((x) => x)),
    services: json["Services"] == null ? null : List<String>.from(json["Services"].map((x) => x)),
    rating: json["Rating"] == null ? null : json["Rating"],
    reviews: json["Reviews"] == null ? null : json["Reviews"],
    bookingsLeft: json["Bookings_Left"] == null ? null : json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"] == null ? null : json["Bookings_Used"],
    status: json["status"] == null ? null : json["status"],
    approved: json["approved"] == null ? null : json["approved"],
    id: json["_id"] == null ? null : json["_id"],
    name: json["Name"] == null ? null : json["Name"],
    email: json["Email"] == null ? null : json["Email"],
    mobileNumber: json["Mobile_number"] == null ? null : json["Mobile_number"],
    category: json["Category"] == null ? null : json["Category"],
    password: json["Password"] == null ? null : json["Password"],
    registerDate: json["Register_date"] == null ? null : DateTime.parse(json["Register_date"]),
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
    aboutUs: json["About_Us"] == null ? null : json["About_Us"],
    description: json["Description"] == null ? null : json["Description"],
    businessType: json["Business_Type"] == null ? null : json["Business_Type"],
    closeTime: json["Close_Time"] == null ? null : json["Close_Time"],
    openTime: json["Open_Time"] == null ? null : json["Open_Time"],
  );

  Map<String, dynamic> toJson() => {
    "Address": address == null ? null : address!.toJson(),
    "Profile_Pic": profilePic == null ? null : profilePic,
    "Photos": photos == null ? null : List<dynamic>.from(photos!.map((x) => x)),
    "Services": services == null ? null : List<dynamic>.from(services!.map((x) => x)),
    "Rating": rating == null ? null : rating,
    "Reviews": reviews == null ? null : reviews,
    "Bookings_Left": bookingsLeft == null ? null : bookingsLeft,
    "Bookings_Used": bookingsUsed == null ? null : bookingsUsed,
    "status": status == null ? null : status,
    "approved": approved == null ? null : approved,
    "_id": id == null ? null : id,
    "Name": name == null ? null : name,
    "Email": email == null ? null : email,
    "Mobile_number": mobileNumber == null ? null : mobileNumber,
    "Category": category == null ? null : category,
    "Password": password == null ? null : password,
    "Register_date": registerDate == null ? null : registerDate!.toIso8601String(),
    "createdAt": createdAt == null ? null : createdAt!.toIso8601String(),
    "updatedAt": updatedAt == null ? null : updatedAt!.toIso8601String(),
    "__v": v == null ? null : v,
    "About_Us": aboutUs == null ? null : aboutUs,
    "Description": description == null ? null : description,
    "Business_Type": businessType == null ? null : businessType,
    "Close_Time": closeTime == null ? null : closeTime,
    "Open_Time": openTime == null ? null : openTime,
  };
}

class Address {
  Address({
    this.type,
    this.coordinates,
    this.address,
    this.city,
    this.state,
  });

  String? type;
  List<double>? coordinates;
  String? address;
  String? city;
  String? state;

  factory Address.fromJson(Map<String, dynamic> json) => Address(
    type: json["type"] == null ? null : json["type"],
    coordinates: json["coordinates"] == null ? null : List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"] == null ? null : json["Address"],
    city: json["City"] == null ? null : json["City"],
    state: json["State"] == null ? null : json["State"],
  );

  Map<String, dynamic> toJson() => {
    "type": type == null ? null : type,
    "coordinates": coordinates == null ? null : List<dynamic>.from(coordinates!.map((x) => x)),
    "Address": address == null ? null : address,
    "City": city == null ? null : city,
    "State": state == null ? null : state,
  };
}
