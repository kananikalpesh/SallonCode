
import 'user_model.dart';
class Review {
  Review({
    required this.approved,
    required this.id,
    required this.saloon,
    required this.rating,
    required this.user,
    required this.description,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  bool approved;
  dynamic id;
  dynamic saloon;
  int rating;
  User user;
  dynamic description;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Review.fromJson(Map<dynamic, dynamic> json) => Review(
    approved: json["approved"],
    id: json["_id"],
    saloon: json["Saloon"],
    rating: json["Rating"],
    user: User.fromJson(json["User"]),
    description: json["Description"],
    date: DateTime.parse(json["date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<dynamic, dynamic> toJson() => {
    "approved": approved,
    "_id": id,
    "Saloon": saloon,
    "Rating": rating,
    "User": user.toJson(),
    "Description": description,
    "date": date,
    "createdAt": createdAt,
    "updatedAt": updatedAt,
    "__v": v,
  };
}