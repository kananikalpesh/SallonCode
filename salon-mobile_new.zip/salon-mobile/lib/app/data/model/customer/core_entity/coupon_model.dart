import 'service_model.dart';
class Coupon {
  Coupon({
    required this.price,
    required this.approved,
    required this.status,
    required this.id,
    required this.user,
    required this.saloon,
    required this.couponName,
    required this.minPrice,
    required this.percentage,
    required this.usage,
    required this.couponCode,
    required this.expiry,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.service,
    required this.startDate,
    required this.description,
    required this.endDate,
  });

  dynamic price;
  bool approved;
  dynamic status;
  dynamic id;
  List<dynamic>? user;
  dynamic saloon;
  dynamic couponName;
  dynamic minPrice;
  dynamic percentage;
  dynamic usage;
  dynamic couponCode;
  dynamic? expiry;
  DateTime? date;
  DateTime? createdAt;
  DateTime? updatedAt;
  dynamic v;
  SaloonService service;
  DateTime? startDate;
  dynamic description;
  DateTime? endDate;

  factory Coupon.fromJson(Map<dynamic, dynamic> json) => Coupon(
    price: json["Price"],
    approved: json["Approved"],
    status: json["Status"],
    id: json["_id"],
    user: json["User"] == null ? null : List<dynamic>.from(json["User"].map((x) => x)),
    saloon: json["Saloon"],
    couponName: json["Coupon_name"],
    minPrice: json["Min_Price"] == null ? null : json["Min_Price"],
    percentage: json["Percentage"],
    usage: json["Usage"] == null ? null : json["Usage"],
    couponCode: json["Coupon_code"],
    expiry:json["Expiry"],
    date: DateTime.parse(json["Date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    service: SaloonService.fromJson(json["Service"]),
    startDate: json["Start_Date"] == null ? null : DateTime.parse(json["Start_Date"]),
    description: json["Description"] == null ? null : json["Description"],
    endDate: json["End_Date"] == null ? null : DateTime.parse(json["End_Date"]),
  );

}

