
class Product {
  Product({
    required this.photos,
    required this.colors,
    required this.quantity,
    required this.quantitySold,
    required this.rating,
    required this.reviews,
    required this.approved,
    required this.deleted,
    required this.available,
    required this.id,
    required this.saloon,
    required this.name,
    required this.category,
    required this.description,
    required this.brandName,
    required this.price,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.profilePic,
  });

  List<dynamic> photos;
  List<dynamic> colors;
  int quantity;
  int quantitySold;
  int rating;
  int reviews;
  bool approved;
  bool deleted;
  bool available;
  dynamic id;
  dynamic saloon;
  dynamic name;
  dynamic category;
  dynamic description;
  dynamic brandName;
  int price;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic profilePic;

  factory Product.fromJson(Map<dynamic, dynamic> json) => Product(
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    colors: List<dynamic>.from(json["Colors"].map((x) => x)),
    quantity: json["Quantity"],
    quantitySold: json["Quantity_Sold"],
    rating: json["Rating"],
    reviews: json["Reviews"],
    approved: json["Approved"],
    deleted: json["Deleted"],
    available: json["Available"],
    id: json["_id"],
    saloon: json["Saloon"],
    name: json["Name"],
    category: json["Category"],
    description: json["Description"],
    brandName: json["BrandName"],
    price: json["Price"],
    date: DateTime.parse(json["date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    profilePic: json["Profile_Pic"],
  );

  Map<dynamic, dynamic> toJson() => {
    "Photos": List<dynamic>.from(photos.map((x) => x)),
    "Colors": List<dynamic>.from(colors.map((x) => x)),
    "Quantity": quantity,
    "Quantity_Sold": quantitySold,
    "Rating": rating,
    "Reviews": reviews,
    "Approved": approved,
    "Deleted": deleted,
    "Available": available,
    "_id": id,
    "Saloon": saloon,
    "Name": name,
    "Category": category,
    "Description": description,
    "BrandName": brandName,
    "Price": price,
    "date": date,
    "createdAt": createdAt,
    "updatedAt": updatedAt,
    "__v": v,
    "Profile_Pic": profilePic,
  };
}