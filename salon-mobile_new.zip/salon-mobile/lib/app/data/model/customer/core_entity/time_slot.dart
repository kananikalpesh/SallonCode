
class TimeSlot {
  TimeSlot({
    required this.day,
    required this.startTime,
    required this.endTime,
    required this.slotTime,
    required this.slotInterval,
  });

  dynamic day;
  dynamic startTime;
  dynamic endTime;
  dynamic slotTime;
  dynamic slotInterval;

  factory TimeSlot.fromJson(Map<dynamic, dynamic> json) => TimeSlot(
    day: json["day"],
    startTime: json["start_time"],
    endTime: json["end_time"],
    slotTime: json["slot_time"],
    slotInterval: json["slot_interval"],
  );

  Map<dynamic, dynamic> toJson() => {
    "day": day,
    "start_time": startTime,
    "end_time": endTime,
    "slot_time": slotTime,
    "slot_interval": slotInterval,
  };
}