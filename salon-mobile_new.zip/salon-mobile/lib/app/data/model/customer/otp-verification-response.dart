// To parse this JSON data, do
//
//     final otpVerificationResponse = otpVerificationResponseFromJson(jsonString);

import 'dart:convert';

OtpVerificationResponse otpVerificationResponseFromJson(String str) => OtpVerificationResponse.fromJson(json.decode(str));

String otpVerificationResponseToJson(OtpVerificationResponse data) => json.encode(data.toJson());

class OtpVerificationResponse {
  OtpVerificationResponse({
    required this.error,
    required this.data,
    required this.token,
  });

  bool error;
  Data data;
  String token;

  factory OtpVerificationResponse.fromJson(Map<String, dynamic> json) => OtpVerificationResponse(
    error: json["Error"],
    data: Data.fromJson(json["data"]),
    token: json["token"],
  );

  Map<String, dynamic> toJson() => {
    "Error": error,
    "data": data.toJson(),
    "token": token,
  };
}

class Data {
  Data({
    required this.role,
    required this.favouriteProducts,
    required this.status,
    required this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.mobileNumber,
    required this.dob,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.otp,
  });

  String role;
  List<dynamic> favouriteProducts;
  bool status;
  String id;
  String name;
  String email;
  String password;
  String mobileNumber;
  String dob;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  int otp;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    role: json["role"],
    favouriteProducts: List<dynamic>.from(json["FavouriteProducts"].map((x) => x)),
    status: json["status"],
    id: json["_id"],
    name: json["name"],
    email: json["email"],
    password: json["password"],
    mobileNumber: json["mobile_number"],
    dob: json["DOB"],
    registerDate: DateTime.parse(json["register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    otp: json["otp"],
  );

  Map<String, dynamic> toJson() => {
    "role": role,
    "FavouriteProducts": List<dynamic>.from(favouriteProducts.map((x) => x)),
    "status": status,
    "_id": id,
    "name": name,
    "email": email,
    "password": password,
    "mobile_number": mobileNumber,
    "DOB": dob,
    "register_date": registerDate.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
    "otp": otp,
  };
}
