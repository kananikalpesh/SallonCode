// To parse this JSON data, do
//
//     final topSaloonModel = topSaloonModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

import 'package:saloon_app/app/data/model/customer/core_entity/saloon_model.dart';

TopSaloonModel topSaloonModelFromJson(String str) => TopSaloonModel.fromJson(json.decode(str));

String topSaloonModelToJson(TopSaloonModel data) => json.encode(data.toJson());

class TopSaloonModel {
  TopSaloonModel({
    required this.msg,
    required this.error,
    required this.top,
  });

  String msg;
  bool error;
  List<SaloonModel> top;

  factory TopSaloonModel.fromJson(Map<String, dynamic> json) => TopSaloonModel(
    msg: json["Msg"],
    error: json["Error"],
    top: List<SaloonModel>.from(json["Top"].map((x) => SaloonModel.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Msg": msg,
    "Error": error,
    "Top": List<dynamic>.from(top.map((x) => x.toJson())),
  };
}


class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });

  String type;
  List<double> coordinates;
  String address;
  String city;
  String state;

  factory Address.fromJson(Map<String, dynamic> json) => Address(
    type: json["type"],
    coordinates: List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"],
    city: json["City"],
    state: json["State"],
  );

  Map<String, dynamic> toJson() => {
    "type": type,
    "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
    "Address": address,
    "City": city,
    "State": state,
  };
}
