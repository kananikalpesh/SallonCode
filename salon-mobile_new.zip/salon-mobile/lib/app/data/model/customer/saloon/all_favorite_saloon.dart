// To parse this JSON data, do
//
//     final favoriteSaloonModel = favoriteSaloonModelFromJson(jsonString);

import 'dart:convert';

import 'package:saloon_app/app/data/model/customer/core_entity/saloon_model.dart';

FavoriteSaloonModel favoriteSaloonModelFromJson(String str) =>
    FavoriteSaloonModel.fromJson(json.decode(str));

String favoriteSaloonModelToJson(FavoriteSaloonModel data) =>
    json.encode(data.toJson());

class FavoriteSaloonModel {
  FavoriteSaloonModel({
    required this.error,
    required this.data,
  });

  bool error;
  List<SaloonModel> data;

  factory FavoriteSaloonModel.fromJson(Map<String, dynamic> json) =>
      FavoriteSaloonModel(
        error: json["Error"],
        data: List<SaloonModel>.from(
            json["Data"].map((x) => SaloonModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Error": error,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}
