// To parse this JSON data, do
//
//     final loginResponse = loginResponseFromJson(jsonString);

import 'dart:convert';

LoginResponse loginResponseFromJson(String str) => LoginResponse.fromJson(json.decode(str));

String loginResponseToJson(LoginResponse data) => json.encode(data.toJson());

class LoginResponse {
  LoginResponse({
    required this.error,
    required this.msg,
    required this.status,
    required this.token,
    required this.user,
  });

  bool? error;
  String? msg;
  bool? status;
  String? token;
  User? user;

  factory LoginResponse.fromJson(Map<String, dynamic> json) => LoginResponse(
    error: json["Error"],
    msg: json["msg"],
    status: json["status"],
    token: json["token"],
    user: User.fromJson(json["user"]),
  );

  Map<String, dynamic> toJson() => {
    "Error": error,
    "msg": msg,
    "status": status,
    "token": token,
    "user": user?.toJson(),
  };
}

class User {
  User({
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
  });

  String id;
  String name;
  String email;
  String mobileNumber;

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    mobileNumber: json["mobile_number"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "mobile_number": mobileNumber,
  };
}
