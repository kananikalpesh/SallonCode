// To parse this JSON data, do
//
//     final couponVerificationRes = couponVerificationResFromJson(jsonString);

import 'dart:convert';

CouponVerificationRes couponVerificationResFromJson(String str) => CouponVerificationRes.fromJson(json.decode(str));

String couponVerificationResToJson(CouponVerificationRes data) => json.encode(data.toJson());

class CouponVerificationRes {
  CouponVerificationRes({
    required this.msg,
    required this.error,
    required this.data,
  });

  String msg;
  bool error;
  Data data;

  factory CouponVerificationRes.fromJson(Map<String, dynamic> json) => CouponVerificationRes(
    msg: json["msg"],
    error: json["Error"],
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "msg": msg,
    "Error": error,
    "Data": data.toJson(),
  };
}

class Data {
  Data({
    required this.price,
    required this.approved,
    required this.status,
    required this.id,
    required this.couponName,
    required this.startDate,
    required this.percentage,
    required this.description,
    required this.service,
    required this.endDate,
    required this.category,
    required this.couponCode,
    required this.saloon,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  int price;
  bool approved;
  String status;
  String id;
  String couponName;
  DateTime startDate;
  int percentage;
  String description;
  String service;
  DateTime endDate;
  String category;
  String couponCode;
  String saloon;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    price: json["Price"],
    approved: json["Approved"],
    status: json["Status"],
    id: json["_id"],
    couponName: json["Coupon_name"],
    startDate: DateTime.parse(json["Start_Date"]),
    percentage: json["Percentage"],
    description: json["Description"],
    service: json["Service"],
    endDate: DateTime.parse(json["End_Date"]),
    category: json["Category"],
    couponCode: json["Coupon_code"],
    saloon: json["Saloon"],
    date: DateTime.parse(json["Date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "Price": price,
    "Approved": approved,
    "Status": status,
    "_id": id,
    "Coupon_name": couponName,
    "Start_Date": "${startDate.year.toString().padLeft(4, '0')}-${startDate.month.toString().padLeft(2, '0')}-${startDate.day.toString().padLeft(2, '0')}",
    "Percentage": percentage,
    "Description": description,
    "Service": service,
    "End_Date": "${endDate.year.toString().padLeft(4, '0')}-${endDate.month.toString().padLeft(2, '0')}-${endDate.day.toString().padLeft(2, '0')}",
    "Category": category,
    "Coupon_code": couponCode,
    "Saloon": saloon,
    "Date": date.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
  };
}
