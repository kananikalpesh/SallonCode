// To parse this JSON data, do
//
//     final specialOfferModel = specialOfferModelFromJson(jsondynamic);

import 'dart:convert';

SpecialOfferModel specialOfferModelFromJson(dynamic str) => SpecialOfferModel.fromJson(json.decode(str));

class SpecialOfferModel {
  SpecialOfferModel({
    required this.error,
    required this.data,
  });

  bool error;
  List<Datum> data;

  factory SpecialOfferModel.fromJson(Map<dynamic, dynamic> json) => SpecialOfferModel(
    error: json["Error"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );
}

class Datum {
  Datum({
    required this.price,
    required this.approved,
    required this.status,
    required this.id,
    required this.couponName,
    required this.startDate,
    required this.service,
    required this.endDate,
    required this.minPrice,
    required this.percentage,
    required this.couponCode,
    required this.description,
    required this.saloon,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  dynamic price;
  bool approved;
  dynamic status;
  dynamic id;
  dynamic couponName;
  DateTime startDate;
  Service service;
  dynamic endDate;
  dynamic minPrice;
  dynamic percentage;
  dynamic couponCode;
  dynamic description;
  Saloon saloon;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Datum.fromJson(Map<dynamic, dynamic> json) => Datum(
    price: json["Price"],
    approved: json["Approved"],
    status: json["Status"],
    id: json["_id"],
    couponName: json["Coupon_name"],
    startDate: DateTime.parse(json["Start_Date"]),
    service: Service.fromJson(json["Service"]),
    endDate: json["End_Date"],
    minPrice: json["Min_Price"],
    percentage: json["Percentage"],
    couponCode: json["Coupon_code"],
    description: json["Description"],
    saloon: Saloon.fromJson(json["Saloon"]),
    date: DateTime.parse(json["Date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}

class Saloon {
  Saloon({
    required this.address,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.profilePic,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
  });

  Address address;
  List<dynamic> photos;
  List<dynamic> services;
  dynamic rating;
  dynamic reviews;
  dynamic bookingsLeft;
  dynamic bookingsUsed;
  bool status;
  bool approved;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic mobileNumber;
  dynamic category;
  dynamic password;
  dynamic profilePic;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic aboutUs;
  dynamic description;
  dynamic businessType;
  dynamic closeTime;
  dynamic openTime;

  factory Saloon.fromJson(Map<dynamic, dynamic> json) => Saloon(
    address: Address.fromJson(json["Address"]),
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    services: List<dynamic>.from(json["Services"].map((x) => x)),
    rating: json["Rating"],
    reviews: json["Reviews"],
    bookingsLeft: json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"],
    status: json["status"],
    approved: json["approved"],
    id: json["_id"],
    name: json["Name"],
    email: json["Email"],
    mobileNumber: json["Mobile_number"],
    category: json["Category"],
    password: json["Password"],
    profilePic: json["Profile_Pic"],
    registerDate: DateTime.parse(json["Register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    aboutUs: json["About_Us"],
    description: json["Description"],
    businessType: json["Business_Type"],
    closeTime: json["Close_Time"],
    openTime: json["Open_Time"],
  );

}

class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });

  dynamic type;
  List<double> coordinates;
  dynamic address;
  dynamic city;
  dynamic state;

  factory Address.fromJson(Map<dynamic, dynamic> json) => Address(
    type: json["type"],
    coordinates: List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"],
    city: json["City"],
    state: json["State"],
  );

  Map<dynamic, dynamic> toJson() => {
    "type": type,
    "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
    "Address": address,
    "City": city,
    "State": state,
  };
}

class Service {
  Service({
    required this.prefix,
    required this.status,
    required this.id,
    required this.name,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.profilePic,
  });

  dynamic prefix;
  bool status;
  dynamic id;
  dynamic name;
  dynamic description;
  dynamic timeRequired;
  int price;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic profilePic;

  factory Service.fromJson(Map<dynamic, dynamic> json) => Service(
    prefix: json["Prefix"],
    status: json["Status"],
    id: json["_id"],
    name: json["Name"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    profilePic: json["Profile_pic"],
  );

}
