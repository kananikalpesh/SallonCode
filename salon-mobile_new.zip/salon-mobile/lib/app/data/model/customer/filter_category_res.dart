// To parse this JSON data, do
//
//     final filterCategoryRes = filterCategoryResFromJson(jsondynamic);

import 'dart:convert';

import 'package:get/get_rx/src/rx_types/rx_types.dart';

FilterCategoryRes filterCategoryResFromJson(dynamic str) => FilterCategoryRes.fromJson(json.decode(str));

class FilterCategoryRes {
  FilterCategoryRes({
    required this.categories,
    required this.services,
    required this.error,
  });

  List<Category> categories;
  List<Service> services;
  bool error;

  factory FilterCategoryRes.fromJson(Map<dynamic, dynamic> json) => FilterCategoryRes(
    categories: List<Category>.from(json["categories"].map((x) => Category.fromJson(x))),
    services: List<Service>.from(json["services"].map((x) => Service.fromJson(x))),
    error: json["Error"],
  );

}

class Category {
  Category({
    required this.status,
    required this.id,
    required this.title,
    required this.description,
    required this.backgroundPic,
    required this.icon,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  bool status;
  RxBool isSelected=false.obs;
  dynamic id;
  dynamic title;
  dynamic description;
  dynamic backgroundPic;
  dynamic icon;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;

  factory Category.fromJson(Map<dynamic, dynamic> json) => Category(
    status: json["status"],
    id: json["_id"],
    title: json["title"],
    description: json["description"],
    backgroundPic: json["Background_Pic"],
    icon: json["Icon"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}

class Service {
  Service({
    required this.prefix,
    required this.status,
    required this.id,
    required this.name,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.profilePic,
  });

  dynamic prefix;
  bool status;
  dynamic id;
  dynamic name;
  dynamic description;
  dynamic timeRequired;
  dynamic price;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;
  dynamic profilePic;

  factory Service.fromJson(Map<dynamic, dynamic> json) => Service(
    prefix: json["Prefix"],
    status: json["Status"],
    id: json["_id"],
    name: json["Name"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    profilePic: json["Profile_pic"],
  );

}
