// To parse this JSON data, do
//
//     final saloonItemsModel = saloonItemsModelFromJson(jsondynamic);

import 'dart:convert';

import 'package:get/get.dart';

SaloonItemsModel saloonItemsModelFromJson(dynamic str) =>
    SaloonItemsModel.fromJson(json.decode(str));

class SaloonItemsModel {
  SaloonItemsModel({
    this.error,
    this.popular,
    this.favorite,
    this.top,
    this.deals,
    this.categories,
  });

  bool? error;
  List<Popular>? popular;
  List<Favorite>? favorite;
  List<Popular>? top;
  List<Deal>? deals;
  List<Category>? categories;

  factory SaloonItemsModel.fromJson(Map<dynamic, dynamic> json) =>
      SaloonItemsModel(
        error: json["Error"]==null?null:json["Error"],
        popular: json["Popular"] == null
            ? null
            : List<Popular>.from(
                json["Popular"].map((x) => Popular.fromJson(x))),
        favorite: json["Favorite"] == null
            ? null
            : List<Favorite>.from(
                json["Favorite"].map((x) => Favorite.fromJson(x))),
        top: json["Top"] == null
            ? null
            : List<Popular>.from(json["Top"].map((x) => Popular.fromJson(x))),
        deals: json["Deals"] == null
            ? null
            : List<Deal>.from(json["Deals"].map((x) => Deal.fromJson(x))),
        categories: json["Categories"] == null
            ? null
            : List<Category>.from(
                json["Categories"].map((x) => Category.fromJson(x))),
      );
}

class Category {
  Category({
    this.id,
    this.title,
    this.backgroundPic,
    this.icon,
  });

  String? id;
  String? title;
  String? backgroundPic;
  String? icon;
  RxBool isSelected = false.obs;

  factory Category.fromJson(Map<dynamic, dynamic> json) => Category(
        id: json["_id"],
        title: json["title"],
        backgroundPic: json["Background_Pic"],
        icon: json["Icon"],
      );

  Map<dynamic, dynamic> toJson() => {
        "_id": id,
        "title": title,
        "Background_Pic": backgroundPic,
        "Icon": icon,
      };
}

class Deal {
  Deal({
    this.price,
    this.approved,
    this.status,
    this.id,
    this.user,
    this.saloon,
    this.couponName,
    this.minPrice,
    this.percentage,
    this.usage,
    this.couponCode,
    this.expiry,
    this.date,
    this.createdAt,
    this.updatedAt,
    this.service,
    this.startDate,
    this.description,
    this.endDate,
  });

  int? price;
  bool? approved;
  String? status;
  String? id;
  List<dynamic>? user;
  String? saloon;
  String? couponName;
  int? minPrice;
  int? percentage;
  String? usage;
  String? couponCode;
  String? expiry;
  String? date;
  String? createdAt;
  String? updatedAt;
  Service? service;
  String? startDate;
  String? description;
  String? endDate;

  factory Deal.fromJson(Map<dynamic, dynamic> json) => Deal(
        price: json["Price"],
        approved: json["Approved"],
        status: json["Status"],
        id: json["_id"],
        user: json["User"] == null
            ? null
            : List<dynamic>.from(json["User"].map((x) => x)),
        saloon: json["Saloon"],
        couponName: json["Coupon_name"],
        minPrice: json["Min_Price"] == null ? null : json["Min_Price"],
        percentage: json["Percentage"],
        usage: json["Usage"] == null ? null : json["Usage"],
        couponCode: json["Coupon_code"],
        expiry: json["Expiry"] == null ? null : json["Expiry"],
        date: json["Date"] != null ? json["Date"] : "",
        createdAt: json["createdAt"] !=null ? json["createdAt"] : "",
        updatedAt: json["updatedAt"] !=null ? json["updatedAt"] : "",
        service: json["Service"] != null ? Service.fromJson(json["Service"]) : null,
        startDate: json["Start_Date"] == null
            ? null
            : json["Start_Date"],
        description: json["Description"] == null ? null : json["Description"],
        endDate:
            json["End_Date"] == null ? null : json["End_Date"],
      );
}

class Service {
  Service({
    this.prefix,
    this.status,
    this.id,
    this.name,
    this.description,
    this.timeRequired,
    this.price,
    this.createdAt,
    this.updatedAt,
    this.packageImage,
  });

  String? prefix;
  bool? status;
  String? id;
  String? name;
  String? description;
  String? timeRequired;
  int? price;
  String? createdAt;
  String? updatedAt;
  String? packageImage;

  factory Service.fromJson(Map<dynamic, dynamic> json) => Service(
        prefix: json["Prefix"],
        status: json["Status"],
        id: json["_id"],
        name: json["Name"],
        description: json["Description"],
        timeRequired: json["Time_required"],
        price: json["Price"],
        createdAt: json["createdAt"] != null ? json["createdAt"] : "",
        updatedAt: json["updatedAt"] !=null ? json["updatedAt"] : "",
        packageImage: json["package_image"] !=null ? json["package_image"] :"",
      );
}

class Favorite {
  Favorite({
    required this.address,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.profilePic,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
  });

  Address? address;
  List<dynamic> photos;
  List<dynamic> services;
  dynamic rating;
  dynamic reviews;
  dynamic bookingsLeft;
  dynamic bookingsUsed;
  bool status;
  bool approved;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic mobileNumber;
  dynamic category;
  dynamic password;
  dynamic profilePic;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;
  dynamic aboutUs;
  dynamic description;
  dynamic businessType;
  dynamic closeTime;
  dynamic openTime;

  factory Favorite.fromJson(Map<dynamic, dynamic> json) => Favorite(
        address: json["Address"]==null?null:Address.fromJson(json["Address"]),
        photos: List<dynamic>.from(json["Photos"].map((x) => x)),
        services: List<dynamic>.from(json["Services"].map((x) => x)),
        rating: json["Rating"],
        reviews: json["Reviews"],
        bookingsLeft: json["Bookings_Left"],
        bookingsUsed: json["Bookings_Used"],
        status: json["status"],
        approved: json["approved"],
        id: json["_id"],
        name: json["Name"],
        email: json["Email"],
        mobileNumber: json["Mobile_number"],
        category: json["Category"],
        password: json["Password"],
        profilePic: json["Profile_Pic"],
        registerDate: DateTime.parse(json["Register_date"]),
        createdAt: DateTime.parse(json["createdAt"]),
        updatedAt: DateTime.parse(json["updatedAt"]),
        v: json["__v"],
        aboutUs: json["About_Us"],
        description: json["Description"],
        businessType: json["Business_Type"],
        closeTime: json["Close_Time"],
        openTime: json["Open_Time"],
      );
}

class Address {
  Address({
    this.type,
    this.coordinates,
    this.address,
    this.city,
    this.state,
  });

  String? type;
  List<double>? coordinates;
  String? address;
  String? city;
  String? state;

  factory Address.fromJson(Map<dynamic, dynamic> json) => Address(
        type: json["type"] != null ? json["type"] : "",
        coordinates:json["coordinates"] !=null ?
            List<double>.from(json["coordinates"].map((x) => x.toDouble())) : null,
        address: json["Address"] != null ? json["Address"] : "",
        city: json["City"] !=null ? json["City"] :"",
        state:json["State"] !=null ? json["State"] :"",
      );

  Map<dynamic, dynamic> toJson() => {
        "type": type,
        "coordinates": List<dynamic>.from(coordinates!.map((x) => x)),
        "Address": address,
        "City": city,
        "State": state,
      };
}

class Popular {
  Popular({
    this.address,
    this.rating,
    this.id,
    this.name,
    this.profilePic,
    this.closeTime,
    this.openTime,
  });

  Address? address;
  int? rating;
  String? id;
  String? name;
  String? profilePic;
  String? closeTime;
  String? openTime;

  factory Popular.fromJson(Map<dynamic, dynamic> json) => Popular(
        address: json["Address"] !=null ? Address.fromJson(json["Address"]) : null,
        rating: json["Rating"] != null ? json["Rating"] : "",
        id: json["_id"] != null ? json["_id"] : "",
        name: json["Name"] != null ? json["Name"] : "",
        profilePic: json["Profile_Pic"] != null ? json["Profile_Pic"] : "",
        closeTime: json["Close_Time"] != null ? json["Close_Time"] : "",
        openTime: json["Open_Time"] != null ? json["Open_Time"] : "",
      );

  Map<dynamic, dynamic> toJson() => {
        "Address": address!.toJson(),
        "Rating": rating,
        "_id": id,
        "Name": name,
        "Profile_Pic": profilePic,
        "Close_Time": closeTime,
        "Open_Time": openTime,
      };
}
