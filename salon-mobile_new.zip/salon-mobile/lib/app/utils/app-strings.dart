class AppStrings {

  static const slowInternet = 'Slow internet';
  static const noInternet = 'No internet';
  static const error = 'Something went wrong';
  static const wait = 'Please wait';
  static const signUpMSG = 'Message sent for mobile number verification.';
  static const GOOGLE_MAP_KEY = 'AIzaSyDa0VvaaapSFK8vRKAOPrcJVPkatFf8VMU';
  static String? tokenOfCurrentUser = '';
  static String? tokenOfAdminUser = '';
  static String userName = '';
  static String mobileNumber = '';
  static String senderID = '';
  static String categoryID = '';
  static List<String> allCategoriesNamesListAppStrings = [];
  static String receiverID = '';
  static String userId = '';
  static String userEmail = '';
  static String accountCreatedOn = '';
  static String dob = '';
  static String fromStaff = '';
  static String streetAddress = '';
  static String addressCity = '';
  static String addressRegion = '';


}
