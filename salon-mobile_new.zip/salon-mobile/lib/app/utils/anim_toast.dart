import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:motion_toast/motion_toast.dart';
import 'package:motion_toast/resources/arrays.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class AnimToast{
 static errorToast(
      BuildContext context, String title, String description) {
    MotionToast.error(
      title: title,
      titleStyle: TextStyle(fontWeight: FontWeight.bold),
      description: description,
      animationType: ANIMATION.FROM_LEFT,
      position: MOTION_TOAST_POSITION.TOP,
      width: SizeConfig.screenWidth,
    ).show(context);
  }
 static infoToast(
      BuildContext context, String title, String description) {
    MotionToast.info(
      title: title,
      titleStyle: TextStyle(fontWeight: FontWeight.bold),
      description: description,
      animationType: ANIMATION.FROM_LEFT,
      position: MOTION_TOAST_POSITION.TOP,
      width: SizeConfig.screenWidth,
    ).show(context);
  }

 static warningToast(
      BuildContext context, String title, String description) {
    MotionToast.warning(
      title: title,
      titleStyle: TextStyle(fontWeight: FontWeight.bold),
      description: description,
      animationType: ANIMATION.FROM_LEFT,
      position: MOTION_TOAST_POSITION.TOP,
      width: SizeConfig.screenWidth,
    ).show(context);
  }

}