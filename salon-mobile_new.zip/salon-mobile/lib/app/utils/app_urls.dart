

class AppUrls{
  /**
   * ivylab 1.0 = 192.168.2.21;
   * ivylab 2.0 = 192.168.18.91;
   * 'http://54.66.178.41:4700/api';
   */
  // static String BASE_URL = 'http://192.168.2.24:4600/api';
  //static String BASE_URL = 'http://3.25.102.3:4700/api';

  static String BASE_URL = 'https://api.salloon.dk/api'; // techExte

  //static String BASE_URL_IMAGE = 'http://3.25.102.3:4700/';

  static String BASE_URL_IMAGE = 'https://api.salloon.dk/'; // techExte


  // static String BASE_URL_IMAGE = 'http://192.168.2.24:4600/';
  static String userTokenKey = 'userTokenKey';
  static String userName = 'userName';
  static String userId = 'userId';
  static String mobileNumber = 'mobileNumber';
  static String product_id = 'producd_id';
  static String Quantity = '';
  static String MON_FRI_OPEN = '';
  static String MON_FRI_CLOSE = '';
  static String FRI_SAT_OPEN = '';
  static String FRI_SAT_CLOSE = '';
// static String Quantity = '';

}