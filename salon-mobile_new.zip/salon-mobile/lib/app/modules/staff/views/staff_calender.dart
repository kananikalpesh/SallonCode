import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/staff/staff_bookings.dart'
    as staffBooking;
import 'package:saloon_app/app/modules/admin/controllers/saloon_appointment_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calender_utils.dart';
import 'package:saloon_app/app/modules/staff/controller/staff-login/staff-login-ctl.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/gv.dart';
import 'package:saloon_app/app/utils/size_config.dart';
import 'package:table_calendar/table_calendar.dart';
// import 'calenders_wrapper.dart';

class StaffCalender extends GetView<StaffLoginController> {
  late final ValueNotifier<List<Event>> _selectedEvents;
  CalendarFormat _calendarFormat = CalendarFormat.month;
  SaloonAppointmentCTL _saloonAppointmentCTL = Get.find();
  bool isEventLoaded = false;

  List<staffBooking.Datum> _getEventsForDay(DateTime day) {
    return controller.getDayEvents(day) ?? [];
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    print("focusedDay Date $focusedDay");
    if (!isSameDay(controller.selectedDay, selectedDay)) {
      controller.focusedDay.value = focusedDay;
      controller.selectedDay = focusedDay;
    }
    for (var d in controller.uniqueDates) {
      controller.isEventLoaded?[d.toString().split(' ')[0]] = false;
    }
    print(
        "isEventLoaded ${controller.isEventLoaded?[focusedDay.toString().split(' ')[0]]}");

    // _selectedEvents.value = _getEventsForDay(selectedDay);
    controller.dayBookingList = controller.getDayEvents(focusedDay) ?? [];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(
        () => controller.isBookingsLoaded.isTrue
            ? Container(
              height: SizeConfig.screenHeight,
              child: ListView(
                children: [
                  Divider(),
                  verticalSpace(SizeConfig.blockSizeVertical),
                  TableCalendar<staffBooking.Datum>(
                    headerVisible: true,
                    currentDay: kToday,
                    firstDay: kFirstDay,
                    lastDay: kLastDay,
                    focusedDay: controller.focusedDay.value,
                    selectedDayPredicate: (day) =>
                        isSameDay(controller.selectedDay, day),
                    rangeStartDay: controller.rangeStart,
                    rangeEndDay: controller.rangeEnd,
                    calendarFormat: controller.calendarFormat.value,
                    // rangeSelectionMode: controller.rangeSelectionMode,
                    eventLoader: _getEventsForDay,
                    startingDayOfWeek: StartingDayOfWeek.monday,
                    calendarStyle: CalendarStyle(
                      // Use `CalendarStyle` to customize the UI
                      outsideDaysVisible: false,
                      selectedDecoration: BoxDecoration(
                        color: ColorsX.calender_orange,
                        shape: BoxShape.circle,
                        //borderRadius: BorderRadius.circular(5.0),
                      ),
                      todayDecoration: BoxDecoration(
                        color: ColorsX.calender_pink,
                        shape: BoxShape.circle,
                        //borderRadius: BorderRadius.circular(5.0),
                      ),
                      markerDecoration: BoxDecoration(
                        color: ColorsX.blue_button_color,
                        shape: BoxShape.circle,
                        //borderRadius: BorderRadius.circular(5.0),
                      ),
                    ),
                    headerStyle: HeaderStyle(
                      leftChevronMargin: EdgeInsets.only(left: 1),
                      rightChevronMargin: EdgeInsets.only(left: 1),
                      leftChevronPadding: EdgeInsets.only(
                          left: 0.0,
                          right: SizeConfig.marginVerticalXsmall),
                      rightChevronPadding: EdgeInsets.only(
                          right: 0.0,
                          left: SizeConfig.marginVerticalXsmall),
                    ),
                    onDaySelected: _onDaySelected,
                    onFormatChanged: (format) {
                      controller.calendarFormat.value = format;
                    },
                    onPageChanged: (focusedDay) {
                      // _focusedDay = focusedDay;
                      // print("Selected Date $_focusedDay");
                      for (var d in controller.uniqueDates) {
                        print(
                            'OnPageChanged...${d.toString().split(' ')[0]}');
                        controller.isEventLoaded?[
                            d.toString().split(' ')[0]] = false;
                      }
                    },

                    calendarBuilders: CalendarBuilders(
                      selectedBuilder: (context, date, events) => Container(
                          margin: const EdgeInsets.all(5.0),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              color: ColorsX.calender_orange,
                              borderRadius: BorderRadius.circular(8.0)),
                          child: Text(
                            date.day.toString(),
                            style: TextStyle(color: Colors.white),
                          )),
                      todayBuilder: (context, date, events) => Container(
                          margin: const EdgeInsets.all(5.0),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(8.0)),
                          child: Text(
                            date.day.toString(),
                            style: TextStyle(color: Colors.white),
                          )),
                      singleMarkerBuilder: (context, date, events) {
                        var mapVal = controller
                            .isEventLoaded?[date.toString().split(' ')[0]];
                        if (mapVal != null) {
                          if (!mapVal) {
                            print('singleMarkerBuilder....');
                            controller.isEventLoaded?[
                                date.toString().split(' ')[0]] = true;
                            return Container(
                              color: ColorsX.blue_gradient_light,
                              width: 14,
                              padding: EdgeInsets.all(1),
                              alignment: Alignment.center,
                              child: Text(
                                '${controller.getDayEvents(date)?.length}',
                                style: TextStyle(
                                    color: ColorsX.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            );
                          } else {
                            return Container(
                              width: 0,
                              height: 0,
                            );
                          }
                        } else {
                          return Container(
                            width: 0,
                            height: 0,
                          );
                        }
                      },
                      outsideBuilder: (context, date, events) => Container(
                          margin: const EdgeInsets.all(5.0),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              color: Colors.deepOrange,
                              borderRadius: BorderRadius.circular(8.0)),
                          child: Text(
                            date.day.toString(),
                            style: TextStyle(color: Colors.white),
                          )),
                    ),
                  ),
                  const SizedBox(height: 8.0),
                  Divider(),
                  controller.dayBookingList.isNotEmpty
                      ? Column(
                          children: [
                            ListView.builder(
                              physics: NeverScrollableScrollPhysics(),
                              padding: EdgeInsets.zero,
                              shrinkWrap: true,
                              itemCount: controller.dayBookingList.length,
                              itemBuilder: (context, index) {
                                return InkWell(
                                  onTap: () {

                                    controller.saloonAppointment = controller.dayBookingList[index];
                                    Get.toNamed(Routes.STAFF_BOOKING_DETAILS);
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.symmetric(
                                      // horizontal: 12.0,
                                      vertical: 4.0,
                                    ),
                                    decoration: BoxDecoration(
                                        // border: Border.all(),
                                        // borderRadius: BorderRadius.circular(12.0),
                                        ),
                                    child: _bookingItem(
                                        day:
                                            "${GV.daysList[controller.focusedDay.value.weekday - 1]}",
                                        time:
                                            "${controller.dayBookingList[index].timeSlot}",
                                        name:
                                            "${controller.dayBookingList[index].user?.name}",
                                        services:
                                            "${controller.dayBookingList[index].services?.name}",
                                        bgColor:
                                            ColorsX.rating_dashboard),
                                  ),
                                );
                              },
                            ),
                            Container(
                              alignment: Alignment.bottomCenter,
                              child: Button(context, 'View All Booking'),
                            ),
                            Container(
                              margin: EdgeInsets.only(bottom: 100),
                            )
                          ],
                        )
                      : Container(
                          alignment: Alignment.topCenter,
                          child: Column(
                            children: [
                              _rowItemForHeaderText(
                                  'No Booking For The Day',
                                  18,
                                  FontWeight.bold,
                                  ColorsX.black,
                                  0,
                                  0,
                                  0),
                              Container(
                                alignment: Alignment.bottomCenter,
                                child:
                                Button(context, 'View All Booking'),
                              )
                            ],
                          ),
                        ),
                ],
              ),
            )
            : Center(
                child: CircularProgressIndicator(),
              ),
      ),
    );
  }

  Widget Button(BuildContext context, String buttonText) {
    return Align(
        alignment: Alignment.topCenter,
        child: InkWell(
          onTap: () {
            Get.toNamed(Routes.STAFF_ALL_BOOKING);
          },
          child: Container(
            margin: EdgeInsets.only(
              top: SizeConfig.marginVerticalXXLarge,
            ),
            width: SizeConfig.screenWidth * .80,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(buttonText,
                    style: TextStyle(
                      fontSize: 16,
                      color: ColorsX.white,
                      fontWeight: FontWeight.w700,
                    )),
              ],
            ),
          ),
        ));
  }

  _bookingItem(
      {required String day,
      required String time,
      required String name,
      required String services,
      required Color bgColor}) {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: SizeConfig.blockSizeHorizontal * 2,
          vertical: SizeConfig.blockSizeVertical),
      decoration: BoxDecoration(
          color: bgColor, borderRadius: BorderRadius.circular(10)),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _rowItemForHeaderText(
                      day, 12, FontWeight.normal, ColorsX.white, 0, 0, 0),
                  _rowItemForHeaderText(
                      time, 12, FontWeight.normal, ColorsX.white, 5, 0, 0)
                ],
              ),
              _rowItemForHeaderText(
                  name, 14, FontWeight.normal, ColorsX.white, 0, 0, 0),
            ],
          ),
          Row(
            children: [
              Spacer(),
              _rowItemForHeaderText(
                  services, 14, FontWeight.bold, ColorsX.white, 0, 0, 0),
            ],
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color color,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style:
            TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }
}
