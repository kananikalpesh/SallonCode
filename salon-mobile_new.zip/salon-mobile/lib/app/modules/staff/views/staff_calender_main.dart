import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/dashboard_controller.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calenders_wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/modules/staff/controller/staff-login/staff-login-ctl.dart';
import 'package:saloon_app/app/modules/staff/views/staff_calender.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';


class StaffCalenderMainScreen extends GetView<StaffLoginController> {
  String drawerValue = "assets/images/appoint_white.png";

  List<String> format = [
    'Monthly',
    'Weekly',
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        // backgroundColor: ColorsX.greydashboard,
        body: Stack(
          children: [
            Container(
              width: SizeConfig.screenWidth,
              height: SizeConfig.screenHeight,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(
                      height: 5,
                    ),
                    _textAndIcon(context, "Calender", AppImages.back),
                    Container(
                      margin: EdgeInsets.only(
                          left: SizeConfig.paddingSmall,right: SizeConfig.paddingSmall),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: SizeConfig.blockSizeVertical * 2,
                          ),
                          // _rowItemForHeaderText("Select Services", 18,
                          //     FontWeight.bold, ColorsX.black, 10, 15, 0),

                          Padding(
                            padding: EdgeInsets.only(
                                right: SizeConfig.blockSizeHorizontal * 6,
                                bottom: SizeConfig.blockSizeVertical * 2),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  margin: EdgeInsets.only(left: 15, top: 10),
                                  decoration: new BoxDecoration(
                                    color: ColorsX.white,
                                    borderRadius: BorderRadius.all(Radius.circular(10)),
                                  ),
                                  child: Text(
                                    'Monthly',),
                                ),
                              ],
                            ),
                          ),

                          Container(
                              width: SizeConfig.screenWidth,
                              height: SizeConfig.screenHeight,
                              child: StaffCalender()),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Container(
            //   margin: EdgeInsets.only(top: SizeConfig.screenHeight * .9),
            //   child: Align(alignment: Alignment.bottomCenter, child: BottomCart()),
            // )

          ],
        ),
      ),
    );
  }

  Widget offsetPopup() => PopupMenuButton<int>(
    color: ColorsX.subBlack,
    itemBuilder: (context) => [
      PopupMenuItem(
        value: 1,
        child: InkWell(
            onTap: () {
              print("clicked");
              // // Get.toNamed(Routes.new_add_on);
              // Get.toNamed(DealsNavigation.createNewDeal,
              //     id: DealsNavigation.id);
              Get.toNamed(
                  CalenderNavigation.choose_customer,
                  id: CalenderNavigation.id);
            },
            child: _rowItemForHeaderText("Add Slot", 10,
                FontWeight.w700, ColorsX.white, 0, 0, 0)),
      ),
      // PopupMenuItem(
      //   value: 2,
      //   child: _rowItemForHeaderText("Preferences", 10, FontWeight.w700, 0xffffffff, 0, 0, 0),
      // ),

      //
    ],
    icon: Container(
      height: double.infinity,
      width: double.infinity,
      decoration: ShapeDecoration(
          color: ColorsX.blue_text_color,
          shape: StadiumBorder(
            side: BorderSide(color: ColorsX.blue_text_color, width: 2),
          )),
      child: Image.asset(
          AppImages.add_slot_icon), // <-- You can give your icon here
    ),
  );
  Widget Button(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: Container(
          margin: EdgeInsets.only(
            top: 20,
          ),
          width: SizeConfig.eightyPercentWidth,
          padding: EdgeInsets.symmetric(vertical: 15),
          decoration: BoxDecoration(
            color: ColorsX.blue_button_color,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text("Continue to Select Add-ons",
                  style: TextStyle(
                    fontSize: 16,
                    color: ColorsX.white,
                    fontWeight: FontWeight.w700,
                  )),
            ],
          ),
        ));
  }

  Widget dropDownContainer(
      BuildContext context, List<String> values, double width, String text) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          DropDownWithoutBorder(values, text),
        ],
      ),
    );
  }

  Widget simpleContainer(
      BuildContext context, String firstText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(
        left: 15,
        top: 10,
      ),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(bottom: 15, top: 5),
            child: _rowItemForHeaderText(firstText, 14, FontWeight.w600,
                ColorsX.dash_textColordark1, 10, 10, 0),
          ),
          Container(
            margin: EdgeInsets.only(top: 12, right: 10),
            child: Image.asset(imagePath),
          ),
        ],
      ),
    );
  }

  Widget deleteButton(BuildContext context, String text, int colorCode) {
    return GestureDetector(
      child: Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(left: 15, top: 15),
        decoration: new BoxDecoration(
          color: Color(colorCode),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: [
            BoxShadow(
              color: text == "Add New" ? ColorsX.blue_button_color : Colors.red,
              blurRadius: 6,
              offset: Offset(1, 1), // Shadow position
            ),
          ],
        ),
        padding: EdgeInsets.symmetric(vertical: 13),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(child: SizedBox()),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Color(0xffffffff)),
            ),
            Expanded(child: SizedBox()),
            Icon(
              Icons.add_circle,
              color: ColorsX.white,
            ),
            SizedBox(
              width: 10,
            )
          ],
        ),
        // child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700,color: Color(0xffffffff)),)
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color color,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style:
        TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      // width: SizeConfig.seventyFivePercentWidth,
      margin:
      EdgeInsets.only(top: 20, left: SizeConfig.blockSizeHorizontal * 6),
      child: Row(
        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _rowItemForHeaderText(
              text, 20, FontWeight.w900, ColorsX.dash_textColordark1, 0, 0, 0),
          Spacer(),
          Container(
            // padding: EdgeInsets.all(5),
            decoration:
            BoxDecoration(shape: BoxShape.circle, color: ColorsX.white),
            child: Image.asset(
              AppImages.bell_dash_ic,
              width: 35,
              height: 35,
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 3),
          Container(
            // padding: EdgeInsets.all(5),
            decoration:
            BoxDecoration(shape: BoxShape.circle, color: ColorsX.white),
            child: InkWell(
              onTap: () {
                DaishBoardController daishBoardController = Get.find();
                daishBoardController.tabIndex.value = 10;
              },
              child: Image.asset(
                AppImages.chat_dash_ic,
                width: 35,
                height: 35,
              ),
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 4),
        ],
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
            alignment: Alignment.bottomRight,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
              margin: EdgeInsets.only(left: 2, top: 2),
              decoration: new BoxDecoration(
                color: ColorsX.rating_dashboard,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    bottomRight: Radius.circular(30)),
              ),
              child: _rowItemForHeaderText(
                  " 4.5", 7, FontWeight.w600, ColorsX.white, 0, 0, 0),
            ),
          )
              : Container(),
        ],
      ),
    );
  }
}