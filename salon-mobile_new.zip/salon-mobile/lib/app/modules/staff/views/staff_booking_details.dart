import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:saloon_app/app/modules/staff/controller/staff-login/staff-login-ctl.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/dot_widget.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SatffBookingDetails extends GetView<StaffLoginController> {
  String drawerValue = "assets/images/chat.png";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsX.greydashboard,
      body: Stack(
        children: <Widget>[
          // Container(
          //   height: SizeConfig.screenHeight,
          //   width: SizeConfig.screenWidth,
          //   margin: EdgeInsets.only(top: 175),
          //   color: ColorsX.dashboardColor,
          // ),
          Container(
            width: SizeConfig.screenWidth,
            color: ColorsX.dashboardBG,
            child: new ListView(
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    InkWell(
                      child: Container(
                        width: SizeConfig.screenWidth * .15,
                        margin: EdgeInsets.only(top: 20),
                        child: Icon(Icons.arrow_back),
                      ),
                      onTap: () {
                        Get.back();
                      },
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        // _search(context),
                        _rowItemForHeaderText("Appointment No:", 20,
                            FontWeight.w900, 0xff515C6F, 20, 10, 0),
                        _rowItemForHeaderText(
                            "#${controller.saloonAppointment?.appointmentId}",
                            16,
                            FontWeight.w700,
                            0xff8890A6,
                            5,
                            10,
                            0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(top: 30, left: 5),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0),
                                child: CachedNetworkImage(
                                  imageUrl: AppUrls.BASE_URL_IMAGE +
                                      '${controller.saloonAppointment?.user?.profilePic}',
                                  errorWidget: (context, url, error) =>
                                      Icon(Icons.error),
                                  fit: BoxFit.cover,
                                  width: 100,
                                  height: 100,
                                  placeholder: (context, url) => Container(
                                      height: 30,
                                      width: 30,
                                      child: Center(
                                          child: CircularProgressIndicator())),
                                ),
                              ),
                            ),
                            Container(
                                margin: EdgeInsets.only(top: 15),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    _rowItemForHeaderText(
                                        "Appointment Status:",
                                        12,
                                        FontWeight.w400,
                                        0xff8890A6,
                                        50,
                                        10,
                                        0),
                                    _rowItemForHeaderText(
                                        "${controller.saloonAppointment?.status}",
                                        12,
                                        FontWeight.w900,
                                        0xffFF5667,
                                        0,
                                        10,
                                        0),
                                  ],
                                )),
                          ],
                        ),
                        customerDetails(context, "Customer Name:",
                            "${controller.saloonAppointment?.user?.name}"),
                        // customerDetails(context, "Gender:", "Male"),
                        customerDetails(context, "Age:",
                            "${controller.saloonAppointment?.user?.dob}"),
                        customerDetails(context, "Booking Time:",
                            "${controller.saloonAppointment?.appointmentDate.toString().split(' ')[0]} ${controller.saloonAppointment?.timeSlot}"),
                        // customerDetails(context, "Services:", "Haircut, Facial"),
                        customerDetails(context, "Barber Assigned:",
                            "${controller.saloonAppointment?.staff?.name}"),
                        //+'\$'),
                        Container(
                            height: 50,
                            margin: EdgeInsets.only(left: 20),
                            width: SizeConfig.screenWidth * .70,
                            child: MySeparator(color: Colors.grey)),
                        Container(
                          width: SizeConfig.screenWidth * .70,
                          margin: EdgeInsets.only(left: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              _rowItemForHeaderText("Services", 14,
                                  FontWeight.w700, 0xff8890A6, 10, 0, 0),
                              _rowItemForHeaderText("Price", 14,
                                  FontWeight.w700, 0xff8890A6, 10, 0, 0),
                            ],
                          ),
                        ),
                        serviceAndPrice(
                            context,
                            "${controller.saloonAppointment?.services?.name}",
                            "${controller.saloonAppointment?.services?.price}"
                                '\$'),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          width: SizeConfig.screenWidth * .70,
                          margin: EdgeInsets.only(left: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              _rowItemForHeaderText("Add-Ons", 14,
                                  FontWeight.w700, 0xff8890A6, 10, 0, 0),
                              _rowItemForHeaderText("Price", 14,
                                  FontWeight.w700, 0xff8890A6, 10, 0, 0),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        //populate add ON
                        for (int i = 0;
                            i <
                                (controller
                                        .saloonAppointment?.products?.length ??
                                    0);
                            i++)
                          addOnsAndPrice(
                              context,
                              "${controller.saloonAppointment?.products![i].quantity}",
                              "${controller.saloonAppointment?.products![i].product?.name}",
                              "${controller.saloonAppointment?.products![i].product?.price}"
                                  '\$'),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          width: SizeConfig.screenWidth * .70,
                          margin: EdgeInsets.only(left: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              _rowItemForHeaderText("Total", 14,
                                  FontWeight.w700, 0xff8890A6, 10, 0, 0),
                              _rowItemForHeaderText(
                                  "${controller.saloonAppointment?.totalPrice}"
                                  '\$',
                                  14,
                                  FontWeight.w700,
                                  0xff8890A6,
                                  10,
                                  0,
                                  0),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          height: 20,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  Widget customerDetails(BuildContext context, String text1, String text2) {
    return Container(
      width: SizeConfig.seventyPercentWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: _rowItemForHeaderText(
                text1, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),
          ),
          Expanded(
            child: _rowItemForHeaderText(
                text2, 13, FontWeight.w400, 0xff515C6F, 10, 10, 0),
          ),

          // Expanded(child: _rowItemForHeaderText(text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0)),
          // Expanded(child: _rowItemForHeaderText(text2, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0)),
        ],
      ),
    );
  }

  Widget serviceAndPrice(BuildContext context, String text1, String text2) {
    return Container(
      width: SizeConfig.seventyPercentWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(
              text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0),
          _rowItemForHeaderText(
              text2, 13, FontWeight.w400, 0xff8890A6, 10, 10, 0),

          // Expanded(child: _rowItemForHeaderText(text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0)),
          // Expanded(child: _rowItemForHeaderText(text2, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0)),
        ],
      ),
    );
  }

  Widget addOnsAndPrice(
      BuildContext context, String numberOfItems, String text1, String text2) {
    return Container(
      width: SizeConfig.seventyPercentWidth,
      margin: EdgeInsets.only(left: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 6),
            decoration: BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(6.0),
              child: _rowItemForHeaderText(
                  numberOfItems, 12, FontWeight.w400, 0xffffffff, 0, 0, 0),
            ),
          ),
          _rowItemForHeaderText(
              text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0),
          Expanded(child: Container()),
          _rowItemForHeaderText(
              text2, 13, FontWeight.w400, 0xff8890A6, 10, 10, 0),

          // Expanded(child: _rowItemForHeaderText(text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0)),
          // Expanded(child: _rowItemForHeaderText(text2, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0)),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    margin: EdgeInsets.only(left: 2, top: 2),
                    decoration: new BoxDecoration(
                      color: ColorsX.rating_dashboard,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          bottomRight: Radius.circular(30)),
                    ),
                    child: _rowItemForHeaderText(
                        " 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
