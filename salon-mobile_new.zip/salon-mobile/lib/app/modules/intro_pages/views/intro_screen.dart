import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/resuseable/intro_screen_pageone.dart';
import 'package:saloon_app/app/utils/images.dart';

class IntroScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        children: <Widget>[
          IntroScreenPageOne(
            imagePath: AppImages.First_introSlider,
            heading: "FIND & BOOK SERVICES",
            subText:
                "Find & Book Barber, Beauty Saloon & Spa Services anywhere, anytime",
            buttonText: "Next",
            skipContinue: "SKIP",
            pageNumber: 0,
          ),
          IntroScreenPageOne(
            imagePath: AppImages.Second_introSlider,
            heading: "STYLE THAT FIT YOUR LIFESTYLE",
            subText:
                "Choose our makeup special after price package that fit your lifestyle",
            buttonText: "Next",
            skipContinue: "SKIP",
            pageNumber: 1,
          ),
          IntroScreenPageOne(
            imagePath: AppImages.Third_introSlider,
            heading: "EASY PAY & BOOKING",
            subText: "Get registered and get access to easy pay & booking",
            buttonText: "Continue",
            skipContinue: "DONE",
            pageNumber: 2,
          ),
        ],
      ),
    );
  }
}
