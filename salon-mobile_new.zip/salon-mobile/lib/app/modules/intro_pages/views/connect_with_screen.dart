import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/login/controllers/signup_controller.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class ConnectWith extends GetView<SignUpCTL> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            child: Image.asset(
              AppImages.Dark_Girl_bg,
              fit: BoxFit.cover,
            ),
          ),
          Container(
            height: 100,
            width: 100,
            margin: EdgeInsets.only(
                left: SizeConfig.tenPercentWidth,
                top: SizeConfig.blockSizeVertical * 29),
            child: Image.asset(
              AppImages.Splash_logo,
              fit: BoxFit.cover,
              height: 80,
              width: 80,
            ),
          ),
          Container(
            height: 40,
            width: 140,
            margin: EdgeInsets.only(
                left: SizeConfig.tenPercentWidth,
                top: SizeConfig.blockSizeVertical * 45),
            child: Image.asset(
              "assets/images/big_logo.png",
              fit: BoxFit.cover,
            ),
          ),
          textWidgets(
              "Book an appointment for Salon, Spa & Barber", 20, context),
          InkWell(
            onTap: (){
              Navigator.pushNamed(context, '/login');
              // Get.toNamed(Routes.LOGIN_SCREEN);
            },
            child: getRowElementFirst("Sign up with email", context,
                SizeConfig.blockSizeVertical * 62, 0xffffffff, 0xff606060),
          ),
          InkWell(
            onTap: () {
              // Get.toNamed(Routes.ADMIN_MAIN_DAISHBOARD);
              // print("google clicked");
            },
            child: getRowElement(
                AppImages.Google_icon,
                "Connect with Google",
                context,
                SizeConfig.seventyPercentHeight,
                0xffffffff,
                0xff606060),
          ),
          getRowElement(AppImages.FB_icon, "Connect with Facebook", context,
              SizeConfig.seventyEightPercentHeight, 0xff5CA6F8, 0xffffffff),
          Platform.isIOS
              ? getRowElement(
                  AppImages.Apple_icon,
                  "Connect with Apple",
                  context,
                  SizeConfig.eightySixPercentHeight,
                  0xff4B4949,
                  0xffffffff)
              : Container(),
          Align(
              alignment: Alignment.center,
              child: GestureDetector(
                onTap: () {
                  // Navigator.pushNamed(context, '/login');
                  Get.toNamed(Routes.LOGIN_SCREEN);
                },
                child: Container(
                    margin: EdgeInsets.only(
                        top: SizeConfig.ninetyThreePercentHeight),
                    child: RichText(
                      text: TextSpan(
                        text: 'Already have an acoount?  ',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            color: ColorsX.white),
                        children: const <TextSpan>[
                          TextSpan(
                              text: 'Log In',
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400,
                                  color: ColorsX.blue_gradient_dark)),
                        ],
                      ),
                    )),
              )),
        ],
      ),
    );
  }

  Widget getRowElement(String? imagePath, String value, BuildContext context,
      double top, int colorCode, int textColor) {
    return Container(
        margin: EdgeInsets.only(
            left: SizeConfig.tenPercentWidth,
            right: SizeConfig.tenPercentWidth,
            top: top),
        padding: EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
            color: Color(colorCode),
            borderRadius: BorderRadius.all(Radius.circular(10))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(),
            imagePath != null
                ? Expanded(
                    flex: 2,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Image.asset(
                          imagePath,
                          fit: BoxFit.fitHeight,
                          width: 20,
                          height: 20,
                        ),
                      ],
                    ),
                  )
                : Expanded(
                    flex: 2,
                    child: Container(
                      width: 20.0,
                      height: 20.0,
                    ),
                  ),
            horizontalSpace(SizeConfig.blockSizeHorizontal * 5),
            Expanded(
              flex: 5,
              child: Text(
                value,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Color(textColor)),
              ),
            ),
            SizedBox(),
          ],
        ));
  }

  Widget getRowElementFirst( String value, BuildContext context,
      double top, int colorCode, int textColor) {
    return GestureDetector(
      onTap: (){
        if(value.contains("email")){
          print("email pressed");
          Navigator.pushNamed(context, '/login');
        }
        else if(value.contains("Google")){
          print("Google clicked");
        }
      },
      child: Container(
          margin: EdgeInsets.only(
              left: SizeConfig.tenPercentWidth,
              right: SizeConfig.tenPercentWidth,
              top: top),
          padding: EdgeInsets.symmetric(vertical: 13),
          decoration: BoxDecoration(
              color: Color(colorCode),
              borderRadius: BorderRadius.all(Radius.circular(10))),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(),
              Expanded(
                flex: 2,
                child: Container(
                  width: 20.0,
                  height: 20.0,
                ),
              ),
              horizontalSpace(SizeConfig.blockSizeHorizontal * 5),
              Expanded(
                flex: 5,
                child: Text(
                  value,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Color(textColor)),
                ),
              ),
              SizedBox(),
            ],
          )),
    );
  }

  Widget textWidgets(String value, double fontSize, BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
          left: SizeConfig.tenPercentWidth,
          top: SizeConfig.blockSizeVertical * 51.5,
          right: SizeConfig.tenPercentWidth),
      child: Text(
        value,
        style: TextStyle(
            color: ColorsX.white,
            fontWeight: FontWeight.w700,
            fontSize: fontSize),
      ),
    );
  }
}
