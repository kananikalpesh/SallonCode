import 'package:get/get.dart';
import 'package:saloon_app/app/modules/login/controllers/otp-controller.dart';


class OTPBinding extends Bindings {
  @override
  void dependencies() {

    Get.put<OTPController>(
      OTPController(),
    );
  }
}
