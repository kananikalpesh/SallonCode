
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/admin/views/top_graph.dart';

class Sales extends StatefulWidget{

  @override
  _Sales createState()=> _Sales();
}
class _Sales extends State<Sales>{
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          // height: SizeConfig.screenHeight,
          child: TopGraph(),
        ),
      ),
    );
  }
}


