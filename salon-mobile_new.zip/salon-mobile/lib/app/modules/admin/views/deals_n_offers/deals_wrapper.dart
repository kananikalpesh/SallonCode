// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/views/deals_n_offers/edit-deal.dart';


import 'create_new_deal.dart';
import 'deals_n_offers_list.dart';



class DealsNavigation {
  DealsNavigation._();
  static const id = 18;
  static const dealsNofferList = '/deals-n-offers-list';
  static const createNewDeal = '/create_new_deal';
  static const editDeal = '/edit_deal';

}
// our wrapper, where our main navigation will navigate to
class DealsNOfferWrapper extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Navigator(
      
      key: Get.nestedKey(DealsNavigation.id),
      onGenerateRoute: (settings) {
        // navigate to a route by name with settings.name
        if (settings.name == DealsNavigation.createNewDeal) {
          return GetPageRoute(
            routeName: DealsNavigation.createNewDeal,
            page: () => CreateNewDeal(
              
            ),
          );
        }else if (settings.name == DealsNavigation.editDeal) {
          return GetPageRoute(
            routeName: DealsNavigation.editDeal,
            page: () => EditDeal(

            ),
          );
        }
        
        else {
          return GetPageRoute(
            routeName: DealsNavigation.dealsNofferList,
            page: () => DealNOffersList(
              
            ),
          );
        }
      },
    );
  }
}