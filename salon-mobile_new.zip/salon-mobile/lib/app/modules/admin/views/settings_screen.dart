import 'dart:io' as Io;

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-services/services-admin-list-and-add-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/deal_n_offers_ctl/admin-deals-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/settingsCtl.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SaloonSettings extends GetView<AdminSettingsCTL> {
  List<String> timeLimit = [
    'Beauty Shop & SPA',
    'Beauty Shop & SPA',
    'Beauty Shop & SPA'
  ];
  List<String> ServiceList = ['Manicure, Pedicure', 'Pedicure', 'Manicure'];
  List<String> CatagoryList = ['All Days',];
  List<String> TimeLimitList = ['8 hours', '1 day', '1 week'];
  List<String> DiscountList = ['10%', '20%', '30%'];
  ServicesAdminListAddCTL adminServiceCTL = Get.find();

  List<String> currencies = ['USD', 'NOK', 'EUR'];
  @override
  Widget build(BuildContext context) {
    AdminLoginController adminLoginController = Get.find();
    AdminDealsCTL adminDealsCTL = Get.find();
    controller.companyNameController.text= "${adminLoginController.adminLoginRes?.saloon.name}";
    controller.businessTypeController.text= "${adminLoginController.adminLoginRes?.saloon.saloon.businessType}";
    controller.workingOpenHoursController.text= "${adminLoginController.adminLoginRes?.saloon.saloon.openTime}";
    controller.workingCloseHoursController.text= "${adminLoginController.adminLoginRes?.saloon.saloon.closeTime}";
    controller.emailController.text= "${adminLoginController.adminLoginRes?.saloon.saloon.email}";
    controller.passwordController.text= "${adminLoginController.adminLoginRes?.saloon.saloon.password}";
    controller.addressController.text= "${adminLoginController.adminLoginRes?.saloon.saloon.address?.address}";
    controller.mobileNumberController.text= "${adminLoginController.adminLoginRes?.saloon.saloon.mobileNumber}";
    // print("this list ${adminServiceCTL.categoryNameList}");
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: <Widget>[
            Container(
              height: SizeConfig.screenHeight,
              width: SizeConfig.screenWidth,
              margin: EdgeInsets.only(top: 175),
              // color: ColorsX.dashboardColor,
            ),
            Container(
              margin: EdgeInsets.only(
                  left: SizeConfig.blockSizeHorizontal * 5,
                  top: SizeConfig.blockSizeVertical * 7),
              child: Padding(
                padding: EdgeInsets.symmetric(
                    vertical: SizeConfig.blockSizeVertical),
                child: Image.asset(AppImages.back),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  width: SizeConfig.screenWidth * .15,
                ),
                // Container(
                //   margin: EdgeInsets.only(top: 40),
                //   child: TestLeftClass("assets/images/cart.png"),
                // ),
                Container(
                  width: SizeConfig.eightyPercentWidth,
                  margin: EdgeInsets.only(
                      top: SizeConfig.blockSizeVertical * 6,
                      left: SizeConfig.blockSizeHorizontal * 3),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Align(
                        alignment: Alignment.centerLeft,
                        child: _rowItemForHeaderText("Settings", 20,
                            FontWeight.w900, 0xff515C6F, 15, 4, 0),
                      ),

                      _rowItemForHeaderText("Company Name", 14, FontWeight.w700,
                          0xff8890A6, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),
                      _textInput(6,controller.companyNameController),
                      // dropDownContainer(context, CatagoryList, .75, 'One Time'),
                      _rowItemForHeaderText("Type of Business", 14,
                          FontWeight.w700, 0xff8890A6, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),
                      _textInput(6,controller.businessTypeController),
                      _rowItemForHeaderText("Category", 14, FontWeight.w700,
                          0xff8890A6, 15, 5, 0),
                      categoryDropdown(),
                      _rowItemForHeaderText("Working hours", 14,
                          FontWeight.w700, 0xff8890A6, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),
                      Row(
                        children: [
                          dropDownContainer(
                              context, CatagoryList, .27, 'All Days'),
                          Spacer(),
                          // dropDownContainer(
                          //     context, CatagoryList, .33, 'All Days'),
                        ],
                      ),
                      // _textInput(6),

                      Row(
                        children: [
                          Container(
                            width: SizeConfig.screenWidth*.33,
                            child: _rowItemForHeaderText("Opens at", 14,
                                FontWeight.w700, 0xff8890A6, 15, 4, 0),
                          ),
                          Spacer(),
                          Container(
                            width: SizeConfig.screenWidth*.33,
                            child: _rowItemForHeaderText("Closes at", 14,
                                FontWeight.w700, 0xff8890A6, 15, 4, 0),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            width: SizeConfig.screenWidth*.33,
                              child: Obx(
                                    () => Expanded(
                                    child: InkWell(
                                        onTap: () async {
                                          _selectTime(context, 'open-time');
                                        },
                                        child: dateContainer(
                                            8, controller.startTime.value=='Open Time'?"${controller.workingOpenHoursController.text}":
                                        "${controller.startTime.value}"))),
                              )
                            // child: _textInput(6,controller.workingOpenHoursController),
                          ),
                          Spacer(),
                          Container(
                            width: SizeConfig.screenWidth*.33,
                            child: Obx(
                                  () => Expanded(
                                  child: InkWell(
                                      onTap: () async {
                                        _selectTime(context, 'close-time');
                                      },
                                      child: dateContainer(
                                          8, controller.endTime.value=='Close Time'?"${controller.workingCloseHoursController.text}":
                                      "${controller.endTime.value}"))),
                            )
                          ),
                          // dropDownContainer(
                          //     context, CatagoryList, .33, 'All Days'),
                        ],
                      ),
                      _rowItemForHeaderText("Email Address", 14,
                          FontWeight.w700, 0xff8890A6, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),
                      _textInput(6,controller.emailController),
                      _rowItemForHeaderText("New Password", 14,
                          FontWeight.w700, 0xff8890A6, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),
                      _textInputPassword(6),
                      _rowItemForHeaderText(
                          "Address", 14, FontWeight.w700, 0xff8890A6, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),
                      _textInput(6,controller.addressController),
                      _rowItemForHeaderText("Mobile Number", 14,
                          FontWeight.w700, 0xff8890A6, 15, 4, 0),

                      verticalSpace(SizeConfig.blockSizeVertical),
                      _textInput(6,controller.mobileNumberController),
                      _rowItemForHeaderText("Saloon Profile Picture", 14,
                          FontWeight.w700, 0xff8890A6, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),

                      whiteBlankContainerUploadPhotos(context, .75),
                      _rowItemForHeaderText("Saloon Cover Picture", 14,
                          FontWeight.w700, 0xff8890A6, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),

                      CoverwhiteBlankContainerUploadPhotos(context, .75),

                      deleteButton(context, "Edit Profile"),
                      verticalSpace(SizeConfig.blockSizeVertical),
                    ],
                  ),
                ),
                // Column(
                //   crossAxisAlignment: CrossAxisAlignment.start,
                //   children: <Widget>[
                //   ],
                // ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget categoryDropdown() {
    return Container(
      width: SizeConfig.screenWidth * .75,
      margin: EdgeInsets.only(left: 5, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Obx(() => Container(
          width: SizeConfig.seventyFivePercentWidth,
          margin: EdgeInsets.only(top: 0, left: 10, bottom: 5),
          child: DropdownButton(
            underline: SizedBox(),
            hint: Text(
              '${controller.selectedCatName.value}',
              style: TextStyle(color: Color(0xff515C6F)),
            ),
            isExpanded: true,
            iconSize: 30.0,
            // icon: Image.asset(AppImages.dropdown_field_ic),
            style: TextStyle(
                color: Color(0xff8890A6),
                fontSize: 14,
                fontWeight: FontWeight.w600),
            items: AppStrings.allCategoriesNamesListAppStrings.map(
                  (val) {
                return DropdownMenuItem<String>(
                  value: val,
                  child: Text(val),
                );
              },
            ).toList(),
            onChanged: (val) {
              controller.selectedCatName.value = val as String;
            },
          ))),
    );
  }

  Widget dropDownContainer(
      BuildContext context, List<String> values, double width, String text) {
    return Card(
      elevation: 1,
      child: Container(
        width: SizeConfig.screenWidth * width,
        // height: SizeConfig.blockSizeVertical * 6,
        margin: EdgeInsets.only(left: 15, top: 10),
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            DropDownWithoutBorder(values, text),
          ],
        ),
      ),
    );
  }

  Widget whiteInputContainer(
      BuildContext context, String values, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
              child: Text(
                values,
                style: TextStyle(
                    color: ColorsX.black,
                    fontSize: 14,
                    fontWeight: FontWeight.w700),
              )),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget _textInput(int height, TextEditingController ctl) {
    return Card(
      elevation: 1,
      child: Container(
        margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 5),
        height: SizeConfig.blockSizeVertical * height,
        // width: SizeConfig.blockSizeHorizontal * 30,
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: TextFormField(
          controller: ctl,
          // obscureText: isPassword,
          // keyboardType: inputType,
          cursorColor: Colors.white,
          textAlign: TextAlign.start,
          style: TextStyle(color: Colors.black, fontSize: 16),
          decoration: InputDecoration(
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
            contentPadding: EdgeInsets.only(right: 5),
            hintStyle: TextStyle(color: Colors.black, fontSize: 16),
            errorBorder: InputBorder.none,
            disabledBorder: InputBorder.none,
            // hintText: "Test Text",
          ),
        ),
      ),
    );
  }

  Widget _textInputPassword(int height) {
    return Card(
      elevation: 1,
      child: Container(
        margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 5),
        height: SizeConfig.blockSizeVertical * height,
        // width: SizeConfig.blockSizeHorizontal * 30,
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: TextFormField(
          // controller: ctl,
          obscureText: true,
          // keyboardType: inputType,
          cursorColor: Colors.white,
          textAlign: TextAlign.start,
          style: TextStyle(color: Colors.black, fontSize: 16),
          decoration: InputDecoration(
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
            contentPadding: EdgeInsets.all(9),
            hintStyle: TextStyle(color: Colors.black, fontSize: 16),
            errorBorder: InputBorder.none,
            disabledBorder: InputBorder.none,
            // hintText: "Test Text",
          ),
        ),
      ),
    );
  }

  Widget dateContainer(int height, String date) {
    return Container(
        height: SizeConfig.blockSizeVertical * height,
        width: SizeConfig.screenWidth * .33,
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(AppImages.calender_picker_ic),
            horizontalSpace(
              SizeConfig.blockSizeHorizontal * 2,
            ),
            _rowItemForHeaderText(
                date, 16, FontWeight.normal, 0xFF000000, 0, 0, 0)
          ],
        ));
  }

  Widget deleteButton(BuildContext context, String text) {
    return GestureDetector(
      onTap: (){
        if(controller.companyNameController.text.isEmpty){
          Functions.showErrorToast(context, "Required", "Company Name is Required");
        }else if(controller.businessTypeController.text.isEmpty){
          Functions.showErrorToast(context, "Required", "Business Type is Required");
        }else if(controller.emailController.text.isEmpty){
          Functions.showErrorToast(context, "Required", "Email is Required");
        }else if(controller.addressController.text.isEmpty){
          Functions.showErrorToast(context, "Required", "Address is Required");
        }else if(controller.mobileNumberController.text.isEmpty){
          Functions.showErrorToast(context, "Required", "Mobile Number is Required");
        }else{
          String companyName = controller.companyNameController.text;
          String businessType = controller.businessTypeController.text;
          String email = controller.emailController.text;
          String password = controller.passwordController.text;
          String address = controller.addressController.text;
          String mobileNumber = controller.mobileNumberController.text;
          String openTime = controller.startTime.value=='Open Time'?"${controller.workingOpenHoursController.text}":
          "${controller.startTime.value}";
          String closeTime = controller.endTime.value=='Close Time'?"${controller.workingCloseHoursController.text}":
          "${controller.endTime.value}";
          AdminLoginController adminLoginController = Get.find();
          String id = "${adminLoginController.adminLoginRes?.saloon.id}";
          adminLoginController.adminLoginRes?.saloon.saloon.address?.address =  address;
          String categoryId = controller.getSelectedCategory();


          Map<String, String> params = Map();

          if(controller.pickedImage==null)
          {
            params['Name'] = companyName;
            params['Business_Type'] = businessType;
            params['Open_Time'] = openTime;
            params['Close_Time'] = closeTime;
            params['Email'] = email;
            params['Password'] = password;
            // params['Address'] = adminLoginController.adminLoginRes?.saloon.saloon.address?.toJson().toString()??"";
            params['Mobile_number'] = mobileNumber;
            params['id'] = id;
            params['Category'] = categoryId;

            print(params);
            controller.adminUpdateSaloon(apiParams: params);
          }
          else{
            params['Name'] = companyName;
            params['Business_Type'] = businessType;
            params['Open_Time'] = openTime;
            params['Close_Time'] = closeTime;
            params['Email'] = email;
            params['Password'] = password;
            // params['Address'] = adminLoginController.adminLoginRes?.saloon.saloon.address?.toJson().toString()??"";
            params['Mobile_number'] = mobileNumber;
            // params['Profile_Pic'] = controller.pickedImage;
            params['id'] = id;
            params['Category'] = categoryId;

            print(params);
            controller.adminUpdateSaloon(apiParams: params);
          }

        }
      },
      child: Container(
          width: SizeConfig.screenWidth * .82,
          margin: EdgeInsets.only(left: 0, top: 15, bottom: 0),
          decoration: new BoxDecoration(
              color: ColorsX.white,
              borderRadius: BorderRadius.all(Radius.circular(10)),
              // boxShadow: [
              //   BoxShadow(
              //     color: text == "View More"
              //         ? ColorsX.blue_button_color
              //         : Colors.red,
              //     blurRadius: 6,
              //     offset: Offset(1, 1), // Shadow position
              //   ),
              // ],
              border: Border.all()),
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: ColorsX.black),
          )),
    );
  }


  Future<void> _selectTime(BuildContext context, String status) async {
    TimeOfDay selectedTime = TimeOfDay.now();
    final TimeOfDay? picked_s = await showTimePicker(
        context: context,
        initialTime: selectedTime,
        builder: (BuildContext? context, Widget? child) {
          return MediaQuery(
            data:
            MediaQuery.of(context!).copyWith(alwaysUse24HourFormat: false),
            child: child!,
          );
        });

    if (picked_s != null) {
      if (status == 'open-time') {
        controller.startTime.value = picked_s.format(context).toString();
      } else if (status == 'close-time') {
        controller.endTime.value = picked_s.format(context).toString();
      }

      print(picked_s.format(context));
    }
  }


  Widget whiteBlankContainer(BuildContext context, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
            child: Container(
              height: 60,
            ),
          ),
          // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget whiteBlankContainerUploadPhotos(BuildContext context, double width) {
    return Card(
      elevation: 1,
      child: Container(
        width: SizeConfig.screenWidth * width,
        margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal, top: 10),
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(left: 0, top: 17, bottom: 17, right: 10),
              child: Container(
                height: 60,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                          color: ColorsX.blue_text_color,
                          shape: BoxShape.circle),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ClipRRect(
                          borderRadius: new BorderRadius.circular(10.0),
                          child: Image.asset(
                            "assets/images/gallery.png",
                            height: 30,
                            width: 30,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: ColorsX.blue_button_color,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                child: Icon(
                                  Icons.add_circle,
                                  color: ColorsX.white,
                                  size: 14,
                                ),
                                margin: EdgeInsets.only(
                                    top: 10, bottom: 10, left: 15, right: 15),
                              ),
                              GestureDetector(
                                onTap: (){
                                  print("Add photos clicked");
                                  _takePicture();
                                },
                                child: Container(
                                    margin: EdgeInsets.only(right: 15),
                                    child: Text(
                                      "Add Photos",
                                      style: TextStyle(
                                          color: ColorsX.white,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 12),
                                    )),
                              ),
                            ],
                          ),
                        ),
                        _rowItemForHeaderText("(Max limit 5mb per image)", 8,
                            FontWeight.w400, 0xff000000, 10, 0, 0),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
            // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
          ],
        ),
      ),
    );
  }
  Widget CoverwhiteBlankContainerUploadPhotos(BuildContext context, double width) {
    return Card(
      elevation: 1,
      child: Container(
        width: SizeConfig.screenWidth * width,
        margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal, top: 10),
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(left: 0, top: 17, bottom: 17, right: 10),
              child: Container(
                height: 60,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                          color: ColorsX.blue_text_color,
                          shape: BoxShape.circle),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ClipRRect(
                          borderRadius: new BorderRadius.circular(10.0),
                          child: Image.asset(
                            "assets/images/gallery.png",
                            height: 30,
                            width: 30,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                            color: ColorsX.blue_button_color,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                child: Icon(
                                  Icons.add_circle,
                                  color: ColorsX.white,
                                  size: 14,
                                ),
                                margin: EdgeInsets.only(
                                    top: 10, bottom: 10, left: 15, right: 15),
                              ),
                              GestureDetector(
                                onTap: (){
                                  print("Add photos clicked");
                                  _takeCoverPicture();
                                },
                                child: Container(
                                    margin: EdgeInsets.only(right: 15),
                                    child: Text(
                                      "Add Photos",
                                      style: TextStyle(
                                          color: ColorsX.white,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 12),
                                    )),
                              ),
                            ],
                          ),
                        ),
                        _rowItemForHeaderText("(Max limit 5mb per image)", 8,
                            FontWeight.w400, 0xff000000, 10, 0, 0),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
            // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
          ],
        ),
      ),
    );
  }

  Widget _offsetPopup() => PopupMenuButton<int>(
        color: ColorsX.subBlack,
        itemBuilder: (context) => [
          PopupMenuItem(
            value: 1,
            child: InkWell(
                onTap: () {
                  print("clicked");
                },
                child: _rowItemForHeaderText("Add New Product", 10,
                    FontWeight.w700, 0xffffffff, 0, 0, 0)),
          ),
          // PopupMenuItem(
          //   value: 2,
          //   child: _rowItemForHeaderText("Preferences", 10, FontWeight.w700, 0xffffffff, 0, 0, 0),
          // ),
        ],
        icon: Container(
          height: double.infinity,
          width: double.infinity,
          decoration: ShapeDecoration(
              color: ColorsX.blue_text_color,
              shape: StadiumBorder(
                side: BorderSide(color: ColorsX.blue_text_color, width: 2),
              )),
          child: Image.asset(
              "assets/images/floating2.png"), // <-- You can give your icon here
        ),
      );
  Widget simpleContainer(BuildContext context, String firstText,
      String secondText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(
                  firstText, 10, FontWeight.w700, 0xffe1e1e1, 15, 10, 0),
              Container(
                width: SizeConfig.sixtyFivePercentWidth,
                child: _rowItemForHeaderText(
                    secondText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),
              ),
              SizedBox(
                height: 15,
              )
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(right: 10, top: 10),
                child: Image.asset(imagePath),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _imageHere(
    BuildContext context,
    String imagePath,
  ) {
    return Container(
      margin: EdgeInsets.only(left: 10, top: 15),
      child: ClipRRect(
        borderRadius: new BorderRadius.circular(10.0),
        child: Image(
          fit: BoxFit.cover,
          image: AssetImage(imagePath),
          width: SizeConfig.seventyFivePercentWidth,
          height: 200.0,
        ),
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 20, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 20, FontWeight.w900, 0xff515C6F, 0, 0, 0),
          Image.asset(
            imagePath,
            height: 21,
            width: 17,
          ),
        ],
      ),
    );
  }

  Widget _search(BuildContext context) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      padding: EdgeInsets.only(left: 8, right: 3),
      decoration: new BoxDecoration(
          color: ColorsX.greydashboard,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: 0, right: 15, left: 10),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.text,
        obscureText: false,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1, //Normal textInputField will be disp
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(top: 15, left: 2),

          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          suffixIcon: Icon(
            Icons.search_rounded,
            color: ColorsX.dash_textColor,
          ),
          hintText: "Search",
          hintStyle: TextStyle(color: ColorsX.subBlack),
          // labelStyle: TextStyle(
          //     fontSize: 13,
          //     color: ColorsX.white,
          //     fontWeight: FontWeight.bold),
          // labelText: 'Email',
        ),
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    margin: EdgeInsets.only(left: 2, top: 2),
                    decoration: new BoxDecoration(
                      color: ColorsX.rating_dashboard,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          bottomRight: Radius.circular(30)),
                    ),
                    child: _rowItemForHeaderText(
                        " 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }

  Future<void>? _takePicture() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      controller.pickedImage = Io.File(image.path);
      controller.isPickSelected.toggle();
      print('image selected. ${controller.pickedImage}');
    } else {
      print('No image selected.');
    }

    // controller.imageFile = File(image.path);
  }
  Future<void>? _takeCoverPicture() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      controller.PickedImageCover?.add(Io.File(image.path));
      controller.isPickSelectedCover.toggle();
      print('image selected. ${controller.PickedImageCover}');
    } else {
      print('No image selected.');
    }

    // controller.imageFile = File(image.path);
  }

  Widget _getImageWidget() {
    if (controller.pickedImage != null) {
      return Container(
        width: 170.0,
        height: 170.0,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(100.0),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(100.0),
          child: Image.file(
            controller.pickedImage!,
            width: 170,
            height: 170,
            fit: BoxFit.fill,
          ),
        ),
      );
    } else if (controller.pickedImage == null) {
      return Image.asset("assets/images/nodp_img.png");
    }
    return Container();
  }

}
