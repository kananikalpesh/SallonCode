// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/views/settings_screen.dart';



class SettingsNavigation {
  SettingsNavigation._();
  static const id = 50;
  static const addOnsList = '/add-ons-list';
  static const addOnsDetail = '/add-ons-Detail';
  static const AddNewaddOns = '/new-add-ons-Detail';

}
// our wrapper, where our main navigation will navigate to
class SettingsWrapper extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Navigator(

      key: Get.nestedKey(SettingsNavigation.id),
      onGenerateRoute: (settings) {
        // navigate to a route by name with settings.name
        if (settings.name == SettingsNavigation.addOnsDetail) {
          return GetPageRoute(
            routeName: SettingsNavigation.addOnsDetail,
            page: () => SaloonSettings(

            ),
          );
        }

        else if (settings.name == SettingsNavigation.AddNewaddOns) {
          return GetPageRoute(
            routeName: SettingsNavigation.AddNewaddOns,
            page: () => SaloonSettings(

            ),
          );
        }


        else {
          return GetPageRoute(
            routeName: SettingsNavigation.addOnsList,
            page: () => SaloonSettings(

            ),
          );
        }
      },
    );
  }
}