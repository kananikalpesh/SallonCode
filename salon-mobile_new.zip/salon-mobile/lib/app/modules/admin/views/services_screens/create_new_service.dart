import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-services/services-admin-list-and-add-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/add-on-tabs.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/reusable-dropdown.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class CreateNewService extends GetView<ServicesAdminListAddCTL> {
  List<String> timeLimit = [
    'Beauty Shop & SPA',
    'Beauty Shop & SPA',
    'Beauty Shop & SPA'
  ];
  List<String> ServiceList = ['Manicure, Pedicure', 'Pedicure', 'Manicure'];
  // List<String> CatagoryList = ['One Time', 'Twice', 'Weekly'];

  List<String> DiscountList = ['10%', '20%', '30%'];
  @override
  Widget build(BuildContext context) {
    controller.serviceNameController.text="";
    controller.priceController.text="";
    controller.descriptionController.text="";
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: <Widget>[
            Container(
              height: SizeConfig.screenHeight,
              width: SizeConfig.screenWidth,
              margin: EdgeInsets.only(top: 175),
              // color: ColorsX.dashboardColor,
            ),
            Container(
              margin: EdgeInsets.only(
                  left: SizeConfig.blockSizeHorizontal * 5,
                  top: SizeConfig.blockSizeVertical * 7),
              child: Padding(
                padding: EdgeInsets.symmetric(
                    vertical: SizeConfig.blockSizeVertical),
                child: Image.asset(AppImages.back),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  width: SizeConfig.screenWidth * .15,
                ),
                // Container(
                //   margin: EdgeInsets.only(top: 40),
                //   child: TestLeftClass("assets/images/cart.png"),
                // ),
                Container(
                  width: SizeConfig.eightyPercentWidth,
                  margin: EdgeInsets.only(
                      top: SizeConfig.blockSizeVertical * 6,
                      left: SizeConfig.blockSizeHorizontal * 3),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Align(
                        alignment: Alignment.centerLeft,
                        child: _rowItemForHeaderText("Add New Service", 20,
                            FontWeight.w900, 0xff515C6F, 15, 4, 0),
                      ),

                      _rowItemForHeaderText("Choose Category", 14,
                          FontWeight.w700, 0xff8890A6, 15, 4, 0),
                      Obx(()=>Container(
                          // constraints: BoxConstraints(
                          //   minHeight: SizeConfig.blockSizeVertical * 4,
                          //   maxHeight: 50.0,
                          // ),
                          // padding: EdgeInsets.all(0.0),
                          // height: SizeConfig.blockSizeVertical * 3,
                          child: Card(
                            elevation: 1,
                            child: Container(
                              width: SizeConfig.screenWidth * .75,
                              // height: SizeConfig.blockSizeVertical * 6,
                              margin: EdgeInsets.only(left: 15, top: 10),
                              decoration: new BoxDecoration(
                                color: ColorsX.white,
                                borderRadius: BorderRadius.all(Radius.circular(10)),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[

                                  DropdownButton<String>(
                                    hint: Text(controller.chosenCatrgory.value),
                                    underline: SizedBox(),
                                    value: controller.chosenCatrgory.value,
                                    //elevation: 5,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 14),
                                    icon: Container(
                                      margin: EdgeInsets.only(left: SizeConfig.screenWidth*.55),
                                      child: Icon(Icons.arrow_drop_down),
                                    ),
                                    items: controller.catagoryList.map<DropdownMenuItem<String>>(
                                            (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  right:
                                                  SizeConfig.marginVerticalXXsmall),
                                              child: Text(value),
                                            ),
                                          );
                                        }).toList(),
                                    onChanged: (value) {
                                      controller.chosenCatrgory.value = value!;
                                      // for(int index=0; index<controller.catagoryList.length; index++){
                                      //   controller.chosenCatrgoryID.value = "${controller.filterCategoryRes?.categories[index].id}";
                                      // }
                                      controller.chosenCatrgoryID.value = getSelectedCategory();
                                      // getSelectedCategory();
                                      print(controller.chosenCatrgory.value);
                                      print(controller.chosenCatrgoryID.value);
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      _rowItemForHeaderText("Service Name", 14, FontWeight.w700,
                          0xff8890A6, SizeConfig.blockSizeVertical * 2, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical * 2),
                      // whiteInputContainer(context, "Extreme Moisturiser", .75),
                      _textInput(6, controller.serviceNameController),
                      _rowItemForHeaderText("Duration of Service", 14,
                          FontWeight.w700, 0xff8890A6, 15, 4, 0),
                      Obx(()=>
                        Container(
                          // constraints: BoxConstraints(
                          //   minHeight: SizeConfig.blockSizeVertical * 4,
                          //   maxHeight: 50.0,
                          // ),
                          // padding: EdgeInsets.all(0.0),
                          // height: SizeConfig.blockSizeVertical * 3,
                          child: Card(
                            elevation: 1,
                            child: Container(
                              width: SizeConfig.screenWidth * .75,
                              // height: SizeConfig.blockSizeVertical * 6,
                              margin: EdgeInsets.only(left: 15, top: 10),
                              decoration: new BoxDecoration(
                                color: ColorsX.white,
                                borderRadius: BorderRadius.all(Radius.circular(10)),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[

                                  DropdownButton<String>(
                                    hint: Text(controller.chosenDuration.value),
                                    underline: SizedBox(),
                                    value: controller.chosenDuration.value,
                                    //elevation: 5,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 14),
                                    icon: Container(
                                      margin: EdgeInsets.only(left: SizeConfig.screenWidth*.57),
                                      child: Icon(Icons.arrow_drop_down),
                                    ),
                                    items: controller.TimeLimitList.map<DropdownMenuItem<String>>(
                                            (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  right:
                                                  SizeConfig.marginVerticalXXsmall),
                                              child: Text(value),
                                            ),
                                          );
                                        }).toList(),
                                    onChanged: (value) {
                                      controller.chosenDuration.value = value!;
                                      print(controller.chosenDuration.value);
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      // dropDownContainerReusable(context, controller.TimeLimitList, .75, '20',"duration"),
                      // _rowItemForHeaderText("Discount", 14, FontWeight.w700,
                      //     0xff8890A6, 15, 4, 0),
                      //
                      // dropDownContainer(context, DiscountList, .75, '20%'),
                      _rowItemForHeaderText(
                          "Price", 14, FontWeight.w700, 0xff8890A6, 15, 4, 0),

                      Row(
                        children: [
                          Expanded(child: _textInput(8, controller.priceController)),
                          Obx(()=>
                            Container(
                              // constraints: BoxConstraints(
                              //   minHeight: SizeConfig.blockSizeVertical * 4,
                              //   maxHeight: 50.0,
                              // ),
                              // padding: EdgeInsets.all(0.0),
                              // height: SizeConfig.blockSizeVertical * 3,
                              child: Card(
                                elevation: 1,
                                child: Container(
                                  width: SizeConfig.screenWidth * .2,
                                  // height: SizeConfig.blockSizeVertical * 6,
                                  margin: EdgeInsets.only(left: 15, top: 10),
                                  decoration: new BoxDecoration(
                                    color: ColorsX.white,
                                    borderRadius: BorderRadius.all(Radius.circular(10)),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: <Widget>[

                                      DropdownButton<String>(
                                        hint: Text(controller.chosenPrefix.value),
                                        underline: SizedBox(),
                                        value: controller.chosenPrefix.value,
                                        //elevation: 5,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 14),
                                        icon: Container(
                                          margin: EdgeInsets.only(left: SizeConfig.screenWidth*.019),
                                          child: Icon(Icons.arrow_drop_down),
                                        ),
                                        items: controller.currencies.map<DropdownMenuItem<String>>(
                                                (String value) {
                                              return DropdownMenuItem<String>(
                                                value: value,
                                                child: Padding(
                                                  padding: EdgeInsets.only(
                                                      right:
                                                      SizeConfig.marginVerticalXXsmall),
                                                  child: Text(value),
                                                ),
                                              );
                                            }).toList(),
                                        onChanged: (value) {
                                          controller.chosenPrefix.value = value!;
                                          print(controller.chosenPrefix.value);
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          // dropDownContainerReusable(context, controller.currencies, .2, 'USD',"payment"),
                        ],
                      ),

                      _rowItemForHeaderText("Description", 14, FontWeight.w700,
                          0xff8890A6, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),

                      _textInput(12, controller.descriptionController),

                      deleteButton(context, "Create Service"),
                    ],
                  ),
                ),
                // Column(
                //   crossAxisAlignment: CrossAxisAlignment.start,
                //   children: <Widget>[
                //   ],
                // ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  String getSelectedCategory() {
    return controller.filterCategoryRes?.categories
        .firstWhere((cat) => cat.title == controller.chosenCatrgory.value)
        .id;
  }
  Widget dropDownContainerReusable(
      BuildContext context, List<String> values, double width, String text, String type) {
    if(type=="category"){
      controller.chosenCatrgory.value = controller.catagoryList[0];
      print(controller.chosenCatrgory.value);
    }if(type=="duration"){
      controller.chosenDuration.value = controller.TimeLimitList[0];
      print(controller.chosenDuration.value);
    }if(type=="payment"){
      controller.chosenPrefix.value = controller.currencies[0];
      print(controller.chosenPrefix.value);
    }
    return Card(
      elevation: 1,
      child: Container(
        width: SizeConfig.screenWidth * width,
        // height: SizeConfig.blockSizeVertical * 6,
        margin: EdgeInsets.only(left: 15, top: 10),
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            ReusableDropDown(values, text, type),
          ],
        ),
      ),
    );
  }


  Widget dropDownContainer(
      BuildContext context, List<String> values, double width, String text) {
    return Card(
      elevation: 1,
      child: Container(
        width: SizeConfig.screenWidth * width,
        // height: SizeConfig.blockSizeVertical * 6,
        margin: EdgeInsets.only(left: 15, top: 10),
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            DropDownWithoutBorder(values, text, ),
          ],
        ),
      ),
    );
  }

  Widget whiteInputContainer(
      BuildContext context, String values, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
              child: Text(
                values,
                style: TextStyle(
                    color: ColorsX.black,
                    fontSize: 14,
                    fontWeight: FontWeight.w700),
              )),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget _textInput(int height, TextEditingController ctl) {
    return Card(
      elevation: 1,
      child: Container(
        margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 5),
        height: SizeConfig.blockSizeVertical * height,
        // width: SizeConfig.blockSizeHorizontal * 30,
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: TextFormField(
          controller: ctl,
          // obscureText: isPassword,
          // keyboardType: inputType,
          cursorColor: Colors.white,
          textAlign: TextAlign.start,
          style: TextStyle(color: Colors.black, fontSize: 16),
          decoration: InputDecoration(
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
            contentPadding: EdgeInsets.all(9),
            hintStyle: TextStyle(color: Colors.black, fontSize: 16),
            errorBorder: InputBorder.none,
            disabledBorder: InputBorder.none,
            hintText: "",
          ),
        ),
      ),
    );
  }

  Widget dateContainer(int height, String date) {
    return Container(
        margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 5),
        height: SizeConfig.blockSizeVertical * height,
        // width: SizeConfig.blockSizeHorizontal * 30,
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(AppImages.calender_picker_ic),
            horizontalSpace(
              SizeConfig.blockSizeHorizontal * 2,
            ),
            _rowItemForHeaderText(
                date, 16, FontWeight.normal, 0xFF000000, 0, 0, 0)
          ],
        ));
  }

  Widget deleteButton(BuildContext context, String text) {
    return GestureDetector(
      onTap: (){
        print("clicked");
        print(controller.chosenCatrgory.value);
        print(controller.chosenDuration.value);
        AdminLoginController adminLoginController = Get.find();

        Functions.hideKeyboard(context);
        String serviceName = controller.serviceNameController.text;
        String description = controller.descriptionController.text;
        String time_required = controller.chosenDuration.value;
        String price = controller.priceController.text;
        String category = controller.chosenCatrgoryID.value;
        String saloon = adminLoginController.adminLoginRes?.saloon.id;
        String prefix = controller.chosenPrefix.value;
        if(serviceName.isEmpty){
          Functions.showErrorToast(context, "Required", "Service Name field is required");
        }
        else if(price.isEmpty){
          Functions.showErrorToast(context, "Required", "Price field is required");
        } else if(description.isEmpty){
          Functions.showErrorToast(context, "Required", "Description field is required");
        }else{

          Map<String,dynamic> serviceInfo = Map();
          serviceInfo['Name'] = serviceName;
          serviceInfo['Description'] = description;
          serviceInfo['Time_required'] = time_required;
          serviceInfo['Price'] = price;
          serviceInfo['Category'] = category;
          serviceInfo['Saloon'] = saloon;
          serviceInfo['Prefix'] = prefix;

          print(serviceInfo);
          controller.adminAddService(apiParams: serviceInfo);
        }

      },
      child: Container(
          width: SizeConfig.screenWidth * .85,
          margin: EdgeInsets.only(left: 0, top: 15, bottom: 0),
          decoration: new BoxDecoration(
            color: ColorsX.blue_button_color,
            borderRadius: BorderRadius.all(Radius.circular(10)),
            // boxShadow: [
            //   BoxShadow(
            //     color: text == "View More"
            //         ? ColorsX.blue_button_color
            //         : Colors.red,
            //     blurRadius: 6,
            //     offset: Offset(1, 1), // Shadow position
            //   ),
            // ],
          ),
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Color(0xffffffff)),
          )),
    );
  }

  Widget whiteBlankContainer(BuildContext context, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
            child: Container(
              height: 60,
            ),
          ),
          // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget whiteBlankContainerUploadPhotos(BuildContext context, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
            child: Container(
              height: 60,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                        color: ColorsX.blue_text_color, shape: BoxShape.circle),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ClipRRect(
                        borderRadius: new BorderRadius.circular(10.0),
                        child: Image.asset(
                          "assets/images/gallery.png",
                          height: 30,
                          width: 30,
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        decoration: BoxDecoration(
                          color: ColorsX.blue_button_color,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              child: Icon(
                                Icons.add_circle,
                                color: ColorsX.white,
                                size: 14,
                              ),
                              margin: EdgeInsets.only(
                                  top: 10, bottom: 10, left: 15, right: 15),
                            ),
                            Container(
                                margin: EdgeInsets.only(right: 15),
                                child: Text(
                                  "Add Photos",
                                  style: TextStyle(
                                      color: ColorsX.white,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 12),
                                )),
                          ],
                        ),
                      ),
                      _rowItemForHeaderText("(Max limit 5mb per image)", 8,
                          FontWeight.w400, 0xff000000, 10, 0, 0),
                    ],
                  ),
                ],
              ),
            ),
          ),
          // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget _offsetPopup() => PopupMenuButton<int>(
        color: ColorsX.subBlack,
        itemBuilder: (context) => [
          PopupMenuItem(
            value: 1,
            child: InkWell(
                onTap: () {
                  print("clicked");
                },
                child: _rowItemForHeaderText("Add New Product", 10,
                    FontWeight.w700, 0xffffffff, 0, 0, 0)),
          ),
          // PopupMenuItem(
          //   value: 2,
          //   child: _rowItemForHeaderText("Preferences", 10, FontWeight.w700, 0xffffffff, 0, 0, 0),
          // ),
        ],
        icon: Container(
          height: double.infinity,
          width: double.infinity,
          decoration: ShapeDecoration(
              color: ColorsX.blue_text_color,
              shape: StadiumBorder(
                side: BorderSide(color: ColorsX.blue_text_color, width: 2),
              )),
          child: Image.asset(
              "assets/images/floating2.png"), // <-- You can give your icon here
        ),
      );
  Widget simpleContainer(BuildContext context, String firstText,
      String secondText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(
                  firstText, 10, FontWeight.w700, 0xffe1e1e1, 15, 10, 0),
              Container(
                width: SizeConfig.sixtyFivePercentWidth,
                child: _rowItemForHeaderText(
                    secondText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),
              ),
              SizedBox(
                height: 15,
              )
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(right: 10, top: 10),
                child: Image.asset(imagePath),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _imageHere(
    BuildContext context,
    String imagePath,
  ) {
    return Container(
      margin: EdgeInsets.only(left: 10, top: 15),
      child: ClipRRect(
        borderRadius: new BorderRadius.circular(10.0),
        child: Image(
          fit: BoxFit.cover,
          image: AssetImage(imagePath),
          width: SizeConfig.seventyFivePercentWidth,
          height: 200.0,
        ),
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 20, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 20, FontWeight.w900, 0xff515C6F, 0, 0, 0),
          Image.asset(
            imagePath,
            height: 21,
            width: 17,
          ),
        ],
      ),
    );
  }

  Widget _search(BuildContext context) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      padding: EdgeInsets.only(left: 8, right: 3),
      decoration: new BoxDecoration(
          color: ColorsX.greydashboard,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: 0, right: 15, left: 10),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.text,
        obscureText: false,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1, //Normal textInputField will be disp
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(top: 15, left: 2),

          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          suffixIcon: Icon(
            Icons.search_rounded,
            color: ColorsX.dash_textColor,
          ),
          hintText: "Search",
          hintStyle: TextStyle(color: ColorsX.subBlack),
          // labelStyle: TextStyle(
          //     fontSize: 13,
          //     color: ColorsX.white,
          //     fontWeight: FontWeight.bold),
          // labelText: 'Email',
        ),
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    margin: EdgeInsets.only(left: 2, top: 2),
                    decoration: new BoxDecoration(
                      color: ColorsX.rating_dashboard,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          bottomRight: Radius.circular(30)),
                    ),
                    child: _rowItemForHeaderText(
                        " 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
