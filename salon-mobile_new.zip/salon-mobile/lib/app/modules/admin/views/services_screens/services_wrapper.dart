// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/bindings/admin_binding.dart';
import 'package:saloon_app/app/modules/admin/views/services_screens/servicec_list.dart';

import 'create_new_service.dart';






class AdminServiceNavigation {
  AdminServiceNavigation._();
  static const id = 16;
  static const servicesList = '/services-list';
  static const createNewService = '/create-new-services';


}
// our wrapper, where our main navigation will navigate to
class AdminServiceWrapper extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Navigator(
      
      key: Get.nestedKey(AdminServiceNavigation.id),
      onGenerateRoute: (settings) {
        // navigate to a route by name with settings.name
        if (settings.name == AdminServiceNavigation.createNewService) {
          return GetPageRoute(
            routeName: AdminServiceNavigation.createNewService,
            page: () => CreateNewService(
            ),
            binding: AdminBinding()
          );
        } 
        
        else {
          return GetPageRoute(
            routeName: AdminServiceNavigation.servicesList,
            page: () => ServiceListOnDash(
              
            ),
          );
        }
      },
    );
  }
}