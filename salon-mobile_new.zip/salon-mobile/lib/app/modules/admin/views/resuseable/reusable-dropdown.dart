import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-services/services-admin-list-and-add-ctl.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class ReusableDropDown extends StatefulWidget {
  List<String> strArr;
  String TextShow;
  String type;
  ReusableDropDown(this.strArr, this.TextShow, this.type);
  @override
  _MyDropDown createState() => _MyDropDown();
}

class _MyDropDown extends State<ReusableDropDown> {
  String? _dropDownValue;
  String? textShow;
  String? type;
  List<String>? strArr;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(top: 0, left: 10, bottom: 5),
        child: DropdownButton(
          underline: SizedBox(),
          hint: _dropDownValue == null
              ? Text(widget.TextShow, style: TextStyle(color: Color(0xff515c6f)),)
              : Text(
            '$_dropDownValue',
            style: TextStyle(color: Color(0xff515C6F)),
          ),
          isExpanded: true,
          iconSize: 30.0,
          // icon: Image.asset(AppImages.dropdown_field_ic),
          style: TextStyle(
              color: Color(0xff8890A6),
              fontSize: 14,
              fontWeight: FontWeight.w600),
          items: this.widget.strArr.map(
                (val) {
              return DropdownMenuItem<String>(
                value: val,
                child: Text(val),
              );
            },
          ).toList(),
          onChanged: (val) {
            setState(
                  () {
                _dropDownValue = val as String;

                ServicesAdminListAddCTL servicesAdminListAddCTL = Get.find();
                if(type == "category"){
                  servicesAdminListAddCTL.chosenCatrgory.value = _dropDownValue!;
                  print(servicesAdminListAddCTL.chosenCatrgory.value);
                  print(servicesAdminListAddCTL.chosenCatrgory);
                }
                if(type == "duration"){
                  servicesAdminListAddCTL.chosenDuration.value = _dropDownValue!;
                  print(servicesAdminListAddCTL.chosenDuration.value);
                  print(servicesAdminListAddCTL.chosenDuration);
                }
                if(type == "payment"){
                  servicesAdminListAddCTL.chosenPrefix.value = _dropDownValue!;
                  print(servicesAdminListAddCTL.chosenPrefix.value);
                  print(servicesAdminListAddCTL.chosenPrefix);
                }
              },
            );
          },
        )
    );


  }
}
