
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/admin/views/reports.dart';
import 'package:saloon_app/app/modules/admin/views/sales.dart';
import 'package:saloon_app/app/utils/size_config.dart';



class TabBarDashboard extends StatefulWidget {
  @override
  _DemoState createState() => _DemoState();
}

class _DemoState extends State<TabBarDashboard>
    with TickerProviderStateMixin {
  TabController ?_tabController;

  @override
  void initState() {
// TODO: implement initState
    super.initState();
    _tabController = new TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController?.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return  Column(
      children: <Widget>[
        Container(
          height: 50,
          // color: ColorsX.greydashboard,
          child: TabBar(
            tabs: [
              Container(
                  width: SizeConfig.twentyPercentWidth,
                  child: Text("Sales",textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, ),)
              ),
              Container(
                  width: SizeConfig.thirtyPercentWidth,
                  child: Text("Reports", textAlign: TextAlign.center,style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, ),)
              ),
              // Container(
              //     width: SizeConfig.thirtyPercentWidth,
              //     child: Text("Shampoos", textAlign: TextAlign.center,style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, ),)
              // ),
              // Container(
              //     width: SizeConfig.twentyPercentWidth,
              //     child: Text("Creams", textAlign: TextAlign.center,style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, ),)
              // ),
            ],
            unselectedLabelColor: const Color(0xff000000),
            indicatorColor: Color(0xff70b4ff),
            labelColor: Color(0xff70b4ff),
            indicatorSize: TabBarIndicatorSize.tab,
            indicatorWeight: 3.0,
            indicatorPadding: EdgeInsets.only(top: 40),
            isScrollable: true,
            controller: _tabController,
          ),
        ),
        Expanded(
          child: TabBarView(
              controller: _tabController,
              children: <Widget>[
                Container(
                  child: Sales(),
                ),
                Container(
                    child: Reports()
                ),
              ]
          ),
        ),
      ],
    );
  }
}
Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
  return Container(
    margin: EdgeInsets.only(top: top, left: left, right: right),
    child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
  );
}


//
// class TabBarDashboard extends StatefulWidget {
//   @override
//   _DemoState createState() => _DemoState();
// }
//
// class _DemoState extends State<TabBarDashboard>
//     with TickerProviderStateMixin {
//   TabController ?_tabController;
//
//   @override
//   void initState() {
// // TODO: implement initState
//     super.initState();
//     _tabController = new TabController(length: 2, vsync: this);
//   }
//
//   @override
//   void dispose() {
//     _tabController?.dispose();
//     super.dispose();
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: <Widget>[
//         Container(
//           height: 55,
//           color: ColorsX.greydashboard,
//           child: TabBar(
//             tabs: [
//
//               Container(
//                   width: SizeConfig.thirtyPercentWidth,
//                   child: Text("Sales",textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400,),)
//               ),
//               Container(
//                   width: SizeConfig.thirtyPercentWidth,
//                   child: Text("Reports", textAlign: TextAlign.center,style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400,),)
//               )
//             ],
//             unselectedLabelColor: const Color(0xff000000),
//             indicatorColor: Color(0xff70b4ff),
//             labelColor: Color(0xff70b4ff),
//             indicatorSize: TabBarIndicatorSize.tab,
//             indicatorWeight: 3.0,
//             indicatorPadding: EdgeInsets.only(top: 40),
//             isScrollable: false,
//             controller: _tabController,
//           ),
//         ),
//         Expanded(
//           child: TabBarView(
//               controller: _tabController,
//               children: <Widget>[
//                 Container(
//                   child: Sales(),
//                 ),
//                 Container(
//                   child: Reports(),
//                 )
//               ]
//           ),
//         ),
//       ],
//     );
//   }
// }
// Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
//   return Container(
//     margin: EdgeInsets.only(top: top, left: left, right: right),
//     child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
//   );
// }