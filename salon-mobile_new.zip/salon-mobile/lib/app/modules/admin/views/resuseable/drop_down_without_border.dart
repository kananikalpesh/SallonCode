import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class DropDownWithoutBorder extends StatefulWidget {
  List<String> strArr;
  String TextShow;
  DropDownWithoutBorder(this.strArr, this.TextShow);
  @override
  _MyDropDown createState() => _MyDropDown();
}

class _MyDropDown extends State<DropDownWithoutBorder> {
  String? _dropDownValue;
  String? textShow;
  List<String>? strArr;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(top: 0, left: 10, bottom: 5),
        child: DropdownButton(
          underline: SizedBox(),
          hint: _dropDownValue == null
              ? Text(widget.TextShow, style: TextStyle(color: Color(0xff515c6f)),)
              : Text(
                  '$_dropDownValue',
                  style: TextStyle(color: Color(0xff515C6F)),
                ),
          isExpanded: true,
          iconSize: 30.0,
          // icon: Image.asset(AppImages.dropdown_field_ic),
          style: TextStyle(
              color: Color(0xff8890A6),
              fontSize: 14,
              fontWeight: FontWeight.w600),
          items: this.widget.strArr.map(
            (val) {
              return DropdownMenuItem<String>(
                value: val,
                child: Text(val),
              );
            },
          ).toList(),
          onChanged: (val) {
            setState(
              () {
                _dropDownValue = val as String;
              },
            );
          },
        ));
 
 
  }
}
