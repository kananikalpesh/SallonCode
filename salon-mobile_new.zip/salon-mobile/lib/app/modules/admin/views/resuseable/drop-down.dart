import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class DropDown extends StatefulWidget{
  List<String> strArr;
  DropDown(this.strArr);
  @override
  _MyDropDown createState() => _MyDropDown();
}
class _MyDropDown extends State<DropDown>{
  String? _dropDownValue;
  List<String>? strArr;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(top: 10, left: 15),
        child: DropdownButton(
          hint: _dropDownValue == null
              ? Text('Select Type')
              : Text(
            '$_dropDownValue',
            style: TextStyle(color: Color(0xff8890A6)),
          ),
          isExpanded: true,
          iconSize: 30.0,
          style: TextStyle(color: Color(0xff8890A6)),
          items: this.widget.strArr.map(
                (val) {
              return DropdownMenuItem<String>(
                value: val,
                child: Text(val),
              );
            },
          ).toList(),
          onChanged: (val) {
            setState(
                  () {
                _dropDownValue = val as String;
              },
            );
          },
        )
    );
  }
}