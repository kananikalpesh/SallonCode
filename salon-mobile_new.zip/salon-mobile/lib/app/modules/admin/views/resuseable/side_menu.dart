import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/dashboard_controller.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SideMenu extends GetView<DaishBoardController> {
  String value = "home";
  SideMenu(this.value);
  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.red,
      // margin: EdgeInsets.only(top: 135, left: 10),
      height: SizeConfig.screenHeight,
      margin: EdgeInsets.only(
        top: SizeConfig.blockSizeVertical * 12,
        left: 10,
      ),
      // padding: EdgeInsets.only(bottom: 20),
      // height: SizeConfig.screenHeight,
      width: SizeConfig.screenWidth * .14,
      child: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(bottom: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _getImageOfIcon(context, "assets/images/avatar.png", 11),
              _getImageOfIcon(context, "assets/images/home_dash.png", 0),
              _getImageOfIcon(context, AppImages.analytics_dash_ic, 1),

              _getImageOfIcon(context, "assets/images/appoint_white.png", 2),
              _getImageOfIcon(context, "assets/images/cart.png", 3),
              _getImageOfIcon(context, "assets/images/group.png", 4),
              // _getImageOfIcon(context, "assets/images/user_white.png", widget.value=="assets/images/user_white.png"?0xff6917e5:0xff70b4ff),
              _getImageOfIcon(context, "assets/images/disk.png", 5),
              _getImageOfIcon(context, "assets/images/chat.png", 6),
              _getImageOfIcon(context, "assets/images/stop.png", 7),
              // _getImageOfIcon(context, "assets/images/info.png", 8),
              _getImageOfIcon(context, AppImages.settings_dash_ic, 8),
              _getImageOfIcon(context, "assets/images/back_logout.png", 9),
            ],
          ),
        ),
      ),
    );
  }

  Widget _getImageOfIcon(BuildContext context, String imagePath, int index) {
    return GestureDetector(
        onTap: () {
          // controller.tabIndex.value = index;
          print("Tab Index Selected: ${index}");
          if (index != 9) {
            controller.tabIndex.value = index;
          } else {
            getLogoutDialog(context);
          }

          // if (imagePath == "assets/images/disk.png") {
          //   // Navigator.push(context, MaterialPageRoute(builder: (context) => Requests("assets/images/disk.png"),));
          //   // setState(() {
          //   //
          //   // });
          //   // Navigator.push(context, MaterialPageRoute(builder: (context) => Requests(imagePath: "assets/images/disk.png"),));
          //   Navigator.pushNamed(context, '/requests');
          //   // print("this is clicked");
          //   // print(widget.value);
          // } else if (imagePath == "assets/images/avatar.png") {
          //   Navigator.pushNamed(context, '/adminProfile');
          //   // Navigator.push(context, MaterialPageRoute(builder: (context) => AdminProfile("assets/images/home_dash.png"),));
          // } else if (imagePath == "assets/images/home_dash.png") {
          //   Navigator.pushNamed(context, '/saloonDashboard');
          //   // Navigator.push(context, MaterialPageRoute(builder: (context) => SaloonDashBoard("assets/images/home_dash.png"),));
          // } else if (imagePath == "assets/images/cart.png") {
          //   // Navigator.push(context, MaterialPageRoute(builder: (context) => Products("assets/images/cart.png"),));
          //   Navigator.pushNamed(context, '/products');
          // } else if (imagePath == "assets/images/group.png") {
          //   // Navigator.push(context, MaterialPageRoute(builder: (context) => ManageStaff("assets/images/group.png"),));
          //   Navigator.pushNamed(context, '/manageStaff');
          // } else if (imagePath == "assets/images/stop.png") {
          //   Navigator.pushNamed(context, '/dealsOffers');
          // } else if (imagePath == "assets/images/appoint_white.png") {
          //   Navigator.pushNamed(context, '/calender'); //'/calender'
          // } else if (imagePath == "assets/images/chat.png") {
          //   //ye wala sai krna
          //   Navigator.pushNamed(context, '/chatAdmin');
          // } else if (imagePath == "assets/images/bell_simple.png") {
          //   Navigator.pushNamed(context, '/notificationsAdmin');
          // } else {
          //   // Navigator.pushNamed(context, '/allGraphs');
          // }
        },
        child: Obx(() => Container(
              height: 50,
              width: 50,
              decoration: new BoxDecoration(
                color: controller.tabIndex.value == index
                    ? ColorsX.white
                    : ColorsX.blue_button_color,
                borderRadius: BorderRadius.all(Radius.circular(10)),
                boxShadow: [
                  BoxShadow(
                    color: ColorsX.blue_button_color,
                    blurRadius: 6,
                    offset: Offset(1, 1), // Shadow position
                  ),
                ],
              ),
              margin: EdgeInsets.only(top: 10),
              child: Stack(
                children: <Widget>[
                  Center(
                    child: imagePath == "assets/images/avatar.png"
                        ? Image.asset(
                            imagePath,
                          )
                        : Image.asset(
                            imagePath,
                            color: controller.tabIndex.value == index
                                ? ColorsX.blue_button_color
                                : ColorsX.white,
                          ),
                  ),
                  imagePath == "assets/images/avatar.png"
                      ? Align(
                          alignment: Alignment.bottomRight,
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                vertical: 6, horizontal: 6),
                            margin: EdgeInsets.only(left: 2, top: 2),
                            decoration: new BoxDecoration(
                              color: ColorsX.rating_dashboard,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(50),
                                  bottomRight: Radius.circular(20)),
                            ),
                            child: _rowItemForHeaderText(" 4.5", 7,
                                FontWeight.w600, 0xffffffff, 0, 0, 0),
                          ),
                        )
                      : Container(),
                ],
              ),
            )));
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget? getLogoutDialog(BuildContext context) {
    Dialog errorDialog = Dialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0)), //this right here
      child: Container(
        height: SizeConfig.screenHeight * .45,
        width: SizeConfig.screenWidth * .90,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              AppImages.logout_img,
              height: 80,
              width: 80,
            ),
            Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 10, horizontal: SizeConfig.blockSizeHorizontal * 3),
              child: Text(
                "Are you sure you want to logout?",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: ColorsX.subBlack,
                    fontWeight: FontWeight.w700,
                    fontSize: 20),
              ),
            ),

            // Text(
            //   "You can view the Appointment bookinginto the 'Appointment' Section",
            //   textAlign: TextAlign.center,
            //   style: TextStyle(
            //       color: ColorsX.subBlack,
            //       fontWeight: FontWeight.w400,
            //       fontSize: 16),
            // ),
            // child: _rowItemForHeaderText("Booking can not be cancelled two hours after booking", 16, FontWeight.w400, 0xff707070, 0, 0, 0),

            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.blockSizeHorizontal * 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: Container(
                      margin: EdgeInsets.only(top: 15, bottom: 15, right: 15),
                      width: SizeConfig.thirtyPercentWidth,
                      padding: EdgeInsets.symmetric(vertical: 15),
                      decoration: BoxDecoration(
                        color: ColorsX.greyBackground,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      child: Text(
                        "No",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: ColorsX.subBlack,
                            fontWeight: FontWeight.w600,
                            fontSize: 16),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Get.back();
                      Get.offAllNamed(Routes.CONNECT_WITH);
                      // Get.back(id: 0);
                      // progressDilog();
                      // cancellationAlert(context);
                    },
                    child: Container(
                      margin: EdgeInsets.only(
                        top: 15,
                        bottom: 15,
                        left: 15,
                      ),
                      width: SizeConfig.thirtyPercentWidth,
                      padding: EdgeInsets.symmetric(vertical: 15),
                      decoration: BoxDecoration(
                        color: ColorsX.blue_gradient_dark,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      child: Text(
                        "Yes",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: ColorsX.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 16),
                      ),
                      // child: _rowItemForHeaderText("Yes", 16, FontWeight.w600, 0xffffffff, 0, 0, 0),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
    showDialog(
        context: context, builder: (BuildContext context) => errorDialog);
  }
}
