import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/choose-customer-ctl.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calenders_wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/choose-customer-wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/resuseable/loading-state.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';


class ChooseCustomer extends GetView<ChooseCustomerCTL> {
  String drawerValue = "assets/images/appoint_white.png";

  List<String> format = [
    'Monthly',
    'Weekly',
  ];

  @override
  Widget build(BuildContext context) {
    return Obx(() => controller.isDataLoaded.isTrue
        ? allCustomers(context)
        : LoadingState());
  }

  Widget Button(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Get.toNamed(
            CalenderNavigation.add_customer,
            id: CalenderNavigation.id);
      },
      child: Align(
          alignment: Alignment.topCenter,
          child: Container(
            margin: EdgeInsets.only(
              top: 20,
              left: SizeConfig.screenWidth*.18,
              right: 15
            ),
            width: SizeConfig.eightyPercentWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Add Customer",
                    style: TextStyle(
                      fontSize: 16,
                      color: ColorsX.white,
                      fontWeight: FontWeight.w700,
                    )),
              ],
            ),
          )),
    );
  }
  Widget usersData(BuildContext context, imageUrl, name,int index){
    return GestureDetector(
      onTap: (){
        controller.idOfCustomer.value= "${controller.adminAllCustomersRes?.data[index].id}";
        print(controller.idOfCustomer.value);
        Get.toNamed(
            CalenderNavigation.AdminSelectServices,
            id: CalenderNavigation.id);
      },
      child: Container(
        width: SizeConfig.screenWidth*.78,
        margin: EdgeInsets.only(left: SizeConfig.screenWidth*.18, top: 10),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[

                Container(
                  height: 60,
                  width: 60,
                  decoration: BoxDecoration(
                      color: ColorsX.blue_button_color, shape: BoxShape.circle),
                  child: ClipRRect(
                    borderRadius: new BorderRadius.circular(30.0),
                    child: CachedNetworkImage(
                      imageUrl: AppUrls.BASE_URL_IMAGE + '${imageUrl}',
                      errorWidget: (context, url, error) => Icon(Icons.error),
                      fit: BoxFit.cover,
                      width: 55,
                      height: 55.0,
                      placeholder: (context, url) => Container(
                          height: 30,
                          width: 30,
                          child: Center(child: CircularProgressIndicator())),
                    ),
                  ),
                ),
                SizedBox(width: 20,),
                _rowItemForHeaderText(name, 16, FontWeight.w400, ColorsX.dash_textColor, 0, 5, 5)
              ],
            ),
            Container(
              height: 2,
              margin: EdgeInsets.only(top: 10),
              color: ColorsX.greydashboard,
            ),
          ],
        ),
      ),
    );
  }

  Widget offsetPopup() => PopupMenuButton<int>(
    color: ColorsX.subBlack,
    itemBuilder: (context) => [
      PopupMenuItem(
        value: 1,
        child: InkWell(
            onTap: () {
              print("clicked");
              Get.toNamed(AdminChooseCustomerNavigation.choose_customer,
                  id: AdminChooseCustomerNavigation.id);
            },
            child: _rowItemForHeaderText("Add Slot", 10,
                FontWeight.w700, ColorsX.white, 0, 0, 0)),
      ),
      // PopupMenuItem(
      //   value: 2,
      //   child: _rowItemForHeaderText("Preferences", 10, FontWeight.w700, 0xffffffff, 0, 0, 0),
      // ),

      //
    ],
    icon: Container(
      height: double.infinity,
      width: double.infinity,
      decoration: ShapeDecoration(
          color: ColorsX.blue_text_color,
          shape: StadiumBorder(
            side: BorderSide(color: ColorsX.blue_text_color, width: 2),
          )),
      child: Image.asset(
          AppImages.add_slot_icon), // <-- You can give your icon here
    ),
  );
  Widget _buildExpandableList(
      String title, String subtitle, String itemTitle, String itemSubtitle) {
    return Card(
      color: Color(0xffEFF6F6),
      margin: EdgeInsets.only(left: 20, right: 20, top: 10),
      child: ExpansionTile(
        leading: Container(
          decoration: BoxDecoration(
              color: ColorsX.blue_button_color, shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(3.0),
            child: Image.asset(
              "assets/images/hair.png",
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _rowItemForHeaderText(
                title, 10, FontWeight.w400, ColorsX.black, 0, 0, 0),
            _rowItemForHeaderText(
                subtitle, 12, FontWeight.w400, ColorsX.greytext, 0, 0, 0),
          ],
        ),
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              ListTile(
                leading: Checkbox(
                  value: true,
                  shape: CircleBorder(),
                  onChanged: (bool? value) {
                    // This is where we update the state when the checkbox is tapped
                    // setState(() {
                    //   isChecked = value!;
                    // });
                  },
                ),
                title: _rowItemForHeaderText(
                    itemTitle, 12, FontWeight.w400, ColorsX.black, 0, 0, 0),
                subtitle: _rowItemForHeaderText(itemSubtitle, 12,
                    FontWeight.w400, ColorsX.greytext, 0, 0, 0),
                trailing: _rowItemForHeaderText("\$86", 12, FontWeight.w400,
                    ColorsX.blue_text_color, 0, 0, 0),
                isThreeLine: true,
              ),
              ListTile(
                leading: Checkbox(
                  shape: CircleBorder(),
                  value: true,
                  onChanged: (bool? value) {
                    // This is where we update the state when the checkbox is tapped
                    // setState(() {
                    //   isChecked = value!;
                    // });
                  },
                ),
                title: _rowItemForHeaderText(
                    itemTitle, 12, FontWeight.w400, ColorsX.black, 0, 0, 0),
                subtitle: _rowItemForHeaderText(itemSubtitle, 12,
                    FontWeight.w400, ColorsX.greytext, 0, 0, 0),
                trailing: _rowItemForHeaderText("\$86", 12, FontWeight.w400,
                    ColorsX.blue_text_color, 0, 0, 0),
                isThreeLine: true,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget dropDownContainer(
      BuildContext context, List<String> values, double width, String text) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          DropDownWithoutBorder(values, text),
        ],
      ),
    );
  }

  Widget simpleContainer(
      BuildContext context, String firstText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(
        left: 15,
        top: 10,
      ),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(bottom: 15, top: 5),
            child: _rowItemForHeaderText(firstText, 14, FontWeight.w600,
                ColorsX.dash_textColordark1, 10, 10, 0),
          ),
          Container(
            margin: EdgeInsets.only(top: 12, right: 10),
            child: Image.asset(imagePath),
          ),
        ],
      ),
    );
  }

  Widget deleteButton(BuildContext context, String text, int colorCode) {
    return GestureDetector(
      child: Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(left: 15, top: 15),
        decoration: new BoxDecoration(
          color: Color(colorCode),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: [
            BoxShadow(
              color: text == "Add New" ? ColorsX.blue_button_color : Colors.red,
              blurRadius: 6,
              offset: Offset(1, 1), // Shadow position
            ),
          ],
        ),
        padding: EdgeInsets.symmetric(vertical: 13),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(child: SizedBox()),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Color(0xffffffff)),
            ),
            Expanded(child: SizedBox()),
            Icon(
              Icons.add_circle,
              color: ColorsX.white,
            ),
            SizedBox(
              width: 10,
            )
          ],
        ),
        // child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700,color: Color(0xffffffff)),)
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color color,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style:
        TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      // width: SizeConfig.seventyFivePercentWidth,
      margin:
      EdgeInsets.only(top: 20, left: SizeConfig.blockSizeHorizontal * 6),
      child: Row(
        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          InkWell(
            onTap: () {
              print("Back Pressed");
              Get.offNamed(CalenderNavigation.calenderMainScreen,
                  id: CalenderNavigation.id);
            },
            child: Container(
                height: 21, width: 17, child: Image.asset(imagePath)),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 11),
          _rowItemForHeaderText(
              text, 20, FontWeight.w900, ColorsX.dash_textColordark1, 0, 0, 0),
          Spacer(),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 4),
        ],
      ),
    );
  }

  Widget _search(BuildContext context) {
    return Container(
      width: SizeConfig.screenWidth*.78,
      padding: EdgeInsets.only(left: 15, right: 1),
      decoration: new BoxDecoration(
          color: ColorsX.greydashboard,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(
          top: SizeConfig.screenHeight * .01,
          right: 10,
          left: SizeConfig.screenWidth * .18),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.text,
        obscureText: false,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1, //Normal textInputField will be disp
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(top: 15, left: 2),

          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          suffixIcon: Icon(
            Icons.search_rounded,
            color: ColorsX.dash_textColor,
          ),
          hintText: "Search",
          hintStyle: TextStyle(color: ColorsX.subBlack),
          // labelStyle: TextStyle(
          //     fontSize: 13,
          //     color: ColorsX.white,
          //     fontWeight: FontWeight.bold),
          // labelText: 'Email',
        ),
      ),
    );
  }
  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
            alignment: Alignment.bottomRight,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
              margin: EdgeInsets.only(left: 2, top: 2),
              decoration: new BoxDecoration(
                color: ColorsX.rating_dashboard,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    bottomRight: Radius.circular(30)),
              ),
              child: _rowItemForHeaderText(
                  " 4.5", 7, FontWeight.w600, ColorsX.white, 0, 0, 0),
            ),
          )
              : Container(),
        ],
      ),
    );
  }

  Widget allCustomers(BuildContext context) {
    int length = controller.adminAllCustomersRes?.data.length??0;
    return Scaffold(
      // backgroundColor: ColorsX.greydashboard,
      body: Stack(
        children: [
          Container(
            width: SizeConfig.screenWidth,
            height: SizeConfig.screenHeight,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  SizedBox(
                    height: SizeConfig.blockSizeVertical * 5,
                  ),
                  _textAndIcon(context, "Choose Customer", AppImages.back),
                  _search(context),
                  SizedBox(
                    height: SizeConfig.blockSizeVertical * 2,
                  ),
                  for(int index=0; index < length; index++)
                    usersData(context, "${controller.adminAllCustomersRes?.data[index].profilePic}", "${controller.adminAllCustomersRes?.data[index].name}", index),

                  Center(child: _rowItemForHeaderText("Customer not found?", 16, FontWeight.w800, ColorsX.dash_textColor, 20, 5, 5)),
                  Center(child: Button(context),),
                  SizedBox(
                    height: SizeConfig.blockSizeVertical * 10,
                  ),
                ],

              ),
            ),
          ),
        ],
      ),
    );
  }
}
