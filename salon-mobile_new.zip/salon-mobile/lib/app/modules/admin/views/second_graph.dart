import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';

class SecondGraph extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(top: 10),
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: AspectRatio(
          aspectRatio: 1.10,
          child: SizedBox(
            child: Container(
              margin: EdgeInsets.only(left: 30, top: 10, right: 10),
              child: LineChart(
                LineChartData(
                  lineTouchData: LineTouchData(enabled: false),
                  lineBarsData: [
                    LineChartBarData(
                      spots: [
                        FlSpot(0, 4),
                        FlSpot(1, 3.5),
                        FlSpot(2, 4.5),
                        FlSpot(3, 3.5),
                        FlSpot(4, 5),
                        FlSpot(5, 6.5),
                        FlSpot(6, 7),
                        FlSpot(7, 6),
                        FlSpot(8, 4),
                        FlSpot(9, 6),
                        FlSpot(10, 6),
                        FlSpot(11, 7),
                      ],
                      isCurved: false,
                      barWidth: 2,
                      colors: [
                        ColorsX.greenish,
                      ],
                      dotData: FlDotData(
                        show: false,
                      ),
                    ),
                    LineChartBarData(
                      spots: [
                        FlSpot(0, 3),
                        FlSpot(1, 2.5),
                        FlSpot(2, 3),
                        FlSpot(3, 4.5),
                        FlSpot(4, 5),
                        FlSpot(5, 3),
                        FlSpot(6, 5),
                        FlSpot(7, 4.5),
                        FlSpot(8, 4),
                        FlSpot(9, 5),
                        FlSpot(10, 5),
                        FlSpot(11, 4),
                      ],
                      isCurved: false,
                      barWidth: 2,
                      colors: [
                        ColorsX.dashboardHome,
                      ],
                      dotData: FlDotData(
                        show: false,
                      ),
                    ),
                  ],
                  minY: 0,
                  titlesData: FlTitlesData(
                    bottomTitles: SideTitles(
                        showTitles: true,
                        getTextStyles: (context, value) =>
                        const TextStyle(color: Colors.black, fontSize: 10),
                        getTitles: (value) {
                          switch (value.toInt()) {
                            case 0:
                              return 'Mon';
                            case 2:
                              return 'Tue';
                            case 4:
                              return 'Wed';
                            case 6:
                              return 'Thur';
                            case 8:
                              return 'Fri';
                            case 10:
                              return 'Sat';
                            case 12:
                              return 'Sun';
                          // case 7:
                          //   return 'Aug';
                          // case 8:
                          //   return 'Sep';
                          // case 9:
                          //   return 'Oct';
                          // case 10:
                          //   return 'Nov';
                          // case 11:
                          //   return 'Dec';
                            default:
                              return '';
                          }
                        }),
                    rightTitles: SideTitles(
                      showTitles: true,
                      getTextStyles: (context, value) =>
                      const TextStyle(color: Colors.black, fontSize: 10),
                      getTitles: (value) {
                        switch (value.toInt()) {
                          case 0:
                            return '0';
                          case 2:
                            return '5k';
                          case 4:
                            return '10k';
                          case 6:
                            return '15k';
                        // case 7:
                        //   return 'Aug';
                        // case 8:
                        //   return 'Sep';
                        // case 9:
                        //   return 'Oct';
                        // case 10:
                        //   return 'Nov';
                        // case 11:
                        //   return 'Dec';
                          default:
                            return '';
                        }
                      },
                    ),
                    leftTitles: SideTitles(
                      showTitles: false,
                      // getTitles: (value) {
                      //   return '\$ ${value + 0.5}';
                      // },
                    ),
                  ),
                  gridData: FlGridData(
                    show: true,
                    checkToShowHorizontalLine: (double value) {
                      // return value == 1 || value == 6 || value == 4 || value == 5;
                      return value ==0;
                    },
                  ),
                ),
              ),
            ),
          ),
        )
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
}