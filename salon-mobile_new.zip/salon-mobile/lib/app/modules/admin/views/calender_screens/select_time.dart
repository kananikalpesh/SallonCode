import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calenders_wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/resuseable/bottom_cart.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SelectTimeOnDash extends StatelessWidget {
  String drawerValue = "assets/images/appoint_white.png";

  List<String> timeLimit = [
    'Beauty Shop & SPA',
    'Beauty Shop & SPA',
    'Beauty Shop & SPA'
  ];
  List<String> discount = ['Working Staff', 'Working Staff', 'Working Staff'];
  List<String> service = ['Today - Wed, 27 Apr, 2021', '28 Apr, 2021'];
  List<String> timeTable = ['Daily', 'Weekends'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: ColorsX.greydashboard,
      body: Container(
        width: SizeConfig.screenWidth,
        height: SizeConfig.screenHeight,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              height: SizeConfig.blockSizeVertical * 5,
            ),
            _textAndIcon(context, "Add Slot", AppImages.back),
            Container(
              margin:
                  EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: SizeConfig.blockSizeVertical * 2,
                  ),
                  // _rowItemForHeaderText("Select Services", 18, FontWeight.bold,
                  //     ColorsX.black, 10, 15, 0),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      _rowItemForHeaderText("Select specialist", 16,
                          FontWeight.w600, ColorsX.black, 15, 15, 0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          _getImagesWithName(
                              context, AppImages.anyone, "Anyone", 0xff707070),
                          _getImagesWithName(context, "assets/images/mike.png",
                              "Mike", 0xff707070),
                          _getImagesWithName(context, "assets/images/paul.png",
                              "Paul", 0xff70b4ff),
                          // _getImagesWithName(context, "assets/images/michael.png", "Michael", 0xff707070),
                          // _getImagesWithName(context, "assets/images/jim.png", "Jim", 0xff707070),
                          // _getImagesWithName(context, "assets/images/ellie.png", "Ellie", 0xff707070),
                          // _getImagesWithName(context, "assets/images/michael.png", "Michael", 0xff707070),
                        ],
                      ),
                      _rowItemForHeaderText("Select your date", 16,
                          FontWeight.w600, ColorsX.subBlack, 15, 15, 0),
                      _getDate(context),
                      _rowItemForHeaderText(
                          "Available Slot",
                          16,
                          FontWeight.w600,
                          ColorsX.blue_button_color,
                          15,
                          15,
                          0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          _boxDecorationTextSerices(
                              context,
                              "09:30 AM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "10:00 AM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xffd5d6d6,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "10:30 AM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "11:00 AM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          _boxDecorationTextSerices(
                              context,
                              "11:30 AM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "12:00 PM",
                              11,
                              FontWeight.w400,
                              0xffffffff,
                              0xffffffff,
                              0xff70b4ff,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "12:30 PM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "01:00 PM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xffd5d6d6,
                              15),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          _boxDecorationTextSerices(
                              context,
                              "01:30 AM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xffd5d6d6,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "02:00 PM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "02:30 PM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "03:00 PM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          _boxDecorationTextSerices(
                              context,
                              "03:30 AM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "04:00 PM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "04:30 PM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                          _boxDecorationTextSerices(
                              context,
                              "05:00 PM",
                              11,
                              FontWeight.w400,
                              0xff707070,
                              0xffffffff,
                              0xfff2f5f5,
                              15),
                        ],
                      ),
                      GestureDetector(
                          onTap: () {
                            Get.toNamed(
                                CalenderNavigation.bookingDetailAdminFirst,
                                id: 13);
                          },
                          child: Button(context)),
                      // BottomCart(),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget Button(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: Container(
          margin: EdgeInsets.only(
            top: 20,
          ),
          width: SizeConfig.eightyPercentWidth,
          padding: EdgeInsets.symmetric(vertical: 15),
          decoration: BoxDecoration(
            color: ColorsX.blue_button_color,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text("Continue",
                  style: TextStyle(
                    fontSize: 16,
                    color: ColorsX.white,
                    fontWeight: FontWeight.w700,
                  )),
            ],
          ),
        ));
  }

  Widget _getImagesWithName(
      BuildContext context, String imageName, String name, int colorCode) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          _getColumnItem(context, imageName, name, colorCode),
        ],
      ),
    );
  }

  Widget _getDate(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(left: 5, right: 5),
      decoration: new BoxDecoration(
          color: ColorsX.lightStackColor,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: 15, right: 15, left: 15),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.datetime,
        obscureText: false,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1, //Normal textInputField will be disp
        decoration: InputDecoration(
          enabledBorder: InputBorder.none,
          contentPadding: EdgeInsets.only(top: 15, left: 15),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide.none,
          ),
          suffixIcon: Image.asset(
            "assets/images/appoint.png",
            height: 20,
            width: 20,
          ),
          hintText: "25/9/2021",
          hintStyle: TextStyle(color: ColorsX.subBlack),
          // labelStyle: TextStyle(
          //     fontSize: 13,
          //     color: ColorsX.white,
          //     fontWeight: FontWeight.bold),
          // labelText: 'Email',
        ),
      ),
    );
  }

  Widget _boxDecorationTextSerices(
      BuildContext context,
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      int selectedColorCode,
      int decoration,
      double horizontal) {
    return GestureDetector(
        onTap: () {
          // Navigator.pushNamed(context, '/book');
        },
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: horizontal),
          margin: EdgeInsets.only(top: 10),
          decoration: new BoxDecoration(
            color: Color(decoration),
            borderRadius: BorderRadius.all(Radius.circular(25)),
          ),
          child: Text(
            value,
            style: TextStyle(
                color: Color(colorCode),
                fontWeight: fontWeight,
                fontSize: fontSize),
          ),
        ));
  }

  Widget _getColumnItem(
      BuildContext context, String imagePath, String name, int colorCode) {
    return Container(
      margin: EdgeInsets.only(top: 10, left: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          // CircleAvatar(
          //   backgroundColor: Colors.white,
          //   radius: 30.0,
          //   child: CircleAvatar(
          //     backgroundImage: AssetImage(imagePath),
          //     radius: 28.0,
          //   ),
          // ),
          Container(
            height: 60,
            width: 60,
            decoration: BoxDecoration(
                color: ColorsX.blue_button_color, shape: BoxShape.circle),
            child: ClipRRect(
              borderRadius: new BorderRadius.circular(10.0),
              child: Image(
                fit: BoxFit.contain,
                image: AssetImage(imagePath),
                width: 55.0,
                height: 55.0,
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            name,
            style: TextStyle(
                color: Color(colorCode),
                fontSize: 14,
                fontWeight: FontWeight.w600),
          )
        ],
      ),
    );
  }

  /// Delete Following Widget

  Widget _buildExpandableList(
      String title, String subtitle, String itemTitle, String itemSubtitle) {
    return Card(
      color: Color(0xffEFF6F6),
      margin: EdgeInsets.only(left: 20, right: 20, top: 10),
      child: ExpansionTile(
        leading: Container(
          decoration: BoxDecoration(
              color: ColorsX.blue_button_color, shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(3.0),
            child: Image.asset(
              "assets/images/hair.png",
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _rowItemForHeaderText(
                title, 10, FontWeight.w400, ColorsX.black, 0, 0, 0),
            _rowItemForHeaderText(
                subtitle, 12, FontWeight.w400, ColorsX.greytext, 0, 0, 0),
          ],
        ),
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              ListTile(
                leading: Checkbox(
                  value: true,
                  shape: CircleBorder(),
                  onChanged: (bool? value) {
                    // This is where we update the state when the checkbox is tapped
                    // setState(() {
                    //   isChecked = value!;
                    // });
                  },
                ),
                title: _rowItemForHeaderText(
                    itemTitle, 12, FontWeight.w400, ColorsX.black, 0, 0, 0),
                subtitle: _rowItemForHeaderText(itemSubtitle, 12,
                    FontWeight.w400, ColorsX.greytext, 0, 0, 0),
                trailing: _rowItemForHeaderText("\$86", 12, FontWeight.w400,
                    ColorsX.blue_text_color, 0, 0, 0),
                isThreeLine: true,
              ),
              ListTile(
                leading: Checkbox(
                  shape: CircleBorder(),
                  value: true,
                  onChanged: (bool? value) {
                    // This is where we update the state when the checkbox is tapped
                    // setState(() {
                    //   isChecked = value!;
                    // });
                  },
                ),
                title: _rowItemForHeaderText(
                    itemTitle, 12, FontWeight.w400, ColorsX.black, 0, 0, 0),
                subtitle: _rowItemForHeaderText(itemSubtitle, 12,
                    FontWeight.w400, ColorsX.greytext, 0, 0, 0),
                trailing: _rowItemForHeaderText("\$86", 12, FontWeight.w400,
                    ColorsX.blue_text_color, 0, 0, 0),
                isThreeLine: true,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget dropDownContainer(
      BuildContext context, List<String> values, double width, String text) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          DropDownWithoutBorder(values, text),
        ],
      ),
    );
  }

  Widget simpleContainer(
      BuildContext context, String firstText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(
        left: 15,
        top: 10,
      ),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(bottom: 15, top: 5),
            child: _rowItemForHeaderText(firstText, 14, FontWeight.w600,
                ColorsX.dash_textColordark1, 10, 10, 0),
          ),
          Container(
            margin: EdgeInsets.only(top: 12, right: 10),
            child: Image.asset(imagePath),
          ),
        ],
      ),
    );
  }

  Widget deleteButton(BuildContext context, String text, int colorCode) {
    return GestureDetector(
      child: Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(left: 15, top: 15),
        decoration: new BoxDecoration(
          color: Color(colorCode),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: [
            BoxShadow(
              color: text == "Add New" ? ColorsX.blue_button_color : Colors.red,
              blurRadius: 6,
              offset: Offset(1, 1), // Shadow position
            ),
          ],
        ),
        padding: EdgeInsets.symmetric(vertical: 13),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(child: SizedBox()),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Color(0xffffffff)),
            ),
            Expanded(child: SizedBox()),
            Icon(
              Icons.add_circle,
              color: ColorsX.white,
            ),
            SizedBox(
              width: 10,
            )
          ],
        ),
        // child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700,color: Color(0xffffffff)),)
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color color,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style:
            TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin:
          EdgeInsets.only(top: 20, left: SizeConfig.blockSizeHorizontal * 6),
      child: Row(
        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          InkWell(
            onTap: () {
              print("Back Pressed");
            },
            child: Container(
              height: 21,
              width: 17,
              child: Image.asset(
                imagePath,
                height: 21,
                width: 17,
              ),
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 11),
          _rowItemForHeaderText(
              text, 20, FontWeight.w900, ColorsX.dash_textColordark1, 0, 0, 0),
        ],
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    margin: EdgeInsets.only(left: 2, top: 2),
                    decoration: new BoxDecoration(
                      color: ColorsX.rating_dashboard,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          bottomRight: Radius.circular(30)),
                    ),
                    child: _rowItemForHeaderText(
                        " 4.5", 7, FontWeight.w600, ColorsX.white, 0, 0, 0),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
