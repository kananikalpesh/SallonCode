import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calenders_wrapper.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class BookingDetailAdminFirst extends StatelessWidget {
  String drawerValue = "assets/images/appoint_white.png";

  List<String> timeLimit = [
    'Beauty Shop & SPA',
    'Beauty Shop & SPA',
    'Beauty Shop & SPA'
  ];
  List<String> discount = ['Working Staff', 'Working Staff', 'Working Staff'];
  List<String> service = ['Today - Wed, 27 Apr, 2021', '28 Apr, 2021'];
  List<String> timeTable = ['Daily', 'Weekends'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: ColorsX.greydashboard,
      body: Container(
        width: SizeConfig.screenWidth,
        height: SizeConfig.screenHeight,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              SizedBox(
                height: SizeConfig.blockSizeVertical * 5,
              ),
              _textAndIcon(context, "Add Slot", AppImages.back),
              Container(
                margin: EdgeInsets.only(
                    left: SizeConfig.blockSizeHorizontal * 18,
                    top: SizeConfig.blockSizeVertical * 2),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _rowItemForHeaderText("Make Reservation", 16,
                        FontWeight.w700, ColorsX.subBlack, 0, 20, 0),

                    // getImage(context, "assets/images/popular.png"),
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              top: SizeConfig.blockSizeVertical * 2, left: 20),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(15.0),
                            child: Image.asset(
                              "assets/images/popular.png",
                              fit: BoxFit.cover,
                              height: SizeConfig.blockSizeVertical * 13,
                              width: SizeConfig.blockSizeHorizontal * 30,
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.only(
                              left: SizeConfig.blockSizeHorizontal * 5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  margin: EdgeInsets.only(top: 5),
                                  child: _rowItemForHeaderText(
                                      "Looks Unisex Saloon",
                                      14,
                                      FontWeight.w700,
                                      ColorsX.black,
                                      0,
                                      0,
                                      0) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                  ),
                              Container(
                                  margin: EdgeInsets.only(
                                    top: 5,
                                  ),
                                  child: _rowItemForHeaderText(
                                      "288 Empola Street, NewYork",
                                      12,
                                      FontWeight.w400,
                                      ColorsX.subBlack,
                                      0,
                                      0,
                                      0) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                  ),
                              Row(
                                children: [
                                  Container(
                                      margin: EdgeInsets.only(
                                        top: 5,
                                      ),
                                      child: Icon(
                                        Icons.location_pin,
                                        color: ColorsX.subBlack,
                                      ) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                      ),
                                  Container(
                                      margin: EdgeInsets.only(
                                        top: 5,
                                      ),
                                      child: _rowItemForHeaderText(
                                          "12km",
                                          12,
                                          FontWeight.w400,
                                          ColorsX.subBlack,
                                          0,
                                          0,
                                          0) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                      ),
                                ],
                              ),
                              Row(
                                children: [
                                  Container(
                                      margin: EdgeInsets.only(
                                        top: 5,
                                      ),
                                      child: Icon(
                                        Icons.star,
                                        color: ColorsX.yellow,
                                      ) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                      ),
                                  Container(
                                      margin: EdgeInsets.only(
                                        top: 5,
                                      ),
                                      child: _rowItemForHeaderText(
                                          "4.0",
                                          12,
                                          FontWeight.w400,
                                          ColorsX.subBlack,
                                          0,
                                          0,
                                          0) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                      ),
                                ],
                              ),
                            ],
                          ),
                        )
                      ],
                    ),

                    ////////////////////////////////////
                    // nameAndStatusRow(
                    //     context, "Looks Unisex Saloon", "Awaiting"),
                    // _rowItemForHeaderText(
                    //     "288 Empola Street, NewYork",
                    //     14,
                    //     FontWeight.w400,
                    //     0xff707070,
                    //     20,
                    //     SizeConfig.tenPercentWidth,
                    //     SizeConfig.tenPercentWidth),
                    // distance(context, "12"),
                    // rating(context, 4.0, "4.0"),
                    // getTotal(context, "Total ", '\$' + ' 280', 0xff707070,
                    //     0xff70b4ff),

                    _dateTimer(context, "25th September 2021 @ 08:30 PM"),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.blockSizeHorizontal * 5,
                          vertical: SizeConfig.blockSizeVertical),
                      child: _itemTextRow("Services", "Price", ColorsX.black),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.blockSizeHorizontal * 5),
                      child: ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          itemCount: 4,
                          itemBuilder: (BuildContext context, int index) {
                            return Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: SizeConfig.blockSizeVertical * 0.5),
                              child: _itemTextRow(
                                  "Buzz Cut, 30 min", "370", ColorsX.greytext),
                            );
                          }),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.blockSizeHorizontal * 5,
                          vertical: SizeConfig.blockSizeVertical * 2),
                      child:
                          _itemTextRow("Service Total", "1370", ColorsX.black),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.blockSizeHorizontal * 5,
                          vertical: SizeConfig.blockSizeVertical),
                      child: Container(
                        height: SizeConfig.blockSizeVertical * 0.1,
                        color: ColorsX.subBlack,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.blockSizeHorizontal * 5,
                          vertical: SizeConfig.blockSizeVertical),
                      child: _itemTextRow("Add-ons", "Price", ColorsX.black),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.blockSizeHorizontal * 5),
                      child: ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          itemCount: 4,
                          itemBuilder: (BuildContext context, int index) {
                            return Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: SizeConfig.blockSizeVertical * 0.5),
                              child: _addOnItemTextRow(
                                  "1 ", "Buzz Cut", "370", ColorsX.greytext),
                            );
                          }),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.blockSizeHorizontal * 5,
                          vertical: SizeConfig.blockSizeVertical),
                      child: Container(
                        height: SizeConfig.blockSizeVertical * 0.1,
                        color: ColorsX.subBlack,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.blockSizeHorizontal * 5,
                          vertical: SizeConfig.blockSizeVertical * 2),
                      child:
                          _itemTextRow("Add-Ons Total", "1470", ColorsX.black),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.blockSizeHorizontal * 5,
                          vertical: SizeConfig.blockSizeVertical * 2),
                      child: _itemTextRow("Total Bill", "3470", ColorsX.black),
                    ),
                    Button(context),
                    verticalSpace(SizeConfig.blockSizeVertical * 2),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Row _itemTextRow(String text1, String text2, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          text1,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
        Text(
          text2,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ],
    );
  }

  Row _addOnItemTextRow(String text1, String text2, String text3, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          text2,
          style: TextStyle(
              color: ColorsX.subBlack,
              fontWeight: FontWeight.bold,
              fontSize: 16),
        ),
        // Text(
        //   text2,
        //   style: TextStyle(
        //       color: color, fontWeight: FontWeight.bold, fontSize: 16),
        // ),

        Row(
          children: [
            Container(
              padding: EdgeInsets.symmetric(vertical: 7, horizontal: 7),
              decoration: BoxDecoration(
                  color: ColorsX.greyBackground, shape: BoxShape.circle),
              child: Text(
                "-",
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: ColorsX.subBlack),
              ),
            ),
            horizontalSpace(SizeConfig.blockSizeHorizontal * 2),
            Text(
              text1,
              style: TextStyle(
                  fontWeight: FontWeight.bold, color: ColorsX.greytext),
            ),
            horizontalSpace(SizeConfig.blockSizeHorizontal * 2),
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                  color: ColorsX.greyBackground, shape: BoxShape.circle),
              child: Center(
                child: Text("+", style: TextStyle(color: ColorsX.subBlack)),
              ),
            ),
          ],
        ),
        Text(
          text3,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ],
    );
  }

  Widget _dateTimer(BuildContext context, String time) {
    return Container(
      width: SizeConfig.screenWidth,
      margin: EdgeInsets.only(left: 15, right: 15, top: 20),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 10, bottom: 10),
            child: Image.asset(
              "assets/images/appoint.png",
              color: ColorsX.blue_button_color,
            ),
          ),
          _rowItemForHeaderText(
              time, 14, FontWeight.w400, ColorsX.subBlack, 0, 0, 0)
        ],
      ),
    );
  }

  Widget Button(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            // Navigator.pushNamed(context, '/verify');
            // getAlertBox(context);
            Get.toNamed(CalenderNavigation.bookingDetailAdminSecond, id: 13);
          },
          child: Container(
            margin: EdgeInsets.only(
              top: 20,
            ),
            width: SizeConfig.eightyPercentWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Make Reservation",
                    style: TextStyle(
                      fontSize: 16,
                      color: ColorsX.white,
                      fontWeight: FontWeight.w700,
                    )),
              ],
            ),
          ),
        ));
  }

  /// Delete Following Widget

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color color,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style:
            TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin:
          EdgeInsets.only(top: 20, left: SizeConfig.blockSizeHorizontal * 6),
      child: Row(
        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          InkWell(
            onTap: () {
              print("Back Pressed");
            },
            child: Container(
              height: 21,
              width: 17,
              child: Image.asset(
                imagePath,
                height: 21,
                width: 17,
              ),
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 11),
          _rowItemForHeaderText(
              text, 20, FontWeight.w900, ColorsX.dash_textColordark1, 0, 0, 0),
        ],
      ),
    );
  }
}
