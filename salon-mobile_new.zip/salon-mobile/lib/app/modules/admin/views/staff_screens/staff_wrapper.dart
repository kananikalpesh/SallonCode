// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/bindings/staff_binding.dart';

import 'add_staff.dart';
import 'manage_staff_view.dart';
import 'staff_detail.dart';







class SaloonStaffNavigation {
  SaloonStaffNavigation._();
  static const id = 15;
  static const staffList = '/staff-list';
  static const staffDetail = '/staff-Detail';
  static const addStaff = '/add-staff';
 
}
// our wrapper, where our main navigation will navigate to
class SaloonStaffWrapper extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Navigator(
      
      key: Get.nestedKey(SaloonStaffNavigation.id),
      onGenerateRoute: (settings) {
        // navigate to a route by name with settings.name
        if (settings.name == SaloonStaffNavigation.staffDetail) {
          return GetPageRoute(
            routeName: SaloonStaffNavigation.staffDetail,
            page: () => SaloonStaffDetail(
              
            ),
            binding: StaffBinding()
          );
        } 
        else if (settings.name == SaloonStaffNavigation.addStaff) {
          return GetPageRoute(
            routeName: SaloonStaffNavigation.addStaff,
            page: () => AddStaff(),
           
          );
        } 
       
             
        else {
          return GetPageRoute(
            routeName: SaloonStaffNavigation.staffList,
            page: () => ManageStaffView(
              
            ),
          );
        }
      },
    );
  }
}