import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/admin/staff/specific_staff_all_booking.dart'
    as specificStaffBooking;
import 'package:saloon_app/app/modules/admin/controllers/staff_screen_controllers/staff_detail_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/staff_screens/staff_wrapper.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SaloonStaffDetail extends GetView<StaffCTL> {
  String drawerValue = "assets/images/chat.png";
  String img = '';

  @override
  Widget build(BuildContext context) {
    img =  "${controller.staffDetail.staffPic}";
    // if (controller.staffDetail.photos != null) {
    //   if (controller.staffDetail.photos!.isNotEmpty) {
    //     img = controller.staffDetail.photos![0];
    //   } else {
    //     img = '';
    //   }
    // } else {
    //   img = '';
    // }

    return Scaffold(
      body: Stack(
        children: <Widget>[
          SingleChildScrollView(
            child: Container(
              width: SizeConfig.screenWidth,
              color: ColorsX.dashboardBG,
              child: Column(
                children: <Widget>[
                  Container(
                    margin: EdgeInsets.only(
                      top: 50,
                    ),
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Get.offNamed(SaloonStaffNavigation.staffList,
                                id: SaloonStaffNavigation.id);
                          },
                          child: Container(
                            margin: EdgeInsets.only(
                              left: SizeConfig.blockSizeHorizontal * 6,
                            ),
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: SizeConfig.blockSizeVertical),
                              child: Image.asset(AppImages.back),
                            ),
                          ),
                        ),
                        _rowItemForHeaderText(
                            "${controller.staffDetail.name}",
                            20,
                            FontWeight.w900,
                            ColorsX.dash_textColordark1,
                            0,
                            SizeConfig.blockSizeHorizontal * 6,
                            0)
                      ],
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox(
                        width: SizeConfig.screenWidth * .18,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          // _search(context),
                          verticalSpace(SizeConfig.blockSizeVertical * 4),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Container(
                                margin: EdgeInsets.only(top: 0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0),
                                  child: CachedNetworkImage(
                                    imageUrl: AppUrls.BASE_URL_IMAGE + '$img',
                                    errorWidget: (context, url, error) =>
                                        Icon(Icons.error),
                                    fit: BoxFit.cover,
                                    height: 100,
                                    width: 100,
                                    placeholder: (context, url) => Container(
                                        height: 30,
                                        width: 30,
                                        child: Center(
                                            child:
                                                CircularProgressIndicator())),
                                  ),
                                ),
                              ),
                              Container(
                                  margin: EdgeInsets.only(top: 15),
                                  child: Column(
                                    children: [
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              _rowItemForHeaderText(
                                                  "Age",
                                                  12,
                                                  FontWeight.bold,
                                                  ColorsX.black,
                                                  0,
                                                  10,
                                                  0),
                                              _rowItemForHeaderText(
                                                  "Gender",
                                                  12,
                                                  FontWeight.w900,
                                                  ColorsX.black,
                                                  10,
                                                  10,
                                                  0),
                                            ],
                                          ),
                                          Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              _rowItemForHeaderText(
                                                  "${controller.staffDetail.age} years old",
                                                  12,
                                                  FontWeight.bold,
                                                  ColorsX.subBlack,
                                                  0,
                                                  10,
                                                  0),
                                              _rowItemForHeaderText(
                                                  "${controller.staffDetail.gender}",
                                                  12,
                                                  FontWeight.w900,
                                                  ColorsX.subBlack,
                                                  10,
                                                  10,
                                                  0),
                                            ],
                                          ),
                                        ],
                                      ),
                                      verticalSpace(
                                          SizeConfig.blockSizeVertical * 2),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Container(
                                            margin: EdgeInsets.only(left: 0),
                                            child: SizedBox(
                                              height: 20,
                                              child: RatingBar.builder(
                                                initialRating: double.parse(
                                                    '${controller.staffDetail.rating ?? 0}'),
                                                minRating: 1,
                                                direction: Axis.horizontal,
                                                allowHalfRating: true,
                                                itemSize: 15,
                                                ignoreGestures: true,
                                                itemCount: 5,
                                                itemPadding:
                                                    EdgeInsets.symmetric(
                                                        horizontal: 2.0),
                                                itemBuilder: (context, _) =>
                                                    Icon(
                                                  Icons.star,
                                                  color: Colors.amber,
                                                ),
                                                onRatingUpdate: (rating) {
                                                  print(rating);
                                                },
                                              ),
                                            ),
                                          ),
                                          _rowItemForHeaderText(
                                              "${controller.staffDetail.rating ?? 0}",
                                              12,
                                              FontWeight.w400,
                                              ColorsX.dash_textColor,
                                              0,
                                              5,
                                              0),
                                        ],
                                      ),
                                    ],
                                  )),
                            ],
                          ),

                          _rowItemForHeaderText("Services", 14, FontWeight.bold,
                              ColorsX.dash_textColordark1, 10, 0, 0),
                          for (var s in controller.staffDetail.services!)
                            _rowItemForHeaderText(
                                "${s.name}",
                                14,
                                FontWeight.normal,
                                ColorsX.dash_textColor,
                                10,
                                0,
                                0),

                          verticalSpace(SizeConfig.blockSizeVertical * 2),
                          _timeTable(),
                          verticalSpace(SizeConfig.blockSizeVertical * 2),

                          Stack(
                            children: [
                              Container(
                                height: SizeConfig.blockSizeVertical * 2,
                                width: SizeConfig.blockSizeHorizontal * 75,
                                decoration: BoxDecoration(
                                    color: ColorsX.dash_textColordark1,
                                    borderRadius: BorderRadius.circular(20)),
                              ),
                              Container(
                                height: SizeConfig.blockSizeVertical * 2,
                                width:
                                    SizeConfig.blockSizeHorizontal * 75 * 0.8,
                                decoration: BoxDecoration(
                                    color: ColorsX.blue_button_color,
                                    borderRadius: BorderRadius.circular(20)),
                              ),
                            ],
                          ),

                          verticalSpace(SizeConfig.blockSizeVertical * 2),
                          Container(
                            child: controller.staffDetail.photos!.isNotEmpty?Row(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10)),
                                  height: SizeConfig.blockSizeVertical * 16,
                                  width: SizeConfig.blockSizeHorizontal * 25,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: CachedNetworkImage(
                                      imageUrl: AppUrls.BASE_URL_IMAGE + "${controller.staffDetail.photos?[0]}",
                                      errorWidget: (context, url, error) =>
                                          Icon(Icons.error),
                                      fit: BoxFit.cover,
                                      placeholder: (context, url) => Container(
                                          height: 30,
                                          width: 30,
                                          child: Center(
                                              child:
                                                  CircularProgressIndicator())),
                                    ),
                                  ),
                                ),
                                horizontalSpace(SizeConfig.blockSizeHorizontal),
                                Column(
                                  // mainAxisAlignment:
                                  //     // MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          height: SizeConfig.blockSizeVertical *
                                              7.5,
                                          width:
                                              SizeConfig.blockSizeHorizontal *
                                                  25,
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: CachedNetworkImage(
                                              imageUrl: AppUrls.BASE_URL_IMAGE +
                                                  '$img',
                                              errorWidget:
                                                  (context, url, error) =>
                                                      Icon(Icons.error),
                                              fit: BoxFit.fill,
                                              placeholder: (context, url) =>
                                                  Container(
                                                      height: 30,
                                                      width: 30,
                                                      child: Center(
                                                          child:
                                                              CircularProgressIndicator())),
                                            ),
                                          ),
                                        ),
                                        horizontalSpace(
                                            SizeConfig.blockSizeHorizontal),
                                        Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          height: SizeConfig.blockSizeVertical *
                                              7.5,
                                          width:
                                              SizeConfig.blockSizeHorizontal *
                                                  25,
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: CachedNetworkImage(
                                              imageUrl: AppUrls.BASE_URL_IMAGE +
                                                  '$img',
                                              errorWidget:
                                                  (context, url, error) =>
                                                      Icon(Icons.error),
                                              fit: BoxFit.fill,
                                              placeholder: (context, url) =>
                                                  Container(
                                                      height: 30,
                                                      width: 30,
                                                      child: Center(
                                                          child:
                                                              CircularProgressIndicator())),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    verticalSpace(
                                        SizeConfig.blockSizeVertical * 0.5),
                                    Row(
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          height: SizeConfig.blockSizeVertical *
                                              7.5,
                                          width:
                                              SizeConfig.blockSizeHorizontal *
                                                  25,
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: CachedNetworkImage(
                                              imageUrl: AppUrls.BASE_URL_IMAGE +
                                                  '$img',
                                              errorWidget:
                                                  (context, url, error) =>
                                                      Icon(Icons.error),
                                              fit: BoxFit.contain,
                                              placeholder: (context, url) =>
                                                  Container(
                                                      height: 30,
                                                      width: 30,
                                                      child: Center(
                                                          child:
                                                              CircularProgressIndicator())),
                                            ),
                                          ),
                                        ),
                                        horizontalSpace(
                                            SizeConfig.blockSizeHorizontal),
                                        Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          height: SizeConfig.blockSizeVertical *
                                              7.5,
                                          width:
                                              SizeConfig.blockSizeHorizontal *
                                                  25,
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: CachedNetworkImage(
                                              imageUrl: AppUrls.BASE_URL_IMAGE +
                                                  '$img',
                                              errorWidget:
                                                  (context, url, error) =>
                                                      Icon(Icons.error),
                                              fit: BoxFit.cover,
                                              placeholder: (context, url) =>
                                                  Container(
                                                      height: 30,
                                                      width: 30,
                                                      child: Center(
                                                          child:
                                                              CircularProgressIndicator())),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ):Container(),
                          ),
                          verticalSpace(SizeConfig.blockSizeVertical * 2),

                          _rowItemForHeaderText(
                              "Appointments",
                              14,
                              FontWeight.normal,
                              ColorsX.dash_textColordark1,
                              10,
                              0,
                              0),

                          Obx(
                            () => controller.isBookingLoaded.isTrue
                                ? Container(
                                    height: SizeConfig.blockSizeVertical * 8,
                                    width: SizeConfig.blockSizeHorizontal * 77,
                                    child: _dashboardTabs())
                                : Container(),
                          ),
                          Obx(
                            () => controller.isBookingLoaded.isTrue
                                ? Container(
                                    height: SizeConfig.blockSizeVertical * 30,
                                    width: SizeConfig.blockSizeHorizontal * 77,
                                    child: TabBarView(
                                        controller: controller.tabController,
                                        children: [
                                          _tabItem('All'),
                                          _tabItem('Pending'),
                                          _tabItem('Cancelled'),
                                        ]),
                                  )
                                : Container(),
                          ),

                          SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Container _dashboardTabs() {
    return Container(
      margin: EdgeInsets.only(
          // top: SizeConfig.blockSizeVertical * 9.5,
          left: SizeConfig.blockSizeHorizontal * 3,
          right: SizeConfig.blockSizeHorizontal * 3),
      child: TabBar(
          controller: controller.tabController,
          indicatorColor: ColorsX.blue_text_color,
          labelColor: ColorsX.blue_text_color,
          unselectedLabelColor: ColorsX.black,
          labelPadding: EdgeInsets.zero,
          tabs: [
            Tab(
              text: "All",
            ),
            Tab(
              text: "Upcoming",
            ),
            Tab(
              text: "Cancelled",
            ),
          ]),
    );
  }

  Widget _tabItem(String status) {
    return Container(
        decoration: BoxDecoration(
            color: ColorsX.white,
            borderRadius: BorderRadius.all(Radius.circular(10))),
        margin: EdgeInsets.only(
            right: 10,
            top: SizeConfig.blockSizeVertical * 2,
            bottom: SizeConfig.blockSizeVertical * 2),
        padding: EdgeInsets.all(0),
        child: ListView.separated(
          padding: EdgeInsets.all(0),
          itemCount: controller.getStaffAllBooking(status)?.length ?? 0,
          itemBuilder: (BuildContext context, int index) {
            if (status == 'All') {
              return appointmentItem(controller.staffAllBookingList?[index]);
            } else if (status == 'Pending') {
              return appointmentItem(
                  controller.staffUpcomingBookingList?[index]);
            }
            return appointmentItem(
                controller.staffCancelledBookingList?[index]);
          },
          separatorBuilder: (context, index) => Divider(
            color: ColorsX.inputfielboarder,
          ),
        )

        // ListView(
        //   padding: EdgeInsets.all(0),
        //   children: [appointmentItem()],
        // ),
        );
  }

  Column appointmentItem(specificStaffBooking.Booking? booking) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: _rowItemForHeaderText("ID #${booking?.appointmentId}", 14,
                  FontWeight.bold, ColorsX.blue_button_color, 10, 5, 0),
            ),
            _rowItemForHeaderText(
                "${booking?.appointmentDate.toString().split(' ')[0]} ${booking?.timeSlot}",
                14,
                FontWeight.bold,
                ColorsX.dash_textColordark1,
                10,
                0,
                10)
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _rowItemForHeaderText("${booking?.user?.name}", 14,
                FontWeight.normal, ColorsX.dash_textColor, 10, 5, 0),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _rowItemForHeaderText("${booking?.services?.name}", 15,
                FontWeight.w600, ColorsX.dash_textColordark1, 5, 5, 0),
            _rowItemForHeaderText("\$${booking?.totalPrice}", 15,
                FontWeight.bold, ColorsX.blue_button_color, 5, 0, 10)
          ],
        ),
      ],
    );
  }

  Container _timeTable() {
    return Container(
      width: SizeConfig.blockSizeHorizontal * 75,
      height: SizeConfig.blockSizeVertical * 30,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Container(
          // height: SizeConfig.blockSizeVertical * 40,
          width: SizeConfig.blockSizeHorizontal * 110,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: _rowItemForHeaderText("Day", 14, FontWeight.bold,
                        ColorsX.dash_textColordark1, 10, 0, 0),
                  ),
                  Expanded(
                    flex: 2,
                    child: _rowItemForHeaderText(
                        "Start Time",
                        14,
                        FontWeight.bold,
                        ColorsX.dash_textColordark1,
                        10,
                        10,
                        0),
                  ),
                  Expanded(
                    flex: 2,
                    child: _rowItemForHeaderText(
                        "End Time",
                        14,
                        FontWeight.bold,
                        ColorsX.dash_textColordark1,
                        10,
                        10,
                        0),
                  ),
                  Expanded(
                    flex: 2,
                    child: _rowItemForHeaderText(
                        "Slot Time",
                        14,
                        FontWeight.bold,
                        ColorsX.dash_textColordark1,
                        10,
                        10,
                        0),
                  ),
                  Expanded(
                    flex: 4,
                    child: _rowItemForHeaderText(
                        "Slot Time Interval",
                        14,
                        FontWeight.bold,
                        ColorsX.dash_textColordark1,
                        10,
                        10,
                        0),
                  ),
                ],
              ),
              for (var t in controller.staffDetail.timeSlots!)
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: _rowItemForHeaderText(
                          "${t.day?.substring(0, 3)}",
                          14,
                          FontWeight.bold,
                          ColorsX.dash_textColor,
                          10,
                          0,
                          0),
                    ),
                    Expanded(
                      flex: 2,
                      child: _rowItemForHeaderText("${t.startTime}", 14,
                          FontWeight.bold, ColorsX.dash_textColor, 10, 10, 0),
                    ),
                    Expanded(
                      flex: 2,
                      child: _rowItemForHeaderText("${t.endTime}", 14,
                          FontWeight.bold, ColorsX.dash_textColor, 10, 10, 0),
                    ),
                    Expanded(
                      flex: 2,
                      child: _rowItemForHeaderText("${t.slotTime} min", 14,
                          FontWeight.bold, ColorsX.dash_textColor, 10, 10, 0),
                    ),
                    Expanded(
                      flex: 4,
                      child: _rowItemForHeaderText("${t.slotInterval} min", 14,
                          FontWeight.bold, ColorsX.dash_textColor, 10, 10, 0),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget Button(BuildContext context, String text, int colorCode) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 10, right: 10),
      decoration: new BoxDecoration(
        color: Color(colorCode),
        borderRadius: BorderRadius.all(Radius.circular(10)),
        boxShadow: [
          BoxShadow(
            color: text == "Accept Request"
                ? ColorsX.blue_button_color
                : Colors.red,
            blurRadius: 6,
            offset: Offset(1, 1), // Shadow position
          ),
        ],
      ),
      padding: EdgeInsets.symmetric(vertical: 13),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
            fontSize: 16, fontWeight: FontWeight.w700, color: ColorsX.white),
      ), // _rowItemForHeaderText(text, 16, FontWeight.w700, 0xffffffff, 0, 0, 0),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: colorCode, fontWeight: fontWeight, fontSize: fontSize),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  Widget _search(BuildContext context) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      padding: EdgeInsets.only(left: 5, right: 1),
      decoration: new BoxDecoration(
          color: ColorsX.greydashboard,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: 15, right: 10, left: 10),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.text,
        obscureText: false,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1,
        //Normal textInputField will be disp
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(top: 15, left: 2),

          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          suffixIcon: Icon(
            Icons.search_rounded,
            color: ColorsX.dash_textColor,
          ),
          hintText: "Search",
          hintStyle: TextStyle(color: ColorsX.subBlack),
          // labelStyle: TextStyle(
          //     fontSize: 13,
          //     color: ColorsX.white,
          //     fontWeight: FontWeight.bold),
          // labelText: 'Email',
        ),
      ),
    );
  }
}
