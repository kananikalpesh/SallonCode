import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/data/model/admin/staff/salon_all_staff_res.dart'
    as allSaloonStaff;
import 'package:saloon_app/app/modules/admin/controllers/staff_screen_controllers/staff_detail_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/staff_screens/staff_wrapper.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class StaffListItem extends GetView<StaffCTL> {
  String img = '';

  @override
  Widget build(BuildContext context) {
    controller.getSaloonAllStaff();

    return PagedListView<int, allSaloonStaff.Datum>(
      padding: EdgeInsets.zero,
      pagingController: controller.pagingController,
      builderDelegate: PagedChildBuilderDelegate<allSaloonStaff.Datum>(
          itemBuilder: (context, item, index) {
        if (item.photos != null) {
          img = "${item.staffPic}";
          // if (item.photos!.isNotEmpty) {
          //   img = item.photos![0];
          // } else {
          //   img = '';
          // }
        } else {
          img = '';
        }

        return InkWell(
          // behavior: HitTestBehavior.translucent,
          onTap: () {
            Get.toNamed(SaloonStaffNavigation.staffDetail,
                id: SaloonStaffNavigation.id);
            controller.staffDetail = item;
            controller.specificStaffAllBooking(staffId: item.id!);


          },
          child: staffItem(
            context,
            "$img",
            "${item.name}",
            "${item.designation}",
            double.parse('${item.rating}'),
            "${item.age}",
            "${item.gender}",
          ),
        );
      }),
    );
  }

  Widget staffItem(
    BuildContext context,
    String imagePath,
    String name,
    String jobType,
    double rating,
    String age,
    String gender,
  ) {
    return Container(
      margin: EdgeInsets.only(left: 0),
      child: Column(
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  height: SizeConfig.blockSizeHorizontal * 30,
                  width: SizeConfig.blockSizeHorizontal * 30,
                  child: ClipRRect(
                    borderRadius: new BorderRadius.circular(10.0),
                    child: CachedNetworkImage(
                      imageUrl: AppUrls.BASE_URL_IMAGE + '${imagePath}',
                      errorWidget: (context, url, error) => Icon(Icons.error),
                      fit: BoxFit.cover,
                      height: SizeConfig.blockSizeHorizontal * 30,
                      width: SizeConfig.blockSizeHorizontal * 30,
                      placeholder: (context, url) => Container(
                          height: 30,
                          width: 30,
                          child: Center(child: CircularProgressIndicator())),
                    ),
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      _rowItemForHeaderText(
                          name, 14, FontWeight.w700, 0xff515C6F, 0, 10, 0),
                      SizedBox(
                        height: 10,
                      ),
                      _rowItemForHeaderText(
                          jobType, 12, FontWeight.w400, 0xff8890A6, 0, 10, 0),
                      SizedBox(
                        height: 10,
                      ),
                      _rowItemForHeaderText(
                          age, 12, FontWeight.w400, 0xff8890A6, 0, 10, 0),
                      SizedBox(
                        height: 10,
                      ),
                      _rowItemForHeaderText(
                          gender, 12, FontWeight.w400, 0xff8890A6, 0, 10, 0),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(left: 10),
                            child: SizedBox(
                              height: 20,
                              child: RatingBar.builder(
                                initialRating: rating,
                                minRating: 1,
                                direction: Axis.horizontal,
                                allowHalfRating: true,
                                itemSize: 15,
                                ignoreGestures: true,
                                itemCount: 5,
                                itemPadding:
                                    EdgeInsets.symmetric(horizontal: 2.0),
                                itemBuilder: (context, _) => Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                ),
                                onRatingUpdate: (rating) {
                                  print(rating);
                                },
                              ),
                            ),
                          ),
                          _rowItemForHeaderText(rating.toString(), 12,
                              FontWeight.w400, 0xff8890A6, 0, 5, 0),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    verticalSpace(SizeConfig.blockSizeVertical * 5),
                    Image.asset("assets/images/next.png"),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget simpleContainer(BuildContext context, String firstText,
      String secondText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(
                  firstText, 10, FontWeight.w700, 0xffe1e1e1, 15, 10, 0),
              Container(
                width: SizeConfig.sixtyFivePercentWidth,
                child: _rowItemForHeaderText(
                    secondText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),
              ),
              SizedBox(
                height: 15,
              )
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(right: 10, top: 10),
                child: Image.asset(imagePath),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget deleteButton(BuildContext context, String text, int colorCode) {
    return GestureDetector(
      child: Container(
          width: SizeConfig.seventyFivePercentWidth,
          margin: EdgeInsets.only(left: 15, top: 15),
          decoration: new BoxDecoration(
            color: Color(colorCode),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Color(0xffffffff)),
          )),
    );
  }

  Widget _imageHere(
    BuildContext context,
    String imagePath,
  ) {
    return Container(
      margin: EdgeInsets.only(left: 10, top: 15),
      child: ClipRRect(
        borderRadius: new BorderRadius.circular(10.0),
        child: Image(
          fit: BoxFit.cover,
          image: AssetImage(imagePath),
          width: SizeConfig.seventyFivePercentWidth,
          height: 200.0,
        ),
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 20, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 20, FontWeight.w900, 0xff515C6F, 0, 0, 0),
          Image.asset(
            imagePath,
            height: 21,
            width: 17,
          ),
        ],
      ),
    );
  }
}
