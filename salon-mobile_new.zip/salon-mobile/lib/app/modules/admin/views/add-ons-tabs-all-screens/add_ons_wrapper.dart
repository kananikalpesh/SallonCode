// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/add-ons-screen.dart';

import 'add-on-detail.dart';
import 'edit_add_on.dart';
import 'new-add-on.dart';

class AddOnsNavigation {
  AddOnsNavigation._();

  static const id = 14;
  static const addOnsList = '/add-ons-list';
  static const addOnsDetail = '/add-ons-Detail';
  static const AddNewaddOns = '/new-add-ons-Detail';
  static const EditAddOns = '/edit-add-ons-Detail';
}

// our wrapper, where our main navigation will navigate to
class AddOnsWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: Get.nestedKey(AddOnsNavigation.id),
      onGenerateRoute: (settings) {
        // navigate to a route by name with settings.name
        if (settings.name == AddOnsNavigation.addOnsDetail) {
          return GetPageRoute(
            routeName: AddOnsNavigation.addOnsDetail,
            page: () => AddOnDetail(),
          );
        } else if (settings.name == AddOnsNavigation.AddNewaddOns) {
          return GetPageRoute(
            routeName: AddOnsNavigation.AddNewaddOns,
            page: () => NewAddOn(),
          );
        } else if (settings.name == AddOnsNavigation.EditAddOns) {
          return GetPageRoute(
            routeName: AddOnsNavigation.EditAddOns,
            page: () => EditAddOn(),
          );
        } else {
          return GetPageRoute(
            routeName: AddOnsNavigation.addOnsList,
            page: () => AddOnsScreen(),
          );
        }
      },
    );
  }
}
