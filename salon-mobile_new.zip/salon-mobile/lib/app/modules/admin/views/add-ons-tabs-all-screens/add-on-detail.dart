import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:saloon_app/app/modules/admin/controllers/add_on/add_on_ctl.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'add_ons_wrapper.dart';

class AddOnDetail extends GetView<AddOnCTL> {
  List<String> strArr = ['Lotion', 'Hair Dryer', 'Hair Brush'];
  String drawerValue = "assets/images/cart.png";

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {

        print('WillPopScope called.......');

        bool result = await  Get.offNamed(AddOnsNavigation.addOnsList, id: AddOnsNavigation.id);;
        return result;
      },
      child: Scaffold(
        backgroundColor: ColorsX.greydashboard,
        drawer: Theme(
          data: Theme.of(context).copyWith(
            canvasColor: Colors
                .transparent, //This will change the drawer background to blue.
            //other styles
          ),
          child: Drawer(
              child: Container(
            decoration: new BoxDecoration(
                color: Color(0xff515C6F),
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(60),
                    topRight: Radius.circular(60))),
            child: ListView(
              // Important: Remove any padding from the ListView.
              padding: EdgeInsets.zero,
              children: <Widget>[
                Container(
                  child: DrawerHeader(
                    decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius:
                            BorderRadius.only(topRight: Radius.circular(60)),
                        image: DecorationImage(
                            image: AssetImage("assets/images/popular.png"),
                            colorFilter: ColorFilter.mode(
                                Colors.black.withOpacity(0.6),
                                BlendMode.dstATop),
                            fit: BoxFit.cover)),
                    child: Stack(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(top: 60),
                          child: Center(
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  drawerImage(
                                      0xffffffff, "assets/images/avatar.png"),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              _rowItemForHeaderText("Lux Saloon", 24,
                                  FontWeight.w600, 0xffffffff, 60, 60, 0),
                              _rowItemForHeaderText("@luxsaloon", 14,
                                  FontWeight.w400, 0xffffffff, 0, 60, 0),
                            ]),
                      ],
                    ),
                  ),
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  title: _rowItemForHeaderText(
                      "Dashboard", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/home_dash.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/home_dash.png"),
                  ), //Image.asset("assets/images/home_dash.png"),
                  onTap: () {
                    Navigator.pushNamed(context, '/saloonDashboard');
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/appoint_white.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/appoint_white.png"),
                  ),
                  title: _rowItemForHeaderText(
                      "Calendar", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    Navigator.pushNamed(context, '/calender');
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/cart.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/cart.png"),
                  ),
                  title: _rowItemForHeaderText(
                      "Products", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    Navigator.pushNamed(context, '/products');
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/group.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/group.png"),
                  ),
                  title: _rowItemForHeaderText(
                      "Manage Staff", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    Navigator.pushNamed(context, '/manageStaff');
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/user_white.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/user_white.png"),
                  ), //Image.asset("assets/images/user_white.png"),
                  title: _rowItemForHeaderText(
                      "Edit Profile", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    Navigator.pushNamed(context, '/adminProfile');
                    // Navigator.push(context, MaterialPageRoute(builder: (context) => AdminProfile("assets/images/user_white.png"),));
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/disk.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/disk.png"),
                  ),
                  title: _rowItemForHeaderText(
                      "Requests", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    Navigator.pushNamed(context, '/requests');
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/chat.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/chat.png"),
                  ),
                  title: _rowItemForHeaderText(
                      "Messages", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    Navigator.pushNamed(context, '/chatAdmin');
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/bell_simple.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/bell_simple.png"),
                  ),
                  title: _rowItemForHeaderText("Notifications", 16,
                      FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    Navigator.pushNamed(context, '/notificationsAdmin');
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/stop.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/stop.png"),
                  ),
                  title: _rowItemForHeaderText("Deals & Offers", 16,
                      FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    Navigator.pushNamed(context, '/dealsOffers');
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/info.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/info.png"),
                  ),
                  title: _rowItemForHeaderText("Help & Support", 16,
                      FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    // Update the state of the app.
                    // ...
                  },
                ),
                ListTile(
                  visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                  leading: Container(
                    height: 40,
                    width: 40,
                    decoration: new BoxDecoration(
                      color: drawerValue == "assets/images/back_logout.png"
                          ? ColorsX.dashboardHome
                          : Colors.transparent,
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                    child: Image.asset("assets/images/back_logout.png"),
                  ),
                  title: _rowItemForHeaderText(
                      "Logout", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                  onTap: () {
                    // Update the state of the app.
                    // ...
                  },
                ),
              ],
            ),
          )),
        ),
        body: SafeArea(
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    child: Container(
                      width: SizeConfig.screenWidth*.15,
                      margin: EdgeInsets.only(top:  20),
                      child: Icon(Icons.arrow_back),
                    ),
                    onTap: (){
                      print('going to addOnsList');
                      Get.offNamed(AddOnsNavigation.addOnsList, id: AddOnsNavigation.id);
                    },
                  ),
                  // _search(context),
                  _rowItemForHeaderText("Cutting Kit", 20,
                      FontWeight.w900, 0xff515C6F, 20, 5, 0),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(
                    width: SizeConfig.screenWidth * .15,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      // _headerTextandIcon(context, "Cutting Kit", "assets/images/pencil.png"),
                      SizedBox(
                        height: 30,
                      ),
                      _imageHere(context, "${controller.productItem?.profilePic}"),
                      Container(
                        width: SizeConfig.seventyFivePercentWidth,
                        margin: EdgeInsets.only(top: 20, left: 15),
                        child: SingleChildScrollView(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              rowOfImages(
                                  context, "${controller.productItem?.profilePic}"),
                              rowOfImages(
                                  context, "${controller.productItem?.profilePic}"),
                            ],
                          ),
                        ),
                      ),
                      // textRows(context, "Colors", "+ Add Colors"),
                      // allColors(context),
                      _texts(
                          context, "Brand Name", "${controller.productItem?.brandName}"),
                      _texts(context, "Price", '${controller.productItem?.price}' + '\$'),
                      _texts(context, "Product Type:", '${controller.productItem?.category?.title}'),

                      Container(
                        width: SizeConfig.seventyFivePercentWidth,
                        child: _rowItemForHeaderText(
                            "${controller.productItem?.description}",
                            12,
                            FontWeight.w400,
                            0xff8890A6,
                            15,
                            15,
                            0),
                      ),
                      Container(
                        width: SizeConfig.seventyFivePercentWidth,
                        margin: EdgeInsets.only(left: 15),
                        child: Row(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.center,
                              children: <Widget>[
                                _rowItemForHeaderText(
                                    "In-Stock",
                                    16,
                                    FontWeight.w400,
                                    0xff515C6F,
                                    10,
                                    0,
                                    0),
                                _rowItemForHeaderText("${controller.productItem?.quantity}", 30,
                                    FontWeight.w700, 0xff70b4ff, 5, 0, 0)
                              ],
                            ),
                            Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.center,
                              children: <Widget>[
                                _rowItemForHeaderText(
                                    "Products Sold",
                                    16,
                                    FontWeight.w400,
                                    0xff515C6F,
                                    10,
                                    0,
                                    0),
                                _rowItemForHeaderText("${controller.productItem?.quantitySold}", 30,
                                    FontWeight.w700, 0xff70b4ff, 5, 0, 0)
                              ],
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                          onTap: (){
                            Get.toNamed(AddOnsNavigation.EditAddOns, id: AddOnsNavigation.id);
                          },
                          child: EditButton(context, "Edit Item")),
                      InkWell(
                          onTap: ()async{
                            final res = await controller.deleteAddOn();
                            if(res){
                              controller.getAddOnsByCategoryRes(1, '', '');
                              controller.pagingController.refresh();
                              await Functions.showSimpleDialog(title: 'Add On', msg: 'Add On deleted successfully');
                              Get.offAllNamed(AddOnsNavigation.addOnsList, id: AddOnsNavigation.id);
                            }
                          },
                          child: deleteButton(context, "Delete Item")),
                      SizedBox(
                        height: 20,
                      )
                      // Container(
                      //   width: SizeConfig.seventyFivePercentWidth,
                      //   margin: EdgeInsets.only(top: 30, left: 15, bottom: 30),
                      //   child: Text("Return to Products", textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700,color: Color(0xff70b4ff)),),
                      // ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future _onBackPressed() async {
    print('going to addOnsList');


  }

  Widget deleteButton(BuildContext context, String text) {
    return Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(left: 10, top: 15),
        decoration: new BoxDecoration(
          color: ColorsX.red_dashboard,
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: [
            BoxShadow(
              color: text == "Create Deal"
                  ? ColorsX.blue_button_color
                  : Colors.red,
              blurRadius: 6,
              offset: Offset(1, 1), // Shadow position
            ),
          ],
        ),
        padding: EdgeInsets.symmetric(vertical: 13),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Color(0xffffffff)),
        ));
  }

  Widget EditButton(BuildContext context, String text) {
    return Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(left: 10, top: 15),
        decoration: new BoxDecoration(
          color: ColorsX.greydashboard,
          border: Border.all(color: ColorsX.black),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: [
            BoxShadow(
              color: text == "Create Deal"
                  ? ColorsX.blue_button_color
                  : ColorsX.dashboardBG,
              blurRadius: 6,
              offset: Offset(1, 1), // Shadow position
            ),
          ],
        ),
        padding: EdgeInsets.symmetric(vertical: 13),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Color(0xff000000)),
        ));
  }

  Widget allColors(BuildContext context) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 20, left: 15),
      child: SingleChildScrollView(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              height: 40,
              width: 40,
              decoration: new BoxDecoration(
                color: Color(0xff6917E5),
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
            ),
            SizedBox(
              width: 10,
            ),
            Container(
              height: 40,
              width: 40,
              decoration: new BoxDecoration(
                color: Color(0xff263ABE),
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
            ),
            SizedBox(
              width: 10,
            ),
            Container(
              height: 40,
              width: 40,
              decoration: new BoxDecoration(
                color: Color(0xffDB5393),
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
            ),
            SizedBox(
              width: 10,
            ),
            Container(
              height: 40,
              width: 40,
              decoration: new BoxDecoration(
                color: Color(0xff55C755),
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget textRows(BuildContext context, String first, String second) {
    return Container(
      margin: EdgeInsets.only(top: 15, left: 15),
      width: SizeConfig.seventyFivePercentWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _rowItemForHeaderText(
              first, 14, FontWeight.w700, 0xff515C6F, 0, 0, 0),
          _rowItemForHeaderText(
              second, 14, FontWeight.w700, 0xff70B4FF, 0, 0, 0),
        ],
      ),
    );
  }

  Widget rowOfImages(BuildContext context, String imagePath) {
    return Container(
      margin: EdgeInsets.only(right: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          ClipRRect(
            borderRadius: new BorderRadius.circular(10.0),
            child:CachedNetworkImage(
              imageUrl: AppUrls.BASE_URL_IMAGE + '${imagePath}',
              errorWidget: (context, url, error) => Icon(Icons.error),
              fit: BoxFit.fill,
              height:40,
              width: 40,
              placeholder: (context, url) => Container(
                  height: 40,
                  width: 40,
                  child: Center(child: CircularProgressIndicator())),
            ),
          ),
        ],
      ),
    );
  }

  Widget _imageHere(
    BuildContext context,
    String imagePath,
  ) {
    return Container(
      margin: EdgeInsets.only(left: 10, top: 0),
      child: ClipRRect(
        borderRadius:  BorderRadius.circular(25.0),
        child: CachedNetworkImage(
          imageUrl: AppUrls.BASE_URL_IMAGE + '${imagePath}',
          errorWidget: (context, url, error) => Icon(Icons.error),
          fit: BoxFit.fill,
          height: 200,
          width: SizeConfig.screenWidth * .75,
          placeholder: (context, url) => Container(
              height: 200,
              width: SizeConfig.screenWidth * .75,
              child: Center(child: CircularProgressIndicator())),
        ),
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _headerTextandIcon(
      BuildContext context, String text, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 20, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 20, FontWeight.w900, 0xff515C6F, 0, 0, 0),
          Image.asset(
            imagePath,
            height: 21,
            width: 17,
          ),
        ],
      ),
    );
  }

  Widget _texts(BuildContext context, String text, String text2) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 20, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
          _rowItemForHeaderText(
              text2, 14, FontWeight.w700, 0xff515C6F, 0, 0, 0),
        ],
      ),
    );
  }

  Widget _search(BuildContext context) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      padding: EdgeInsets.only(left: 5, right: 1),
      decoration: new BoxDecoration(
          color: ColorsX.greydashboard,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: 15, right: 15, left: 10),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.text,
        obscureText: false,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1,
        //Normal textInputField will be disp
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(top: 15, left: 2),

          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          suffixIcon: Icon(
            Icons.search_rounded,
            color: ColorsX.dash_textColor,
          ),
          hintText: "Search",
          hintStyle: TextStyle(color: ColorsX.subBlack),
          // labelStyle: TextStyle(
          //     fontSize: 13,
          //     color: ColorsX.white,
          //     fontWeight: FontWeight.bold),
          // labelText: 'Email',
        ),
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    margin: EdgeInsets.only(left: 2, top: 2),
                    decoration: new BoxDecoration(
                      color: ColorsX.rating_dashboard,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          bottomRight: Radius.circular(30)),
                    ),
                    child: _rowItemForHeaderText(
                        " 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
