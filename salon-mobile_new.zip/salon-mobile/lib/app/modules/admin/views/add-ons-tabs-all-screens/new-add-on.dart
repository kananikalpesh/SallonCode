import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/add_on/add_on_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/add-on-tabs.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class NewAddOn extends GetView<AddOnCTL> {
  List<String> timeLimit = [
    'Beauty Shop & SPA',
    'Beauty Shop & SPA',
    'Beauty Shop & SPA'
  ];
  List<String> strArr = ['Lotion', 'Hair Dryer', 'Hair Brush'];
  List<String> currencies = ['DKK', 'USA', 'EUR'];
  String drawerValue = "assets/images/cart.png";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsX.greydashboard,
      drawer: Theme(
        data: Theme.of(context).copyWith(
          canvasColor: Colors
              .transparent, //This will change the drawer background to blue.
          //other styles
        ),
        child: Drawer(
            child: Container(
          decoration: new BoxDecoration(
              color: Color(0xff515C6F),
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(60),
                  topRight: Radius.circular(60))),
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: <Widget>[
              Container(
                child: DrawerHeader(
                  decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius:
                          BorderRadius.only(topRight: Radius.circular(60)),
                      image: DecorationImage(
                          image: AssetImage("assets/images/popular.png"),
                          colorFilter: new ColorFilter.mode(
                              Colors.black.withOpacity(0.6), BlendMode.dstATop),
                          fit: BoxFit.cover)),
                  child: Stack(
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.only(top: 60),
                        child: Center(
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                drawerImage(
                                    0xffffffff, "assets/images/avatar.png"),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            _rowItemForHeaderText("Lux Saloon", 24,
                                FontWeight.w600, 0xffffffff, 60, 60, 0),
                            _rowItemForHeaderText("@luxsaloon", 14,
                                FontWeight.w400, 0xffffffff, 0, 60, 0),
                          ]),
                    ],
                  ),
                ),
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                title: _rowItemForHeaderText(
                    "Dashboard", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/home_dash.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/home_dash.png"),
                ), //Image.asset("assets/images/home_dash.png"),
                onTap: () {
                  Navigator.pushNamed(context, '/saloonDashboard');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/appoint_white.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/appoint_white.png"),
                ),
                title: _rowItemForHeaderText(
                    "Calendar", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/calender');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/cart.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/cart.png"),
                ),
                title: _rowItemForHeaderText(
                    "Products", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/products');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/group.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/group.png"),
                ),
                title: _rowItemForHeaderText(
                    "Manage Staff", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/manageStaff');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/user_white.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/user_white.png"),
                ), //Image.asset("assets/images/user_white.png"),
                title: _rowItemForHeaderText(
                    "Edit Profile", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/adminProfile');
                  // Navigator.push(context, MaterialPageRoute(builder: (context) => AdminProfile("assets/images/user_white.png"),));
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/disk.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/disk.png"),
                ),
                title: _rowItemForHeaderText(
                    "Requests", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/requests');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/chat.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/chat.png"),
                ),
                title: _rowItemForHeaderText(
                    "Messages", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/chatAdmin');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/bell_simple.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/bell_simple.png"),
                ),
                title: _rowItemForHeaderText(
                    "Notifications", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/notificationsAdmin');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/stop.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/stop.png"),
                ),
                title: _rowItemForHeaderText(
                    "Deals & Offers", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/dealsOffers');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/info.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/info.png"),
                ),
                title: _rowItemForHeaderText(
                    "Help & Support", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  // Update the state of the app.
                  // ...
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/back_logout.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/back_logout.png"),
                ),
                title: _rowItemForHeaderText(
                    "Logout", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  // Update the state of the app.
                  // ...
                },
              ),
            ],
          ),
        )),
      ),
      body: SingleChildScrollView(
        child: Stack(
          children: <Widget>[
            Container(
              height: SizeConfig.screenHeight,
              width: SizeConfig.screenWidth,
              margin: EdgeInsets.only(top: 175),
              // color: ColorsX.dashboardColor,
            ),
            Container(
              margin: EdgeInsets.only(
                  left: SizeConfig.blockSizeHorizontal * 5,
                  top: SizeConfig.blockSizeVertical * 5),
              child: Padding(
                padding: EdgeInsets.symmetric(
                    vertical: SizeConfig.blockSizeVertical),
                child: Image.asset(AppImages.drawer_ic),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  width: SizeConfig.screenWidth * .15,
                ),
                // Container(
                //   margin: EdgeInsets.only(top: 40),
                //   child: TestLeftClass("assets/images/cart.png"),
                // ),
                Container(
                  width: SizeConfig.eightyPercentWidth,
                  margin: EdgeInsets.only(top: 25),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Align(
                        alignment: Alignment.centerLeft,
                        child: _rowItemForHeaderText("Add an add-on", 20,
                            FontWeight.w900, 0xff515C6F, 15, 18, 0),
                      ),
                      _rowItemForHeaderText("Add-On Name", 14, FontWeight.w700,
                          0xff8890A6, 15, 20, 0),
                      whiteContainer(
                          controller.addOnNameCTL, TextInputType.text, .75),
                      _rowItemForHeaderText("Category", 14, FontWeight.w700,
                          0xff8890A6, 15, 20, 0),
                      categoryDropdown(),
                      _rowItemForHeaderText("Brand Name", 14, FontWeight.w700,
                          0xff8890A6, 15, 20, 0),
                      whiteContainer(
                          controller.brandNameCTL, TextInputType.text, .75),
                      _rowItemForHeaderText(
                          "Price", 14, FontWeight.w700, 0xff8890A6, 15, 20, 0),
                      Row(
                        children: [
                          whiteContainer(controller.addOnPriceCTL,
                              TextInputType.number, .52),
                          currencyDropdown(),
                        ],
                      ),
                      _rowItemForHeaderText("Description", 14, FontWeight.w700,
                          0xff8890A6, 15, 20, 0),
                      whiteBlankContainer(context, .75),
                      _rowItemForHeaderText("Upload Photos", 14,
                          FontWeight.w700, 0xff8890A6, 15, 20, 0),
                      whiteBlankContainerUploadPhotos(context, .75),
                      saveButton(context, "Add"),
                    ],
                  ),
                ),
                // Column(
                //   crossAxisAlignment: CrossAxisAlignment.start,
                //   children: <Widget>[
                //   ],
                // ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget categoryDropdown() {
    return Container(
      width: SizeConfig.screenWidth * .75,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Obx(() => Container(
          width: SizeConfig.seventyFivePercentWidth,
          margin: EdgeInsets.only(top: 0, left: 10, bottom: 5),
          child: DropdownButton(
            underline: SizedBox(),
            hint: Text(
              '${controller.selectedCatName.value}',
              style: TextStyle(color: Color(0xff515C6F)),
            ),
            isExpanded: true,
            iconSize: 30.0,
            // icon: Image.asset(AppImages.dropdown_field_ic),
            style: TextStyle(
                color: Color(0xff8890A6),
                fontSize: 14,
                fontWeight: FontWeight.w600),
            items: controller.getCategoryNameList().map(
              (val) {
                return DropdownMenuItem<String>(
                  value: val,
                  child: Text(val),
                );
              },
            ).toList(),
            onChanged: (val) {
              controller.selectedCatName.value = val as String;
            },
          ))),
    );
  }

  Widget currencyDropdown() {
    return Container(
      width: SizeConfig.screenWidth * .18,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Obx(() => Container(
          width: SizeConfig.seventyFivePercentWidth,
          margin: EdgeInsets.only(top: 0, left: 10, bottom: 5),
          child: DropdownButton(
            underline: SizedBox(),
            hint: Text(
              '${controller.selectedCurrency.value}',
              style: TextStyle(color: Color(0xff515C6F)),
            ),
            isExpanded: true,
            iconSize: 30.0,
            // icon: Image.asset(AppImages.dropdown_field_ic),
            style: TextStyle(
                color: Color(0xff8890A6),
                fontSize: 14,
                fontWeight: FontWeight.w600),
            items: currencies.map(
              (val) {
                return DropdownMenuItem<String>(
                  value: val,
                  child: Text(val),
                );
              },
            ).toList(),
            onChanged: (val) {
              controller.selectedCurrency.value = val as String;
            },
          ))),
    );
  }

  Widget whiteContainer(
      TextEditingController ctl, dynamic textType, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
              child: TextField(
                controller: ctl,
                keyboardType: textType,
                style: TextStyle(
                    color: ColorsX.black,
                    fontSize: 14,
                    fontWeight: FontWeight.w700),
                decoration: new InputDecoration(
                    border: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    disabledBorder: InputBorder.none,),
              )),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget saveButton(BuildContext context, String text) {
    return GestureDetector(
      onTap: () async {
        print("SaveButton Res ${controller.getSelectedCategory()}");

        final res = await controller.addNewAddOn();
        if(res){
          Functions.showSimpleDialog(title: 'Add On', msg: 'Add On added successfully');
        }
        // print("SaveButton Res $res");
      },
      child: Container(
          width: SizeConfig.screenWidth * .85,
          margin: EdgeInsets.only(left: 15, top: 15, bottom: 0),
          decoration: new BoxDecoration(
            color: ColorsX.blue_button_color,
            borderRadius: BorderRadius.all(Radius.circular(10)),
            boxShadow: [
              BoxShadow(
                color: ColorsX.blue_button_color,
                blurRadius: 6,
                offset: Offset(1, 1), // Shadow position
              ),
            ],
          ),
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Color(0xffffffff)),
          )),
    );
  }

  Widget whiteBlankContainer(BuildContext context, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
            child: Container(
                height: 60,
                child: TextField(
                  controller: controller.addOnDescriptionCTL,
                  style: TextStyle(
                      color: ColorsX.black,
                      fontSize: 14,
                      fontWeight: FontWeight.w700),
                    decoration: new InputDecoration(
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      errorBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,)
                )),
          ),
          // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget whiteBlankContainerUploadPhotos(BuildContext context, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
            child: Container(
              height: 60,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                        color: ColorsX.blue_text_color, shape: BoxShape.circle),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ClipRRect(
                        borderRadius: new BorderRadius.circular(10.0),
                        child: Image.asset(
                          "assets/images/gallery.png",
                          height: 30,
                          width: 30,
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      InkWell(
                        child: Container(
                          decoration: BoxDecoration(
                            color: ColorsX.blue_button_color,
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                child: Icon(
                                  Icons.add_circle,
                                  color: ColorsX.white,
                                  size: 14,
                                ),
                                margin: EdgeInsets.only(
                                    top: 10, bottom: 10, left: 15, right: 15),
                              ),
                              Container(
                                  margin: EdgeInsets.only(right: 15),
                                  child: Text(
                                    "Add Photos",
                                    style: TextStyle(
                                        color: ColorsX.white,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 12),
                                  )),
                            ],
                          ),
                        ),
                        onTap: () {
                          controller.pickMultipleImages();
                        },
                      ),
                      Obx(() => _rowItemForHeaderText(
                          "${controller.addOnImageCount} images",
                          8,
                          FontWeight.w400,
                          0xff000000,
                          10,
                          0,
                          0)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget simpleContainer(BuildContext context, String firstText,
      String secondText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(
                  firstText, 10, FontWeight.w700, 0xffe1e1e1, 15, 10, 0),
              Container(
                width: SizeConfig.sixtyFivePercentWidth,
                child: _rowItemForHeaderText(
                    secondText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),
              ),
              SizedBox(
                height: 15,
              )
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(right: 10, top: 10),
                child: Image.asset(imagePath),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    margin: EdgeInsets.only(left: 2, top: 2),
                    decoration: new BoxDecoration(
                      color: ColorsX.rating_dashboard,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          bottomRight: Radius.circular(30)),
                    ),
                    child: _rowItemForHeaderText(
                        " 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
