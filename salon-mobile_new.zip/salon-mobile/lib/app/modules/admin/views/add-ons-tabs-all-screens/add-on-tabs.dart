import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:saloon_app/app/modules/admin/controllers/add_on/add_on_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/all_items_add_ons.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class AddOnsTabs extends GetView<AddOnCTL> {
  TabController? _tabController;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: controller.adminServiceCTL.categoryTypeList.isEmpty
          ? 1
          : controller.adminServiceCTL.categoryTypeList.length,
      child: Column(
        children: <Widget>[
          Container(
            height: 50,
            margin: EdgeInsets.only(left: 10),
            color: ColorsX.greydashboard,
            child: TabBar(
              onTap: (index)async{

                if(controller.adminServiceCTL.categoryTypeList.isNotEmpty){
                  String catID=controller.adminServiceCTL.categoryTypeList[index].id;
                  controller.getAddOnsByCategoryRes(1, catID, controller.searchText);
                  controller.pagingController.refresh();
                }

              },

              tabs: [
                if (controller.adminServiceCTL.categoryTypeList.isEmpty)
                  Container(
                      width: SizeConfig.thirtyPercentWidth,
                      child: Text(
                        "All",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      )),
                for (var cat in controller.adminServiceCTL.categoryTypeList)
                  Container(
                      width: SizeConfig.thirtyPercentWidth,
                      child: Text(
                        "${cat.title}",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      )),
              ],
              unselectedLabelColor: const Color(0xff000000),
              indicatorColor: Color(0xff70b4ff),
              labelColor: Color(0xff70b4ff),
              indicatorSize: TabBarIndicatorSize.tab,
              indicatorWeight: 3.0,
              indicatorPadding: EdgeInsets.only(top: 40),
              isScrollable: true,
              controller: _tabController,
            ),
          ),
          Expanded(
            child: TabBarView(controller: _tabController, children: <Widget>[
              if (controller.adminServiceCTL.categoryTypeList.isEmpty)
                Container(child: AddOnsItems()),
              for (var i = 0;
                  i < controller.adminServiceCTL.categoryTypeList.length;
                  i++)
                Container(child: AddOnsItems()),
            ]),
          ),
        ],
      ),
    );
  }
}
