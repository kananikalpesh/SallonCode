import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class TestCase1 extends StatelessWidget {
  TestCase1({Key? key}) : super(key: key);

  bool showAvg = false;
  // bool showAvg = true;

  List<Color> gradientColors = [
    const Color(0xff70b4ff),
    // const Color(0xff70b4ff),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: SizeConfig.screenHeight * .33,
          margin: EdgeInsets.only(
              top: SizeConfig.blockSizeVertical * 5,
              left: SizeConfig.blockSizeHorizontal * 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(
                  "Test Case", 14, FontWeight.w900, 0xff8890A6, 10, 0, 0),
              Expanded(
                child: AspectRatio(
                  aspectRatio: 1.5,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pushNamed(context, '/analyticsReports');
                    },
                    child: Container(
                      // width: SizeConfig.screenWidth*.9,
                      // height: SizeConfig.screenHeight*.3,
                      margin: EdgeInsets.only(left: 0, top: 10, right: 10),
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(
                            Radius.circular(18),
                          ),
                          color: Color(0xffffffff)),
                      child: Padding(
                        padding: const EdgeInsets.only(
                            right: 2.0, left: 2.0, top: 10, bottom: 12),
                        child: LineChart(
                          showAvg ? avgData() : mainData(),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // Stats(),
              SizedBox(
                height: 10,
              ),
              // BarGraph(),
              // BarGraph("2014",5),
            ],
          ),
        ),
        SizedBox(
          width: 60,
          height: 34,
          child: TextButton(
            onPressed: () {
              // setState(() {
              //   showAvg = !showAvg;
              // });
            },
            child: Text(
              '',
              style: TextStyle(
                  fontSize: 12,
                  color:
                      showAvg ? Colors.white.withOpacity(0.5) : Colors.white),
            ),
          ),
        ),
      ],
    );
  }

  LineChartData mainData() {
    return LineChartData(
      gridData: FlGridData(
        show: true,
        drawVerticalLine: true,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,
          getTextStyles: (value, double) => TextStyle(
              color: Color(0xff68737d),
              fontWeight: FontWeight.w400,
              fontSize: 8),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '18 \n Dec';
              case 2:
                return '19 \n Dec';
              case 4:
                return '1 \n Han';
              case 6:
                return '12 \n Jan';
              case 8:
                return '2 \n Feb';
              case 10:
                return '12 \n Mar';
              case 12:
                return '22 \n Mar';
            }
            return '';
          },
          margin: 8,
        ),
        rightTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value, double) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.w400,
            fontSize: 8,
          ),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '122';
              case 2:
                return '124';
              case 4:
                return '126';
              case 6:
                return '128';
              case 8:
                return '130';
              case 10:
                return '132';
            }
            return '';
          },
          reservedSize: 28,
          margin: 4,
        ),
        leftTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value, double) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.w400,
            fontSize: 8,
          ),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '';
              case 1:
                return '';
              case 2:
                return '';
              case 3:
                return '';
              case 4:
                return '';
              case 5:
                return '';
              case 6:
                return '';
              case 7:
                return '';
              case 8:
                return '';
              case 9:
                return '';
              case 10:
                return '';
              case 11:
                return '';
              case 10:
                return '';
            }
            return '';
          },
          reservedSize: 28,
          margin: 4,
        ),
      ),
      borderData: FlBorderData(
          show: true,
          border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 11,
      lineBarsData: [
        LineChartBarData(
          spots: [
            FlSpot(0, 2),
            FlSpot(2.6, 4),
            FlSpot(3.9, 1),
            FlSpot(5.8, 5.1),
            FlSpot(8, 2),
            FlSpot(9.5, 7.5),
            FlSpot(11, 6.3),
          ],
          isCurved: true,
          colors: gradientColors,
          barWidth: 2,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(
            show: true,
            colors:
                gradientColors.map((color) => color.withOpacity(0.4)).toList(),
          ),
        ),
      ],
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  LineChartData avgData() {
    return LineChartData(
      lineTouchData: LineTouchData(enabled: false),
      gridData: FlGridData(
        show: true,
        drawHorizontalLine: true,
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,
          getTextStyles: (value, double) => const TextStyle(
              color: Color(0xff68737d),
              fontWeight: FontWeight.bold,
              fontSize: 16),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '18 \n Dec';
              case 2:
                return '19 \n Dec';
              case 4:
                return '1 \n Han';
              case 6:
                return '12 \n Jan';
              case 8:
                return '2 \n Feb';
              case 10:
                return '12 \n Mar';
              case 12:
                return '22 \n Mar';
            }
            return '';
          },
          margin: 8,
        ),
        rightTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value, double) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '122';
              case 2:
                return '124';
              case 4:
                return '126';
              case 6:
                return '128';
              case 8:
                return '130';
              case 10:
                return '132';
            }
            return '';
          },
          reservedSize: 28,
          margin: 12,
        ),
      ),
      borderData: FlBorderData(
          show: true,
          border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 6,
      lineBarsData: [
        LineChartBarData(
          spots: [
            FlSpot(0, 3.44),
            FlSpot(2.6, 3.44),
            FlSpot(4.9, 3.44),
            FlSpot(6.8, 3.44),
            FlSpot(8, 3.44),
            FlSpot(9.5, 3.44),
            FlSpot(11, 3.44),
          ],
          isCurved: true,
          colors: [
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!,
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!,
          ],
          barWidth: 5,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(show: true, colors: [
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!
                .withOpacity(0.1),
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!
                .withOpacity(0.1),
          ]),
        ),
      ],
    );
  }
}
