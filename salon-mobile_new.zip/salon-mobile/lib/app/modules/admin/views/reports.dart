import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class Reports extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsX.dashboardColor,
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.eightyPercentWidth,
        child: Column(
          children: <Widget>[
            _textAndRounded(context, "Finances"),
            simpleContainer(context, '\$'+'2880.00', '\$'+'40.00', '\$'+'2840.00', "Sales Amount"),
            _textAndRounded(context, "Sales"),
            simpleContainer(context, '1220', '20', '1200', "Sales Quantity"),
            _textAndRounded(context, "Inventory"),
            simpleContainer(context, '1220', '05', '900', "Product Sales"),
            _textAndRounded(context, "Appointments"),
            simpleContainer(context, '1220', '05', '900', "Product Sales"),
            _textAndRounded(context, "Vouchers"),
            simpleContainer(context, '1220', '05', '900', "Product Sales"),
            _textAndRounded(context, "Clients"),
            simpleContainer(context, '1220', '05', '900', "Product Sales"),
            _textAndRounded(context, "Staff"),
            simpleContainer(context, '1220', '05', '900', "Product Sales"),
          ],
        ),
      ),
    );
  }
  Widget simpleContainer(BuildContext context, String firstText, String secondText, String thirdText, String firstHeading){
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15,top: 5, ),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(firstHeading, 10, FontWeight.w700, 0xffE1E1E1, 10, 10, 10),
              _rowItemForHeaderText(firstText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 10),
              SizedBox(height: 10,)
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              _rowItemForHeaderText("Refund", 10, FontWeight.w700, 0xffE1E1E1, 10, 10, 10),
              _rowItemForHeaderText(secondText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 10),
              SizedBox(height: 10,)
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              _rowItemForHeaderText("Grand Total", 10, FontWeight.w700, 0xffE1E1E1, 10, 10, 10),
              _rowItemForHeaderText(thirdText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 10),
              SizedBox(height: 10,)
            ],
          ),
        ],
      ),
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
  Widget _textAndRounded(BuildContext context, String text){
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 10, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),
          Container(
            decoration: new BoxDecoration(
              color: ColorsX.blue_text_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 8),
            child: Text("Export", style: TextStyle(color: ColorsX.white, fontWeight: FontWeight.w400, fontSize: 10),),// _rowItemForHeaderText(, 10, FontWeight.w400, 0xffffffff, 0, 10, 0),
          ),
        ],
      ),
    );
  }
}