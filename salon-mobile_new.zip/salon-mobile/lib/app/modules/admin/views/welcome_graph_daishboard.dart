import 'package:cached_network_image/cached_network_image.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/admin/admin_analaytics_res.dart' as analytic;
import 'package:saloon_app/app/modules/admin/controllers/admin-services/services-admin-list-and-add-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class WelcomeGraphDaishboard extends GetView<ServicesAdminListAddCTL> {
  bool showAvg = false;
  int lengthOfTotalSales = 0;
  int lengthOfTotalStaff = 0;
  int lengthOfTotalAppointment = 0;
  // bool showAvg = true;

  AdminLoginController _adminLoginController=Get.find();
  List<Color> gradientColors = [
    const Color(0xff70b4ff),
    // const Color(0xff70b4ff),
  ];

  @override
  Widget build(BuildContext context) {
    return Obx(()=> controller.isDataLoaded.isTrue? Container(
        // color: Colors.blue,
        margin: EdgeInsets.only(
            left: SizeConfig.blockSizeHorizontal * 5,
            top:  20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding:
                  EdgeInsets.symmetric(vertical: SizeConfig.blockSizeVertical),
              child: Image.asset(AppImages.drawer_ic),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                  margin: EdgeInsets.only(
                    left: SizeConfig.blockSizeHorizontal * 10,
                  ),
                  child: DefaultTabController(
                    length: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _rowItemForHeaderText(
                                      "Welcome,",
                                      14,
                                      FontWeight.w400,
                                      ColorsX.dash_textColor,
                                      0,
                                      0,
                                      0),
                                  _rowItemForHeaderText(
                                      "${_adminLoginController.adminLoginRes?.saloon.name}",
                                      18,
                                      FontWeight.bold,
                                      ColorsX.dash_textColordark1,
                                      5,
                                      0,
                                      0),
                                  _rowItemForHeaderText(
                                      "Dashboard",
                                      12,
                                      FontWeight.w500,
                                      ColorsX.dash_textColor,
                                      5,
                                      0,
                                      0)
                                ],
                              ),
                            ),
                            horizontalSpace(SizeConfig.blockSizeHorizontal * 25),
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle, color: ColorsX.white),
                              child: Image.asset(
                                AppImages.bell_dash_ic,
                                width: 35,
                                height: 35,
                              ),
                            ),
                            horizontalSpace(SizeConfig.blockSizeHorizontal * 3),
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle, color: ColorsX.white),
                              child: Image.asset(
                                AppImages.chat_dash_ic,
                                width: 35,
                                height: 35,
                              ),
                            )

                          ],
                        ),
                        Container(
                          height: SizeConfig.screenHeight * .32,
                          margin: EdgeInsets.only(),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              _rowItemForHeaderText(
                                  "Analytics",
                                  14,
                                  FontWeight.w900,
                                  ColorsX.dash_textColor,
                                  10,
                                  0,
                                  0),
                              Expanded(
                                child: AspectRatio(
                                  aspectRatio: 1.5,
                                  child: GestureDetector(
                                    onTap: () {
                                      Navigator.pushNamed(
                                          context, '/analyticsReports');
                                    },
                                    child: Container(
                                      // width: SizeConfig.screenWidth*.9,
                                      // height: SizeConfig.screenHeight*.3,
                                      margin: EdgeInsets.only(
                                          left: 0, top: 10, right: 10),
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                            Radius.circular(18),
                                          ),
                                          color: Color(0xffffffff)),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            right: 2.0,
                                            left: 2.0,
                                            top: 10,
                                            bottom: 12),
                                        child: LineChart(
                                          showAvg ? avgData() : mainData(),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              // Stats(),
                              SizedBox(
                                height: 10,
                              ),
                              // BarGraph(),
                              // BarGraph("2014",5),
                            ],
                          ),
                        ),
                        rowText("Sales", "Financials"),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: getItemOfDataToBeShown(
                                  context,
                                  lengthOfTotalSales.isGreaterThan(1)?
                                  "${controller.adminAnalyticsRes?.totalsales?[0].totalAmount}+":"0+",
                                  "Sales Today",
                                  "assets/images/bottle.png",
                                  0xff70b4ff),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: getItemOfDataToBeShown(
                                  context,
                                  "${controller.adminAnalyticsRes?.services}+",
                                  "Services",
                                  "assets/images/clients.png",
                                  0xffffffff),
                            ),
                          ],
                        ),
                        rowText("Add-Ons", "Categories"),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: getItemOfDataToBeShown(
                                  context,
                                  "${controller.adminAnalyticsRes?.categories}+",
                                  "Products",
                                  "assets/images/bottle.png",
                                  0xff70b4ff),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: getItemOfDataToBeShown(
                                  context,
                                  "${controller.adminAnalyticsRes?.totalclients}+",
                                  "Clients",
                                  "assets/images/clients.png",
                                  0xffffffff),
                            ),
                          ],
                        ),
                        rowText("Team Members", "Services"),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: getItemOfDataToBeShown(
                                  context,
                                  "${controller.adminAnalyticsRes?.staffcount}+",
                                  "Barbers",
                                  "assets/images/bottle.png",
                                  0xff70b4ff),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: getItemOfDataToBeShown(
                                  context,
                                  "${controller.adminAnalyticsRes?.services}+",
                                  "Services",
                                  "assets/images/clients.png",
                                  0xffffffff),
                            ),
                          ],
                        ),
                        _rowItemForHeaderText("Appointments", 14, FontWeight.bold,
                            ColorsX.dash_textColor, 7, 0, 0),
                        lengthOfTotalAppointment.isGreaterThan(1)?_dashboardTabs():Center(
                          child: Container(
                            child: _rowItemForHeaderText("No appointments", 12, FontWeight.w700, ColorsX.black, 0, 0, 0),
                          ),
                        ),
                        lengthOfTotalAppointment.isGreaterThan(1)?Container(
                          height: SizeConfig.blockSizeVertical * 30,
                          child: TabBarView(
                              children: [
                                _tabItem(),
                                _tabItem(),
                              ]),
                        ):Container(),
                        _rowItemForHeaderText("Staff Members", 14, FontWeight.bold,
                            ColorsX.dash_textColor, 7, 0, 0),
                        lengthOfTotalStaff.isGreaterThan(1)?Container(
                          padding: EdgeInsets.symmetric(
                              vertical: SizeConfig.blockSizeVertical * 2),
                          height: SizeConfig.blockSizeVertical * 37,
                          child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: controller.adminAnalyticsRes?.staffs?.length??0,
                              itemBuilder: (BuildContext context, int index) {
                                String? img='';
                                int? length = controller.adminAnalyticsRes?.staffs?[index].photos?.length;
                                if(controller.adminAnalyticsRes?.staffs?[index].photos !=null){
                                  if(length!>0){
                                    img= controller.adminAnalyticsRes?.staffs![index].photos![0];
                                  }else{
                                    img='';
                                  }
                                }else{
                                  img='';
                                }

                                return Container(
                                  // height: SizeConfig.blockSizeVertical * 20,
                                  decoration: BoxDecoration(
                                      color: ColorsX.white,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(20))),
                                  margin: EdgeInsets.only(
                                      right: SizeConfig.blockSizeHorizontal * 4),
                                  padding: EdgeInsets.symmetric(
                                      vertical: SizeConfig.blockSizeVertical * 3,
                                      horizontal: SizeConfig.blockSizeVertical * 2),
                                  child: Column(
                                    children: [
                                      ClipRRect(
                                        child:  CachedNetworkImage(
                                          imageUrl: AppUrls.BASE_URL_IMAGE + '${img}',
                                          errorWidget: (context, url, error) => Icon(Icons.error),
                                          fit: BoxFit.cover,
                                          width: 50,
                                          height: 50,
                                          placeholder: (context, url) => Container(
                                              height: 30,
                                              width: 30,
                                              child: Center(child: CircularProgressIndicator())),
                                        ),
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          _rowItemForHeaderText(
                                              "${controller.adminAnalyticsRes?.staffs?[index].name}",
                                              14,
                                              FontWeight.bold,
                                              ColorsX.dash_textColordark1,
                                              SizeConfig.blockSizeVertical,
                                              0,
                                              0),
                                          _rowItemForHeaderText(
                                              "Barber",
                                              12,
                                              FontWeight.bold,
                                              ColorsX.dash_textColor,
                                              SizeConfig.blockSizeVertical,
                                              0,
                                              0),
                                          _rowItemForHeaderText(
                                              "${controller.adminAnalyticsRes?.staffs?[index].age} years old",
                                              12,
                                              FontWeight.bold,
                                              ColorsX.dash_textColor,
                                              SizeConfig.blockSizeVertical,
                                              0,
                                              0),
                                          _rowItemForHeaderText(
                                              "${controller.adminAnalyticsRes?.staffs?[index].gender}",
                                              12,
                                              FontWeight.bold,
                                              ColorsX.dash_textColor,
                                              SizeConfig.blockSizeVertical,
                                              0,
                                              0),
                                          _rating(context, double.parse("${controller.adminAnalyticsRes?.staffs?[index].rating??0}"))
                                        ],
                                      )
                                    ],
                                  ),
                                );
                              }),
                        ):Center(
                          child: Container(
                            height: 50,
                            child: _rowItemForHeaderText("No staff member", 12, FontWeight.w700, ColorsX.black, 0, 0, 0),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ):Container(),
    );
  }

  Widget _rating(BuildContext context, double rating) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            height: SizeConfig.blockSizeVertical * 2,
            child: RatingBar.builder(
              initialRating: rating,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemSize: SizeConfig.blockSizeVertical * 1.5,
              itemPadding: EdgeInsets.symmetric(horizontal: 2),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                print(rating);
              },
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 3),
          _rowItemForHeaderText(
              "4.0", 14, FontWeight.w400, ColorsX.subBlack, 0, 0, 0)
        ],
      ),
    );
  }

  Widget _tabItem() {
    return Container(
        decoration: BoxDecoration(
            color: ColorsX.white,
            borderRadius: BorderRadius.all(Radius.circular(10))),
        margin: EdgeInsets.only(
            right: 10,
            top: SizeConfig.blockSizeVertical * 2,
            bottom: SizeConfig.blockSizeVertical * 2),
        padding: EdgeInsets.all(0),
        child: ListView.separated(
          padding: EdgeInsets.all(0),
          itemCount:controller.adminAnalyticsRes?.appointments?.length??0,
          itemBuilder: (BuildContext context, int index) {
            return appointmentItem(controller.adminAnalyticsRes?.appointments?[index]);
          },
          separatorBuilder: (context, index) => Divider(
            color: ColorsX.inputfielboarder,
          ),
        )
        );
  }

  Column appointmentItem(analytic.Appointment? appointment) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: _rowItemForHeaderText("ID #${appointment?.appointmentId}", 14, FontWeight.bold,
                  ColorsX.blue_button_color, 10, 5, 0),
            ),
            _rowItemForHeaderText("${appointment?.appointmentDate.toString().split(' ')[0]} ${appointment?.timeSlot}", 14, FontWeight.bold,
                ColorsX.dash_textColordark1, 10, 0, 10)
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _rowItemForHeaderText("${appointment?.appointmentUser?.name}", 14, FontWeight.normal,
                ColorsX.dash_textColor, 10, 5, 0),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _rowItemForHeaderText("${appointment?.services?.name}", 15, FontWeight.w600,
                ColorsX.dash_textColordark1, 5, 5, 0),
            _rowItemForHeaderText("\$${appointment?.totalPrice}", 15, FontWeight.bold,
                ColorsX.blue_button_color, 5, 0, 10)
          ],
        ),
      ],
    );
  }

  Container _dashboardTabs() {
    return Container(
      margin: EdgeInsets.only(
          // top: SizeConfig.blockSizeVertical * 9.5,
          left: SizeConfig.blockSizeHorizontal * 3,
          right: SizeConfig.blockSizeHorizontal * 3),
      child: TabBar(
          indicatorColor: ColorsX.blue_text_color,
          labelColor: ColorsX.blue_text_color,
          unselectedLabelColor: ColorsX.black,
          labelPadding: EdgeInsets.zero,
          tabs: [
            Tab(
              text: "All",
            ),
            Tab(
              text: "Upcoming",
            ),
          ]),
    );
  }

  Widget rowText(String text1, String text2) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
              child: _rowItemForHeaderText(text1, 14, FontWeight.w700,
                  ColorsX.dash_textColor, 10, 0, 0)),
          Expanded(
              child: _rowItemForHeaderText(text2, 14, FontWeight.w700,
                  ColorsX.dash_textColor, 10, 10, 0)),
        ],
      ),
    );
  }

  Widget getItemOfDataToBeShown(BuildContext context, String text1,
      String text2, String imagePath, int colorCode) {
    lengthOfTotalSales = controller.adminAnalyticsRes?.totalsales?.length??0;
    lengthOfTotalStaff = controller.adminAnalyticsRes?.staffs?.length??0;
    lengthOfTotalAppointment = controller.adminAnalyticsRes?.appointments?.length??0;
    return Stack(
      children: <Widget>[
        Container(
          decoration: new BoxDecoration(
            color: Color(colorCode),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          height: 60,
          margin: EdgeInsets.only(right: 10, top: 10),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            // Expanded(child: SizedBox()),
            SizedBox(
              width: 10,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Align(
                  alignment: Alignment.center,
                  child: _rowItemForHeaderText(
                      text1,
                      18,
                      FontWeight.w900,
                      text2 == "Products"
                          ? ColorsX.white
                          : ColorsX.dash_textColor,
                      23,
                      0,
                      0),
                ),
                Align(
                  alignment: Alignment.center,
                  child: _rowItemForHeaderText(
                      text2,
                      9,
                      FontWeight.w900,
                      text2 == "Products"
                          ? ColorsX.white
                          : ColorsX.dash_textColor,
                      2,
                      0,
                      0),
                ),
              ],
            ),
            Expanded(child: SizedBox()),
            Container(
              margin: EdgeInsets.only(top: 13),
              child: Image.asset(imagePath),
            ),
            SizedBox(
              width: 15,
            ),
            // Expanded(child: SizedBox()),
          ],
        ),
      ],
    );
  }

  LineChartData mainData() {
    return LineChartData(
      gridData: FlGridData(
        show: true,
        drawVerticalLine: true,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,
          getTextStyles: (value, double) => TextStyle(
              color: Color(0xff68737d),
              fontWeight: FontWeight.w400,
              fontSize: 8),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '18 \n Dec';
              case 2:
                return '19 \n Dec';
              case 4:
                return '1 \n Han';
              case 6:
                return '12 \n Jan';
              case 8:
                return '2 \n Feb';
              case 10:
                return '12 \n Mar';
              case 12:
                return '22 \n Mar';
            }
            return '';
          },
          margin: 8,
        ),
        rightTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value, double) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.w400,
            fontSize: 8,
          ),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '122';
              case 2:
                return '124';
              case 4:
                return '126';
              case 6:
                return '128';
              case 8:
                return '130';
              case 10:
                return '132';
            }
            return '';
          },
          reservedSize: 28,
          margin: 4,
        ),
        leftTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value, double) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.w400,
            fontSize: 8,
          ),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '';
              case 1:
                return '';
              case 2:
                return '';
              case 3:
                return '';
              case 4:
                return '';
              case 5:
                return '';
              case 6:
                return '';
              case 7:
                return '';
              case 8:
                return '';
              case 9:
                return '';
              case 10:
                return '';
              case 11:
                return '';
              case 10:
                return '';
            }
            return '';
          },
          reservedSize: 28,
          margin: 4,
        ),
      ),
      borderData: FlBorderData(
          show: true,
          border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 11,
      lineBarsData: [
        LineChartBarData(
          spots: [
            FlSpot(0, 2),
            FlSpot(2.6, 4),
            FlSpot(3.9, 1),
            FlSpot(5.8, 5.1),
            FlSpot(8, 2),
            FlSpot(9.5, 7.5),
            FlSpot(11, 6.3),
          ],
          isCurved: true,
          colors: gradientColors,
          barWidth: 2,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(
            show: true,
            colors:
                gradientColors.map((color) => color.withOpacity(0.4)).toList(),
          ),
        ),
      ],
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color color,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style:
            TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }

  LineChartData avgData() {
    return LineChartData(
      lineTouchData: LineTouchData(enabled: false),
      gridData: FlGridData(
        show: true,
        drawHorizontalLine: true,
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,
          getTextStyles: (value, double) => const TextStyle(
              color: Color(0xff68737d),
              fontWeight: FontWeight.bold,
              fontSize: 16),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '18 \n Dec';
              case 2:
                return '19 \n Dec';
              case 4:
                return '1 \n Han';
              case 6:
                return '12 \n Jan';
              case 8:
                return '2 \n Feb';
              case 10:
                return '12 \n Mar';
              case 12:
                return '22 \n Mar';
            }
            return '';
          },
          margin: 8,
        ),
        rightTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value, double) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '122';
              case 2:
                return '124';
              case 4:
                return '126';
              case 6:
                return '128';
              case 8:
                return '130';
              case 10:
                return '132';
            }
            return '';
          },
          reservedSize: 28,
          margin: 12,
        ),
      ),
      borderData: FlBorderData(
          show: true,
          border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 6,
      lineBarsData: [
        LineChartBarData(
          spots: [
            FlSpot(0, 3.44),
            FlSpot(2.6, 3.44),
            FlSpot(4.9, 3.44),
            FlSpot(6.8, 3.44),
            FlSpot(8, 3.44),
            FlSpot(9.5, 3.44),
            FlSpot(11, 3.44),
          ],
          isCurved: true,
          colors: [
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!,
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!,
          ],
          barWidth: 5,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(show: true, colors: [
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!
                .withOpacity(0.1),
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!
                .withOpacity(0.1),
          ]),
        ),
      ],
    );
  }
}
