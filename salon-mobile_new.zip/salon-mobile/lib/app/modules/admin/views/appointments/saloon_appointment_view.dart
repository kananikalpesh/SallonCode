import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/saloon_appointment_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/appointments/saloon_appointment_tab.dart';
// import 'package:saloon_app/app/modules/admin/views/resuseable/test_left_class.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SaloonAppointmentView extends GetView<SaloonAppointmentCTL>{
  String drawerValue="assets/images/chat.png";
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorsX.greydashboard,
           body: Stack(
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(
                  left: SizeConfig.blockSizeHorizontal * 5,
                  top: 5),
              child: Padding(
                padding:
                EdgeInsets.symmetric(vertical: SizeConfig.blockSizeVertical),
                child: Image.asset(AppImages.drawer_ic),
              ),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Container(
                //   margin: EdgeInsets.only(top: 40),
                //   child: SideMenu("assets/images/chat.png"),
                // ),
                SizedBox(width: SizeConfig.screenWidth*.15,),

                Container(
                  width: SizeConfig.eightyPercentWidth,
                  margin: EdgeInsets.only(top: 5),
                  child: Column(
                    children: <Widget>[
                      _textAndIcon(context, "Appointments", AppImages.request),
                      Expanded(
                        child: Container(
                          width: SizeConfig.seventyFivePercentWidth,
                          margin: EdgeInsets.only(top: 50),
                          child: SaloonAppointmentTabs(),
                        ),
                      ),
                    ],
                  ),
                ),
                // Column(
                //   crossAxisAlignment: CrossAxisAlignment.start,
                //   children: <Widget>[
                //   ],
                // ),
              ],
            ),

            _search(context),
            // Align(
            //   alignment: Alignment.bottomRight,
            //   child: Container(
            //     height: 70,
            //     width: 70,
            //     margin: EdgeInsets.only(bottom: 10, right: 10),
            //     child: _offsetPopup(),
            //     // child: FloatingActionButton(
            //
            //     //   onPressed: () {
            //     //     // Add your onPressed code here!
            //     //   },
            //     //   child: Image.asset("assets/images/floating.png"),
            //     //   backgroundColor: ColorsX.blue_text_color,
            //     // ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  Widget _search(BuildContext context){
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      padding: EdgeInsets.only(left: 5,right: 1),
      decoration: new BoxDecoration(
          color: ColorsX.greydashboard,
          borderRadius: BorderRadius.all( Radius.circular(10))),

      margin: EdgeInsets.only(top: SizeConfig.screenHeight*.05, right: 10, left: SizeConfig.screenWidth*.16),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.text,
        obscureText:  false,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1, //Normal textInputField will be disp
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(top: 15, left: 2),

          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))
          ),
          suffixIcon: Icon(Icons.search_rounded, color: ColorsX.dash_textColor,),
          hintText: "Search",
          hintStyle: TextStyle(color: ColorsX.subBlack),
          // labelStyle: TextStyle(
          //     fontSize: 13,
          //     color: ColorsX.white,
          //     fontWeight: FontWeight.bold),
          // labelText: 'Email',
        ),
      ),
    );
  }
  Widget _offsetPopup() => PopupMenuButton<int>(
    color: ColorsX.subBlack,

    itemBuilder: (context) => [
      PopupMenuItem(
        value: 1,
        child: _rowItemForHeaderText("Add Appointment", 10, FontWeight.w700, 0xffffffff, 0, 0, 0),
      ),
    ],
    icon: Container(
      height: double.infinity,
      width: double.infinity,
      decoration: ShapeDecoration(
          color: ColorsX.blue_text_color,
          shape: StadiumBorder(
            side: BorderSide(color: ColorsX.blue_text_color, width: 2),
          )
      ),
      child: Image.asset("assets/images/floating.png"),// <-- You can give your icon here
    ),
  );
  Widget simpleContainer(BuildContext context, String firstText, String secondText, String imagePath){
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15,top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(firstText, 10, FontWeight.w700, 0xffe1e1e1, 15, 10, 0),
              Container(
                width: SizeConfig.sixtyFivePercentWidth,
                child: _rowItemForHeaderText(secondText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),
              ),
              SizedBox(height: 15,)
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(right: 10,top: 10),
                child: Image.asset(imagePath),
              ),
            ],
          ),
        ],
      ),
    );
  }
  Widget deleteButton(BuildContext context, String text, int colorCode){
    return GestureDetector(
      child: Container(
          width: SizeConfig.seventyFivePercentWidth,
          margin: EdgeInsets.only(left: 15, top: 15),
          decoration: new BoxDecoration(
            color: Color(colorCode),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700,color: Color(0xffffffff)),)
      ),
    );
  }
  Widget _imageHere(BuildContext context,String imagePath,){
    return Container(
      margin: EdgeInsets.only(left: 10,top: 15),
      child: ClipRRect(
        borderRadius: new BorderRadius.circular(10.0),
        child : Image(fit: BoxFit.cover, image: AssetImage(imagePath), width: SizeConfig.seventyFivePercentWidth, height: 200.0,),
      ),
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
  Widget _textAndIcon(BuildContext context, String text, String imagePath){
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 5, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 20, FontWeight.w900, 0xff515C6F, 0, 0, 0),

          Image.asset(imagePath, height: 21, width: 17,),
        ],
      ),
    );
  }
  Widget drawerImage(int colorCode, String imagePath ){
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath=="assets/images/avatar.png"?Align(
            alignment: Alignment.bottomRight,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
              margin: EdgeInsets.only(left: 2, top: 2),
              decoration: new BoxDecoration(
                color: ColorsX.rating_dashboard,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(50), bottomRight: Radius.circular(30)),
              ),
              child: _rowItemForHeaderText(" 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
            ),
          ):Container(),
        ],
      ),
    );
  }
}