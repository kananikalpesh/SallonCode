import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/data/model/admin/appointment/saloon_all_booking.dart'
    as appointment;
import 'package:saloon_app/app/modules/admin/controllers/saloon_appointment_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/appointments/appointments_wrapper.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SaloonAppointmentItem extends GetView<SaloonAppointmentCTL> {
  @override
  Widget build(BuildContext context) {
    return PagedListView<int, appointment.Datum>(
      padding: EdgeInsets.zero,
      pagingController: controller.pagingController,
      builderDelegate: PagedChildBuilderDelegate<appointment.Datum>(
          itemBuilder: (context, item, index) {
        return InkWell(
          // behavior: HitTestBehavior.translucent,
          onTap: () {

            controller.saloonAppointment = item;
            Get.toNamed(SaloonAppointmentsNavigation.appointmentsDetail,
                id: SaloonAppointmentsNavigation.id);
          },
          child: requestItem(
            context,
            "${item.user?.profilePic ?? ''}",
            "${item.user?.name ?? ''}",
            "${item.services?.name ?? ''}",
            double.parse('${item.user?.rating ?? 0}'),
            "${item.timeSlot}",
            "@${item.appointmentId}",
            "Male",
            "${item.status}",
          ),
        );
      }),
    );
  }

  Widget requestItem(
    BuildContext context,
    String imagePath,
    String name,
    String service,
    double rating,
    String time,
    String orderNumber,
    String gender,
    String status,
  ) {
    return Container(
      margin: EdgeInsets.only(left: 0),
      child: Stack(
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Stack(
                  children: <Widget>[
                    Container(
                      height: 80,
                      child: ClipRRect(
                        borderRadius: new BorderRadius.circular(10.0),
                        child: CachedNetworkImage(
                          imageUrl: AppUrls.BASE_URL_IMAGE + '${imagePath}',
                          errorWidget: (context, url, error) =>
                              Icon(Icons.error),
                          fit: BoxFit.cover,
                          width: 80,
                          height: 80,
                          placeholder: (context, url) => Container(
                              height: 30,
                              width: 30,
                              child:
                                  Center(child: CircularProgressIndicator())),
                        ),
                      ),
                    ),
                    Container(
                      height: 75,
                      child: Align(
                        alignment: Alignment.bottomRight,
                        child: Container(
                          margin: EdgeInsets.only(top: 45, left: 40),
                          padding: EdgeInsets.symmetric(
                              vertical: 5, horizontal: 10),
                          decoration: new BoxDecoration(
                            color: ColorsX.dashboardHome,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                bottomRight: Radius.circular(7)),
                          ),
                          child: _rowItemForHeaderText(
                              "New", 7, FontWeight.w700, 0xffffffff, 0, 0, 0),
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    _rowItemForHeaderText(
                        name, 14, FontWeight.w700, 0xff515C6F, 0, 10, 0),
                    SizedBox(
                      height: 10,
                    ),
                    _rowItemForHeaderText(
                        service, 12, FontWeight.w400, 0xff8890A6, 0, 10, 0),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(left: 10),
                          child: SizedBox(
                            height: 20,
                            child: RatingBar.builder(
                              initialRating: rating,
                              minRating: 1,
                              direction: Axis.horizontal,
                              allowHalfRating: true,
                              itemSize: 15,
                              ignoreGestures: true,
                              itemCount: 5,
                              itemPadding:
                                  EdgeInsets.symmetric(horizontal: 2.0),
                              itemBuilder: (context, _) => Icon(
                                Icons.star,
                                color: Colors.amber,
                              ),
                              onRatingUpdate: (rating) {
                                print(rating);
                              },
                            ),
                          ),
                        ),
                        _rowItemForHeaderText(rating.toString(), 12,
                            FontWeight.w400, 0xff8890A6, 0, 5, 0),
                      ],
                    ),
                  ],
                ),
                Expanded(
                  child: SizedBox(),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    _rowItemForHeaderText(
                        time, 14, FontWeight.w600, 0xff515C6F, 0, 0, 0),
                    Image.asset("assets/images/next.png"),
                  ],
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(top: 90, left: 10),
                height: 1,
                color: Color(0xffe1e1e1),
              ),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    _rowItemForHeaderText("Order No:", 8, FontWeight.w400,
                        0xff8890A6, 5, 10, 0),
                    Expanded(child: SizedBox()),
                    _rowItemForHeaderText(
                        orderNumber, 8, FontWeight.w700, 0xff707070, 5, 0, 0),
                    Expanded(child: SizedBox()),
                    _rowItemForHeaderText(
                        "Gender:", 8, FontWeight.w400, 0xff8890A6, 5, 0, 0),
                    Expanded(child: SizedBox()),
                    _rowItemForHeaderText(
                        gender, 8, FontWeight.w700, 0xff707070, 5, 0, 0),
                    Expanded(child: SizedBox()),
                    _rowItemForHeaderText(
                        "Status:", 8, FontWeight.w400, 0xff8890A6, 5, 0, 0),
                    Expanded(child: SizedBox()),
                    _rowItemForHeaderText(
                        status, 8, FontWeight.w700, 0xffff0000, 5, 0, 0),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 5, left: 10),
                height: 1,
                color: Color(0xffe1e1e1),
              )
            ],
          ),
        ],
      ),
    );
  }

  Widget simpleContainer(BuildContext context, String firstText,
      String secondText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(
                  firstText, 10, FontWeight.w700, 0xffe1e1e1, 15, 10, 0),
              Container(
                width: SizeConfig.sixtyFivePercentWidth,
                child: _rowItemForHeaderText(
                    secondText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),
              ),
              SizedBox(
                height: 15,
              )
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(right: 10, top: 10),
                child: Image.asset(imagePath),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget deleteButton(BuildContext context, String text, int colorCode) {
    return GestureDetector(
      child: Container(
          width: SizeConfig.seventyFivePercentWidth,
          margin: EdgeInsets.only(left: 15, top: 15),
          decoration: new BoxDecoration(
            color: Color(colorCode),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Color(0xffffffff)),
          )),
    );
  }

  Widget _imageHere(
    BuildContext context,
    String imagePath,
  ) {
    return Container(
      margin: EdgeInsets.only(left: 10, top: 15),
      child: ClipRRect(
        borderRadius: new BorderRadius.circular(10.0),
        child: Image(
          fit: BoxFit.cover,
          image: AssetImage(imagePath),
          width: SizeConfig.seventyFivePercentWidth,
          height: 200.0,
        ),
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 20, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 20, FontWeight.w900, 0xff515C6F, 0, 0, 0),
          Image.asset(
            imagePath,
            height: 21,
            width: 17,
          ),
        ],
      ),
    );
  }
}
