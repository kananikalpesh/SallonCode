// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/bindings/saloon_appointment_binding.dart';
import 'package:saloon_app/app/modules/admin/views/appointments/saloon_request_detail.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calender_main_screen.dart';

import 'saloon_appointment_view.dart';

class SaloonAppointmentsNavigation {
  SaloonAppointmentsNavigation._();

  static const id = 17;
  static const appointmentsList = '/appointments-list';
  static const appointmentsDetail = '/appointments-Detail';
  static const calenderMainScreen = '/calender-main-screen';
}

// our wrapper, where our main navigation will navigate to
class SaloonAppointmentsWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    print('SaloonAppointmentsWrapper called...........');
    return Navigator(
      key: Get.nestedKey(SaloonAppointmentsNavigation.id),
      onGenerateRoute: (settings) {
        // navigate to a route by name with settings.name
        if (settings.name == SaloonAppointmentsNavigation.appointmentsDetail) {
          return GetPageRoute(
              routeName: SaloonAppointmentsNavigation.appointmentsDetail,
              page: () => SaloonRequestDetail(),
              binding: SaloonAppointmentBinding());
        } else if (settings.name ==
            SaloonAppointmentsNavigation.calenderMainScreen) {
          return GetPageRoute(
            routeName: SaloonAppointmentsNavigation.calenderMainScreen,
            page: () => CalenderMainScreen(),
          );
        } else {
          return GetPageRoute(
              routeName: SaloonAppointmentsNavigation.appointmentsList,
              page: () => SaloonAppointmentView(),
              binding: SaloonAppointmentBinding());
        }
      },
    );
  }
}
