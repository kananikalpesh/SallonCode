import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:motion_toast/motion_toast.dart';
import 'package:motion_toast/resources/arrays.dart';
import 'package:saloon_app/app/data/model/admin/admin-otp-verify-res.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/services/admin/adminHomeApi.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/size_config.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OTPCodeAdmin extends StatefulWidget {
  String phone = '033344';
  OTPCodeAdmin({required this.phone});

  @override
  State<OTPCodeAdmin> createState() => _OTPCodeState();
}

class _OTPCodeState extends State<OTPCodeAdmin> {
  TextEditingController firstController = TextEditingController();

  TextEditingController secondController = TextEditingController();

  TextEditingController thirdController = TextEditingController();

  TextEditingController forthController = TextEditingController();

  FocusNode f1 = new FocusNode();

  FocusNode f2 = new FocusNode();

  FocusNode f3 = new FocusNode();

  FocusNode f4 = new FocusNode();
  String myOtpString = '';

  final interval = const Duration(seconds: 1);

  final int timerMaxSeconds = 25;

  int currentSeconds = 0;

  String get timerText =>
      '${((timerMaxSeconds - currentSeconds) ~/ 60).toString().padLeft(2, '0')}: ${((timerMaxSeconds - currentSeconds) % 60).toString().padLeft(2, '0')}';

  startTimeout([int? milliseconds]) {
    var duration = interval;
    Timer.periodic(duration, (timer) {
      setState(() {
        print(timer.tick);
        currentSeconds = timer.tick;
        if (timer.tick >= timerMaxSeconds) timer.cancel();
      });
    });
  }

  @override
  void initState() {
    startTimeout();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print("${widget.phone} phone received");
    return Scaffold(
      appBar: AppBar(
        backgroundColor: ColorsX.white,
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: ColorsX.subBlack),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Container(
        width: SizeConfig.screenHeight,
        color: ColorsX.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Align(
              alignment: Alignment.topCenter,
              child: Text(
                "Phone verification",
                style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 30,
                    color: ColorsX.blue_text_color),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 15),
              child: Align(
                alignment: Alignment.topCenter,
                child: Text(
                  "Enter your OTP Code here",
                  style: TextStyle(
                      fontWeight: FontWeight.w400,
                      fontSize: 16,
                      color: ColorsX.subBlack),
                ),
              ),
            ),
            _getRowElememt(context),
            Container(
              margin: EdgeInsets.only(top: 15),
              child: Align(
                alignment: Alignment.topCenter,
                child: Text(
                  "$timerText",
                  style: TextStyle(
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                      color: ColorsX.subBlack),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.pushNamed(context, '/continue');
              },
              child: Container(
                margin: EdgeInsets.only(top: 40),
                child: Align(
                  alignment: Alignment.topCenter,
                  child: Text(
                    "Didn't receive any code?",
                    style: TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                        color: ColorsX.subBlack),
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                reSendOtp(context);
                // Get.toNamed(Routes.MAIN_CONTINUE_AS_SCREEN);
              },
              child: Container(
                margin: EdgeInsets.only(top: 20),
                child: Align(
                  alignment: Alignment.topCenter,
                  child: Text(
                    "Resend a new code",
                    style: TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                        color: ColorsX.blue_text_color),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  Widget _getRowElememt(BuildContext context) {
    return Container(
      width: SizeConfig.screenWidth,
      margin: EdgeInsets.only(
          top: 15,
          right: SizeConfig.tenPercentWidth,
          left: SizeConfig.tenPercentWidth),
      // color: ColorsX.subBlack,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 10,
          ),
          Container(
            height: 50,
            width: 50,
            decoration: new BoxDecoration(
                color: firstController.text.isEmpty
                    ? ColorsX.greyBackground
                    : ColorsX.blue_text_color,
                borderRadius: BorderRadius.all(Radius.circular(10))),
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
              // decoration: new BoxDecoration(
              //     color: ColorsX.greyBackground,
              //     borderRadius: BorderRadius.all(Radius.circular(10))),

              // margin: EdgeInsets.only(top: top, right: right, left: left),
              child: TextFormField(
                inputFormatters: [
                  LengthLimitingTextInputFormatter(1),
                ],
                style: TextStyle(color: ColorsX.subBlack),
                keyboardType: TextInputType.number,
                // obscureText: obscure,
                controller: firstController,
                // validator: (String value) => value.length < 10
                //     ? 'Çharacter Length Must Be 10 Character Long'
                //     : null,
                minLines: 1,
                focusNode: f1,
                onChanged: (String newValue) {
                  setState(() {});
                  if (newValue.length == 1) {
                    //changed here
                    // setState(() {

                    // });
                    f1.unfocus();
                    myOtpString = firstController.text +
                        secondController.text +
                        thirdController.text +
                        forthController.text;
                    FocusScope.of(context).requestFocus(f2);

                    if (myOtpString.length == 4) {
                      //changed here
                      // setState(() {

                      // });
                      f4.unfocus();
                      print(widget.phone);
                      sendOtp(context);
                      // Navigator.pushNamed(context, '/continue');
                    }
                  }
                },
                //Normal textInputField will be disp
                decoration: InputDecoration(
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  // hintText: hint,
                  contentPadding: EdgeInsets.only(left: 10, bottom: 18),

                  hintStyle: TextStyle(color: ColorsX.subBlack),
                ),
              ),
            ),
            // TextFields(),
          ),
          Container(
              height: 50,
              width: 50,
              decoration: new BoxDecoration(
                  color: secondController.text.isEmpty
                      ? ColorsX.greyBackground
                      : ColorsX.blue_text_color,
                  borderRadius: BorderRadius.all(Radius.circular(10))),
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                // decoration: new BoxDecoration(
                //     color: ColorsX.greyBackground,
                //     borderRadius: BorderRadius.all(Radius.circular(10))),

                // margin: EdgeInsets.only(top: top, right: right, left: left),
                child: TextFormField(
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(1),
                  ],
                  style: TextStyle(color: ColorsX.subBlack),
                  keyboardType: TextInputType.number,
                  // obscureText: obscure,
                  controller: secondController,
                  // validator: (String value) => value.length < 10
                  //     ? 'Çharacter Length Must Be 10 Character Long'
                  //     : null,
                  minLines: 1,
                  focusNode: f2,

                  onChanged: (String newValue) {
                    setState(() {});

                    if (newValue.length == 0) {
                      f2.unfocus();
                      FocusScope.of(context).requestFocus(f1);
                    }

                    if (newValue.length == 1) {
                      if (firstController.text.isEmpty) {
                        f2.unfocus();
                        myOtpString = firstController.text +
                            secondController.text +
                            thirdController.text +
                            forthController.text;
                        FocusScope.of(context).requestFocus(f1);
                      } else {
                        f2.unfocus();

                        myOtpString = firstController.text +
                            secondController.text +
                            thirdController.text +
                            forthController.text;
                        FocusScope.of(context).requestFocus(f3);
                      }

                      if (myOtpString.length == 4) {
                        //changed here
                        // setState(() {

                        // });
                        f4.unfocus();
                        sendOtp(context);
                        // Get.toNamed(Routes.MAIN_CONTINUE_AS_SCREEN);

                        // Navigator.pushNamed(context, '/continue');
                      }
                    }
                  },
                  //Normal textInputField will be disp

                  decoration: InputDecoration(
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    // hintText: hint,
                    contentPadding: EdgeInsets.only(left: 10, bottom: 18),

                    hintStyle: TextStyle(color: ColorsX.subBlack),
                  ),
                ),
              )),
          Container(
              height: 50,
              width: 50,
              decoration: new BoxDecoration(
                  color: thirdController.text.isEmpty
                      ? ColorsX.greyBackground
                      : ColorsX.blue_text_color,
                  borderRadius: BorderRadius.all(Radius.circular(10))),
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                // decoration: new BoxDecoration(
                //     color: ColorsX.greyBackground,
                //     borderRadius: BorderRadius.all(Radius.circular(10))),

                // margin: EdgeInsets.only(top: top, right: right, left: left),
                child: TextFormField(
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(1),
                  ],
                  style: TextStyle(color: ColorsX.subBlack),
                  keyboardType: TextInputType.number,
                  // obscureText: obscure,
                  controller: thirdController,
                  // validator: (String value) => value.length < 10
                  //     ? 'Çharacter Length Must Be 10 Character Long'
                  //     : null,
                  minLines: 1,
                  focusNode: f3,
                  onChanged: (String newValue) {
                    setState(() {});

                    if (newValue.length == 0) {
                      f3.unfocus();
                      FocusScope.of(context).requestFocus(f2);
                    }

                    if (newValue.length == 1) {
                      //Changed Here
                      // setState(() {

                      // });
                      if (firstController.text.isEmpty) {
                        f3.unfocus();
                        myOtpString = firstController.text +
                            secondController.text +
                            thirdController.text +
                            forthController.text;
                        FocusScope.of(context).requestFocus(f1);
                      } else if (secondController.text.isEmpty) {
                        f3.unfocus();
                        myOtpString = firstController.text +
                            secondController.text +
                            thirdController.text +
                            forthController.text;
                        FocusScope.of(context).requestFocus(f2);
                      } else {
                        f3.unfocus();
                        myOtpString = firstController.text +
                            secondController.text +
                            thirdController.text +
                            forthController.text;
                        FocusScope.of(context).requestFocus(f4);
                      }

                      if (myOtpString.length == 4) {
                        //changed here
                        // setState(() {

                        // });
                        f4.unfocus();
                        sendOtp(context);
                        // Get.toNamed(Routes.MAIN_CONTINUE_AS_SCREEN);

                        // Navigator.pushNamed(context, '/continue');
                      }
                    }
                  },
                  //Normal textInputField will be disp
                  decoration: InputDecoration(
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    // hintText: hint,
                    contentPadding: EdgeInsets.only(left: 10, bottom: 18),

                    hintStyle: TextStyle(color: ColorsX.subBlack),
                  ),
                ),
              )),
          Container(
              height: 50,
              width: 50,
              decoration: new BoxDecoration(
                  color: forthController.text.isEmpty
                      ? ColorsX.greyBackground
                      : ColorsX.blue_text_color,
                  borderRadius: BorderRadius.all(Radius.circular(10))),
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                // decoration: new BoxDecoration(
                //     color: ColorsX.greyBackground,
                //     borderRadius: BorderRadius.all(Radius.circular(10))),

                // margin: EdgeInsets.only(top: top, right: right, left: left),
                child: TextFormField(
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(1),
                  ],
                  style: TextStyle(color: ColorsX.subBlack),
                  keyboardType: TextInputType.number,
                  // obscureText: obscure,
                  controller: forthController,
                  // validator: (String value) => value.length < 10
                  //     ? 'Çharacter Length Must Be 10 Character Long'
                  //     : null,
                  minLines: 1,
                  focusNode: f4,
                  onChanged: (String newValue) {
                    setState(() {});
                    if (forthController.text.isEmpty) {
                      f4.unfocus();
                      FocusScope.of(context).requestFocus(f3);
                    }

                    if (newValue.length == 1) {
                      if (firstController.text.isEmpty) {
                        f4.unfocus();
                        myOtpString = firstController.text +
                            secondController.text +
                            thirdController.text +
                            forthController.text;
                        FocusScope.of(context).requestFocus(f1);
                      } else if (secondController.text.isEmpty) {
                        f4.unfocus();
                        myOtpString = firstController.text +
                            secondController.text +
                            thirdController.text +
                            forthController.text;
                        FocusScope.of(context).requestFocus(f2);
                      } else if (thirdController.text.isEmpty) {
                        f4.unfocus();
                        myOtpString = firstController.text +
                            secondController.text +
                            thirdController.text +
                            forthController.text;
                        FocusScope.of(context).requestFocus(f3);
                      } else {
                        myOtpString = firstController.text +
                            secondController.text +
                            thirdController.text +
                            forthController.text;
                      }

                      if (myOtpString.length == 4) {
                        //changed here
                        // setState(() {

                        // });
                        f4.unfocus();
                        sendOtp(context);
                        // Get.toNamed(Routes.MAIN_CONTINUE_AS_SCREEN);

                        // Navigator.pushNamed(context, '/continue');
                      } else {
                        _displayErrorMotionToast(
                            context, "Otp error", "Please fill in all fields");
                      }
                      // FocusScope.of(context).requestFocus(f4);
                    }
                  },
                  //Normal textInputField will be disp
                  decoration: InputDecoration(
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    // hintText: hint,
                    contentPadding: EdgeInsets.only(left: 10, bottom: 18),

                    hintStyle: TextStyle(color: ColorsX.subBlack),
                  ),
                ),
              )),
          SizedBox(
            width: 10,
          ),
        ],
      ),
    );
  }

  void sendOtp(BuildContext context) async {
    final adminHomeApi = AdminHomeApi();
    String otpCode = firstController.text +
        secondController.text +
        thirdController.text +
        forthController.text;
    String phone = widget.phone;
    Map<String, dynamic> apiParams = {
      'mobile_number': phone,
      'otp': otpCode,
    };
    print(apiParams);
    Functions.showProgressDialog(context, "Loading", "Please wait...");
    Functions.progressDialog.show();
    final res = await adminHomeApi.adminotpVerifyFirstTime(apiParams: apiParams);
    Functions.progressDialog.dismiss();
    // SmartDialog.dismiss();
    if (res is ErrorResponse) {
      if (res.error == true) {
        print("OTP response from UI ${res.msg}");
        Functions.showErrorDialog(title: 'Error', msg: res.msg,isSuccess:false);
      } else {

        print("OTP response from UI ${res.msg}");
      }
    } else {
      if (res is AdminOtpVerifyResponse) {
        print("OTP response from UI in ${res}");
        // showPopUp(context, 'Error', res.token, "OK",false);
        if (res != null && res.token != null) {
          if(res.data.status==true) {
            print('token');
            SharedPreferences prefs = await SharedPreferences.getInstance();
            AppStrings.tokenOfCurrentUser = res.token;
            // UserPreferences().userToken = res.token;
            // UserPreferences().userName = res.data.name;
            // UserPreferences().userID = res.data.id;
            // UserPreferences().userMobileNumber = res.data.mobileNumber;
            // UserPreferences().emailId = res.data.email;
            //
            // AppStrings.tokenOfCurrentUser = res.token;
            // print("USER TOKEN ${UserPreferences().userToken}");
            // Navigator.pushNamed(context, '/continue');
            // Get.toNamed(Routes.ADMIN_MAIN_DAISHBOARD);
            Get.toNamed(Routes.LOGIN_SCREEN_ADMIN);

          }
          else{
            Get.toNamed(Routes.LOGIN_SCREEN_ADMIN);
            // Get.toNamed(Routes.MAIN_CONTINUE_AS_SCREEN);
          }

        }
      } else {
        print("OTP response from UI ${res.msg}");
      }
    }
  }

  void reSendOtp(BuildContext context) async {
    final adminHomeApi = AdminHomeApi();
    String phone = widget.phone;
    Map<String, dynamic> apiParams = {
      'mobile_number': phone,
    };
    Functions.showProgressLoader("Please wait");
    final res = await adminHomeApi.resendOtp(apiParams: apiParams);
    Functions.hideProgressLoader();
    // SmartDialog.dismiss();
    if (res is ErrorResponse) {
      if (res.error == true) {
        print("resend otp response ${res.msg}");
        Functions.showSimpleDialog(title: 'Error', msg: res.msg);
      } else {
        Functions.showSimpleDialog(title: 'Code sent', msg: res.msg);
      }
    }
    // if(res is ErrorResponse) {
    //   if(res.error == true){
    //     print("OTP response from UI ${res.msg}");
    //     Functions.showSimpleDialog(title: 'Error', msg: res.msg);
    //   }else{
    //     Functions.showSimpleDialog(title: 'Code sent', msg: res.msg);
    //   }
    // }
    // else{
    //   if(res is )
    //   showPopUp(context, 'Ye Wala Success', "response", "OK", true,true);
    //   if(res is OtpVerificationResponse) {
    //     // print("OTP response from UI ${res.msg}");
    //     // showPopUp(context, 'Error', res.token, "OK",false);
    //     if (res != null && res.token!=null) {
    //       print('token');
    //       SharedPreferences prefs = await SharedPreferences.getInstance();
    //       UserPreferences().userToken=res.token;
    //       UserPreferences().userName=res.data.name;
    //       UserPreferences().userID=res.data.id;
    //       // UserPreferences().userMobileNumber=res.token;
    //
    //       print("USER TOKEN ${UserPreferences().userToken}");
    //       Navigator.pushNamed(context, '/continue');
    //     }
    //   }
    //   else{
    //
    //   }
    // }
  }

  _displayErrorMotionToast(
      BuildContext context, String title, String description) {
    MotionToast.error(
      title: title,
      titleStyle: TextStyle(fontWeight: FontWeight.bold),
      description: description,
      animationType: ANIMATION.FROM_LEFT,
      position: MOTION_TOAST_POSITION.TOP,
      width: SizeConfig.screenWidth,
    ).show(context);
  }

// void showPopUp(BuildContext context, String title, String content, String ok,
//     bool status) {
//   animatedDialog.showAnimatedDialog(
//     context: context,
//     barrierDismissible: true,
//     builder: (BuildContext context) {
//       return animatedDialog.ClassicGeneralDialogWidget(
//         titleText: title,
//         contentText: content,
//         positiveText: ok,
//         onPositiveClick: () {
//           if (status == false) {
//             Navigator.of(context).pop();
//           } else {
//             // Navigator.of(context).push(MaterialPageRoute(builder:(context)=>OTPCode(phone: _phoneController.text)));
//             Navigator.pushNamed(context, '/continue');
//           }
//         },
//       );
//     },
//     animationType: animatedDialog.DialogTransitionType.fade,
//     curve: Curves.fastOutSlowIn,
//     duration: Duration(seconds: 1),
//   );
// }
}









