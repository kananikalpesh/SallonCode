
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:saloon_app/app/data/model/admin/add-service-response.dart';
import 'package:saloon_app/app/data/model/admin/admin-get-categorized-services-res.dart';
import 'package:saloon_app/app/data/model/admin/admin_analaytics_res.dart';
import 'package:saloon_app/app/data/model/admin/get-service-names.dart' as serv;
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/filter_category_res.dart'
    as cat;
import 'package:saloon_app/app/data/services/admin/adminHomeApi.dart';
import 'package:saloon_app/app/modules/admin/controllers/settingsCtl.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class ServicesAdminListAddCTL extends GetxController {
  final adminHomeApi = AdminHomeApi();
  cat.FilterCategoryRes? filterCategoryRes;
  ErrorResponse? errorResponse;
  GetCategorizedServicesRes? getCategorizedServicesRes;
  AdminAnalyticsRes? adminAnalyticsRes;
  serv.GetServiceNames? getServiceNamesModel;
  AddServiceRes? addServiceRes;
  RxBool isDataLoaded = false.obs;
  // var categoriesList = [].obs;
  List<String> categoryNameList = [];
  List<String> serviceNameList = [];
  List<cat.Category> categoryTypeList = [];
  List<cat.Service> serviceList = [];
  List<serv.Datum> serviceTypeList=[];
  RxBool isServiceAdded = false.obs;
  RxBool isAllServiceLoaded = false.obs;
  RxBool isAllServiceNamesLoaded = false.obs;
  List<String> TimeLimitList = ['20', '30', '40','50','60'];
  List<String> currencies = ['USD',];
  List<String> catagoryList = [];
  List<String> serviceNamesList = [];
  RxString chosenCatrgory = "".obs;
  RxString chosenCatrgoryID = "".obs;
  RxString chosenServiceID = "".obs;
  RxString chosenDuration = "".obs;
  RxString chosenPrefix = "".obs;
  RxString chosenService = "".obs;

  TextEditingController serviceNameController = TextEditingController();
  TextEditingController priceController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();

  final count = 0.obs;

  @override
  void onInit() {
    getAdminAnalytics();
    getAdminAllServices();
    getFilterCategories();
    getServiceNames();
    super.onInit();
  }

  Future<bool> getFilterCategories() async {
    final res = await adminHomeApi.getFilterCategories();
    if (res is cat.FilterCategoryRes) {
      filterCategoryRes = res;
      categoryTypeList = res.categories;
      serviceList = res.services;
      int length = filterCategoryRes?.categories.length ?? 0;
      for (int index = 0; index < length; index++) {
        categoryNameList.add("${filterCategoryRes?.categories[index].title}");
        serviceNameList.add("${filterCategoryRes?.services[index].name}");
        catagoryList.add("${filterCategoryRes?.categories[index].title}");
      }
      chosenCatrgory.value = "${filterCategoryRes?.categories[0].title}";
      chosenDuration.value = "${TimeLimitList[0]}";
      chosenPrefix.value = "${currencies[0]}";
      chosenCatrgoryID.value = "${filterCategoryRes?.categories[0].id}";
      print("list of categories print ${categoryNameList}");
      AppStrings.allCategoriesNamesListAppStrings.addAll(categoryNameList);
      AdminSettingsCTL adminSettingsCTL = Get.find();
      adminSettingsCTL.selectedCatName.value = AppStrings.allCategoriesNamesListAppStrings[0];
      print("app strings list of categories print ${AppStrings.allCategoriesNamesListAppStrings}");

      return true;
    }
    else if (res is ErrorResponse) {
      print('Categories ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<bool> getAdminAllServices() async {
    isAllServiceLoaded = false.obs;
    final res = await adminHomeApi.getAdminAllServices();
    if (res is GetCategorizedServicesRes) {
      getCategorizedServicesRes = res;
      print('adminAllServiceRes');
      isAllServiceLoaded.toggle();
      return true;
    }
    else if (res is ErrorResponse) {
      print('adminAllServiceRes');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<bool> getAdminAnalytics() async {
    this.isDataLoaded.value=false;
    Functions.showProgressLoader("Please Wait");
    final res = await adminHomeApi.getAdminAnalytics();
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is AdminAnalyticsRes) {
      adminAnalyticsRes = res;
      print('adminAllServiceRes');
      this.isDataLoaded.value=true;
      return true;
    }
    else if (res is ErrorResponse) {
      print('adminAllServiceRes');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<bool> getServiceNames() async {
    final res = await adminHomeApi.getAllServicesNames();
    if (res is serv.GetServiceNames) {
      getServiceNamesModel = res;
      serviceTypeList= res.data;
      int length = getServiceNamesModel?.data.length??0;
      for(int index = 0; index < length; index++){
        if(!serviceNamesList.contains("${getServiceNamesModel?.data[index].name}")){
          serviceNamesList.add("${getServiceNamesModel?.data[index].name}");
        }
        else{
          print("${getServiceNamesModel?.data[index].name} already exists");
        }
      }

      chosenServiceID.value = "${getServiceNamesModel?.data[0].id}";
      chosenService.value = "${getServiceNamesModel?.data[0].name}";
      print("${serviceNamesList} service names list");
      print('adminAllServiceRes');
      print("${serviceNamesList} all services names");
      isAllServiceNamesLoaded.toggle();
      return true;
    }
    else if (res is ErrorResponse) {
      print('adminAllServiceRes');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<bool> adminAddService({required Map<String, dynamic> apiParams}) async {
    Functions.showProgressLoader("Please Wait");

    final res = await adminHomeApi.adminAddService(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is AddServiceRes) {
      addServiceRes = res;
      print('addServiceRes RESPONSE FOUND');
      isServiceAdded.toggle();
      Functions.serviceAddedDialog(
        title: "Added",
        msg: "Service Added",
      );
      return true;
    }
    else if (res is ErrorResponse) {
      return true;
    }  else if (res == ExceptionCode.timeOut) {
      Functions.showErrorDialog(
        title: "Error",
        msg: "Connection Timeout",
          isSuccess:false
      );
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      Functions.showErrorDialog(
        title: "Error",
        msg: AppStrings.noInternet,
          isSuccess:false
      );
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showErrorDialog(
        title: "Error",
        msg: AppStrings.error,
          isSuccess:false
      );
      return false;
    }
    return false;
  }
  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

}
