// ignore_for_file: unused_field

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class WelcomeGraphDaishboardCTL extends GetxController
    with SingleGetTickerProviderMixin {
  //TODO: Implement HomeController

  late TabController tabController;
  // late int test;

  @override
  void onInit() {
    tabController = TabController(length: 3, vsync: this);
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}
