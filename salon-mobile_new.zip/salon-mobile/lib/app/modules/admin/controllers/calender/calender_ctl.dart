import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/admin/appointment/saloon_all_booking.dart'
    as salonBooking;
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/services/admin/calender_api.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';
import 'package:table_calendar/table_calendar.dart';

class CalenderCTL extends GetxController {
  CalenderApi _calender = CalenderApi();
  List<salonBooking.Datum>? saloonAllBooking = [];
  CalendarFormat _calendarFormat = CalendarFormat.month;
  RangeSelectionMode _rangeSelectionMode = RangeSelectionMode
      .toggledOff; // Can be toggled on/off by longpressing a date
  Rx<DateTime> focusedDay = DateTime.now().obs;
  DateTime? selectedDay;
  DateTime? rangeStart;
  DateTime? rangeEnd;
  Map<String, List<salonBooking.Datum>>? events = {};
  Map<String, bool>? isEventLoaded = {};
  List<salonBooking.Datum> dayBookingList = [];
  List<DateTime> uniqueDates = [];
  RxBool isBookingsLoaded = false.obs;
  Rx<CalendarFormat> calendarFormat = CalendarFormat.month.obs;
  RxString calenderFormat='Monthly'.obs;

  @override
  void onInit() {
    selectedDay = focusedDay.value;
    getConfirmedBookings();
    super.onInit();
  }

  Future<bool> getConfirmedBookings() async {
    final res = await _calender.getConfirmedBookings();
    // Functions.hideProgressLoader();
    if (res is salonBooking.SaloonBookingRes) {
      saloonAllBooking = res.data;
      //get unique dates
      for (var b in saloonAllBooking!) {
        if (!uniqueDates.contains(b.appointmentDate)) {
          this.uniqueDates.add(b.appointmentDate!);
        }
      }
      print("Unique Date : ${uniqueDates.length}");
      print("Unique Date : ${uniqueDates}");
      //filter booking
      this.filterBooking();
      this.uniqueDates.forEach((date) {
        print('Events ${events?[date]?.length}');
      });

      isBookingsLoaded.toggle();

      return true;
    } else if (res is ErrorResponse) {
      Functions.showErrorDialog(
          title: "Error", msg: '${res.msg}', isSuccess: false);
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      return false;
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
      return false;
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
      return false;
    }
    return false;
  }

  Function? filterBooking() {
    for (var date in uniqueDates) {
      isEventLoaded?[date.toString().split(' ')[0]]=false;
      List<salonBooking.Datum> booking = [];
      for (var b in saloonAllBooking!) {
        if (date == b.appointmentDate) {
          booking.add(b);
        }
      }
      String newDate = date.toString().split(' ')[0];
      this.events?[newDate] = booking;
    }
  }

  List<salonBooking.Datum>? getDayEvents(DateTime day) {
    return this.events?[day.toString().split(' ')[0]];
  }

  void setCalenderFormat(String format){
    if(format=='Monthly'){
      calendarFormat.value = CalendarFormat.month;
    }else if(format=='Weekly'){
      calendarFormat.value = CalendarFormat.week;
    }
  }

}
