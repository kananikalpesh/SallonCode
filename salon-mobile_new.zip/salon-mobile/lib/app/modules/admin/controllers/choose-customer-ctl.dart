import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/admin/customers/admin-add-customers.dart';
import 'package:saloon_app/app/data/model/admin/customers/admin-all-customers.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/services/admin/adminHomeApi.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class ChooseCustomerCTL extends GetxController {
  final adminHomeApi = AdminHomeApi();
  AdminAllCustomersRes? adminAllCustomersRes;
  AdminAddCustomersRes? adminAddCustomersRes;
  RxBool isDataLoaded = false.obs;
  RxString idOfCustomer = "".obs;


  TextEditingController emailController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  TextEditingController dobCTL = TextEditingController();
  String dob = '';
  String gender = '';

  @override
  void onInit() {
    getAllCustomers(search: '');
    super.onInit();
  }

  // Future<void> getSaloonAllBookings(int pageKey, String status) async {
  //   try {
  //     print('Get saloon bookingss... getSaloonAllBookings');
  //
  //     final newItems = await _saloonAppointmentApi.getSaloonAllBookings(
  //         page: pageKey, status: status);
  //     final isLastPage = newItems.data.length < _pageSize;
  //     if (isLastPage) {
  //       pagingController.appendLastPage(newItems.data);
  //     } else {
  //       final nextPageKey = pageKey + 1;
  //       pagingController.appendPage(newItems.data, nextPageKey);
  //     }
  //   } catch (error) {
  //     print(error);
  //     pagingController.error = error;
  //   }
  // }
  //
  Future<bool> getAllCustomers(
      {required String search}) async {

    isDataLoaded = false.obs;
    Functions.showProgressLoader("Please Wait");

    Map<String,dynamic> userInfo = Map();
    userInfo['Search'] = search;
    print(userInfo);
    final res = await adminHomeApi.adminGetAllCustomers(
        apiParams: userInfo);
    Functions.hideProgressLoader();
    isDataLoaded.toggle();
    if (res is AdminAllCustomersRes) {
      adminAllCustomersRes = res;
      return true;
    } else if (res is ErrorResponse) {
      Functions.showErrorDialog(
          title: "Error", msg: '${res.msg}', isSuccess: false);
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      return false;
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
      return false;
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
      return false;
    }
    return false;
  }


  Future<bool> userSignUpAdmin({required Map<String, dynamic> apiParams}) async {
    Functions.showProgressLoader("Please Wait");

    final res = await adminHomeApi.userSignUp(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is AdminAddCustomersRes) {
      adminAddCustomersRes = res;
      idOfCustomer.value = "${adminAddCustomersRes?.data.id}";
      return true;
    } else if (res is ErrorResponse) {
      Functions.showErrorDialog(
          title: "Error",
          msg: "${res.msg}",
          isSuccess:false
      );
      return false;
    }  else if (res == ExceptionCode.timeOut) {
      Functions.showErrorDialog(
          title: "Error",
          msg: "Connection Timeout",
          isSuccess:false
      );
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.noInternet,
          isSuccess:false
      );
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.error,
          isSuccess:false

      );
      return false;
    }
    return false;
  }
}
