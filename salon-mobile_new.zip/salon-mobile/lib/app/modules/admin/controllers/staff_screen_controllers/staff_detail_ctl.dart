// ignore_for_file: unused_field

import 'dart:convert';
import 'dart:io';
import 'dart:io' as Io;

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/data/model/admin/designation_res.dart'
    as designation;
import 'package:saloon_app/app/data/model/admin/staff/salon_all_staff_res.dart'
    as allSaloonStaff;
import 'package:saloon_app/app/data/model/admin/staff/specific_staff_all_booking.dart'
    as specificStaffBooking;
import 'package:saloon_app/app/data/model/customer/core_entity/time_slot.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/services/admin/staff_api.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-services/services-admin-list-and-add-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class StaffCTL extends GetxController with SingleGetTickerProviderMixin {
  //TODO: Implement HomeController

  late TabController tabController;
  StaffApi _staffApi = StaffApi();

  // late int test;
  ServicesAdminListAddCTL _servicesAdminListAddCTL = Get.find();
  AdminLoginController _adminLoginController = Get.find();
  TextEditingController staffNameCTL = TextEditingController();
  TextEditingController staffEmailCTL = TextEditingController();
  TextEditingController staffPhoneCTL = TextEditingController();
  RxString day = 'Monday'.obs;
  RxString selectedDesignationName = 'Barber'.obs;
  RxString startTime = 'Start Time'.obs;
  RxString endTime = 'End Time'.obs;
  RxString slotTime = 'Slot Time'.obs;
  RxString slotInterval = 'Slot Interval'.obs;
  RxString age = '20'.obs;
  RxString gender = 'Male'.obs;
  RxString color = 'Pink'.obs;
  RxString imageStatus = 'NO Image'.obs;
  RxString profileImg = ''.obs;
  RxList<TimeSlot> timeSlotList = RxList();
  List selectedTimeSlot = [];
  File? pickedImage;
  RxBool isBookingLoaded = false.obs;
  RxBool isStaffLoaded = false.obs;

  List<RxString>? dropdownValue;
  List<String> selectedServiceName = [];
  List<String> designationNameList = [];
  List<designation.Datum> designationList = [];
  late allSaloonStaff.Datum staffDetail;

  final PagingController<int, allSaloonStaff.Datum> pagingController =
      PagingController(firstPageKey: 1);
  static const _pageSize = 10;
  specificStaffBooking.SpecificStaffAllBookingRes? staffAllBookingRes;
  List<specificStaffBooking.Booking>? staffAllBookingList = [];
  List<specificStaffBooking.Booking>? staffUpcomingBookingList = [];
  List<specificStaffBooking.Booking>? staffCancelledBookingList = [];

  @override
  void onInit() {
    print('ADD EMPLOYEE CTL>>>>>>>>>>');
    tabController = TabController(vsync: this, length: 4);

    getDesignations();
    dropdownValue = [
      day,
      slotTime,
      slotInterval,
      selectedDesignationName,
      gender,
      age,
      color
    ];
    tabController = TabController(length: 3, vsync: this);
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

  Function? addSlot(TimeSlot slot) {
    timeSlotList.add(slot);
    selectedTimeSlot.add(slot.toJson());
  }

  List<String> getServiceNameList() {
    return _servicesAdminListAddCTL.serviceNameList;
  }

  String? getDesignationId() {
    return designationList
        .firstWhere((d) => d.title == selectedDesignationName.value)
        .id;
  }

  List<String> getSelectedServices() {
    List<String> result = [];
    selectedServiceName.forEach((aElement) {
      dynamic value = _servicesAdminListAddCTL.serviceTypeList.firstWhere(
        (bElement) => bElement.name == aElement,
      );
      if (value != '') {
        result.add(value.id);
      }
    });
    print(result);
    return result;
  }

  Future<void>? takePicture() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      pickedImage = Io.File(image.path);
      print('image selected. ${pickedImage}');
      imageStatus.value = 'Selected';
    } else {
      imageStatus.value = 'No image';
      pickedImage = null;
      print('No image selected.');
    }

    // controller.imageFile = File(image.path);
  }

  Future<bool> addEmployee(BuildContext context) async {
    String name = staffNameCTL.text;
    String email = staffEmailCTL.text;
    String phn = staffPhoneCTL.text;
    String? d_id = getDesignationId();
    var serviceList = getSelectedServices();
    var timeSlot = selectedTimeSlot;
    var empAge = age.value;
    var empColor = color.value;
    var empgender = gender.value;

    var apiParams = {
      "Name": "$name",
      "Designation": "$d_id",
      "Gender": "$empgender",
      "Age": '$empAge',
      "Saloon": "${_adminLoginController.adminLoginRes?.saloon.id ?? ''}",
      "Services": jsonEncode(serviceList),
      "Email": "$email",
      "Time_Slots": jsonEncode(timeSlot),
    };
    print("employeeData :$apiParams");
    Functions.showProgressLoader("Please Wait");
    var res;
    res = await _staffApi.addEmployee(
      apiParams: apiParams,
      image: pickedImage,
    );
    Functions.hideProgressLoader();
    if (res == ExceptionCode.success) {
      return true;
    } else if (res is ErrorResponse) {
      Functions.showToast(res.msg);
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<bool> getDesignations() async {
    var res;
    res = await _staffApi.getDesignations();
    if (res is designation.DesignationRes) {
      designationList = res.data!;
      for (var d in res.data!) {
        designationNameList.add(d.title!);
      }
      return true;
    } else if (res is ErrorResponse) {
      Functions.showToast(res.msg);
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<void> getSaloonAllStaff(
      [String search = '', String designation = '', int pageKey = 1]) async {
    try {

      final newItems =
          await _staffApi.getSaloonAllStaff(search, designation, pageKey);
      isStaffLoaded.value = true;
      final isLastPage = newItems.data.length < _pageSize;
      if (isLastPage) {
        pagingController.appendLastPage(newItems.data);
      } else {
        final nextPageKey = pageKey + 1;
        pagingController.appendPage(newItems.data, nextPageKey);
      }
    } catch (error) {
      print(error);
      pagingController.error = error;
    }
  }

  List<specificStaffBooking.Booking>? getStaffAllBooking(String status) {
    print('getStaffAllBooking........$status ');
    var bl;
    if (status == 'All') {
      staffAllBookingList = staffAllBookingRes?.data;
      return staffAllBookingRes?.data;
    } else if (status == 'Pending') {
      bl = staffAllBookingRes?.data?.where((b) => b.status == status).toList();
      staffUpcomingBookingList = bl;
    } else if (status == 'Cancelled') {
      bl = staffAllBookingRes?.data?.where((b) => b.status == status).toList();
      staffCancelledBookingList = bl;
    }
    print('getStaffAllBooking........${bl?.length} ');

    return bl;
  }

  Future<void> specificStaffAllBooking({required String staffId}) async {
    try {
      final res = await _staffApi.specificStaffAllBooking(staffId: staffId);
      isBookingLoaded.value = true;
      if (res is specificStaffBooking.SpecificStaffAllBookingRes) {
        staffAllBookingRes = res;
      }
    } catch (error) {
      print(error);
      pagingController.error = error;
    }
  }
}
