import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/staff_screen_controllers/staff_detail_ctl.dart';



class StaffBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<StaffCTL>(
      () => StaffCTL(),
    );
  
  }
}
