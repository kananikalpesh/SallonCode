import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-add-slot/admin-saloon-controller.dart';
import 'package:saloon_app/app/modules/admin/controllers/choose-customer-ctl.dart';

class ChooseCustomerBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<ChooseCustomerCTL>(
      ChooseCustomerCTL(),
    );
    Get.put<AdminSaloonController>(
      AdminSaloonController(),
    );
  }
}