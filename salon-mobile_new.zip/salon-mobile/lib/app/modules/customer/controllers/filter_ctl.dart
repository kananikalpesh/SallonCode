import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/saloon-item-model.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';

class FilterCTL extends GetxController {
  // HomeApi _homeApi=HomeApi();

  List selectedCategoryList = [];
  RxDouble rating = 1.0.obs;
  RxDouble distance = 1.0.obs;
  Rx<RangeValues> distanceRangeValues = RangeValues(1, 2).obs;
  Rx<RangeValues> priceRangeValues = RangeValues(1, 2).obs;
  RxString sortByGroupValue = 'Most Popular'.obs;
  RxBool isCategoryLoaded = false.obs;
  late RxList<Category> categories;

  @override
  void onInit() {
    DashboardItemController dCTL = Get.find();
    if (dCTL.saloonItemsModel?.categories != null)
      categories = dCTL.saloonItemsModel!.categories!.obs;
    super.onInit();
  }

// Future<bool> getSpecificStaffDetails() async {
//   Functions.showProgressLoader("Please Wait");
//
//   isCategoryLoaded = false.obs;
//   print(MiddleContainer.staffId);
//   print(getTodaysDate());
//   Map<String, String> apiParams = {
//     "date": getTodaysDate(),
//     "id": MiddleContainer.staffId
//   };
//   String date = getTodaysDate();
//   final res = await homeApi.getSpecificStaffDetails(date: date, id:MiddleContainer.staffId);
//   print(' CTL RESPONSE${res}');
//   Functions.hideProgressLoader();
//   if (res is StaffDetailModel) {
//     staffDetailModel = res;
//     // isServiceChecked =
//     //     List<bool>.generate(res.saloon.services.length, (index) => false).obs;
//     print('GET STAFF DETAIL RESPONSE FOUND');
//     isCategoryLoaded.toggle();
//     return true;
//   } else if (res is ErrorResponse) {
//     print('ADD MEMBER ERROR RESPONSE FOUND');
//     errorResponse = res;
//     return false;
//   } else if (res == ExceptionCode.timeOut) {
//     print(res);
//     Functions.showToast(AppStrings.slowInternet);
//     //slow internet
//   } else if (res == ExceptionCode.noInternet) {
//     //no internet
//     print(res);
//     Functions.showToast(AppStrings.noInternet);
//   } else if (res == ExceptionCode.error) {
//     //server error
//     print(res);
//     Functions.showToast(AppStrings.error);
//   }
//   return false;
// }

}
