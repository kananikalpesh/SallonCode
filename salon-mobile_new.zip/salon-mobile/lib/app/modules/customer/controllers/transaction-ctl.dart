import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/data/model/customer/appointment/my_appointment.dart'
as appointment;
import 'package:saloon_app/app/data/model/customer/appointment/my_appointment.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/services/customer/appointment_api.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class TransactionCTL extends GetxController with SingleGetTickerProviderMixin  {
  final appointmentApi = AppointmentApi();
  static const _pageSize = 10;
  Datum? myAppointment;
  appointment.MyAppointment? myAppointmentRes;
  ErrorResponse? errorResponse;
  int servicesTotal = 0;
  int addOnsTotal = 0;
  RxInt endTime = 0.obs;
  RxBool isBookingCancelled = false.obs;
  RxBool isDataLoaded = false.obs;
  final PagingController<int, appointment.Datum> pagingController =
  PagingController(firstPageKey: 1);
  // TabController? tabController;
  // RxInt tabCurrentIndex=0.obs;

  @override
  void onInit() {
    // tabController = TabController(vsync: this, length: 4);

    fetchAllAppointment(1, 'All');
    super.onInit();
  }

  Future<bool> fetchAllAppointment(int pageKey, String status) async {

    Functions.showProgressLoader("Please wait");

    final res = await appointmentApi.getAllAppointment(page: pageKey, status: status);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is appointment.MyAppointment) {
      myAppointmentRes = res;
      print('User Profile RESPONSE FOUND now jcdfhgjkfdhjkgh ');
      isDataLoaded.value=true;
      return true;
    } else if (res is ErrorResponse) {
      print('ADD MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<bool> cancelBooking({required String id}) async {
    Functions.showProgressLoader("Please Wait");
    final res = await appointmentApi.cancelBooking(id: id);
    Functions.hideProgressLoader();
    if (res is ErrorResponse) {
      if (res.error) {
        Functions.showErrorDialog(title: "Error", msg: '${res.msg}',isSuccess:false);
      } else {
        return true;
      }
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      return false;
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
      return false;
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
      return false;
    }
    return false;
  }

  void initializeTimer() {

    if (myAppointment!.status != 'Cancelled') {
      int year = myAppointment!.appointmentDate?.year??0;
      int month = myAppointment!.appointmentDate?.month??0;
      int day = myAppointment!.appointmentDate?.day??0;
      int hour = int.parse('${myAppointment!.timeSlot?.split(':')[0]??0}');
      int mints =
      int.parse('${myAppointment!.timeSlot?.split(':')[1].split(' ')[0]??0}');
      print('$hour ...... $mints');
      myAppointment!.appointmentDate?.millisecondsSinceEpoch;
      endTime.value =
          DateTime(year, month, day, hour, mints, 00).millisecondsSinceEpoch;
    } else {
      isBookingCancelled.value=true;
      endTime.value = DateTime.now().millisecondsSinceEpoch;
    }
  }
}
