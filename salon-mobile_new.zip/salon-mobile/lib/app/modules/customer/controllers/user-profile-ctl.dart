import 'dart:io';

import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/user-profile-edit.dart';
import 'package:saloon_app/app/data/model/customer/user-profile.dart';
import 'package:saloon_app/app/data/services/customer/saloon-home-api.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class UserProfileCtl extends GetxController {
  final homeApi = HomeApi();
  UserProfileModel? userProfileModel;
  EditUserProfileModel? editUserProfileModel;
  ErrorResponse? errorResponse;
  String accountCreated = "";
  // final emailCtl = TextEditingController();
  // final mobileCtl = TextEditingController();
  // final dobCtl = TextEditingController();
  RxBool isDataLoaded = false.obs;
  RxString chosenDateTime="".obs;
  String? day="";
  String? month="";
  String? year="";
  File? pickedImage;
  RxBool isPickSelected=false.obs;

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }
  Future<bool> getSpecificUserDetails() async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    final res = await homeApi.getSpecificUserDetails();
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is UserProfileModel) {
      userProfileModel = res;
      print('User Profile RESPONSE FOUND now jcdfhgjkfdhjkgh ');
      accountCreated = userProfileModel!.data.registerDate.toString().split("T11:19:09.876Z")[0];
      day = userProfileModel?.data.dob.toString().split("/")[0];
      month = userProfileModel?.data.dob.toString().split("/")[1];
      year = userProfileModel?.data.dob.toString().split("/")[2];
      print(day);
      print(month);
      print(year);
      print(isDataLoaded);
      isDataLoaded.value=true;
      return true;
    } else if (res is ErrorResponse) {
      print('ADD MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }
  Future<bool> editSpecificUserDetails({required Map<String, dynamic> apiParams}) async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    final res = await homeApi.editSpecificUserDetails(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is EditUserProfileModel) {
      editUserProfileModel = res;
      print('User Profile RESPONSE FOUND');
      accountCreated = userProfileModel!.data.registerDate.toString().split("T11:19:09.876Z")[0];
      day = userProfileModel?.data.dob.toString().split("/")[0];
      month = userProfileModel?.data.dob.toString().split("/")[1];
      year = userProfileModel?.data.dob.toString().split("/")[2];
      print(day);
      print(month);
      print(year);
      print(isDataLoaded);
      isDataLoaded.toggle();
      Functions.showErrorDialog(title: "Edit Profile", msg: "${editUserProfileModel?.msg}",isSuccess:false);
      return true;
    } else if (res is ErrorResponse) {
      print('Edit MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }
  Future<bool> editSpecificUserDetailswithImage({required Map<String, String> apiParams}) async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    final res = await homeApi.editSpecificUserDetailswithImages(apiParams: apiParams,image: pickedImage);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is EditUserProfileModel) {
      editUserProfileModel = res;
      print('User Profile RESPONSE FOUND');
      accountCreated = userProfileModel!.data.registerDate.toString().split("T11:19:09.876Z")[0];
      day = userProfileModel?.data.dob.toString().split("/")[0];
      month = userProfileModel?.data.dob.toString().split("/")[1];
      year = userProfileModel?.data.dob.toString().split("/")[2];
      print(day);
      print(month);
      print(year);
      print(isDataLoaded);
      isDataLoaded.toggle();
      Functions.showErrorDialog(title: "Edit Profile", msg: "${editUserProfileModel?.msg}",isSuccess:false);
      return true;
    } else if (res is ErrorResponse) {
      print('Edit MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }
  // Future<bool> saloonItems({required Map<String, dynamic> apiParams, required BuildContext context}) async {
  //   Functions.showProgressLoader("Please Wait");
  //
  //   isDataLoaded = false.obs;
  //   final res = await authApi.userLogin(apiParams: apiParams);
  //   print(' CTL RESPONSE${res}');
  //   Functions.hideProgressLoader();
  //   if (res is SaloonItemsModel) {
  //     saloonItemsModel = res;
  //     print('ADD MEMBER SUCCESS RESPONSE FOUND');
  //     isDataLoaded.toggle();
  //     return true;
  //   } else if (res is ErrorResponse) {
  //     print('ADD MEMBER ERROR RESPONSE FOUND');
  //     errorResponse = res;
  //     return false;
  //   } else if (res == ExceptionCode.timeOut) {
  //     print(res);
  //     Functions.showToast(AppStrings.slowInternet);
  //     //slow internet
  //   } else if (res == ExceptionCode.noInternet) {
  //     //no internet
  //     print(res);
  //     Functions.showToast(AppStrings.noInternet);
  //   } else if (res == ExceptionCode.error) {
  //     //server error
  //     print(res);
  //     Functions.showToast(AppStrings.error);
  //   }
  //   return false;
  // }
  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
