import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/custome_home_controller.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/modules/customer/views/Categories.dart';
import 'package:saloon_app/app/modules/customer/views/HeaderStack.dart';
import 'package:saloon_app/app/modules/customer/views/home/home_wrapper.dart';
import 'package:saloon_app/app/resuseable/saloon_listview_items.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SearchScreen extends StatelessWidget {
  //DashboardItem _dashboardItem = DashboardItem();
  CustomerHomeController customerHomeController = Get.find();
  //final GlobalKey<NavigatorState> navigatorKey = GlobalKey();
  DashboardItemController _dashboardItemController = Get.find();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: SizeConfig.screenHeight,
          width: SizeConfig.screenWidth,
          child: myStackOnTop(context),
        ),
      ),
    );
  }

  Widget myStackOnTop(BuildContext context) {
    return Column(
      children: <Widget>[
        HeaderStack(
          categoryShow: "yes",
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _myLocationText(context, "Search Result", 0xff000000, 25, 0, 0,
                FontWeight.w600, 16),
            Container(
              margin: EdgeInsets.only(right: 25),
              // width: 50,
              // height: 20,
              decoration: BoxDecoration(
                  //color: Colors.blue,
                  borderRadius: BorderRadius.all(Radius.circular(8))),
              child: Row(
                children: [
                  InkWell(
                    onTap: () {},
                    child: Container(
                      width: SizeConfig.blockSizeHorizontal * 8,
                      height: SizeConfig.blockSizeVertical * 4,
                      decoration: BoxDecoration(
                          color: ColorsX.blue_button_color,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(8),
                              bottomLeft: Radius.circular(8))),
                      child: Center(
                        child: Image.asset(
                          AppImages.List_ic,
                          color: ColorsX.white,
                        ),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      // customerHomeController.homecurrentScreenIndex.value = 2;
                      Get.toNamed(HomeNavigation.locationScreen, id: 2);
                    },
                    child: Container(
                      width: SizeConfig.blockSizeHorizontal * 8,
                      height: SizeConfig.blockSizeVertical * 4,
                      decoration: BoxDecoration(
                          border: Border.all(color: ColorsX.icon_grey),
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(8),
                              bottomRight: Radius.circular(8))),
                      child: Center(
                          child: Image.asset(
                        AppImages.Location_ic,
                        color: ColorsX.icon_grey,
                      )),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
        Container(
          //margin: EdgeInsets.only(top: SizeConfig.screenHeight * .30),
          //height: 220,
          child: SaloonListViewItem(
            saloonItemsModel: _dashboardItemController.searchedSaloonItems!.value,
          ),
        ),
      ],
    );
  }

  Widget TextFields(bool obscure, double top, double left, double right,
      String hint, String inputType) {
    return Container(
      padding: EdgeInsets.only(left: 5, right: 5),
      decoration: BoxDecoration(
          color: ColorsX.greyBackground,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: top, right: right, left: left),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.text,
        obscureText: obscure,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1,
        //Normal textInputField will be disp
        decoration: InputDecoration(
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          hintText: hint,
          contentPadding: EdgeInsets.only(top: 15),
          hintStyle: TextStyle(color: ColorsX.subBlack),
          prefixIcon: Icon(
            Icons.search,
            color: ColorsX.subBlack,
          ),
        ),
      ),
    );
  }

  Widget _myLocationText(
      BuildContext context,
      String text,
      int colorCode,
      double left,
      double top,
      double right,
      FontWeight fontWeight,
      double fontSize) {
    return GestureDetector(
        onTap: () {
          if (text == ("View All")) {
            // Navigator.pushNamed(context, '/viewAll');
            Categories.ID = "";
            //Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomSheetReusable(value: "Home")));
          } else {
            print("no");
          }
        },
        child: Container(
          margin: EdgeInsets.only(left: left, top: top, right: right),
          child: Text(
            text,
            style: TextStyle(
                color: Color(colorCode),
                fontWeight: FontWeight.w600,
                fontSize: fontSize),
          ),
        ));
  }

  // Future<void> progressDilog() async {
  //   final _dashboardItemProvider = DashboardItemProvider();
  //   Functions.showProgressLoader("Loading Data");
  //   final res = await _dashboardItemProvider.saloonDashboardItem();
  //   // await Future.delayed(Duration(seconds: 3)).then((value) => Functions.progressDialog.dismiss());
  //   Functions.hideProgressLoader();
  //   setState(() {
  //     loadingdone = true;
  //   });
  //   if(res is ErrorMessage){
  //     if(res.error==true){
  //       print("DASHBOARD ITEM UI ${res.msg}");
  //       showPopUp(context, 'Error', res.msg, "OK",false);
  //     }
  //     else{
  //       print("DASHBOARD_ITEM UI${res.msg}");
  //     }
  //   }else{
  //     if(res is DashboardItem){
  //       _dashboardItem = res;
  //       print("DASHBOARD_RESPONSE${res.popular}");
  //     }
  //     else{
  //       print("DASHBOARD_RESPONSE_HERE${res}");
  //     }
  //   }
  // }

  // void showPopUp(BuildContext context,String title, String content,String ok, bool status){
  //   animatedDialog.showAnimatedDialog(
  //     context: context,
  //     barrierDismissible: true,
  //     builder: (BuildContext context) {
  //       return animatedDialog.ClassicGeneralDialogWidget(
  //         titleText: title,
  //         contentText: content,
  //         positiveText: ok,
  //         onPositiveClick: () {
  //           if (status==false) {
  //             Navigator.of(context).pop();
  //           }
  //           else {
  //             // Navigator.of(context).push(MaterialPageRoute(builder:(context)=>OTPCode(phone: _phoneController.text)));
  //             // Navigator.pushNamed(context, '/continue');
  //           }
  //         },
  //       );
  //     },
  //     animationType: animatedDialog.DialogTransitionType.fade,
  //     curve: Curves.fastOutSlowIn,
  //     duration: Duration(seconds: 1),
  //   );
  // }

}
