import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/modules/customer/views/Categories.dart';
import 'package:saloon_app/app/modules/customer/views/HeaderStack.dart';
import 'package:saloon_app/app/modules/customer/views/favourite-saloons.dart';
import 'package:saloon_app/app/resuseable/loading-state.dart';
import 'package:saloon_app/app/resuseable/package_and_offers_row.dart';
import 'package:saloon_app/app/resuseable/saloon_row_item.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/gv.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class HeaderWelcome extends GetView<DashboardItemController> {
  @override
  Widget build(BuildContext context) {
    return  Obx(() => controller.isDataLoaded.isTrue
        ? itemDashboard(context)
        : LoadingState());

  }
  Widget itemDashboard(BuildContext context){
    return
      Scaffold(
          body: Container(
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            child: ListView(
              children: <Widget>[
                myStackOnTop(context),
              ],
            ),
          )
      );
  }

  Widget myStackOnTop(BuildContext context) {
    return Stack(
      children: <Widget>[
        HeaderStack(
          categoryShow: "yes",
        ),

        Container(
          margin: EdgeInsets.only(top: SizeConfig.screenHeight * .33),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _myLocationText(context, "Categories", 0xff000000, 25, 20, 0,
                      FontWeight.w600, 16),
                ],
              ),
              Categories(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _myLocationText(context, "Top Saloons", 0xff000000, 25, 20, 0,
                      FontWeight.w600, 16),
                  InkWell(
                    onTap: (){
                      GV.isFromFavorite=false;
                      AppStrings.categoryID="";
                      print('Going to all saloons clicked...');
                      Get.toNamed(Routes.VIEW_ALL_SALOONS_SCREEN);
                    },
                    child: _myLocationText(context, "View All", 0xff70b4ff, 0, 20, 20,
                        FontWeight.w600, 16),
                  ),
                ],
              ),
              Container(
                // child: SaloonRowItem(dashboardItem: _dashboardItem, isPopular: true,)
                child: SaloonRowItem(
                  saloonItemsModel: controller.saloonItemsModel!,
                  isHorizontal: true,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _myLocationText(context, "Special Packages & Offers",
                      0xff000000, 25, 15, 0, FontWeight.w600, 16),
                  InkWell(
                    onTap: (){
                      print('Going to all Offers clicked...');

                      AppStrings.categoryID="";
                      Get.toNamed(Routes.VIEW_ALL_OFFER_SCREEN);
                    },
                    child: _myLocationText(context, "View All", 0xff70b4ff, 0, 15, 20,
                        FontWeight.w600, 16),
                  ),
                ],
              ),
              Container(
                // child: SaloonRowItem(dashboardItem: _dashboardItem, isPopular: true,)
                child: PackageAndOfferRow(),
              ),
              (controller.saloonItemsModel!.favorite?.isNotEmpty??false)?Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _myLocationText(context, "Favourite Saloons", 0xff000000, 25,
                      15, 0, FontWeight.w600, 16),
                  InkWell(
                    onTap: (){
                      GV.isFromFavorite=true;

                      AppStrings.categoryID="";
                      Get.toNamed(Routes.VIEW_ALL_SALOONS_SCREEN);
                    },
                    child: _myLocationText(context, "View All", 0xff70b4ff, 0, 15, 20,
                        FontWeight.w600, 16),
                  ),
                ],
              ):Container(),
              (controller.saloonItemsModel!.favorite?.isNotEmpty??false)?Container(
                child: FavoriteSaloon(
                  isHorizontal: true,
                ),
              ):Container(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _myLocationText(
      BuildContext context,
      String text,
      int colorCode,
      double left,
      double top,
      double right,
      FontWeight fontWeight,
      double fontSize) {
    return Container(
      margin: EdgeInsets.only(left: left, top: top, right: right),
      child: Text(
        text,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: FontWeight.w600,
            fontSize: fontSize),
      ),
    );
  }


}
