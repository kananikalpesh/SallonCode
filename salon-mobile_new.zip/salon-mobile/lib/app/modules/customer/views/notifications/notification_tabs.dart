
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/customer/views/notifications/all.dart';
import 'package:saloon_app/app/utils/colors.dart';


class NotificationTabs extends StatefulWidget {
  @override
  _DemoState createState() => _DemoState();
}

class _DemoState extends State<NotificationTabs> with TickerProviderStateMixin {
  TabController? _tabController;

  @override
  void initState() {
// TODO: implement initState
    super.initState();
    _tabController = new TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController?.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Container(
          height: 55,
          color: ColorsX.lightStackColor,
          child: TabBar(
            tabs: [
              Container(
                  width: 70.0,
                  child: Text("All", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, ),)
              ),
              Container(
                  width: 75.0,
                  child: Text("Read", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),)
              ),
              Container(
                  width: 75.0,
                  child: Text("Unread", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),)
              ),
            ],
            unselectedLabelColor: const Color(0xff000000),
            indicatorColor: Color(0xff70b4ff),
            labelColor: Color(0xff70b4ff),
            indicatorSize: TabBarIndicatorSize.tab,
            indicatorWeight: 3.0,
            indicatorPadding: EdgeInsets.all(10),
            isScrollable: false,
            controller: _tabController,
          ),
        ),
        Expanded(
          child: Container(
            child: TabBarView(
                controller: _tabController,
                children: <Widget>[
                  Container(
                    child: All(),
                  ),
                  Container(
                    child: All(),
                  ),
                  Container(
                    child: All(),
                  ),
                ]
            ),
          ),
        ),
      ],
    );
  }
}
Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
  return Container(
    margin: EdgeInsets.only(top: top, left: left, right: right),
    child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
  );
}