import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';


class All extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: <Widget>[
        _myNotification(context, "New Booking Request",
            "A new request by the customer", "10", "yes", 0xff70b4ff),
        _myNotification(context, "Booking Accepted",
            "Your booking has been accepted by saloon", "55", "", 0xff00ff00),
        _myNotification(context, "Booking Disapproved",
            "Your booking is not accepted by saloon", "10", "", 0xffff0000),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
        _myNotification(
            context,
            "Booking Accepted",
            "Your booking has been accepted by saloon",
            "55",
            "yes",
            0xff00ff00),
      ],
    );
  }

  Widget _myNotification(BuildContext context, String heading, String text,
      String time, String icon, int colorCode) {
    return Stack(
      children: <Widget>[
        Container(
          height: 80,
          margin: EdgeInsets.only(left: 15, right: 15, top: 10),
          decoration: new BoxDecoration(
            color: ColorsX.white,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              icon == 'yes'
                  ? Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        margin: EdgeInsets.only(left: 10, top: 20),
                        child: Icon(
                          Icons.circle,
                          color: ColorsX.blue_text_color,
                          size: 10,
                        ),
                      ),
                    )
                  : Container(
                      margin: EdgeInsets.only(left: 10),
                    ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Align(
                    alignment: Alignment.topCenter,
                    child: _rowItemForHeaderText(
                        heading, 12, FontWeight.w700, colorCode, 20, 15, 0),
                  ),
                  Align(
                    alignment: Alignment.topCenter,
                    child: _rowItemForHeaderText(
                        text, 10, FontWeight.w400, 0xff707070, 10, 15, 0),
                  ),
                ],
              ),
              Expanded(child: SizedBox()),
              Container(
                margin: EdgeInsets.only(top: 20, bottom: 20),
                child: VerticalDivider(
                  color: ColorsX.subBlack,
                  width: 3,
                ),
              ),
              SizedBox(
                width: 20,
              ),
              // Expanded(child: SizedBox()),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Align(
                    alignment: Alignment.topCenter,
                    child: _rowItemForHeaderText(
                        time, 12, FontWeight.w700, 0xff707070, 20, 0, 0),
                  ),
                  Align(
                    alignment: Alignment.topCenter,
                    child: _rowItemForHeaderText(
                        "min ago", 12, FontWeight.w700, 0xff707070, 5, 0, 0),
                  ),
                ],
              ),
              SizedBox(
                width: 20,
              ),
              // Expanded(child: SizedBox()),
            ],
          ),
        ),
      ],
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }
}
