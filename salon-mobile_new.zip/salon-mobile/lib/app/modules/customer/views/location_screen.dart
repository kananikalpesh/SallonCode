import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:saloon_app/app/modules/customer/controllers/custome_home_controller.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/modules/customer/views/home/home_wrapper.dart';
import 'package:saloon_app/app/resuseable/saloon_row_item.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';
class LocationScreen extends GetView<DashboardItemController> {
  //DashboardItem _dashboardItem = DashboardItem();
  CustomerHomeController customerHomeController = Get.find();
  DashboardItemController _dashboardItemController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: SizeConfig.screenHeight,
        width: SizeConfig.screenWidth,
        child: Obx(()=>controller.isSearchedDataLoading.isTrue?myStackOnTop(context):myStackOnTop(context)),
      ),
    );
  }

  Widget myStackOnTop(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(top: 15),
          child: LocationHeaderStack(
            categoryShow: "yes",
          ),
        ),
        Container(
          margin: EdgeInsets.only(top: SizeConfig.screenHeight * .27),
          child: Column(
            children: [
              //filter
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _myLocationText(context, "Search Result", 0xff000000, 25, 0,
                      0, FontWeight.w600, 16),
                  Container(
                    margin: EdgeInsets.only(right: 25),
                    // width: 50,
                    // height: 20,
                    decoration: BoxDecoration(
                        //color: Colors.blue,
                        borderRadius: BorderRadius.all(Radius.circular(8))),
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            // customerHomeController
                            //     .homecurrentScreenIndex.value = 1;
                            Get.offNamed(HomeNavigation.searchScreen, id: 2);
                          },
                          child: Container(
                            width: SizeConfig.blockSizeHorizontal * 8,
                            height: SizeConfig.blockSizeVertical * 4,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(8),
                                    bottomLeft: Radius.circular(8))),
                            child: Center(
                              child: Image.asset(
                                AppImages.List_ic,
                                color: ColorsX.icon_grey,
                              ),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {},
                          child: Container(
                            width: SizeConfig.blockSizeHorizontal * 8,
                            height: SizeConfig.blockSizeVertical * 4,
                            decoration: BoxDecoration(
                                border: Border.all(color: ColorsX.icon_grey),
                                color: ColorsX.blue_button_color,
                                borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(8),
                                    bottomRight: Radius.circular(8))),
                            child: Center(
                                child: Image.asset(
                              AppImages.Location_ic,
                              color: ColorsX.white,
                            )),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
              Spacer(),
              Container(
                //margin: EdgeInsets.only(top: SizeConfig.screenHeight * .25),
                //height: 220,
                child: SaloonRowItem(
                  saloonItemsModel: controller.searchedSaloonItems!.value,
                  isHorizontal: true,
                ) ,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _myLocationText(
      BuildContext context,
      String text,
      int colorCode,
      double left,
      double top,
      double right,
      FontWeight fontWeight,
      double fontSize) {
    return Container(
      margin: EdgeInsets.only(left: left, top: top, right: right),
      child: Text(
        text,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: FontWeight.w600,
            fontSize: fontSize),
      ),
    );
  }
  Widget TextFields(bool obscure, double top, double left, double right,
      String hint, String inputType) {
    return Container(
      padding: EdgeInsets.only(left: 5, right: 5),
      decoration: BoxDecoration(
          color: ColorsX.greyBackground,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: top, right: right, left: left),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.text,
        obscureText: obscure,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1,
        //Normal textInputField will be disp
        decoration: InputDecoration(
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          hintText: hint,
          contentPadding: EdgeInsets.only(top: 15),
          hintStyle: TextStyle(color: ColorsX.subBlack),
          prefixIcon: Icon(
            Icons.search,
            color: ColorsX.subBlack,
          ),
        ),
      ),
    );
  }

}

class LocationHeaderStack extends GetView<DashboardItemController> {
  CustomerHomeController customerHomeController = Get.find();
  String categoryShow;
  LocationHeaderStack({required this.categoryShow});

  TextEditingController searCTL=TextEditingController();

  @override
  Widget build(BuildContext context) {

    customerHomeController.addSaloonMarker(controller.saloonItemsModel!);

    return Stack(
      children: <Widget>[
        //google map
       Obx(()=>Container(
         width: SizeConfig.screenWidth,
         margin: EdgeInsets.only(top: SizeConfig.screenHeight * .24),
         child:GoogleMap(
           mapType: MapType.normal,
           initialCameraPosition: customerHomeController.userLocation,
           onMapCreated: (GoogleMapController controller) {
             customerHomeController.mapCTL.complete(controller);
           },
           markers: Set<Marker>.of(customerHomeController.markers.values),
           // onCameraMove: ((_position) => customerHomeController.updatePosition(_position)),
         ),
       ),) ,
        Container(
          width: SizeConfig.screenWidth,
          margin: EdgeInsets.only(top: 0),
          child: Image.asset(
            AppImages.Location_stack_bg,
            fit: BoxFit.fill,
          ),
        ),
        Container(
          margin: EdgeInsets.only(
              top: SizeConfig.screenHeight * .06, left: 20, right: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                child: Image.asset(
                  "assets/images/bell.png",
                ),
              ),
              SizedBox(width: 5,),
              Container(
                  margin: EdgeInsets.only(left: 5),
                  child: Image.asset(
                    "assets/images/head.png",
                  )),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.only(top: SizeConfig.screenHeight * .06, left: 20),
          child: Text(
            "Your location",
            style: TextStyle(
                color: ColorsX.myblack,
                fontWeight: FontWeight.w400,
                fontSize: 16),
          ),
        ),
        Container(
          margin: EdgeInsets.only(
              top: SizeConfig.screenHeight * .11, left: 20, right: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                  child: Icon(
                Icons.location_pin,
                color: ColorsX.myblack,
              )),
              Expanded(
                child: _myLocationText(context, "${customerHomeController.userAddress}", 0xff000000, 15,
                    0, 0, FontWeight.w600, 16),
              ),
              _myLocationText(
                  context, "Change", 0xff70b4ff, 15, 0, 0, FontWeight.w600, 16),
              SizedBox(
                width: 10,
              ),
              Container(
                  child: Image.asset(
                "assets/images/change.png",
              )),
              // Expanded(child: _myLocationText(context, "Change", 0xff70b4ff))
            ],
          ),
        ),
        TextFields(false, SizeConfig.screenHeight * .16, 20, 20,
            "Search for salons", "text"),
      ],
    );
  }

  Widget TextFields(bool obscure, double top, double left, double right,
      String hint, String inputType) {
    return Container(
      padding:
          EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 3, right: 0),
      height: SizeConfig.blockSizeVertical * 6,
      decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: top, right: right, left: left),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Flexible(
            child: TextFormField(
              style: TextStyle(color: ColorsX.subBlack),
              keyboardType: TextInputType.text,
              obscureText: obscure,
              onChanged: (v)=>print(v),
              controller: searCTL,
              // validator: (String value) => value.length < 10
              //     ? 'Çharacter Length Must Be 10 Character Long'
              //     : null,
              minLines: 1,
              //Normal textInputField will be disp
              decoration: InputDecoration(
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                hintText: hint,
                contentPadding: EdgeInsets.only(top: 0.0, right: 0.0),
                hintStyle: TextStyle(color: ColorsX.subBlack),
                // prefixIcon: Icon(
                //   Icons.search,
                //   color: ColorsX.subBlack,
                // ),
              ),
            ),
          ),
          InkWell(
            onTap: ()async {
              //Get.to();
              customerHomeController.homecurrentScreenIndex.value = 1;
              final res = await controller.saloonItems(searCTL.text);

              print("Clicked on search");
            },
            child: Container(
              width: SizeConfig.blockSizeHorizontal * 12,
              //margin: EdgeInsets.only(top: top, right: right, left: left),
              decoration: new BoxDecoration(
                  color: ColorsX.blue_button_color,
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(10),
                      bottomRight: Radius.circular(10))),
              // padding: EdgeInsets.all(20),
              child: Center(
                child: Icon(
                  Icons.search,
                  color: ColorsX.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _myLocationText(
      BuildContext context,
      String text,
      int colorCode,
      double left,
      double top,
      double right,
      FontWeight fontWeight,
      double fontSize) {
    return GestureDetector(
        onTap: () {
          if (text == ("View All")) {
            Navigator.pushNamed(context, '/viewAll');
          } else {
            print("no");
          }
        },
        child: Container(
          margin: EdgeInsets.only(left: left, top: top, right: right),
          child: Text(
            text,
            style: TextStyle(
                color: Color(colorCode),
                fontWeight: FontWeight.w600,
                fontSize: fontSize),
          ),
        ));
  }
}
