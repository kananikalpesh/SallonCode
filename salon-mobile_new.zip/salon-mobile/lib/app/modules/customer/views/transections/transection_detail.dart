import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/transaction-ctl.dart';
import 'package:saloon_app/app/resuseable/loading-state.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class TransectionDetail extends GetView<TransactionCTL> {
  const TransectionDetail({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // await controller.fetchAllAppointment(1, 'All');
    // controller.pagingController.refresh();
    return Obx(() => controller.isDataLoaded.isTrue
        ? allTransactions(context)
        : LoadingState());
  }
  Widget allTransactions(BuildContext context){
    print("done");
    int length= controller.myAppointmentRes?.data.length??0;
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  height: SizeConfig.screenHeight * .12,
                  color: ColorsX.lightStackColor,
                ),
                Container(
                  margin: EdgeInsets.only(
                      top: SizeConfig.screenHeight * .06,
                      left: SizeConfig.blockSizeHorizontal * 5),
                  child: GestureDetector(
                    onTap: () {
                      // Get.toNamed(Routes.TRANSECTION_LIST);
                      Get.back();
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: ColorsX.blue_text_color,
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.center,
                  child: _rowItemForHeaderText(
                      "Transactions",
                      16,
                      FontWeight.w700,
                      ColorsX.subBlack,
                      SizeConfig.screenHeight * .06,
                      0,
                      0),
                ),
              ],
            ),
            for(int index =0; index<length; index++)
              controller.myAppointmentRes?.data[index].status=="Accepted"?_paymentCard(index):Container(),

            _rowItemForHeaderText(
                "If you have any question, please email on",
                13,
                FontWeight.normal,
                ColorsX.subBlack4,
                SizeConfig.blockSizeVertical * 1.5,
                SizeConfig.blockSizeHorizontal * 5,
                SizeConfig.blockSizeHorizontal * 5),
            _rowItemForHeaderText(
                "saloon@gmail.com",
                13,
                FontWeight.normal,
                ColorsX.blue_button_color,
                SizeConfig.blockSizeVertical * 1.5,
                SizeConfig.blockSizeHorizontal * 5,
                SizeConfig.blockSizeHorizontal * 5),
            verticalSpace(SizeConfig.blockSizeVertical * 2),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(AppImages.Insta_ic),
                horizontalSpace(SizeConfig.blockSizeHorizontal * 5),
                Image.asset(AppImages.Twitter_ic),
                horizontalSpace(SizeConfig.blockSizeHorizontal * 5),
                Image.asset(AppImages.FB_ic),
                horizontalSpace(SizeConfig.blockSizeHorizontal * 5),
                Image.asset(AppImages.Linkedin_ic),
              ],
            ),
            SizedBox(height: 20,)
          ],
        ),
      ),
    );
  }
  Padding _buttonsRow(int index) {
    return Padding(
      padding: EdgeInsets.symmetric(
          horizontal: SizeConfig.blockSizeHorizontal * 5,
          vertical: SizeConfig.blockSizeVertical * 1),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () {
                // Get.toNamed(Routes.TRANSECTION_LIST);
                print(index);
                print(controller.myAppointmentRes?.data[index].timeSlot);
              },
              child: Container(
                height: SizeConfig.blockSizeVertical * 7,
                decoration: BoxDecoration(
                    color: ColorsX.blue_button_color,
                    borderRadius: BorderRadius.circular(10)),
                child: Center(
                  child: Text(
                    "Download",
                    style: TextStyle(
                        color: ColorsX.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16),
                  ),
                ),
              ),
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 5),
          Expanded(
            child: Container(
              height: SizeConfig.blockSizeVertical * 7,
              decoration: BoxDecoration(
                  color: ColorsX.white,
                  borderRadius: BorderRadius.circular(10),
                  border:
                      Border.all(color: ColorsX.blue_button_color, width: 2)),
              child: Center(
                child: Text(
                  "Share",
                  style: TextStyle(
                      color: ColorsX.blue_button_color,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _paymentCard(int index) {
    return Container(
      width: SizeConfig.screenWidth,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        elevation: 10,
        margin: EdgeInsets.symmetric(
            horizontal: SizeConfig.blockSizeHorizontal * 5,
            vertical: SizeConfig.blockSizeVertical * 3),
        child: Padding(
          padding: EdgeInsets.symmetric(
              horizontal: SizeConfig.blockSizeHorizontal * 5,
              vertical: SizeConfig.blockSizeVertical * 3),
          child: Column(
            children: [
              Image.asset(AppImages.Calender_w_logo),
              _rowItemForHeaderText(
                  "Appointment ID: ${controller.myAppointmentRes?.data[index].appointmentId}",
                  16,
                  FontWeight.bold,
                  ColorsX.black,
                  SizeConfig.blockSizeVertical * 1.5,
                  0.0,
                  0.0),
              verticalSpace(SizeConfig.blockSizeVertical * 1.5),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _rowItemForHeaderText("Appointment Date", 12,
                          FontWeight.w600, ColorsX.black, 0.0, 0.0, 0.0),
                      verticalSpace(SizeConfig.blockSizeVertical * 1.5),
                      _rowItemForHeaderText("${controller.myAppointmentRes?.data[index].appointmentDate.toString().split(" ")[0]}", 12, FontWeight.bold,
                          ColorsX.blue_text_color, 0.0, 0.0, 0.0),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _rowItemForHeaderText("Appointment Time", 12,
                          FontWeight.w600, ColorsX.black, 0.0, 0.0, 0.0),
                      verticalSpace(SizeConfig.blockSizeVertical * 1.5),
                      _rowItemForHeaderText("${controller.myAppointmentRes?.data[index].timeSlot}", 12, FontWeight.bold,
                          ColorsX.blue_text_color, 0.0, 0.0, 0.0),
                    ],
                  ),
                ],
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 1.5),
              Container(
                height: SizeConfig.blockSizeVertical * 0.1,
                color: ColorsX.inputfielboarder,
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 1.5),
              _rowTextItems(
                "Salloon Name",
                "${controller.myAppointmentRes?.data[index].saloon?.name}",
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 1.5),
              _rowTextItems(
                "Salon Address",
                "${controller.myAppointmentRes?.data[index].saloon?.address.address}",
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 1.5),
              _rowTextItems(
                "Service Name",
                "${controller.myAppointmentRes?.data[index].services?.name}",
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 1.5),
              _rowTextItems(
                "Total Amount",
                "\$${controller.myAppointmentRes?.data[index].totalPrice}",
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 1.5),
              _rowTextItems(
                "Staff Name",
                "${controller.myAppointmentRes?.data[index].staff?.name}",
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 1.5),
              _rowTextItems(
                "Transaction ID",
                "${controller.myAppointmentRes?.data[index].id}",
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 1.5),
              _rowTextItems(
                "Mode of Payment",
                "${controller.myAppointmentRes?.data[index].paymentType}",
              ),
              _buttonsRow(index),
            ],
          ),
        ),
      ),
    );
  }

  Row _rowTextItems(String text1, String text2) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _rowItemForHeaderText(
            text1, 12, FontWeight.w600, ColorsX.black, 0.0, 0.0, 0.0),
        _rowItemForHeaderText(
            text2, 12, FontWeight.w600, ColorsX.blue_text_color, 0.0, 0.0, 0.0),
      ],
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color color,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style:
            TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }
}
