import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class TransectionList extends StatelessWidget {
  TransectionList({Key? key}) : super(key: key);

  final List<String> sortingList = [
    "Lowest to Heighest",
    "Heighest to Lowest",
  ];

  RxString sortingValue = "Lowest to Heighest".obs;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Stack(
            children: [
              Container(
                height: SizeConfig.screenHeight * .12,
                color: ColorsX.lightStackColor,
              ),
              Container(
                margin: EdgeInsets.only(
                    top: SizeConfig.screenHeight * .06,
                    left: SizeConfig.blockSizeHorizontal * 5),
                child: GestureDetector(
                  onTap: () {
                    // Get.toNamed(page)
                    Get.back();

                  },
                  child: Icon(
                    Icons.arrow_back,
                    color: ColorsX.blue_text_color,
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: _rowItemForHeaderText(
                    "Transections",
                    16,
                    FontWeight.w700,
                    ColorsX.subBlack,
                    SizeConfig.screenHeight * .06,
                    0,
                    0),
              ),
            ],
          ),
          Padding(
            padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.blockSizeHorizontal * 5,
                vertical: SizeConfig.blockSizeVertical * 1.5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _rowItemForHeaderText("History", 16, FontWeight.bold,
                    ColorsX.black, 0.0, 0.0, 0.0),
                Obx(() => Container(
                    decoration: BoxDecoration(
                        // color: Color(0xFFF5F5F5),
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        border: Border.all(color: ColorsX.blue_button_color)),
                    child: Padding(
                      padding: EdgeInsets.only(
                          left: SizeConfig.marginVerticalXsmall,
                          top: SizeConfig.marginVerticalXXsmall,
                          bottom: SizeConfig.marginVerticalXXsmall,
                          right: SizeConfig.marginVerticalXsmall),
                      child: Row(
                        children: [
                          Container(
                            constraints: BoxConstraints(
                              minHeight: SizeConfig.blockSizeVertical * 4,
                              maxHeight: 50.0,
                            ),
                            padding: EdgeInsets.all(0.0),
                            height: SizeConfig.blockSizeVertical * 3,
                            child: DropdownButton<String>(
                              enableFeedback: true,
                              hint: Text(
                                sortingValue.value,
                                style: TextStyle(color: ColorsX.black),
                              ),
                              underline: SizedBox(),
                              value: sortingValue.value,
                              //elevation: 5,
                              style: TextStyle(
                                  color: ColorsX.blue_button_color,
                                  fontSize: 16),
                              icon: Image.asset(
                                AppImages.Dropdown_blue_ic,
                                width: SizeConfig.blockSizeVertical * 2,
                              ),
                              items: sortingList.map<DropdownMenuItem<String>>(
                                  (String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        right:
                                            SizeConfig.marginVerticalXXsmall),
                                    child: Text(
                                      value,
                                    ),
                                  ),
                                );
                              }).toList(),
                              onChanged: (value) {
                                sortingValue.value = value!;
                              },
                            ),
                          ),
                        ],
                      ),
                    ))),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
                itemCount: 7,
                itemBuilder: (BuildContext context, int index) {
                  return TransectionItem(
                    imagePath: "assets/images/popular.png",
                    name: "Looks Unisex Saloon",
                    address: "288 Empola Street, NewYork",
                    time: "2:30",
                    date: "28",
                    AmPm: "PM",
                    month: "Sep 20",
                    transectionId: "#12345678",
                    amount: "\$62",
                  );
                }),
          )
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color color,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style:
            TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }
}

class TransectionItem extends StatelessWidget {
  String imagePath;
  String name;
  String address;
  String time;
  String date;
  String AmPm;
  String month;

  String transectionId;

  String amount;
  TransectionItem(
      {required this.imagePath,
      required this.name,
      required this.address,
      required this.time,
      required this.date,
      required this.AmPm,
      required this.month,
      required this.transectionId,
      required this.amount});
  @override
  Widget build(BuildContext context) {
    return Card(
        elevation: 5,
        margin: EdgeInsets.only(left: 15, right: 15, top: 10),
        shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.white70, width: 1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _myItemRowValues(
              context,
              imagePath,
              name,
              address,
              time,
              date,
              AmPm,
              month,
            ),
            appointmentAndServicesRow(context, transectionId, amount),
          ],
        ));
  }

  Widget appointmentAndServicesRow(
      BuildContext context, String appointmentId, String status) {
    return Container(
      margin: EdgeInsets.only(left: 20, right: 15, bottom: 15, top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText("Transection ID: ", 10, FontWeight.w400,
              ColorsX.subBlack, 10, 0, 0),
          _rowItemForHeaderText(
              appointmentId, 10, FontWeight.w700, ColorsX.subBlack, 10, 0, 0),
          Expanded(child: SizedBox()),
          // _rowItemForHeaderText("Services: ", 8, FontWeight.w400, 0xff707070, 10, 0, 0),
          // _rowItemForHeaderText(services, 8, FontWeight.w700, 0xff707070, 10, 0, 0),
          Expanded(child: SizedBox()),

          // appointmentStatus(status),
          _rowItemForHeaderText(amount, 22, FontWeight.bold,
              ColorsX.blue_button_color, 10, 10, 10)
        ],
      ),
    );
  }

  Widget _myItemRowValues(
    BuildContext context,
    String imagePath,
    String name,
    String address,
    String time,
    String date,
    String amPm,
    String month,
  ) {
    return Container(
      margin: EdgeInsets.only(top: 10, left: 10, right: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              getImage(context, imagePath),
            ],
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 5),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _boldText(name, 14, FontWeight.w700, 0xff707070, 0, 0, 0),
              _rowItemForHeaderText(
                  address, 12, FontWeight.w400, ColorsX.subBlack, 0, 0, 0),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  _rowItemForHeaderText(
                      time, 12, FontWeight.w400, ColorsX.subBlack, 0, 0, 0),
                  SizedBox(
                    width: 35,
                  ),
                  _rowItemForHeaderText(
                      date, 12, FontWeight.w400, ColorsX.black, 0, 0, 0),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                    decoration: new BoxDecoration(
                      color: ColorsX.greyBackground,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: _rowItemForHeaderText(
                        AmPm, 12, FontWeight.w400, ColorsX.black, 0, 0, 0),
                  ),
                  SizedBox(
                    width: 30,
                  ),
                  _rowItemForHeaderText(
                      month, 12, FontWeight.w400, ColorsX.subBlack, 0, 0, 0),
                ],
              )
            ],
          ),
        ],
      ),
    );
  }

  Widget getImage(BuildContext context, String imagePath) {
    return Container(
      width: 65,
      margin: EdgeInsets.only(left: 10, right: 10),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15.0),
        child: Image.asset(
          imagePath,
          fit: BoxFit.cover,
          height: 65,
          width: 65,
        ),
      ),
    );
  }

  Widget _boldText(String value, double fontSize, FontWeight fontWeight,
      int colorCode, double top, double left, double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: colorCode, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }
}
