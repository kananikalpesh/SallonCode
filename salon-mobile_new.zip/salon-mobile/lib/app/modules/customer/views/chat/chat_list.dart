import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class ChatList extends StatefulWidget {


  @override
  State<ChatList> createState() => _ChatListState();
}

  class _ChatListState extends State<ChatList> {
    List allUsers = [];
    List allUsersIDs = [];
    @override
    Widget build(BuildContext context) {
      getAllUsers(context);
      return Scaffold(
        body: ListView(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // SizedBox(
                //   width: 10,
                // ),
                Container(
                  height: SizeConfig.screenHeight,
                  child: Align(
                    alignment: Alignment.center,
                    child: Center(
                      child: _rowItemForHeaderText("This feature is coming soon", 18, FontWeight.w700, 0xff000000, 0, 0, 0),
                    ),
                  ),
                )
                // Container(
                //   child: Image.asset("assets/images/search.png"),
                //   margin: EdgeInsets.only(top: 22),
                // ),
                // TextFields(false, 0, 30, 30, "Search messages", "text", context),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            // for(int i=0; i< allUsers.length; i++)
            //   _chatItem(context, "assets/images/mike.png", "ONLINE",
            //       allUsers[i], "How much are the charges?", "09:40am",allUsersIDs[i]),
            // _chatItem(context, "assets/images/jordan.png", "", "Jordan Saloon",
            //     "Where are you from?", "09:12am"),
            // _chatItem(context, "assets/images/jim.png", "ONLINE", "Hair Away",
            //     "Hello :)", "Yesterday"),
            // _chatItem(context, "assets/images/paul.png", "", "Hair Away",
            //     "I'll Let you know when i'm around", "Yesterday"),
          ],
        ),
      );
    }

    getAllUsers(BuildContext context){
      var collection = FirebaseFirestore.instance.collection('saloon_users');
      // allUsers=new List[];
      // allUsers.clear();

      collection.snapshots().listen((querySnapshot) {
        for (var doc in querySnapshot.docs) {
          Map<String, dynamic> data = doc.data();
          var usernames = data['username']; // <-- Retrieving the value.
          var ids = data['id'];
          if(allUsers.contains(usernames)){
            print("${usernames} exists already");
          }
          else {
            allUsers.add(usernames);
          }
          if(allUsersIDs.contains(ids)){
            print("${ids} exists already");
          }
          else{
            allUsersIDs.add(ids);
          }
        }
        print(allUsers);
        print(allUsersIDs);
        setState(() {
        });
      });
    }

    Widget _chatItem(BuildContext context, String imagePath, String status,
        String nameOfSaloon, String message, String time, String id) {
      return GestureDetector(
        onTap: () {
          // Navigator.pushNamed(context, '/chatWith');
          print(id);
          AppStrings.receiverID = id;
          Get.toNamed(Routes.CHAT_DETAIL);
        },
        child: Container(
          margin: EdgeInsets.only(left: 10, right: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Align(
                alignment: Alignment.topRight,
                child: _rowItemForHeaderText(
                    time, 12, FontWeight.w400, 0xff9b9b9b, 0, 0, 20),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  _getImagesWithName(context, imagePath, status, 0xffffffff),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      _rowItemForHeaderText(nameOfSaloon, 16, FontWeight.w700,
                          0xff000000, 0, 20, 10),
                      _rowItemForHeaderText(
                          message, 14, FontWeight.w400, 0xff707070, 5, 20, 10),
                    ],
                  ),
                  Expanded(child: SizedBox()),
                  // _rowItemForHeaderText("09:40am", 12, FontWeight.w400, 0xff9b9b9b, 0, 0, 10),
                ],
              ),
              Container(
                margin: EdgeInsets.only(left: 15, right: 15, top: 5),
                child: Divider(
                  color: ColorsX.timeChat,
                ),
              ),
            ],
          ),
        ),
      );
    }

    Widget _rowItemForHeaderText(
        String value,
        double fontSize,
        FontWeight fontWeight,
        int colorCode,
        double top,
        double left,
        double right) {
      return Container(
        margin: EdgeInsets.only(top: top, left: left, right: right),
        child: Text(
          value,
          style: TextStyle(
              color: Color(colorCode),
              fontWeight: fontWeight,
              fontSize: fontSize),
        ),
      );
    }

    Widget _getColumnItem(
        BuildContext context, String imagePath, String name, int colorCode) {
      return Container(
        margin: EdgeInsets.only(top: 5, left: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Stack(
              children: [
                ClipRRect(
                  borderRadius: new BorderRadius.circular(10.0),
                  child: Image(
                    fit: BoxFit.contain,
                    image: AssetImage(imagePath),
                    width: 50.0,
                    height: 50.0,
                  ),
                ),
                name == "ONLINE"
                    ? Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    height: 20,
                    width: 50,
                    margin: EdgeInsets.only(top: 42, left: 0),
                    decoration: new BoxDecoration(
                      color: ColorsX.greenish,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Padding(
                      padding:
                      EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                      child: Text(
                        name,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Color(colorCode),
                            fontSize: 9,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                )
                    : Container(),
              ],
            ),
          ],
        ),
      );
    }

    Widget _getImagesWithName(
        BuildContext context, String imageName, String name, int colorCode) {
      return Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _getColumnItem(context, imageName, name, colorCode),
          ],
        ),
      );
    }

    Widget TextFields(bool obscure, double top, double left, double right,
        String hint, String inputType, BuildContext context) {
      return Container(
        width: SizeConfig.seventyPercentWidth,
        padding: EdgeInsets.only(left: 5, right: 15),
        // decoration: new BoxDecoration(
        //     color: ColorsX.greyBackground,
        //     borderRadius: BorderRadius.all(Radius.circular(10))),

        margin: EdgeInsets.only(top: top, right: right, left: left),
        child: TextFormField(
          style: TextStyle(color: ColorsX.subBlack),
          keyboardType: inputType == "text"
              ? TextInputType.text
              : inputType == "phone"
              ? TextInputType.number
              : inputType == "email"
              ? TextInputType.emailAddress
              : inputType == "date"
              ? TextInputType.datetime
              : TextInputType.text,
          obscureText: obscure,
          // controller: numberController,
          // validator: (String value) => value.length < 10
          //     ? 'Çharacter Length Must Be 10 Character Long'
          //     : null,
          minLines: 1,
          //Normal textInputField will be disp
          decoration: InputDecoration(
            // enabledBorder: InputBorder,
            enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Color(0xffead6fd))),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Color(0xffead6fd))),
            hintText: hint,
            contentPadding: EdgeInsets.only(top: 15),
            hintStyle: TextStyle(color: ColorsX.subBlack),
            // prefixIcon: Image.asset(
            //   "assets/images/suffix.png",
            //   height: 20,
            //   width: 20,
            // ),
          ),
        ),
      );
    }
  }


