import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';


class ChatMessages extends StatefulWidget{

  @override
  State<ChatMessages> createState() => _ChatListState();
}

class _ChatListState extends State<ChatMessages> {
  List allMessages = [];
  List allMessagesIDs = [];
  @override
  Widget build(BuildContext context) {
    getAllMessages(context);
    return allMessages.isNotEmpty? new Container(
      margin: EdgeInsets.only(bottom: 0.06),
        child: ListView(
          children: <Widget>[
            for(int index=0; index<allMessages.length; index++)
              // WholeRwoOfHisMessage(context,"assets/images/jim.png","Hey good morning ! Yes i was home quite late but i had a good rest","09:42am"),
              WholeRowOfMyMessage(context,"${allMessages[index]}","09:40am"),
            getDate(context),
            // WholeRwoOfHisMessage(context,"assets/images/jim.png","Hey good morning ! Yes i was home quite late but i had a good rest","09:42am"),
            // HisvoiceMessageLayout(context,"assets/images/jim.png","09:43am"),
            // WholeRowOfMyMessage(context,"Hehehe that's great then, let's speak later :)","09:40am"),
          ],
        )
    ):Container();
  }
  Widget WholeRwoOfHisMessage(BuildContext context, String imagePath,String message, String time){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Align(
          alignment: Alignment.topCenter,
          child: ImageOfPerson(context, imagePath) ,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            HisChatItem(context,message),
            _rowItemForHeaderText(time, 12, FontWeight.w700, 0xffb2b2b2, 5, 15, 0, 0),
          ],
        ),
      ],
    );
  }
  Widget WholeRowOfMyMessage(BuildContext context,String message, String time){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: <Widget>[
        MyChatItem(context,message),
        _rowItemForHeaderText(time, 12, FontWeight.w700, 0xffb2b2b2, 5, 15, 15, 15),
      ],
    );
  }
  Widget HisChatItem(BuildContext context, String message){
    return Container(
      margin: EdgeInsets.only(left: 15, top: 10),
      constraints: BoxConstraints(minWidth: 20, maxWidth: SizeConfig.screenWidth*.60),
      decoration: new BoxDecoration(
          color:ColorsX.greyBackground,
          borderRadius: BorderRadius.all(Radius.circular(10))
      ),
      child: _rowItemForHeaderText(message, 14, FontWeight.w400, 0xff707070, 15, 15, 15,15),
    );
  }
  Widget MyChatItem(BuildContext context, String message){
    return Container(
      margin: EdgeInsets.only(right: 15, top: 10),
        constraints: BoxConstraints(minWidth: 20, maxWidth: SizeConfig.screenWidth*.60),
      decoration: new BoxDecoration(
          color:ColorsX.blue_text_color,
          borderRadius: BorderRadius.all(Radius.circular(10))
      ),
      child: _rowItemForHeaderText(message, 14, FontWeight.w400, 0xffffffff, 15, 15, 15,15),
    );
  }
  Widget getDate(BuildContext context){
    return Center(
        child: Container(
          margin: EdgeInsets.only(bottom: 10),
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: new BoxDecoration(
              color:ColorsX.white,
              border: Border.all(color: Color(0xffc2bdde)),
              borderRadius: BorderRadius.all(Radius.circular(20))
          ),
          child: _rowItemForHeaderText("16 September 2021", 14, FontWeight.w400, 0xffc2bdde, 0, 0, 0, 0),
        )
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right, double bottom){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right, bottom:  bottom),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
  Widget ImageOfPerson(BuildContext context, String imagePath){
    return Container(
        margin: EdgeInsets.only(top: 10,left: 15),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(15.0),
          child: Image.asset(imagePath, fit: BoxFit.cover,height: 30,width: 30,),
        ),
      );
  }
  Widget HisvoiceMessageLayout(BuildContext context, String imagePath, String time){
    return Container(
      margin: EdgeInsets.only(right: SizeConfig.thirtyPercentWidth, top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          ImageOfPerson(context, imagePath),
          SizedBox(width: 15,),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(top: 5),
                decoration: new BoxDecoration(
                  color:ColorsX.greyBackground,
                  borderRadius: BorderRadius.all(Radius.circular(10)
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(width: 5,),
                    Icon(Icons.play_circle_filled_rounded, color: ColorsX.subBlack,),
                    _rowItemForHeaderText("Voice message", 14, FontWeight.w400, 0xff707070, 10, 0, 0, 10),
                    timeContainer(context,"00:27"),
                  ],
                ),
              ),
              _rowItemForHeaderText(time, 12, FontWeight.w700, 0xffb2b2b2, 5, 5, 0, 10),
            ],
          ),
        ],
      ),
    );
  }
  Widget timeContainer(BuildContext context, String voiceMessageTime){
    return Container(
      decoration: new BoxDecoration(
        color:ColorsX.myblack,
        borderRadius: BorderRadius.only(topRight: Radius.circular(10), bottomRight: Radius.circular(10)
        ),
      ),
      child: _rowItemForHeaderText(voiceMessageTime, 14, FontWeight.w700, 0xffffffff, 10, 10, 10, 10),
    );
  }

  getAllMessages(BuildContext context) {

    var collection = FirebaseFirestore.instance.collection('messages_saloon');
    // allUsers=new List[];
    // allUsers.clear();

    collection.snapshots().listen((querySnapshot) {
      for (var doc in querySnapshot.docs) {
        Map<String, dynamic> data = doc.data();
        var message_string = data['message_string']; // <-- Retrieving the value.
        var ids = data['id'];
        if(allMessages.contains(message_string)){
          print("${message_string} exists already");
        }
        else {
          allMessages.add(message_string);
        }
        if(allMessagesIDs.contains(ids)){
          print("${ids} exists already");
        }
        else{
          allMessagesIDs.add(ids);
        }
      }
      print(allMessages);
      print(allMessagesIDs);
      setState(() {
      });
    });
  }
}