import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/data/model/customer/special_offer.dart' as offer;
import 'package:saloon_app/app/data/services/customer/saloon-home-api.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/modules/customer/views/HeaderStack.dart';
import 'package:saloon_app/app/resuseable/offer_item_widget.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class ViewAllOffers extends StatefulWidget {
  // String categoryId;
  // ViewAll({required this.categoryId});

  @override
  _ViewAllOffersState createState() => _ViewAllOffersState();
}

class _ViewAllOffersState extends State<ViewAllOffers> {
  bool loadingdone = false;

  DashboardItemController dashboardItemController=Get.find();

  final homeApi = HomeApi();
  static const _pageSize = 10;

  final PagingController<int, offer.Datum> _pagingController =
      PagingController(firstPageKey: 1);

  @override
  void initState() {
    dashboardItemController.page='offer';

    _pagingController.addPageRequestListener((pageKey) {
      _fetchAdPage(pageKey);
    });
    super.initState();
    // WidgetsBinding.instance!.addPostFrameCallback((timeStamp) { getSaloonDetailsNow();});
  }

  Future<void> _fetchAdPage(int pageKey) async {
    try {
      final newItems = await homeApi.getAllOffers(pageKey);
      final isLastPage = newItems.data.length < _pageSize;
      if (isLastPage) {
        _pagingController.appendLastPage(newItems.data);
      } else {
        final nextPageKey = pageKey + 1;
        _pagingController.appendPage(newItems.data, nextPageKey);
      }
    } catch (error) {
      print(error);
      _pagingController.error = error;
    }
  }

  @override
  Widget build(BuildContext context) {
    // print(widget.categoryId);
    return Scaffold(
        body: Container(
      height: SizeConfig.screenHeight,
      width: SizeConfig.screenWidth,
      child: myStackOnTop(context),
    ));
  }

  Widget myStackOnTop(
    BuildContext context,
  ) {
    return Stack(
      children: <Widget>[
        HeaderStack(
          categoryShow: "no",
        ),
        Container(
          // margin: EdgeInsets.only(top: SizeConfig.screenHeight*.60),
          margin: EdgeInsets.only(top: SizeConfig.screenHeight * .30),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _myLocationText(context, "Search Results", 0xff000000, 25, 0, 0,
                    FontWeight.w600, 16),
                Expanded(
                    child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: PagedListView<int, offer.Datum>(
                    pagingController: _pagingController,
                    builderDelegate: PagedChildBuilderDelegate<offer.Datum>(
                      itemBuilder: (context, item, index) => Container(
                        padding: EdgeInsets.only(left: 20),
                        child: OfferItemWidget(
                          index: index.toString(),
                          image: AppImages.Packages_img,
                          dealName: item.couponName,
                          serviceName: item.service.name,
                          status: item.status,
                          discountedPrice: '',
                          validDate: item.endDate,
                          originalPrice: item.price.toString(),
                          discount: item.percentage.toString(),
                          dealID:item.couponCode,
                        ),
                      ),
                    ),
                  ),
                )),
              ]),
        ),
      ],
    );
  }

  Widget _myLocationText(
      BuildContext context,
      String? text,
      int colorCode,
      double left,
      double top,
      double right,
      FontWeight fontWeight,
      double fontSize) {
    return Container(
      margin: EdgeInsets.only(left: left, top: top, right: right),
      child: Text(
        '${text}',
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: FontWeight.w600,
            fontSize: fontSize),
      ),
    );
  }
}
