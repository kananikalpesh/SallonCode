import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';

class CustomerBottomNavigationBar extends StatelessWidget {
  const CustomerBottomNavigationBar({
    Key? key,
    required String value,
  }) : _value = value, super(key: key);

  final String _value;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: ColorsX.white,
        border: Border.all(color: ColorsX.greyBackground, width: 2),
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20), topRight: Radius.circular(20)),
      ),
      child: ListView(
        //scrollDirection: Axis.horizontal,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              SizedBox(
                width: 15,
              ),
              Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    GestureDetector(
                     // onTap: () => setState(() => _value = 'Profile'),
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Image.asset("assets/images/profile.png",
                            fit: BoxFit.contain,
                            color: _value == 'Profile'
                                ? ColorsX.blue_button_color
                                : ColorsX.subBlack),
                      ),
                    ),
                    GestureDetector(
                      //onTap: () => setState(() => _value = 'Profile'),
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Text("Profile",
                            style: TextStyle(
                                color: _value == 'Profile'
                                    ? ColorsX.blue_button_color
                                    : ColorsX.subBlack,
                                fontSize: 11,
                                fontWeight: FontWeight.w400)),
                      ),
                    ),
                  ],
                ),
                margin: EdgeInsets.only(top: 5),
              ),
              SizedBox(
                width: 15,
              ),
              Container(
                margin: EdgeInsets.only(top: 5),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    GestureDetector(
                      //onTap: () => setState(() => _value = 'Favourite'),
                      child: Align(
                          alignment: Alignment.topCenter,
                          child: Image.asset("assets/images/favorite.png",
                              fit: BoxFit.contain,
                              color: _value == 'Favourite'
                                  ? ColorsX.blue_button_color
                                  : ColorsX.subBlack)),
                    ),
                    GestureDetector(
                      //onTap: () => setState(() => _value = 'Favourite'),
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Text("Favourite",
                            style: TextStyle(
                                color: _value == 'Favourite'
                                    ? ColorsX.blue_button_color
                                    : ColorsX.subBlack,
                                fontSize: 11,
                                fontWeight: FontWeight.w400)),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 15,
              ),
              Container(
                margin: EdgeInsets.only(top: 5),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    GestureDetector(
                      //onTap: () => setState(() => _value = 'Home'),
                      child: Align(
                          alignment: Alignment.topCenter,
                          child: Image.asset("assets/images/home.png",
                              fit: BoxFit.contain,
                              color: _value == 'Home'
                                  ? ColorsX.blue_button_color
                                  : ColorsX.subBlack)),
                    ),
                    GestureDetector(
                      //onTap: () => setState(() => _value = 'Home'),
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Text("Home",
                            style: TextStyle(
                                color: _value == 'Home'
                                    ? ColorsX.blue_button_color
                                    : ColorsX.subBlack,
                                fontSize: 11,
                                fontWeight: FontWeight.w400)),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 15,
              ),
              Container(
                margin: EdgeInsets.only(top: 5),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    GestureDetector(
                     // onTap: () => setState(() => _value = 'Messages'),
                      child: Align(
                          alignment: Alignment.topCenter,
                          child: Image.asset("assets/images/message.png",
                              fit: BoxFit.contain,
                              color: _value == 'Messages'
                                  ? ColorsX.blue_button_color
                                  : ColorsX.subBlack)),
                    ),
                    GestureDetector(
                      //onTap: () => setState(() => _value = 'Messages'),
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Text("Messages",
                            style: TextStyle(
                                color: _value == 'Messages'
                                    ? ColorsX.blue_button_color
                                    : ColorsX.subBlack,
                                fontSize: 11,
                                fontWeight: FontWeight.w400)),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 15,
              ),
              Container(
                margin: EdgeInsets.only(top: 5),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    GestureDetector(
                      //onTap: () => setState(() => _value = 'Appointments'),
                      child: Align(
                          alignment: Alignment.topCenter,
                          child: Image.asset("assets/images/appoint.png",
                              fit: BoxFit.contain,
                              color: _value == 'Appointments'
                                  ? ColorsX.blue_button_color
                                  : ColorsX.subBlack)),
                    ),
                    GestureDetector(
                      //onTap: () => setState(() => _value = 'Appointments'),
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Text("Appointments",
                            style: TextStyle(
                                color: _value == 'Appointments'
                                    ? ColorsX.blue_button_color
                                    : ColorsX.subBlack,
                                fontSize: 11,
                                fontWeight: FontWeight.w400)),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 15,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
