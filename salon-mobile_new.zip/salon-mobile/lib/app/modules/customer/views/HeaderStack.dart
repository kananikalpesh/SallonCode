// ignore_for_file: unnecessary_new, file_names

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/custome_home_controller.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/modules/customer/views/home/home_wrapper.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/size_config.dart';
import 'package:saloon_app/main.dart';

import 'home/search_screen_w_text.dart';

class HeaderStack extends GetView<DashboardItemController> {
  CustomerHomeController customerHomeController = Get.find();
  // LoginController _loginController = Get.find();
  String categoryShow;

  HeaderStack({required this.categoryShow});

  // TextEditingController searchController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          width: SizeConfig.screenWidth,
          margin: EdgeInsets.only(top: 0),
          child: Image.asset(
            "assets/images/stack_bg.png",
            fit: BoxFit.fill,
          ),
        ),
        Row(
          children: [
            Expanded(
              child: Container(
                margin: EdgeInsets.only(top:20, left: 20),
                child: Text(
                  "Hello, ${sharedPreferences!.get("name")}",
                  style: TextStyle(
                      color: ColorsX.blue_text_color,
                      fontWeight: FontWeight.w900,
                      fontSize: 20),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(
                  top:20, left: 20, right: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    onTap: () {
                      Get.toNamed(Routes.NOTIFICATION_SCREEN);
                    },
                    child: Container(
                      child: Image.asset(
                        "assets/images/bell.png",
                      ),
                    ),
                  ),
                  SizedBox(width: 5,),
                  InkWell(
                    onTap: () {
                      // customerHomeController.homecurrentScreenIndex.value = 3;
                      Get.toNamed(Routes.CUSTOMER_FILTER);
                      print("head clicked");
                    },
                    child: Container(
                        margin: EdgeInsets.only(left: 5),
                        child: Image.asset(
                          "assets/images/head.png",
                        )),
                  ),
                ],
              ),
            ),

          ],
        ),
        Container(
          margin: EdgeInsets.only(top: SizeConfig.screenHeight * .11, left: 20),
          child: Text(
            "Your location",
            style: TextStyle(
                color: ColorsX.myblack,
                fontWeight: FontWeight.w400,
                fontSize: 16),
          ),
        ),
        Container(
          margin: EdgeInsets.only(
              top: SizeConfig.screenHeight * .16, left: 20, right: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                  child: Icon(
                Icons.location_pin,
                color: ColorsX.myblack,
              )),
              Expanded(
                child: _myLocationText(
                    context,
                    "${customerHomeController.userAddress}",
                    0xff000000,
                    15,
                    0,
                    0,
                    FontWeight.w600,
                    16),
              ),
              _myLocationText(
                  context, "Change", 0xff70b4ff, 15, 0, 0, FontWeight.w600, 16),
              SizedBox(
                width: 10,
              ),
              Container(
                  child: Image.asset(
                "assets/images/change.png",
              )),
              // Expanded(child: _myLocationText(context, "Change", 0xff70b4ff))
            ],
          ),
        ),
        TextFields(context, false, SizeConfig.screenHeight * .22, 20, 20,
            "Search for salons", "text"),
      ],
    );
  }

  Widget TextFields(BuildContext context, bool obscure, double top, double left,
      double right, String hint, String inputType) {
    return Container(
      padding:
          EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 3, right: 0),
      height: SizeConfig.blockSizeVertical * 6,
      decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: top, right: right, left: left),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Flexible(
            child: TextFormField(
              onChanged: (v) => print(v),
              controller: controller.searchCTL,
              style: TextStyle(color: ColorsX.subBlack),
              keyboardType: TextInputType.text,
              obscureText: obscure,
              // controller: numberController,
              // validator: (String value) => value.length < 10
              //     ? 'Çharacter Length Must Be 10 Character Long'
              //     : null,
              minLines: 1,
              //Normal textInputField will be disp
              decoration: InputDecoration(
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                hintText: hint,
                contentPadding: EdgeInsets.only(top: 0.0, right: 0.0),
                hintStyle: TextStyle(color: ColorsX.subBlack),
                // prefixIcon: Icon(
                //   Icons.search,
                //   color: ColorsX.subBlack,
                // ),
              ),
            ),
          ),
          InkWell(
            onTap: () async {
              Functions.hideKeyboard(context);
              //Get.to();
              // customerHomeController.homecurrentScreenIndex.value = 1;
              if (controller.searchCTL.text.isEmpty) {
                // Get.toNamed(HomeNavigation.searchScreen, id: 2);
                print("Empty Search");
              } else {
                final res =
                    await controller.saloonItems(controller.searchCTL.text);
                if (controller.page == 'home') {
                  Get.toNamed(HomeNavigation.searchScreenWithText, id: 2);
                } else if (controller.page == 'offer') {
                  Get.to(SearchScreenWText());
                }else{
                  Get.toNamed(HomeNavigation.searchScreenWithText, id: 2);
                }
              }
            },
            child: Container(
              width: SizeConfig.blockSizeHorizontal * 12,
              //margin: EdgeInsets.only(top: top, right: right, left: left),
              decoration: new BoxDecoration(
                  color: ColorsX.blue_button_color,
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(10),
                      bottomRight: Radius.circular(10))),
              // padding: EdgeInsets.all(20),
              child: Center(
                child: Icon(
                  Icons.search,
                  color: ColorsX.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _myLocationText(
      BuildContext context,
      String text,
      int colorCode,
      double left,
      double top,
      double right,
      FontWeight fontWeight,
      double fontSize) {
    return GestureDetector(
        onTap: () {
          if (text == ("View All")) {
            // Navigator.pushNamed(context, '/viewAllSaloon');
          } else {
            print("no");
            Get.toNamed(HomeNavigation.locationScreen, id: 2);
          }
        },
        child: Container(
          margin: EdgeInsets.only(left: left, top: top, right: right),
          child: Text(
            text,
            style: TextStyle(
                color: Color(colorCode),
                fontWeight: FontWeight.w600,
                fontSize: fontSize),
          ),
        ));
  }
}
