import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:saloon_app/app/modules/customer/controllers/user-profile-ctl.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class MyProfile extends GetView<UserProfileCtl> {
  @override
  Widget build(BuildContext context) {
    return  ListView(
      children: <Widget>[
       Obx(()=> controller.isDataLoaded.isTrue ?Column(
         crossAxisAlignment: CrossAxisAlignment.center,
         children: <Widget>[
           Stack(
             children: <Widget>[
               Container(
                 height: 80,
                 color: ColorsX.lightStackColor,
               ),
               Container(
                 margin: EdgeInsets.only(top: 30),
                 child: Column(
                   crossAxisAlignment: CrossAxisAlignment.center,
                   children: <Widget>[
                     Align(
                       alignment: Alignment.center,
                       child: _rowItemForHeaderText("My Profile", 16,
                           FontWeight.w700, 0xff707070, 0, 0, 0),
                     ),
                     // Align(
                     //   alignment: Alignment.center,
                     //   child: _rowItemForHeaderText("Edited 15 min ago", 12,
                     //       FontWeight.w400, 0xff707070, 5, 0, 0),
                     // )
                   ],
                 ),
               ),
             ],
           ),
           _myDp(context, "${controller.userProfileModel?.data.profilePic}"),
           _rowItemForHeaderText(
               "${controller.userProfileModel?.data.name}", 18, FontWeight.w700, 0xff383838, 20, 0, 0),
           _rowItemForHeaderText("Account Created on "+formatISOTimeNew(DateTime.parse(controller.accountCreated)), 12,
               FontWeight.w400, 0xff707070, 10, 0, 0),
           GestureDetector(
               onTap: () {
                 Get.toNamed(Routes.TRANSECTION_DETAIL);
               },
               child: _myButton("Show receipt")),
           _rating(context, controller.userProfileModel?.data.rating.toDouble()),
           SizedBox(
             height: 20,
           ),
           _rowOfProfile(
               context, '${controller.userProfileModel?.data.email}', "assets/images/email.png"),
           _rowOfProfile(
               context, "${controller.userProfileModel?.data.mobileNumber}", "assets/images/mobile.png"),
           _rowOfProfile(context, "${controller.userProfileModel?.data.dob}", "assets/images/dob.png"),
           _rowOfProfile(context, "Log Out", "assets/images/logout.png"),
           Align(
               alignment: Alignment.topCenter,
               child: GestureDetector(
                 onTap: () {
                   // Navigator.pushNamed(context, '/notifications');
                   // Get.toNamed(Routes.TRANSECTION_LIST);
                   Get.toNamed(Routes.edit_my_profile);

                 },
                 child: Container(
                   margin: EdgeInsets.only(
                     top: SizeConfig.twentyPercentWidth,
                   ),
                   width: SizeConfig.eightyPercentWidth,
                   padding: EdgeInsets.symmetric(vertical: 15),
                   decoration: BoxDecoration(
                     color: ColorsX.blue_button_color,
                     borderRadius: BorderRadius.all(Radius.circular(10)),
                   ),
                   child: Row(
                     mainAxisAlignment: MainAxisAlignment.center,
                     children: <Widget>[
                       Text('Edit Profile',
                           style: TextStyle(
                             fontSize: 16,
                             color: ColorsX.white,
                             fontWeight: FontWeight.w700,
                           )),
                     ],
                   ),
                 ),
               ))
         ],
       ):Container(),),
      ],
    );
  }
  // handleAppLifecycleState() {
  //   AppLifecycleState _lastLifecyleState;
  //   SystemChannels.lifecycle.setMessageHandler((msg) {
  //     print('SystemChannels> $msg');
  //
  //     switch (msg) {
  //       case "AppLifecycleState.paused":
  //         print("paused");
  //         _lastLifecyleState = AppLifecycleState.paused;
  //         break;
  //       case "AppLifecycleState.inactive":
  //         print("inactive");
  //         _lastLifecyleState = AppLifecycleState.inactive;
  //         break;
  //       case "AppLifecycleState.resumed":
  //         print("resume");
  //         _lastLifecyleState = AppLifecycleState.resumed;
  //         break;
  //       default:
  //     }
  //   });
  // }
  String formatISOTime(DateTime date) {
    var duration = date.timeZoneOffset;
    if (duration.isNegative)
      return (date.toIso8601String() + "-${duration.inHours.toString().padLeft(2, '0')}:${(duration.inMinutes - (duration.inHours * 60)).toString().padLeft(2, '0')}");
    else
      return (date.toIso8601String() + "+${duration.inHours.toString().padLeft(2, '0')}:${(duration.inMinutes - (duration.inHours * 60)).toString().padLeft(2, '0')}");
  }
  Widget _myButton(String text) {
    return Container(
      margin: EdgeInsets.only(
        top: SizeConfig.blockSizeVertical * 2,
      ),
      width: SizeConfig.blockSizeHorizontal * 45,
      padding: EdgeInsets.symmetric(vertical: SizeConfig.blockSizeVertical),
      decoration: BoxDecoration(
        color: ColorsX.blue_button_color,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(text,
              style: TextStyle(
                fontSize: 16,
                color: ColorsX.white,
                fontWeight: FontWeight.w700,
              )),
        ],
      ),
    );
  }

  Widget _rowOfProfile(BuildContext context, String text, String imagePath) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            width: SizeConfig.blockSizeHorizontal * 25,
          ),
          Image.asset(
            imagePath,
            color: ColorsX.blue_text_color,
          ),
          SizedBox(
            width: 40,
          ),
          Expanded(
              child: _rowItemForHeaderText(
                  text, 16, FontWeight.w400, 0xff707070, 0, 0, 0)),
        ],
      ),
    );
  }

  Widget _rating(BuildContext context, dynamic rating) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            height: 26,
            child: RatingBar.builder(
              initialRating: rating,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemSize: 20,
              ignoreGestures: true,
              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                print(rating);
              },
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 3),
          _rowItemForHeaderText("${controller.userProfileModel?.data.rating}", 16, FontWeight.w400, 0xff707070, 0, 0, 0)
        ],
      ),
    );
  }

  Widget _myDp(BuildContext context, String imagePath) {
    return
      Container(
        margin: EdgeInsets.only(top: 30),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(60),
          child: Container(
            decoration: new BoxDecoration(
              shape: BoxShape.circle,
            ),
            child: CachedNetworkImage(
              imageUrl: AppUrls.BASE_URL_IMAGE+'${imagePath}',
              errorWidget: (context, url, error) => Icon(Icons.error),// Icon(Icons.error),
              fit: BoxFit.cover,width: 115, height: 115,

              placeholder: (context, url) => Container(
                  height: 30,
                  width: 30,
                  child: Center(child: CircularProgressIndicator())),
            ),
            // child: Image.asset("assets/images/mike.png"),
          ),
        ),
      );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  String formatISOTimeNew(DateTime s) {
    String formattedDate = DateFormat('dd-MM-yyyy').format(s);
    return formattedDate;
  }
}
