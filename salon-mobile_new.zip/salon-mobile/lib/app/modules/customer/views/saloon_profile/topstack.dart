
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/modules/intro_pages/views/slidercontent.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class TopStack extends GetView<SaloonController> {
  // late GetSaloonDetailsModel getSaloonDetailsModel;

  // TopStack({required this.getSaloonDetailsModel});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: SizeConfig.fortyPercentHeight,
      width: SizeConfig.screenWidth,
      child: ListView.builder(
        itemCount: controller.getSaloonDetailsModel?.saloon?.photos.length??0,
        scrollDirection: Axis.horizontal,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return Container(
            height: SizeConfig.fortyPercentHeight,
            width: SizeConfig.screenWidth,
            child: PageView(
              children: <Widget>[
                // SliderContent(imagePath: getSaloonDetailsModel.saloon?.photos?[index], pageNumber:index, numberOfDots: getSaloonDetailsModel.saloon?.photos?.length, buttonText: "OPEN",
                //   reviews: getSaloonDetailsModel.saloon?.reviews, rating: getSaloonDetailsModel.saloon?.rating,),
                SliderContent(imagePath: controller.getSaloonDetailsModel?.saloon?.photos[index], pageNumber:index, numberOfDots: controller.getSaloonDetailsModel?.saloon?.photos.length, buttonText: "OPEN",
                  reviews: controller.getSaloonDetailsModel?.saloon?.reviews, rating: controller.getSaloonDetailsModel?.saloon?.rating,)
              ],
            ),
          );
        },
      ),
    );
  }
}