import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/resuseable/bottom_cart.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';



class AddOns extends GetView<SaloonController> {
  String clickValue = "";
  bool valuefirst = false;
  bool isChecked = false;
  bool valuesecond = false;
  final _headerStyle = TextStyle(
      color: Color(0xff989696), fontSize: 15, fontWeight: FontWeight.bold);
  final _contentStyleHeader = TextStyle(
      color: Color(0xff999999), fontSize: 14, fontWeight: FontWeight.w700);
  final _contentStyle = TextStyle(
      color: Color(0xff999999), fontSize: 14, fontWeight: FontWeight.normal);
  final _loremIpsum =
  '''Lorem ipsum is typically a corrupted version of 'De finibus bonorum et malorum', a 1st century BC text by the Roman statesman and philosopher Cicero, with words altered, added, and removed to make it nonsensical and improper Latin.''';

  @override
  Widget build(BuildContext context) {
    controller.buttonValue.value == "Book Now";
    // Color getColor(Set<MaterialState> states) {
    //   const Set<MaterialState> interactiveStates = <MaterialState>{
    //     MaterialState.pressed,
    //     MaterialState.hovered,
    //     MaterialState.focused,
    //   };
    //   if (states.any(interactiveStates.contains)) {
    //     return Colors.blue;
    //   }
    //   return Colors.red;
    // }
    return Container(
      child: Column(
        children: <Widget>[
          if(controller.getSaloonDetailsModel?.products?.isNotEmpty??false)

            for(int index =0; index < (controller.getSaloonDetailsModel?.products?.length??0); index++)
              _buildExpandableList(index,"Product Type", controller.getSaloonDetailsModel?.products?[index].category.title,
                  "", "",
                  "",""),
          // GestureDetector(
          //     onTap: () {
          //       if(controller.selectedServicesList.isEmpty){
          //         print("Select at least one service");
          //         Functions.showErrorToast(context, "Can't Continue", "Select at least one service to continue");
          //       }
          //       else {
          //         Get.toNamed(Routes.SELECT_ADD_ONS);
          //       }
          //     },
          //     child: Button(context)),
          verticalSpace(SizeConfig.blockSizeVertical * 10),
          BottomCart()
        ],
      ),
    );

    // child: Column(
    //   crossAxisAlignment: CrossAxisAlignment.start,
    //   children: <Widget>[
    //
    //            _servicesClicked("assets/images/hair.png","Hair Styling","30 minutes", "30" +"\$",0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Bridal Makeup", context),
    //            _servicesClicked("assets/images/straight.png","Shaving","1 hour", "50" +"\$",0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Hair Drying", context),
    //            _servicesClicked("assets/images/dryer.png","Hair Drying","30 minutes", "30" +"\$",0xffffffff,0xff6EC8FD,0xffffffff, clickValue="Hair Drying", context),
    //            _servicesClicked("assets/images/comb.png","Hair Cutting","1 hour", "50" +"\$",0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Bridal Makeup", context),
    //            _servicesClicked("assets/images/party.png","Party Makeup","30 minutes", "30" +"\$",0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Hair Drying", context),
    //   ],
    // ),
    // );

    //   widget.getSaloonDetailsModel.saloon?.services==null?Container():Container(
    //   height: SizeConfig.screenHeight,
    //   width: SizeConfig.screenWidth,
    //   child: Column(
    //     crossAxisAlignment: CrossAxisAlignment.start,
    //     children: <Widget>[
    //       for ( var i=0;i<widget.getSaloonDetailsModel.saloon!.services!.length;i++ )Column(
    //         mainAxisSize: MainAxisSize.min,
    //         children: [
    //           _services(widget.getSaloonDetailsModel.saloon?.services?[i].profilePic,widget.getSaloonDetailsModel.saloon?.services?[i].name,
    //               '${widget.getSaloonDetailsModel.saloon?.services?[i].timeRequired} minutes','${widget.getSaloonDetailsModel.saloon?.services?[i].price} '
    //                   '${widget.getSaloonDetailsModel.saloon?.services?[i].prefix}',0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Bridal Makeup", context, false),
    //         ],
    //       )
    //
    //
    //     ],
    //   ),
    //   // child: Column(
    //   //   crossAxisAlignment: CrossAxisAlignment.start,
    //   //   children: <Widget>[
    //   //     _services("assets/images/hair.png","Hair Styling","30 minutes", "30" +"\$",0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Bridal Makeup", context),
    //   //     _services("assets/images/straight.png","Shaving","1 hour", "50" +"\$",0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Hair Drying", context),
    //   //     _services("assets/images/dryer.png","Hair Drying","30 minutes", "30" +"\$",0xffffffff,0xff6EC8FD,0xffffffff, clickValue="Hair Drying", context),
    //   //     _services("assets/images/comb.png","Hair Cutting","1 hour", "50" +"\$",0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Bridal Makeup", context),
    //   //     _services("assets/images/party.png","Party Makeup","30 minutes", "30" +"\$",0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Hair Drying", context),
    //   //     _services("assets/images/makeup.png","Bridal Makeup","1 hour", "50" +"\$",0xff707070,0xfff2f5f5,0xff6EC8FD, clickValue="Bridal Makeup", context),
    //   //     // _servicesClicked("assets/images/dryer.png","Hair Drying","30 minutes", "30" +"\$",0xffffffff,0xff6EC8FD,0xffffffff, clickValue="Hair Drying", context)
    //   //   ],
    //   // ),
    // );
  }


  Widget _buildExpandableList(int index,String title, String? subtitle, String itemTitle, String itemSubtitle, String? id, String? itemPrice) {
    int length = controller.getSaloonDetailsModel?.products?[index].products.length??0;
    return Card(
      color: Color(0xffEFF6F6),
      margin: EdgeInsets.only(left: 20, right: 20, top: 10),
      child: ExpansionTile(
        leading: Container(
          decoration: BoxDecoration(
              color: ColorsX.blue_button_color, shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(3.0),
            child: Image.asset(
              "assets/images/hair.png",
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _rowItemForHeaderText(
                title, 10, FontWeight.w400, 0xff000000, 0, 0, 0),
            _rowItemForHeaderText(
                "${subtitle}", 12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
          ],
        ),
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              for(int i=0; i<length;i++)
                ListTile(
                  leading: _rowItemForHeaderText(
                      "${i+1}", 12, FontWeight.w400, 0xff000000, 0, 0, 0),
                  // Obx(() => Checkbox(
                  //   value: controller.isAddOnChecked[index],
                  //   onChanged: (bool? value) {
                  //     controller.isAddOnChecked[index] =
                  //     !controller.isAddOnChecked[index];
                  //     controller.addOnCount.value = controller
                  //         .isAddOnChecked
                  //         .where((check) => check == true)
                  //         .length;
                  //     print(controller.addOnCount.value);
                  //     if(controller.isAddOnChecked[index]){
                  //       if(!controller.selectedAddOnsList.contains(itemTitle)) {
                  //         controller.selectedAddOnsPriceList.add(int.parse(itemPrice!));
                  //         controller.selectedAddOnsList.add(itemTitle);
                  //         controller.selectedAddOnsIDSList.add(id);
                  //       }
                  //       else{
                  //         print("already exist");
                  //       }
                  //     }else{
                  //       if(controller.selectedAddOnsList.contains(itemTitle)) {
                  //         controller.selectedAddOnsList.remove(itemTitle);
                  //         controller.selectedAddOnsPriceList.remove(int.parse(itemPrice!));
                  //         controller.selectedAddOnsIDSList.remove(id);
                  //       }else{
                  //         print("does not exist in cart");
                  //       }
                  //     }
                  //     print(controller.addOnCount.value);
                  //     print(controller.selectedAddOnsPriceList);
                  //     print(controller.selectedAddOnsList);
                  //     print(controller.selectedAddOnsIDSList);
                  //     // This is where we update the state when the checkbox is tapped
                  //     // setState(() {
                  //     //   isChecked = value!;
                  //     // });
                  //   },
                  // )),
                  title: _rowItemForHeaderText(
                      "${controller.getSaloonDetailsModel?.products?[index].products[i].name}", 12, FontWeight.w400, 0xff000000, 0, 0, 0),
                  subtitle: _rowItemForHeaderText(
                      "${controller.getSaloonDetailsModel?.products?[index].products[i].description}", 12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
                  trailing: _rowItemForHeaderText(
                      "${controller.getSaloonDetailsModel?.products?[index].products[i].price} \$", 12, FontWeight.w700, 0xff70b4f3, 0, 0, 0),
                  isThreeLine: true,
                ),

              // ListTile(
              //   leading: Checkbox(
              //     value: true,
              //     onChanged: (bool? value) {
              //       // This is where we update the state when the checkbox is tapped
              //       // setState(() {
              //       //   isChecked = value!;
              //       // });
              //     },
              //   ),
              //   title: _rowItemForHeaderText(
              //       itemTitle, 12, FontWeight.w400, 0xff000000, 0, 0, 0),
              //   subtitle: _rowItemForHeaderText(
              //       itemSubtitle, 12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
              //   isThreeLine: true,
              // ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(String value, double fontSize,
      FontWeight fontWeight, int colorCode, double top, double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode),
          fontWeight: fontWeight,
          fontSize: fontSize),),
    );
  }
}
    // Widget _buildExpandableList(String title, String subtitle) {
    //   var isexpanded = false.obs;
    //
    //
    //   return Obx(() =>
    //       Card(
    //         // color: Color(0xffEFF6F6),
    //         margin: EdgeInsets.only(left: 20, right: 20, top: 10),
    //         child: ExpansionTile(
    //           trailing: isexpanded.value
    //               ? Image.asset(AppImages.drop_down_expandable_ic)
    //               : Image.asset(AppImages.drop_down_expandable_ic),
    //           leading: Container(
    //             decoration: BoxDecoration(
    //                 color: ColorsX.blue_button_color,
    //                 shape: BoxShape.circle
    //             ),
    //             child: Padding(
    //               padding: const EdgeInsets.all(3.0),
    //               child: Image.asset("assets/images/hair.png",),
    //             ),
    //           ),
    //           title: Column(
    //             crossAxisAlignment: CrossAxisAlignment.start,
    //             children: [
    //               _rowItemForHeaderText(
    //                   "Product Type",
    //                   10,
    //                   FontWeight.w400,
    //                   0xff000000,
    //                   0,
    //                   0,
    //                   0),
    //               _rowItemForHeaderText(
    //                   "Lotion",
    //                   12,
    //                   FontWeight.w400,
    //                   0xffa8a7a7,
    //                   0,
    //                   0,
    //                   0),
    //             ],
    //           ),
    //           onExpansionChanged: (value) {
    //             isexpanded.value = value;
    //             print(isexpanded);
    //           },
    //           backgroundColor: ColorsX.expandable_collapsed,
    //           collapsedBackgroundColor: ColorsX.expandable_collapsed,
    //           children: <Widget>[
    //             Container(
    //               color: ColorsX.white,
    //               child: Column(
    //                 crossAxisAlignment: CrossAxisAlignment.start,
    //                 children: <Widget>[
    //                   ListTile(
    //                     leading: Checkbox(
    //                       value: isChecked,
    //                       shape: CircleBorder(),
    //
    //                       onChanged: (
    //                           bool? value) { // This is where we update the state when the checkbox is tapped
    //                         // setState(() {
    //                         //   isChecked = value!;
    //                         // });
    //                       },
    //                     ),
    //                     title: _rowItemForHeaderText(
    //                         "Body Lotion 500ml",
    //                         12,
    //                         FontWeight.w400,
    //                         0xff000000,
    //                         0,
    //                         0,
    //                         0),
    //                     subtitle: _rowItemForHeaderText(
    //                         "Recommended for soft skin",
    //                         12,
    //                         FontWeight.w400,
    //                         0xffa8a7a7,
    //                         0,
    //                         0,
    //                         0),
    //                     trailing: _rowItemForHeaderText(
    //                         '80 ' + '\$',
    //                         12,
    //                         FontWeight.w700,
    //                         0xff70b4ff,
    //                         0,
    //                         0,
    //                         0),
    //                     isThreeLine: true,
    //                   ),
    //                   ListTile(
    //                     leading: Checkbox(
    //                       value: isChecked,
    //                       shape: CircleBorder(),
    //
    //                       onChanged: (
    //                           bool? value) { // This is where we update the state when the checkbox is tapped
    //                         // setState(() {
    //                         //   isChecked = value!;
    //                         // });
    //                       },
    //                     ),
    //                     title: _rowItemForHeaderText(
    //                         "Body Lotion 800ml",
    //                         12,
    //                         FontWeight.w400,
    //                         0xff000000,
    //                         0,
    //                         0,
    //                         0),
    //                     subtitle: _rowItemForHeaderText(
    //                         "Recommended for soft skin",
    //                         12,
    //                         FontWeight.w400,
    //                         0xffa8a7a7,
    //                         0,
    //                         0,
    //                         0),
    //                     trailing: _rowItemForHeaderText(
    //                         '50 ''\$',
    //                         12,
    //                         FontWeight.w700,
    //                         0xff70b4ff,
    //                         0,
    //                         0,
    //                         0),
    //                     isThreeLine: true,
    //                   ),
    //                 ],
    //               ),
    //             ),
    //           ],
    //         ),
    //       ));
    // }
    // Widget _services(String? imagePath, String? value1, String? value2, String ?value3, int colorCode, int background, int circleColor, String clickValue, BuildContext context, bool isVisible){
    //   return GestureDetector(
    //       onTap: (){
    //         // if(clickValue=="Hair Drying"){
    //         //   Navigator.pushNamed(context, '/appointmentTwo');
    //         // }
    //         // else if(clickValue == "Bridal Makeup"){
    //         //   Navigator.pushNamed(context, '/bridal');
    //         // }
    //         // else{
    //         //
    //         // }
    //         setState(() {
    //           isVisible==true;
    //         });
    //       },
    //       child: Container(
    //           margin: EdgeInsets.only(left: 15, right: 15, top: 10),
    //           decoration: new BoxDecoration(
    //             color: Color(background),
    //             borderRadius: BorderRadius.all( Radius.circular(10)),
    //           ),
    //           child: Column(
    //             crossAxisAlignment: CrossAxisAlignment.start,
    //             children: <Widget>[
    //               Row(
    //                 mainAxisAlignment: MainAxisAlignment.spaceAround,
    //                 children: <Widget>[
    //                   Container(
    //                     width: 50,
    //                     height: 50,
    //                     margin: EdgeInsets.only(top: 5, bottom: 5),
    //                     child: CachedNetworkImage(
    //                       imageUrl: Constants.BASE_URL_IMAGE+'${imagePath}',
    //                       errorWidget: (context, url, error) => Icon(Icons.error),
    //                       fit: BoxFit.cover,width: 50, height: 50,
    //
    //                       placeholder: (context, url) => Container(
    //                           height: 30,
    //                           width: 30,
    //                           child: Center(child: CircularProgressIndicator())),
    //                     ),
    //                     // child: _circleDraw(imagePath, circleColor, 0xffffffff),
    //                   ),
    //                   _columnItem("Service Type",'${value1}', colorCode),
    //                   _columnItem("Time Required",'${value2}', colorCode),
    //                   _columnItem("Price",'${value3}', colorCode),
    //                 ],
    //               ),
    //               Visibility(
    //                 visible: false,// isVisible?false:true,
    //                 child: Row(
    //                   mainAxisAlignment: MainAxisAlignment.spaceAround,
    //                   children: <Widget>[
    //                     SizedBox(width: 50,),
    //                     _rowItemForHeaderText("Description", 8, FontWeight.w400, 0xffffffff, 0, 0, 0),
    //                     SizedBox(width: 50,),
    //                     SizedBox(width: 50,),
    //                   ],
    //                 ),
    //               ),
    //               Visibility(
    //                 visible: false,// isVisible?false:true,
    //                 child: Row(
    //                   mainAxisAlignment: MainAxisAlignment.spaceAround,
    //                   children: <Widget>[
    //                     Container(height: 50,width: 50,),
    //                     SizedBox(width: 10,),
    //                     Container(
    //                       width: SizeConfig.sixtyPercentWidth,
    //                       child: Text("A hair dryer, hairdryer or blow dryer is an electromechanical device that blows ambient or hot air over dump hair to speed the evaporation", style: TextStyle(
    //                           fontSize: 12, fontWeight: FontWeight.w400, color: ColorsX.white),),
    //                     ),
    //                     // _rowItemForHeaderText("A hair dryer, hairdryer or blow dryer is an electromechanical device that blows ambient or hot air over dump hair to speed the evaporation", 8, FontWeight.w400, 0xffffffff, 0, 0, 0),
    //                     // SizedBox(width: 50,),
    //                   ],
    //                 ),
    //               ),
    //
    //               // Row(
    //               //   mainAxisAlignment: MainAxisAlignment.spaceAround,
    //               //   children: <Widget>[
    //               //     Container(
    //               //       width: 50,
    //               //       height: 50,
    //               //     ),
    //               //     Container(
    //               //       width: MediaQuery.of(context).size.width*100,
    //               //       child: _rowItemForHeaderText("gjnfn gkfjnkjnf fjdgnkfngg fgfnfjk jgfnkj gjnfn gkfjnkjnf fjdgnkfngg fgfnfjk jgfnkjgjnfn gkfjnkjnf fjdgnkfngg fgfnfjk jgfnkj", 8, FontWeight.w400, 0xffffffff, 0, 0, 0),
    //               //     ),
    //               //
    //               //   ],
    //               // ),
    //             ],
    //           )
    //       )
    //
    //   );
    // }

    // Widget _servicesClicked(String imagePath, String value1, String value2,
    //     String value3, int colorCode, int background, int circleColor,
    //     String clickValue, BuildContext context) {
    //   return GestureDetector(
    //       onTap: () {
    //         if (clickValue == "Hair Drying") {
    //           Navigator.pushNamed(context, '/appointmentTwo');
    //         }
    //         else if (clickValue == "Bridal Makeup") {
    //           Navigator.pushNamed(context, '/bridal');
    //         }
    //         else {}
    //       },
    //       child: Container(
    //           margin: EdgeInsets.only(left: 15, right: 15, top: 10),
    //           decoration: new BoxDecoration(
    //             color: Color(background),
    //             borderRadius: BorderRadius.all(Radius.circular(10)),
    //           ),
    //           child: Column(
    //             crossAxisAlignment: CrossAxisAlignment.start,
    //             children: <Widget>[
    //               Row(
    //                 mainAxisAlignment: MainAxisAlignment.spaceAround,
    //                 children: <Widget>[
    //                   Container(
    //                     width: 50,
    //                     height: 50,
    //                     margin: EdgeInsets.only(top: 5, bottom: 5),
    //                     child: _circleDraw(imagePath, circleColor, 0xffffffff),
    //                   ),
    //                   _columnItem("Service Type", value1, colorCode),
    //                   _columnItem("Time Required", value2, colorCode),
    //                   _columnItem("Price", value3, colorCode),
    //                 ],
    //               ),
    //               Row(
    //                 mainAxisAlignment: MainAxisAlignment.spaceAround,
    //                 children: <Widget>[
    //                   SizedBox(width: 50,),
    //                   _rowItemForHeaderText(
    //                       "Description",
    //                       8,
    //                       FontWeight.w400,
    //                       0xffffffff,
    //                       0,
    //                       0,
    //                       0),
    //                   SizedBox(width: 50,),
    //                   SizedBox(width: 50,),
    //                 ],
    //               ),
    //               Row(
    //                 mainAxisAlignment: MainAxisAlignment.spaceAround,
    //                 children: <Widget>[
    //                   Container(height: 50, width: 50,),
    //                   SizedBox(width: 10,),
    //                   Container(
    //                     width: SizeConfig.sixtyPercentWidth,
    //                     child: Text(
    //                       "A hair dryer, hairdryer or blow dryer is an electromechanical device that blows ambient or hot air over dump hair to speed the evaporation",
    //                       style: TextStyle(
    //                           fontSize: 12,
    //                           fontWeight: FontWeight.w400,
    //                           color: ColorsX.white
    //                       ),),
    //                   ),
    //                   // _rowItemForHeaderText("A hair dryer, hairdryer or blow dryer is an electromechanical device that blows ambient or hot air over dump hair to speed the evaporation", 8, FontWeight.w400, 0xffffffff, 0, 0, 0),
    //                   // SizedBox(width: 50,),
    //                 ],
    //               ),
    //
    //               // Row(
    //               //   mainAxisAlignment: MainAxisAlignment.spaceAround,
    //               //   children: <Widget>[
    //               //     Container(
    //               //       width: 50,
    //               //       height: 50,
    //               //     ),
    //               //     Container(
    //               //       width: MediaQuery.of(context).size.width*100,
    //               //       child: _rowItemForHeaderText("gjnfn gkfjnkjnf fjdgnkfngg fgfnfjk jgfnkj gjnfn gkfjnkjnf fjdgnkfngg fgfnfjk jgfnkjgjnfn gkfjnkjnf fjdgnkfngg fgfnfjk jgfnkj", 8, FontWeight.w400, 0xffffffff, 0, 0, 0),
    //               //     ),
    //               //
    //               //   ],
    //               // ),
    //             ],
    //           )
    //       )
    //   );
    // }
    //
    //
    // Widget _columnItem(String value1, String value2, int colorCode) {
    //   return
    //     Column(
    //       crossAxisAlignment: CrossAxisAlignment.start,
    //       children: <Widget>[
    //         _rowItemForHeaderText(
    //             value1,
    //             8,
    //             FontWeight.w400,
    //             colorCode,
    //             5,
    //             0,
    //             0),
    //         _rowItemForHeaderText(
    //             value2,
    //             12,
    //             FontWeight.w400,
    //             colorCode,
    //             5,
    //             0,
    //             0),
    //       ],
    //     );
    // }

    // Widget _circleDraw(String imagePath, int circleColor, int imageColor,) {
    //   return Container(
    //     width: 60,
    //     height: 60,
    //     child: Image.asset(imagePath),
    //     decoration: BoxDecoration(
    //         shape: BoxShape.circle,
    //         color: Color(circleColor)),
    //   );
    // }
  // }