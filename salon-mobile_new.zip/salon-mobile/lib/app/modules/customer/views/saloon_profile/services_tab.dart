import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/add-ons.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'packages_offer.dart';
import 'services_content.dart';
// import 'package:saloon_app/Model/saloons/get_saloon_details.dart';
// import 'package:saloon_app/screens/customer/aboutSaloon/ServicesContent.dart';
// import 'package:saloon_app/styles/colors.dart';
// import 'package:saloon_app/utils/size_config.dart';

// import 'PackageOfferList.dart';

class ServicesTab extends StatefulWidget {
  // GetSaloonDetailsModel getSaloonDetailsModel;
  // ServicesTab({required this.getSaloonDetailsModel});
  @override
  _HomeScreenState createState() => _HomeScreenState();
}
class _HomeScreenState extends State<ServicesTab>{
  String _value = "Services";
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Container(
            width: SizeConfig.screenWidth,
            margin: EdgeInsets.only(left: 20, right: 20),
            decoration: new BoxDecoration(
              color: ColorsX.white,
              borderRadius: BorderRadius.all( Radius.circular(5)),
              border: Border.all(color: ColorsX.blue_text_color),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                GestureDetector(
                  onTap:() => setState(() => _value = 'Services'),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    decoration: new BoxDecoration(
                      color: _value=="Services"?Color(0xff70b4ff):Color(0xffffffff),
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(4),bottomLeft: Radius.circular(4)),
                    ),
                    child: _rowItemForHeaderText("Services", 14, FontWeight.w600, _value=="Services"?0xffffffff:0xff000000, 10, 0, 0,10),
                  ),
                ),
                Container(
                  width: 1,
                  color: ColorsX.blue_text_color,
                  height: 35,
                ),
                Expanded(child: Center(
                  child: GestureDetector(
                    onTap:() => setState(() => _value = 'Package' ),
                    child: Container(
                      width: SizeConfig.seventyPercentWidth,
                      // padding: EdgeInsets.symmetric(horizontal: 21),
                      decoration: new BoxDecoration(
                        color: _value=="Package"?Color(0xff70b4ff):Color(0xffffffff),
                        // borderRadius: BorderRadius.all( Radius.circular(4)),
                      ),
                      child: _rowItemForHeaderText("Package & Offers", 14, FontWeight.w600, _value=="Package"?0xffffffff:0xff000000, 10, 0, 0,10),
                    ),),
                ),
                ),
                Container(
                  width: 1,
                  color: ColorsX.blue_text_color,
                  height: 35,
                ),
                GestureDetector(
                  onTap:() => setState(() => _value = 'Price'),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    decoration: new BoxDecoration(
                      color: _value=="Price"?Color(0xff70b4ff):Color(0xffffffff),
                      borderRadius: BorderRadius.only(topRight: Radius.circular(4), bottomRight: Radius.circular(4)),
                    ),
                    child: _rowItemForHeaderText("Add-Ons", 14, FontWeight.w600, _value=="Price"?0xffffffff:0xff000000, 10, 0, 0,10),
                  ),
                ),
              ],
            ),
          ),
          _openViewAccordingToItemSelected(context,_value),
        ],
      ),
    );
  }
  Widget _openViewAccordingToItemSelected(BuildContext context,String item){
    switch (item){
      case 'Services':
        // return ServicesContent(getSaloonDetailsModel: widget.getSaloonDetailsModel,);
        return ServicesContent();
      case 'Package':
        // return PackageOfferList(getSaloonDetailsModel: widget.getSaloonDetailsModel,);
        return PackageOfferList();
      case 'Price':
        return AddOns();
    }
    return Container();
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right, double bottom){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right, bottom: bottom),
      child: Text(value,textAlign: TextAlign.center, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
}