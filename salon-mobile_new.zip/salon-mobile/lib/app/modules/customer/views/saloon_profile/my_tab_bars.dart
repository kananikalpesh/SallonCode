
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/photos.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/reviews.dart';
// import 'package:saloon_app/Model/saloons/get_saloon_details.dart';
import 'package:saloon_app/app/utils/colors.dart';

// import 'package:saloon_app/screens/customer/aboutSaloon/About.dart';
// import 'package:saloon_app/screens/customer/aboutSaloon/Reviews.dart';
// import 'package:saloon_app/screens/customer/aboutSaloon/Services.dart';
// import 'package:saloon_app/screens/customer/aboutSaloon/list_product_categories.dart';
// import 'package:saloon_app/screens/customer/aboutSaloon/show_products.dart';
// import 'package:saloon_app/screens/customer/aboutSaloon/test_products.dart';
// import 'package:saloon_app/styles/colors.dart';

import 'about.dart';
import 'services_tab.dart';

class MyTabBars extends StatefulWidget {
  // GetSaloonDetailsModel getSaloonDetailsModel;
  // MyTabBars({required this.getSaloonDetailsModel});
  @override
  _DemoState createState() => _DemoState();
}

class _DemoState extends State<MyTabBars>
    with TickerProviderStateMixin {
  TabController? _tabController;

  int _myTabIndex=0;
  @override
  void initState() {
// TODO: implement initState
    super.initState();
    _tabController = new TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController?.dispose();
    super.dispose();
  }

  void _setTabIndex(int index){
    setState(() {
      _myTabIndex=index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Container(
          height: 55,
          color: ColorsX.lightStackColor,
          child: TabBar(
            onTap: (index){
              _setTabIndex(index);
            },
            tabs: [
              Container(
                  width: 70.0,
                  child: Text("Info",textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),)
              ),
              Container(
                  width: 75.0,
                  child: Text("Services",textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),)
              ),
              Container(
                  width: 75.0,
                  child: Text("Reviews",textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),)
              ),
              Container(
                  width: 75.0,
                  child: Text("Photos", textAlign: TextAlign.center,style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),)
              )
            ],
            unselectedLabelColor: const Color(0xff000000),
            indicatorColor: Color(0xff70b4ff),
            labelColor: Color(0xff70b4ff),
            indicatorSize: TabBarIndicatorSize.tab,
            indicatorWeight: 3.0,
            indicatorPadding: EdgeInsets.all(15),
            isScrollable: false,
            controller: _tabController,
          ),
        ),
        Container(
          child: IndexedStack(
            // controller: _tabController,
              index: _myTabIndex,
              children: <Widget>[
                Container(
                  // child: _myTabIndex==0?About(getSaloonDetailsModel: widget.getSaloonDetailsModel,):Container(),
                  child: _myTabIndex==0?About():Container(),
                ),
                Container(
                  // child: _myTabIndex==1?ServicesTab(getSaloonDetailsModel: widget.getSaloonDetailsModel,):Container(),
                  child: _myTabIndex==1?ServicesTab():Container(),
                ),
                Container(
                  child: _myTabIndex==2?Reviews():Container(),
                ),
                Container(
                  // child: _myTabIndex==3?TestProducts(value: 'All', getSaloonDetailsModel: widget.getSaloonDetailsModel,):Container(),
                  child: _myTabIndex==3?Photos():Container(),
                ),
              ]),
        ),
      ],
    );
  }
}
Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
  return Container(
    margin: EdgeInsets.only(top: top, left: left, right: right),
    child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
  );
}