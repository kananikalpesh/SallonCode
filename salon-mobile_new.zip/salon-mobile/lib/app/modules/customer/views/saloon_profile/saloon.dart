
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animated_dialog/flutter_animated_dialog.dart'as animatedDialog;
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/resuseable/loading-state.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'middle_container.dart';
import 'my_tab_bars.dart';
import 'topstack.dart';

class Saloon extends GetView<SaloonController>{
  // GetSaloonDetailsModel? getSaloonDetailsModel;To
  // Saloon({this.getSaloonDetailsModel});
//   @override
//   _SaloonState createState() => _SaloonState();
// }
//
// class _SaloonState extends State<Saloon> {

  bool loadingdone = false;
  // GetSaloonDetailsModel _getSaloonDetailsModel = GetSaloonDetailsModel();
  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   // WidgetsBinding.instance!.addPostFrameCallback((timeStamp) { getSaloonDetailsNow();});
  // }
  @override
  Widget build(BuildContext context) {
    return Obx(() => controller.isDataLoaded.isTrue
        ? saloonDetails(context)
        : LoadingState());

  }
  Widget saloonDetails(BuildContext context){
    return Scaffold(
      body: SizedBox(
        height: SizeConfig.screenHeight,
        child: SingleChildScrollView(
          child:Column(
            children: <Widget>[
              Stack(
                children: <Widget>[
                   TopStack(),
                  Container(
                    margin: EdgeInsets.only(top: SizeConfig.thirtySixPercentHeight),
                    child:
                    // _getSaloonDetailsModel.staff!=null?
                    // MiddleContainer(getSaloonDetailsModel: _getSaloonDetailsModel,),
                    MiddleContainer(),
                    // :Container(),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    margin: EdgeInsets.only(top: SizeConfig.screenHeight*.32, left: 20),
                    child: ClipRRect(
                      borderRadius: new BorderRadius.circular(50.0),
                      child: CachedNetworkImage(
                        imageUrl: AppUrls.BASE_URL_IMAGE+'${controller.getSaloonDetailsModel?.saloon?.profilePic}',
                        errorWidget: (context, url, error) => Icon(Icons.error),
                        fit: BoxFit.fill,width: 100, height: 100,

                        placeholder: (context, url) => Container(
                            height: 30,
                            width: 30,
                            child: Center(child: CircularProgressIndicator())),
                      ),
                      // Image.asset("assets/images/mike.png", height: 100, width: 100,fit: BoxFit.contain,),
                    ),
                  ),
                ],
              ),
             MyTabBars()
              // :Container(),
            ],
          ),
        ),
      ),
    );
  }
  void showPopUp(BuildContext context,String title, String content,String ok, bool status){
    animatedDialog.showAnimatedDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return animatedDialog.ClassicGeneralDialogWidget(
          titleText: title,
          contentText: content,
          positiveText: ok,
          onPositiveClick: () {
            if (status==false) {
              Navigator.of(context).pop();
            }
            else {

                 }
          },
        );
      },
      animationType: animatedDialog.DialogTransitionType.fade,
      curve: Curves.fastOutSlowIn,
      duration: Duration(seconds: 1),
    );
  }
}