import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class Photos extends GetView<SaloonController> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Center(
          child: Wrap( // We changed from Row to Wrap// we need to specify the direction
            runSpacing: 5.0,
            spacing: 5.0,

            children: List.generate(controller.getSaloonDetailsModel?.saloon?.photos.length??0, (i) {
              return InkWell(
                onTap: (){
                  // controller.categories[i].isSelected.value = !controller.categories[i].isSelected.value;
                  // if(controller.categories[i].isSelected.value){
                  //   if(!controller.selectedCategoryList.contains(controller.categories[i].id)){
                  //     controller.selectedCategoryList.add(controller.categories[i].id);
                  //   }
                  // }else{
                  //   if(controller.selectedCategoryList.contains(controller.categories[i].id)){
                  //     controller.selectedCategoryList.remove(controller.categories[i].id);
                  //   }
                  // }
                  Functions.showZoomImage(imageName: controller.getSaloonDetailsModel?.saloon?.photos[i]);
                  print(controller.getSaloonDetailsModel?.saloon?.photos[i]);
                },
                child: images("${controller.getSaloonDetailsModel?.saloon?.photos[i]}"),
                // Padding(
                //   padding: const EdgeInsets.all(8.0),
                //   child: Chip(
                //     backgroundColor: controller.categories[i].isSelected.isTrue?ColorsX.blue_button_color:ColorsX.greytext,
                //     label: Text("${controller.categories[i].title}"),
                //   ),
                // ),
              );
            }),
          ),
        ),
        // for(int index=0; index<(controller.getSaloonDetailsModel?.saloon?.photos.length??0); index++)
        //   getPhotos((controller.getSaloonDetailsModel?.saloon?.photos[index]), controller.getSaloonDetailsModel!.saloon?.photos[index])
        // getPhotos(AppImages.PIC_ONE, AppImages.PIC_TWO),
        // getPhotos(AppImages.PIC_TWO, AppImages.PIC_THREE),
        // getPhotos(AppImages.PIC_ONE, AppImages.PIC_TWO),
        // getPhotos(AppImages.PIC_TWO, AppImages.PIC_THREE),
      ],
    );
  }
}

Widget images(String url){
  return
    Container(

      margin: EdgeInsets.only(top: 10, bottom: 5),
      width: SizeConfig.blockSizeHorizontal * 40,
      height: SizeConfig.blockSizeVertical * 23,
      child: ClipRRect(
        borderRadius: new BorderRadius.circular(20.0),
        child: CachedNetworkImage(
          imageUrl: AppUrls.BASE_URL_IMAGE+'${url}',
          errorWidget: (context, url, error) => Icon(Icons.error),
          fit: BoxFit.fill, height: 120,

          placeholder: (context, url) => Container(
              height: 30,
              width: 30,
              child: Center(child: CircularProgressIndicator())),
        ),
        // Image.asset("assets/images/mike.png", height: 100, width: 100,fit: BoxFit.contain,),
      ),
    );
}

Widget getPhotos(String pic_one, String pic_two) {
  return Container(
    margin: EdgeInsets.only(top: 10, bottom: 5),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[

        Container(
          width: SizeConfig.blockSizeHorizontal * 40,
          height: SizeConfig.blockSizeVertical * 23,
          child: ClipRRect(
            borderRadius: new BorderRadius.circular(20.0),
            child: CachedNetworkImage(
              imageUrl: AppUrls.BASE_URL_IMAGE+'${pic_one}',
              errorWidget: (context, url, error) => Icon(Icons.error),
              fit: BoxFit.fill, height: 120,

              placeholder: (context, url) => Container(
                  height: 30,
                  width: 30,
                  child: Center(child: CircularProgressIndicator())),
            ),
            // Image.asset("assets/images/mike.png", height: 100, width: 100,fit: BoxFit.contain,),
          ),
        ),
        SizedBox(
          width: SizeConfig.blockSizeHorizontal * 4,
        ),
        Container(
          width: SizeConfig.blockSizeHorizontal * 40,
          height: SizeConfig.blockSizeVertical * 23,
          child: ClipRRect(
            borderRadius: new BorderRadius.circular(20.0),
            child: CachedNetworkImage(
              imageUrl: AppUrls.BASE_URL_IMAGE+'${pic_two}',
              errorWidget: (context, url, error) => Icon(Icons.error),
              fit: BoxFit.fill, height: 120,

              placeholder: (context, url) => Container(
                  height: 30,
                  width: 30,
                  child: Center(child: CircularProgressIndicator())),
            ),
            // Image.asset("assets/images/mike.png", height: 100, width: 100,fit: BoxFit.contain,),
          ),
        ),
      ],
    ),
  );
}
