// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/views/header_welcome.dart';
import 'package:saloon_app/app/modules/customer/views/home/search_screen_w_text.dart';
import 'package:saloon_app/app/modules/customer/views/location_screen.dart';
import 'package:saloon_app/app/modules/customer/views/search_screen.dart';

class HomeNavigation {
  HomeNavigation._();
  static const id = 2;
  static const homeScreen = '/home-screen';
  static const searchScreen = '/search-screen';
  static const locationScreen = '/location-screen';
  static const searchScreenWithText = '/location-screen-w-text';
  static const dialogTwo = '/dialog-two';
}

// our wrapper, where our main navigation will navigate to
class HomeWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: Get.nestedKey(HomeNavigation.id),
      onGenerateRoute: (settings) {
        // print("Route Generated");
        // navigate to a route by name with settings.name
        if (settings.name == HomeNavigation.searchScreen) {
          return GetPageRoute(
            routeName: HomeNavigation.searchScreen,
            page: () => SearchScreen(),
          );
        } else if (settings.name == HomeNavigation.locationScreen) {
          return GetPageRoute(
            routeName: HomeNavigation.locationScreen,
            page: () => LocationScreen(),
          );
        } 
        else if (settings.name == HomeNavigation.searchScreenWithText) {
          return GetPageRoute(
            routeName: HomeNavigation.searchScreenWithText,
            page: () => SearchScreenWText(),
          );
        } 
        else {
          return GetPageRoute(
            routeName: HomeNavigation.homeScreen,
            page: () => HeaderWelcome(),
            // routeName: HomeNavigation.locationScreen,
            // page: () => LocationScreen(

            // ),
          );
        }
      },
    );
  }
}
