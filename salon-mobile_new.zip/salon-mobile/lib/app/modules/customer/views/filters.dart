import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:group_radio_button/group_radio_button.dart';
import 'package:saloon_app/app/modules/customer/controllers/custome_home_controller.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/modules/customer/controllers/filter_ctl.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'home/home_wrapper.dart';

class Filters extends GetView<FilterCTL> {
  String? globalValue;
  List<String> _sortByStatus = ["Most Popular", "Cost Low to High", "Cost High to Low"];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Stack(
          children: <Widget>[
            Container(
              height: 100,
              width: SizeConfig.screenWidth,
              color: ColorsX.lightStackColor,
            ),
            Container(
              margin: EdgeInsets.only(top: SizeConfig.screenHeight * .08),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(
                    width: 20,
                  ),
                  InkWell(
                    onTap: (){
                      Get.back();
                    },
                    child: _rowItemForHeaderText(
                        "Cancel", 16, FontWeight.w400, 0xff707070, 0),
                  ),
                  Expanded(child: SizedBox()),
                  _rowItemForHeaderText(
                      "Filters", 20, FontWeight.w900, 0xff6EC8FD, 0),
                  Expanded(child: SizedBox()),
                  InkWell(
                    onTap: (){

                      DashboardItemController dCTL=Get.find();
                      CustomerHomeController hCTL=Get.find();

                      var params={
                        "Rating": "${controller.rating.value}",
                        "Category":controller.selectedCategoryList,
                        "Coordinates": [
                         hCTL.userLog ,
                         hCTL.userLat
                        ],
                        "Distance":controller.distance.value
                      };

                      print(params);

                      dCTL.filteredSaloon(apiParams:params);

                      Get.back();
                      Get.toNamed(HomeNavigation.searchScreenWithText, id: 2);



                    },
                    child: _rowItemForHeaderText(
                        "Done", 16, FontWeight.w400, 0xff707070, 0),
                  ),
                  SizedBox(
                    width: 20,
                  ),
                ],
              ),
            ),
           Obx(()=>Container(
             margin: EdgeInsets.only(top: 100, left: 20, right: 20),
             child: Column(
               mainAxisAlignment: MainAxisAlignment.start,
               crossAxisAlignment: CrossAxisAlignment.start,
               children: <Widget>[
                 _rowItemForHeaderText(
                     "Categories", 16, FontWeight.w600, 0xff000000, 15),
                 Wrap( // We changed from Row to Wrap// we need to specify the direction
                   children: List.generate(controller.categories.length, (i) {
                     return InkWell(
                       onTap: (){
                         controller.categories[i].isSelected.value = !controller.categories[i].isSelected.value;
                         if(controller.categories[i].isSelected.value){
                           if(!controller.selectedCategoryList.contains(controller.categories[i].id)){
                             controller.selectedCategoryList.add(controller.categories[i].id);
                           }
                         }else{
                           if(controller.selectedCategoryList.contains(controller.categories[i].id)){
                             controller.selectedCategoryList.remove(controller.categories[i].id);
                           }
                         }
                       print(controller.selectedCategoryList);
                       },
                       child: Padding(
                         padding: const EdgeInsets.all(8.0),
                         child: Chip(
                           backgroundColor: controller.categories[i].isSelected.isTrue?ColorsX.blue_button_color:ColorsX.greytext,
                           label: Text("${controller.categories[i].title}"),
                         ),
                       ),
                     );
                   }),
                 ),
                 _rowItemForHeaderText(
                     "Rating", 16, FontWeight.w600, 0xff000000, 15),
                 _rating("${controller.rating.value}",),
                 Container(
                   // margin: EdgeInsets.only(
                   //     left: SizeConfig.seventyFivePercentWidth),
                   child: Row(
                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                     children: [
                       _rowItemForHeaderText(
                           "Distance", 16, FontWeight.w600, 0xff000000, 15),
                       _rowItemForHeaderText(
                           "${controller.distanceRangeValues.value.end.round().toString()}.0km", 16, FontWeight.w400, 0xff39D2D2, 10),
                     ],
                   ),
                 ),
                 RangeSlider(
                   values: controller.distanceRangeValues.value,
                   min: 1,
                   max: 10,
                   divisions: 10,
                   labels: RangeLabels(
                     controller.distanceRangeValues.value.start.round().toString(),
                     controller.distanceRangeValues.value.end.round().toString(),
                   ),
                   onChanged: (RangeValues values) {
                     controller.distanceRangeValues.value=values;
                     // setState(() {
                     //   _currentRangeValues = values;
                     // });
                   },
                 ),

                 //ProgressBar(context),
                 _rowItemForHeaderText(
                     "Sort By", 16, FontWeight.w600, 0xff000000, 15),
                 RadioGroup<String>.builder(
                   groupValue: controller.sortByGroupValue.value,
                   onChanged: (value) {
                     controller.sortByGroupValue.value = value!;
                   },
                   items: _sortByStatus,
                   itemBuilder: (item) => RadioButtonBuilder(
                     item,
                     textPosition: RadioButtonTextPosition.right,
                   ),
                 ),
                 _rowItemForHeaderText(
                     "Price", 16, FontWeight.w600, 0xff000000, 15),

                 Container(
                   // margin: EdgeInsets.only(
                   //     left: SizeConfig.seventyFivePercentWidth),
                   child: Row(
                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                     children: [
                       _rowItemForHeaderText(
                           "1.0 k", 16, FontWeight.w400, 0xff39D2D2, 10),
                       _rowItemForHeaderText(
                           "50 k", 16, FontWeight.w400, 0xff39D2D2, 10),
                     ],
                   ),
                 ),
                 RangeSlider(
                   values: controller.priceRangeValues.value,
                   min: 1,
                   max: 50,
                   divisions: 10,
                   labels: RangeLabels(
                     controller.priceRangeValues.value.start.round().toString(),
                     controller.priceRangeValues.value.end.round().toString(),
                   ),
                   onChanged: (RangeValues values) {
                     controller.priceRangeValues.value=values;
                     // setState(() {
                     //   _currentRangeValues = values;
                     // });
                   },
                 ),

               ],
             ),
           )) ,
          ],
        ),
      ),
    );
  }

  Widget _rating(String ratingValue,) {
    return Container(
      margin: EdgeInsets.only(top: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            height: 26,
            child: RatingBar.builder(
              initialRating: controller.rating.value,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemSize: 20,
              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                print(rating);
                controller.rating.value=rating;
              },
            ),
          ),
          SizedBox(
            width: 10,
          ),
          _rowItemForHeaderText(
              ratingValue, 26, FontWeight.w400, 0xff707070, 0),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
    String value,
    double fontSize,
    FontWeight fontWeight,
    int colorCode,
    double top,
  ) {
    return Container(
      margin: EdgeInsets.only(top: top),
      child: Text(
        value,
        style: TextStyle(
            color: value == "Male" ? Color(0xff70b4ff) : Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

}
