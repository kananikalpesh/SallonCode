import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/transaction-ctl.dart';
import 'package:saloon_app/app/modules/customer/controllers/appointment_ctl.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';

import '../controllers/custome_home_controller.dart';

class AppointmentBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AppointmentCTL>(
      () => AppointmentCTL(),
    );
    Get.lazyPut<TransactionCTL>(
      () => TransactionCTL(),
    );
  }
}
