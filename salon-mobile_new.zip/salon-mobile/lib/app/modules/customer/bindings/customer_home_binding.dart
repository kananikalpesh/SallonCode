import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/modules/customer/controllers/user-profile-ctl.dart';

class CustomerHomeBinding extends Bindings {
  @override
  void dependencies() {
    // Get.lazyPut<CustomerHomeController>(
    //   () => CustomerHomeController(),
    // );
    Get.put<DashboardItemController>(
      DashboardItemController(),
    );
    Get.put<UserProfileCtl>(
      UserProfileCtl(),
    );
  }
}
