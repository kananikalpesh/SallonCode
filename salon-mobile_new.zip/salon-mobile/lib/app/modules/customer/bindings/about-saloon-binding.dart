import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';

class AboutSaloonBinding extends Bindings {
  @override
  void dependencies() {
    // Get.lazyPut<CustomerHomeController>(
    //       () => CustomerHomeController(),
    // );
    Get.put<SaloonController>(
      SaloonController(),
    );
  }
}
