import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:geocode/geocode.dart';

import 'package:get/get.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app/modules/customer/controllers/custome_home_controller.dart';
import 'app/routes/app_pages.dart';
import 'app/utils/common_functions.dart';
import 'app/utils/user-preferences.dart';
import 'package:location/location.dart';

SharedPreferences? sharedPreferences;
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Functions.initializeLoader();
  // await UserPreferences().init();
  sharedPreferences = await SharedPreferences.getInstance();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  // SharedPreferences sharedPreferences;
  @override
  Widget build(BuildContext context) {
    Get.put<CustomerHomeController>(CustomerHomeController(),);

    // SystemChrome.setPreferredOrientations([
    //   DeviceOrientation.portraitUp,
    // ]);
    _getCurrentLocation();

    return  GetMaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Flutter Demo',
          theme: ThemeData(
              primarySwatch: Colors.blue,
              fontFamily: 'Sofia',
              hintColor: Colors.white),
          initialRoute: AppPages.INITIAL,
          getPages: AppPages.routes,
          builder: EasyLoading.init(),
        );
  }


  Future _getCurrentLocation()async{
    print('Getting User Location.........');
    Location location = new Location();
    CustomerHomeController customerHomeController = Get.find();
    GeoCode geoCode = GeoCode(apiKey: AppStrings.GOOGLE_MAP_KEY);
    bool _serviceEnabled;
    PermissionStatus _permissionGranted;
    LocationData _locationData;
    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }
    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }
    _locationData = await location.getLocation();
    if(_locationData != null) {
      customerHomeController.userLat = _locationData.latitude!;
      customerHomeController.userLog = _locationData.longitude!;
      customerHomeController.setUserLocation(
          _locationData.latitude!, _locationData.longitude!);
      try {
        Address address = await geoCode.reverseGeocoding(
            latitude: customerHomeController.userLat,
            longitude: customerHomeController.userLog);
        customerHomeController.userAddress = address.city!;
        print("Latitude: ${address.region}");
        print("Longitude: ${address.city}");
        print("Latitude of user: ${customerHomeController.userLat}");
        print("Longitude of user: ${customerHomeController.userLog}");
        print("city of user: ${address.city}");
        print("customerHomeController.userAddress : ${customerHomeController.userAddress }");
        print("customerHomeController.userAddress state: ${address.streetAddress }");
        AppStrings.streetAddress = "${address.streetAddress}";
        AppStrings.addressCity = "${address.city}";
        AppStrings.addressRegion = "${address.region}";
      } catch (e) {
        print(e);
      }
    }else{
      _getCurrentLocation();
    }
  }
}
