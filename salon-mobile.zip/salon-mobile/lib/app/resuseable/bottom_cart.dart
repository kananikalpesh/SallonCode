import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';

class BottomCart extends GetView<SaloonController> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      decoration: BoxDecoration(
        color: ColorsX.cart_background,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(
                  "${controller.getSaloonDetailsModel?.saloon?.name}",
                  14,
                  FontWeight.w700,
                  0xff000000,
                  10,
                  10,
                  0),
              Obx(() => Container(
                  margin: EdgeInsets.only(bottom: 2),
                  child: _rowItemForHeaderText(
                      "${controller.serviceCount} Selected Service",
                      14,
                      FontWeight.w700,
                      0xff70bdff,
                      5,
                      10,
                      0))),
              Obx(() => controller.addOnCount == 0
                  ? Container()
                  : Container(
                      // margin: EdgeInsets.only(bottom: 10),
                      child: _rowItemForHeaderText(
                          "${controller.addOnCount} Add Ons",
                          14,
                          FontWeight.w700,
                          0xff70bdff,
                          2,
                          10,
                          0))),
            ],
          ),
          Expanded(child: Container()),
          Obx(
            () => InkWell(
              onTap: () {
                if (controller.getSaloonDetailsModel?.staff?.isEmpty ?? true) {
                  Functions.showSimpleDialog(
                      title: "Saloon Staff",
                      msg: 'Currently no specialist available.');
                } else {
                  Get.toNamed(Routes.BOOKING_DETAIL_FIRST);
                }
              },
              child: Container(
                margin: EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  color: ColorsX.blue_button_color,
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                ),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                  child: _rowItemForHeaderText(
                      controller.buttonValue.value == "Book Now"
                          ? "Book Now"
                          : controller.buttonValue.value,
                      12,
                      FontWeight.w700,
                      0xffffffff,
                      0,
                      0,
                      0),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }
}
