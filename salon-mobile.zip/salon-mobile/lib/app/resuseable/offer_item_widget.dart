import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class OfferItemWidget extends StatelessWidget {
  String? image,
      dealID,
      dealName,
      serviceName,
      originalPrice,
      discountedPrice,
      discount,
      validDate,
      index,
      status;

  OfferItemWidget(
      {required this.image,
      required this.dealName,
      required this.dealID,
      required this.status,
      required this.discount,
      required this.discountedPrice,
      required this.originalPrice,
      required this.serviceName,
      required this.index,
      required this.validDate});

  @override
  Widget build(BuildContext context) {
    return _PopularItemView();
  }

  Widget _PopularItemView() {
    return GestureDetector(
      onTap: () {
        //SALOON_ID = saloonId!;
        // Navigator.pushNamed(context, '/aboutSaloon');

        // Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomSheetReusable(value: "aboutSaloon")));
      },
      child: Container(
        margin: EdgeInsets.only(top: 15, right: 20),
        height: SizeConfig.screenHeight * .29,
        width: SizeConfig.eightyPercentWidth,
        child: Stack(
          children: <Widget>[
            InkWell(
              onTap: (){
                print(index);
                Functions.showDealDetail(index: int.parse("${index}"));
              },
              child: Align(
                alignment: Alignment.topCenter,
                child: Container(
                  height: SizeConfig.screenHeight * .30,

                  // width: ,
                  child: ClipRRect(
                      borderRadius: new BorderRadius.circular(10.0),
                      child: Image.asset(
                        image!,
                        fit: BoxFit.cover,
                        width: SizeConfig.screenWidth,
                        height: 160.0,
                      )),
                ),
                // child: Image.asset(imageOne, fit: BoxFit.contain,),),
              ),
            ),

            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.blockSizeHorizontal * 5,
                  vertical: SizeConfig.blockSizeVertical * 2),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _rowItemText("Deal", 12, FontWeight.bold, ColorsX.white),
                        verticalSpace(SizeConfig.blockSizeVertical * 0.25),
                        _rowItemText(dealID, 12, FontWeight.bold, ColorsX.white),
                        verticalSpace(SizeConfig.blockSizeVertical * 5),
                        _rowItemText(
                            dealName, 16, FontWeight.normal, ColorsX.white),
                        verticalSpace(SizeConfig.blockSizeVertical * 1),
                        _rowItemText(
                            serviceName, 16, FontWeight.bold, ColorsX.white),
                        verticalSpace(SizeConfig.blockSizeVertical * 2),
                        originalPrice == "0"
                            ? _rowItemText(
                                "Price", 16, FontWeight.normal, ColorsX.white)
                            : Container(),
                        verticalSpace(SizeConfig.blockSizeVertical * 1),
                        Row(
                          children: [
                            originalPrice == "0"
                                ? _rowItemText("$discountedPrice\$", 16,
                                    FontWeight.bold, ColorsX.white)
                                : Container(),
                            horizontalSpace(SizeConfig.blockSizeVertical * 2),
                            originalPrice == "0"
                                ? _rowItemLineThroughText("$originalPrice\$", 16,
                                    FontWeight.bold, ColorsX.red_dashboard)
                                : Container(),
                          ],
                        )
                      ],
                    ),
                  ),
                  Spacer(),
                  SizedBox(width: 5,),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _rowItemText("$discount%", 28, FontWeight.bold,
                          ColorsX.light_orange_text),
                      _rowItemText("OFF", 28, FontWeight.bold,
                          ColorsX.light_orange_text),
                      verticalSpace(SizeConfig.blockSizeVertical * 3),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.blockSizeHorizontal * 4,
                            vertical: SizeConfig.blockSizeVertical * 0.5),
                        decoration: BoxDecoration(
                            color: ColorsX.active_green,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                        child: _rowItemText(
                            status, 13, FontWeight.bold, ColorsX.white),
                      ),
                      verticalSpace(SizeConfig.blockSizeVertical * 2),
                      _rowItemText(
                          "Valid only", 16, FontWeight.normal, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 1),
                      _rowItemText(
                          validDate, 16, FontWeight.normal, ColorsX.white),
                    ],
                  )
                ],
              ),
            ),
            // _containerStyling("4.0",4.0,14, FontWeight.w400),
          ],
        ),
      ),
    );
  }

  Widget _rowItemText(
      String? text1, double fontSize, FontWeight fontWeight, Color color) {

    if(text1?.contains('[')??false){
      final removedBrackets = text1!.substring(1, text1.length-1);
      print(removedBrackets);
      text1=removedBrackets;
    }

    return Text(
      '$text1',
      style:
          TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize,
            // overflow: TextOverflow.ellipsis,
          ),
      maxLines: 2,
    );
  }

  Widget _rowItemLineThroughText(
      String? text1, double fontSize, FontWeight fontWeight, Color color) {
    return Text(
      '${text1}',
      style: TextStyle(
          color: color,
          fontWeight: fontWeight,
          fontSize: fontSize,
          decoration: TextDecoration.lineThrough),
    );
  }
}
