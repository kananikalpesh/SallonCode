import 'package:flutter/cupertino.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class LoadingState extends StatefulWidget {
  const LoadingState({Key? key}) : super(key: key);

  @override
  State<LoadingState> createState() => _LoadingStateState();
}

class _LoadingStateState extends State<LoadingState> {

  @override
  Widget build(BuildContext context) {
    return Container(width: SizeConfig.screenWidth,height: SizeConfig.screenHeight,);
  }

}
