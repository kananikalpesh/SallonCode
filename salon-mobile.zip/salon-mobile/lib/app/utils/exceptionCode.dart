class ExceptionCode {
  static const timeOut = 100;
  static const noInternet = 101;
  static const error = 102;
  static const exception = 103;
  static const success = 200;
  static const timeOut20 = 40;
  static const timeOut30 = 50;
  static const timeOut70 = 70;
}
