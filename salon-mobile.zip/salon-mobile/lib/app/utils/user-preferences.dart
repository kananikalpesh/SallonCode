import 'package:shared_preferences/shared_preferences.dart';
import 'app-strings.dart';

class UserPreferences {
  static final UserPreferences  _instance = UserPreferences._ctor();

  factory UserPreferences() {
    return _instance;
  }

  UserPreferences._ctor();

  late SharedPreferences _prefs;

  init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  String get userToken {
    return _prefs.getString("${AppStrings.tokenOfCurrentUser}") ?? '';
  }

  set userToken(String? value) {
    _prefs.setString("${AppStrings.tokenOfCurrentUser}", '${value}');
  }
  String get userName {
    return _prefs.getString(AppStrings.userName) ?? '';
  }

  set userName(String? value) {
    _prefs.setString(AppStrings.userName, '${value}');
  }
  String get userMobileNumber {
    return _prefs.getString(AppStrings.mobileNumber) ?? '';
  }

  set userMobileNumber(String? value) {
    _prefs.setString(AppStrings.mobileNumber, '${value}');
  }
  String get userID {
    return _prefs.getString(AppStrings.userId) ?? '';
  }

  set userID(String? value) {
    _prefs.setString(AppStrings.userId, '${value}');
  }
  String get emailId {
    return _prefs.getString(AppStrings.userEmail) ?? '';
  }

  set emailId(String? value) {
    _prefs.setString(AppStrings.userEmail, '${value}');
  }
}
