class GV {
  static bool isFromFavorite = false;
  static const pageSize = 10;

  static List<String> daysList = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];
}
