
import 'package:flutter/cupertino.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:saloon_app/app/data/model/admin/add-service-response.dart';
import 'package:saloon_app/app/data/model/admin/admin-get-categorized-services-res.dart';
import 'package:saloon_app/app/data/model/admin/deals/admin-deals-response.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/filter_category_res.dart';
import 'package:saloon_app/app/data/services/admin/adminHomeApi.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class AdminDealsCTL extends GetxController {
  final adminHomeApi = AdminHomeApi();
  FilterCategoryRes? filterCategoryRes;
  ErrorResponse? errorResponse;
  GetCategorizedServicesRes? getCategorizedServicesRes;
  AddServiceRes? addServiceRes;
  AdminAddDealRes? adminAddDealRes;
  RxBool isDataLoaded = false.obs;
  RxBool isServiceAdded = false.obs;
  RxBool isDealAdded = false.obs;
  RxBool isAllServiceLoaded = false.obs;
  List<String> TimeLimitList = ['20', '30', '40','50','60'];
  List<String> CatagoryList = ['One Time', 'Cancellation Offer', 'Bundle Offer'];
  List<String> discount = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20',
    '21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39', '40',
    '41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60',
    '61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79', '80',
    '81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99',];
  // List<String> discount = ['10','20', '30','40', '50','60', '70','80', '90','100'];
  List<String> currencies = ['USD',];
  List<String> catagoryList = [];
  RxString chosenCatrgory = "".obs;
  RxString chosenCatrgoryID = "".obs;
  RxString chosenDuration = "".obs;
  RxString chosenPrefix = "".obs;
  RxString chosenDiscount = "".obs;

  TextEditingController dealNameController = TextEditingController();
  TextEditingController dealCodeController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController priceController = TextEditingController();
  TextEditingController minimumPriceController = TextEditingController();

  RxString chosenDateTimeFromSetAppointmentWithDashes="".obs;
  RxString chosenDateTimeForEndDateWithDashes="".obs;

  final count = 0.obs;

  @override
  void onInit() {
    chosenCatrgory.value = "${CatagoryList[0]}";
    chosenDiscount.value = discount[0];

    getAdminAllServices();
    getFilterCategories();
    super.onInit();
  }


  Future<bool> getFilterCategories() async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    final res = await adminHomeApi.getFilterCategories();
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is FilterCategoryRes) {
      filterCategoryRes = res;
      int length = filterCategoryRes?.categories.length??0;
      for(int index =0; index<length; index++){
        catagoryList.add("${filterCategoryRes?.categories[index].title}");
      }
      // chosenCatrgory.value = "${filterCategoryRes?.categories[0].title}";
      // chosenCatrgory.value = "${CatagoryList[0]}";
      chosenDuration.value = TimeLimitList[0];
      chosenPrefix.value = currencies[0];
      // chosenDiscount.value = discount[0];
      chosenCatrgoryID.value = "${filterCategoryRes?.categories[0].id}";
      print(catagoryList);
      print(chosenCatrgoryID);
      print('Categories SUCCESS RESPONSE FOUND');
      isDataLoaded.toggle();
      return true;
    }
    else if (res is ErrorResponse) {
      print('Categories ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }


  Future<bool> getAdminAllServices() async {
    Functions.showProgressLoader("Please Wait");

    isAllServiceLoaded = false.obs;
    final res = await adminHomeApi.getAdminAllServices();
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is GetCategorizedServicesRes) {
      getCategorizedServicesRes = res;
      print('adminAllServiceRes');
      isAllServiceLoaded.toggle();
      return true;
    }
    else if (res is ErrorResponse) {
      print('adminAllServiceRes');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<bool> adminAddDeal({required Map<String, dynamic> apiParams}) async {
    Functions.showProgressLoader("Please Wait");
    isDealAdded=false.obs;
    final res = await adminHomeApi.adminAddDeal(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is AdminAddDealRes) {
      adminAddDealRes = res;
      print('addServiceRes RESPONSE FOUND');
      dealNameController.text="";
      dealCodeController.text="";
      descriptionController.text="";
      priceController.text="";
      minimumPriceController.text="";
      isDealAdded.toggle();
      Functions.dealAddedDialog(
        title: "Added",
        msg: "${adminAddDealRes?.msg}",
      );
      return true;
    }
    else if (res is ErrorResponse) {
      return true;
    }  else if (res == ExceptionCode.timeOut) {
      Functions.showErrorDialog(
        title: "Error",
        msg: "Connection Timeout",
          isSuccess:false
      );
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      Functions.showErrorDialog(
        title: "Error",
        msg: AppStrings.noInternet,
          isSuccess:false
      );
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showErrorDialog(
        title: "Error",
        msg: AppStrings.error,
          isSuccess:false
      );
      return false;
    }
    return false;
  }

  // Future<bool> getSpecificStaffDetails() async {
  //   Functions.showProgressLoader("Please Wait");
  //
  //   isDataLoaded = false.obs;
  //   print(MiddleContainer.staffId);
  //   print(getTodaysDate());
  //   Map<String, String> apiParams = {
  //     "date": getTodaysDate(),
  //     "id": MiddleContainer.staffId
  //   };
  //   String date = getTodaysDate();
  //   final res = await homeApi.getSpecificStaffDetails(date: date, id:MiddleContainer.staffId);
  //   print(' CTL RESPONSE${res}');
  //   Functions.hideProgressLoader();
  //   if (res is StaffDetailModel) {
  //     staffDetailModel = res;
  //     // isServiceChecked =
  //     //     List<bool>.generate(res.saloon.services.length, (index) => false).obs;
  //     print('GET STAFF DETAIL RESPONSE FOUND');
  //     isDataLoaded.toggle();
  //     return true;
  //   } else if (res is ErrorResponse) {
  //     print('ADD MEMBER ERROR RESPONSE FOUND');
  //     errorResponse = res;
  //     return false;
  //   } else if (res == ExceptionCode.timeOut) {
  //     print(res);
  //     Functions.showToast(AppStrings.slowInternet);
  //     //slow internet
  //   } else if (res == ExceptionCode.noInternet) {
  //     //no internet
  //     print(res);
  //     Functions.showToast(AppStrings.noInternet);
  //   } else if (res == ExceptionCode.error) {
  //     //server error
  //     print(res);
  //     Functions.showToast(AppStrings.error);
  //   }
  //   return false;
  // }
  // getTodaysDate(){
  //   final DateTime now = DateTime.now();
  //   print("now wali date"+"${now}");
  //   final DateFormat formatter = DateFormat('yyyy-MM-dd');
  //   final String formatted = formatter.format(now);
  //   print(formatted);
  //   return formatted;
  // }
  //
  //
  // Future<bool> getSpecificStaffDetailsForSpecificDates( String date) async {
  //   Functions.showProgressLoader("Please Wait");
  //
  //   isDataLoaded = false.obs;
  //   print(MiddleContainer.staffId);
  //   print(date);
  //   Map<String, String> apiParams = {
  //     "date": date,
  //     "id": (MiddleContainer.staffId)
  //   };
  //   print(apiParams);
  //   // String date = getTodaysDate();
  //   final res = await homeApi.getSpecificStaffDetails(date: date, id:(MiddleContainer.staffId));
  //   print(' CTL RESPONSE${res}');
  //   Functions.hideProgressLoader();
  //   if (res is StaffDetailModel) {
  //     staffDetailModel = res;
  //     // isServiceChecked =
  //     //     List<bool>.generate(res.saloon.services.length, (index) => false).obs;
  //     print('GET STAFF DETAIL RESPONSE FOUND');
  //     isDataLoaded.toggle();
  //     return true;
  //   } else if (res is ErrorResponse) {
  //     print('ADD MEMBER ERROR RESPONSE FOUND');
  //     errorResponse = res;
  //     return false;
  //   } else if (res == ExceptionCode.timeOut) {
  //     print(res);
  //     Functions.showToast(AppStrings.slowInternet);
  //     //slow internet
  //   } else if (res == ExceptionCode.noInternet) {
  //     //no internet
  //     print(res);
  //     Functions.showToast(AppStrings.noInternet);
  //   } else if (res == ExceptionCode.error) {
  //     //server error
  //     print(res);
  //     Functions.showToast(AppStrings.error);
  //   }
  //   return false;
  // }
  //
  //
  //
  // Future<bool> saloonAddBookingViaStaffMember({required Map<String, dynamic> apiParams, required BuildContext context}) async {
  //   Functions.showProgressLoader("Please Wait");
  //
  //   isDataLoaded = false.obs;
  //   final res = await homeApi.saloonAddBookingViaStaff(apiParams: apiParams, context:  context);
  //   print(' CTL RESPONSE${res}');
  //   Functions.hideProgressLoader();
  //   if (res is AddBookingViaStaff) {
  //     addBookingViaStaff = res;
  //     print('ADD MEMBER SUCCESS RESPONSE FOUND');
  //     isDataLoaded.toggle();
  //     return true;
  //   }
  //   else if (res is ErrorResponse) {
  //     print('ADD MEMBER ERROR RESPONSE FOUND');
  //     errorResponse = res;
  //     return false;
  //   } else if (res == ExceptionCode.timeOut) {
  //     print(res);
  //     Functions.showToast(AppStrings.slowInternet);
  //     //slow internet
  //   } else if (res == ExceptionCode.noInternet) {
  //     //no internet
  //     print(res);
  //     Functions.showToast(AppStrings.noInternet);
  //   } else if (res == ExceptionCode.error) {
  //     //server error
  //     print(res);
  //     Functions.showToast(AppStrings.error);
  //   }
  //   return false;
  // }
  //
  //
  //
  //
  //
  // getSumOfServices(){
  //   int sum =0;
  //   for(int index =0; index< selectedServicesPriceList.length; index++){
  //     print("${selectedServicesPriceList[index]} prices list");
  //     sum = selectedServicesPriceList[index]+sum;
  //     print(sum);
  //   }
  //   return sum.toString();
  // }
  //
  // getSumOfAddOns(){
  //   int sum =0;
  //   for(int index =0; index< selectedAddOnsPriceList.length; index++){
  //     print("${selectedAddOnsPriceList[index]} add ons prices list");
  //     sum = selectedAddOnsPriceList[index]+sum;
  //     print(sum);
  //   }
  //   return sum.toString();
  // }

  // Future<bool> saloonItems({required Map<String, dynamic> apiParams, required BuildContext context}) async {
  //   Functions.showProgressLoader("Please Wait");
  //
  //   isDataLoaded = false.obs;
  //   final res = await authApi.userLogin(apiParams: apiParams);
  //   print(' CTL RESPONSE${res}');
  //   Functions.hideProgressLoader();
  //   if (res is SaloonItemsModel) {
  //     saloonItemsModel = res;
  //     print('ADD MEMBER SUCCESS RESPONSE FOUND');
  //     isDataLoaded.toggle();
  //     return true;
  //   } else if (res is ErrorResponse) {
  //     print('ADD MEMBER ERROR RESPONSE FOUND');
  //     errorResponse = res;
  //     return false;
  //   } else if (res == ExceptionCode.timeOut) {
  //     print(res);
  //     Functions.showToast(AppStrings.slowInternet);
  //     //slow internet
  //   } else if (res == ExceptionCode.noInternet) {
  //     //no internet
  //     print(res);
  //     Functions.showToast(AppStrings.noInternet);
  //   } else if (res == ExceptionCode.error) {
  //     //server error
  //     print(res);
  //     Functions.showToast(AppStrings.error);
  //   }
  //   return false;
  // }
  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

  void increment() => count.value++;

}
