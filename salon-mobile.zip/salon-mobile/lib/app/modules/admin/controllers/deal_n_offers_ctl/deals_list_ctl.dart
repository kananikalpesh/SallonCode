
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/data/model/admin/deals/admin-get-coupons-resp.dart'as allCouponsResp;
import 'package:saloon_app/app/data/model/admin/deals/admin-get-coupons-resp.dart';
import 'package:saloon_app/app/data/model/admin/deals/admin-update-deal.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/services/admin/adminHomeApi.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class DealsListCTL extends GetxController

    with SingleGetTickerProviderMixin {
  //TODO: Implement HomeController

  final adminHomeApi = AdminHomeApi();
  AdminGetCouponsRes? adminGetCouponsRes;
  AdminUpdateDealRes? adminUpdateDealRes;
  ErrorResponse? errorResponse;
  RxBool isDataLoaded = false.obs;
  RxBool isDealAdded = false.obs;
  RxBool isDealDeleted = false.obs;
  RxInt lengthOfData = 0.obs;



  TextEditingController dealNameControllerEdit = TextEditingController();
  TextEditingController dealCodeControllerEdit = TextEditingController();
  TextEditingController descriptionControllerEdit = TextEditingController();
  TextEditingController priceControllerEdit = TextEditingController();
  TextEditingController minimumPriceControllerEdit = TextEditingController();


  List<String> TimeLimitList = ['20', '30', '40','50','60'];
  List<String> CatagoryList = ['One Time', 'Cancellation Offer', 'Bundle Offer'];
  List<String> discount = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20',
    '21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39', '40',
    '41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60',
    '61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79', '80',
    '81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99',];
  List<String> currencies = ['USD',];
  List<String> catagoryList = [];
  String id = "";
  RxString chosenCatrgory = "".obs;
  RxString chosenServiceID = "".obs;
  RxString chosenCatrgoryID = "".obs;
  RxString chosenDuration = "".obs;
  RxString chosenPrefix = "".obs;
  RxString chosenDiscount = "".obs;
  RxString chosenService = "".obs;

  RxString chosenDateTimeFromSetAppointmentWithDashes="".obs;
  RxString chosenDateTimeForEndDateWithDashes="".obs;


  final PagingController<int, allCouponsResp.Datum> pagingController =
  PagingController(firstPageKey: 1);
  static const _pageSize = 10;
  TabController? tabController;
  allCouponsResp.Datum? saloonAllDealsResponse;
  // late int test;

  @override
  void onInit() {
    getSaloonAllDeals(1, 10);
    tabController = TabController(length: 3, vsync: this);
    super.onInit();
  }


  Future<bool> adminEditDeal({required Map<String, dynamic> apiParams}) async {
    Functions.showProgressLoader("Please Wait");
    isDealAdded=false.obs;
    final res = await adminHomeApi.adminUpdatedDeal(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is AdminUpdateDealRes) {
      adminUpdateDealRes = res;
      print('addServiceRes RESPONSE FOUND');
      // dealNameController.text="";
      // dealCodeController.text="";
      // descriptionController.text="";
      // priceController.text="";
      // minimumPriceController.text="";
      isDealAdded.toggle();
      Functions.dealUpdateDialog(
        title: "Updated",
        msg: "${adminUpdateDealRes?.msg}",
      );
      return true;
    }
    else if (res is ErrorResponse) {
      return true;
    }  else if (res == ExceptionCode.timeOut) {
      Functions.showErrorDialog(
          title: "Error",
          msg: "Connection Timeout",
          isSuccess:false
      );
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.noInternet,
          isSuccess:false
      );
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.error,
          isSuccess:false
      );
      return false;
    }
    return false;
  }

  Future<bool> adminDeleteDeal({required Map<String, dynamic> apiParams}) async {
    Functions.showProgressLoader("Please Wait");
    isDealDeleted=false.obs;
    final res = await adminHomeApi.adminDeleteDeal(id: id);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is ErrorResponse) {
      // adminUpdateDealRes = res;
      print('addServiceRes RESPONSE FOUND');
      isDealDeleted.toggle();
      if(res.msg.toString().contains("Coupon Deleted Successfully")){
        Functions.dealUpdateDialog(
          title: "Deleted",
          msg: "${res.msg}",
        );
        return true;
      }
      else{
        Functions.dealUpdateDialog(
          title: "Error",
          msg: "${res.msg}",
        );
        return true;
      }
    }else if (res == ExceptionCode.timeOut) {
      Functions.showErrorDialog(
          title: "Error",
          msg: "Connection Timeout",
          isSuccess:false
      );
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.noInternet,
          isSuccess:false
      );
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.error,
          isSuccess:false
      );
      return false;
    }
    return false;
  }

  Future<void> getSaloonAllDeals(int pageKey, int limit) async {
    try {
      print('Get saloon deals... getSaloonAllDeals');
      isDataLoaded.toggle();
      final newItems = await adminHomeApi.getSaloonAllDeals(
          page: pageKey, Limit: 10);
      print ("${newItems.data.length} length of array");
      lengthOfData.value = newItems.data.length??0;
      print ("${lengthOfData.value} lengthOfData");

      final isLastPage = newItems.data.length < _pageSize;
      if (isLastPage) {
        pagingController.appendLastPage(newItems.data);
      } else {
        final nextPageKey = pageKey + 1;
        pagingController.appendPage(newItems.data, nextPageKey);
      }
    } catch (error) {
      print(error);
      pagingController.error = error;
    }
  }
  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}