import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/admin/add_ons/add_ons_by_category_res.dart'
    as addOns;
import 'package:saloon_app/app/data/services/admin/addOn_api.dart';
import 'package:saloon_app/app/data/services/customer/saloon-home-api.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-services/services-admin-list-and-add-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';
import 'dart:io' as Io;

import 'package:saloon_app/app/utils/gv.dart';
import 'package:saloon_app/app/data/model/customer/filter_category_res.dart'
    as cat;

class AddOnCTL extends GetxController {
  final homeApi = HomeApi();
  final addOnApi = AddOnApi();
  ServicesAdminListAddCTL adminServiceCTL = Get.find();
  AdminLoginController _adminLoginController = Get.find();

  TextEditingController addOnNameCTL = TextEditingController();
  TextEditingController brandNameCTL = TextEditingController();
  TextEditingController addOnDescriptionCTL = TextEditingController();
  TextEditingController addOnPriceCTL = TextEditingController();
  RxString selectedCatName = ''.obs;
  RxString selectedCurrency = 'DKK'.obs;
  RxBool isDataLoaded = false.obs;
  List<XFile>? images = [];
  RxInt addOnImageCount = 0.obs;
  RxInt productCount = 0.obs;
  String searchText='';
  List<cat.Category> categoryTypeList = [];
  addOns.Product? productItem;
  final PagingController<int, addOns.Product> pagingController =
      PagingController(firstPageKey: 1);

  @override
  void onInit() {
    getAddOnsByCategoryRes(1, '', searchText);
    super.onInit();
  }

  List<String> getCategoryNameList() {
    return adminServiceCTL.categoryNameList;
  }

  String getSelectedCategory() {
    return adminServiceCTL.categoryTypeList
        .firstWhere((cat) => cat.title == selectedCatName.value)
        .id;
  }

  Future<void> pickMultipleImages() async {
    final ImagePicker _picker = ImagePicker();
    // Pick multiple images
    images = await _picker.pickMultiImage(
        maxWidth: 400, maxHeight: 400, imageQuality: 70);
    if (images != null) {
      addOnImageCount.value = images!.length;
    }
  }

  Future<bool> addNewAddOn() async {
    List<File> imageFiles = [];
    for (var img in images!) {
      imageFiles.add(Io.File(img.path));
    }

    Map<String, String> apiParams = {
      'Name': addOnNameCTL.text,
      'Description': addOnDescriptionCTL.text,
      'Category': getSelectedCategory(),
      'Saloon': '${_adminLoginController.adminLoginRes?.saloon.id}',
      'Price': addOnPriceCTL.text,
    };
    print(apiParams);
    Functions.showProgressLoader("Please Wait");
    isDataLoaded = false.obs;
    var res;
    res = await addOnApi.addNewAddOn(
      apiParams: apiParams,
      image: imageFiles,
    );
    Functions.hideProgressLoader();
    if (res == ExceptionCode.success) {
      return true;
    } else if (res is ErrorResponse) {
      Functions.showToast(res.msg);
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<void> getAddOnsByCategoryRes(
      int pageKey, String catID, String search) async {
    try {
      final newItems = await addOnApi.getAddOnsByCategoryRes(
          page: pageKey, catID: catID, search: search);
      productCount.value = newItems.count;
      final isLastPage = newItems.products.length < GV.pageSize;
      if (isLastPage) {
        pagingController.appendLastPage(newItems.products);
      } else {
        final nextPageKey = pageKey + 1;
        pagingController.appendPage(newItems.products, nextPageKey);
      }
    } catch (error) {
      print(error);
      pagingController.error = error;
    }
  }

  void populateAddONsDataForEdit() {
    addOnNameCTL.text = '${productItem?.name}';
    brandNameCTL.text = '${productItem?.brandName}';
    addOnDescriptionCTL.text = '${productItem?.description}';
    addOnPriceCTL.text = '${productItem?.price}';
    selectedCatName.value = '${productItem?.category?.title}';
  }

  Future<bool> updateAddOn() async {
    List<File> imageFiles = [];
    for (var img in images!) {
      imageFiles.add(Io.File(img.path));
    }

    Map<String, String> apiParams = {
      'id': '${productItem?.id}',
      'Name': addOnNameCTL.text,
      'Description': addOnDescriptionCTL.text,
      'Category': getSelectedCategory(),
      'Saloon': '${_adminLoginController.adminLoginRes?.saloon.id}',
      'Price': addOnPriceCTL.text,
      'Brand_Name': brandNameCTL.text,
    };
    print(apiParams);
    Functions.showProgressLoader("Please Wait");
    isDataLoaded = false.obs;
    var res;
    res = await addOnApi.updateAddOn(
      apiParams: apiParams,
      image: imageFiles,
    );
    Functions.hideProgressLoader();
    if (res == ExceptionCode.success) {
      return true;
    } else if (res is ErrorResponse) {
      Functions.showToast(res.msg);
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<bool> deleteAddOn() async {
    Functions.showProgressLoader("Please Wait");
    var res;
    res = await addOnApi.deleteAddOn(pId: '${productItem?.id}');
    Functions.hideProgressLoader();
    if (res == ExceptionCode.success) {
      return true;
    } else if (res is ErrorResponse) {
      Functions.showToast(res.msg);
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }
}
