import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/data/model/admin/appointment/saloon_all_booking.dart'
    as appointment;
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/services/admin/saloon_appointment_api.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';
import 'package:saloon_app/app/utils/gv.dart';

class SaloonAppointmentCTL extends GetxController
    with SingleGetTickerProviderMixin {
  SaloonAppointmentApi _saloonAppointmentApi = SaloonAppointmentApi();

  final PagingController<int, appointment.Datum> pagingController =
      PagingController(firstPageKey: 1);
  TabController? tabController;
  appointment.Datum? saloonAppointment;
  bool isFromAdminCalender = false;

  @override
  void onInit() {
    tabController = TabController(vsync: this, length: 4);
    print('Get saloon bookingss...');

    getSaloonAllBookings(1, 'New');
    super.onInit();
  }

  Future<void> getSaloonAllBookings(int pageKey, String status) async {
    try {
      print('Get saloon bookingss... getSaloonAllBookings');

      final newItems = await _saloonAppointmentApi.getSaloonAllBookings(
          page: pageKey, status: status);
      final isLastPage = newItems.data.length < GV.pageSize;
      if (isLastPage) {
        pagingController.appendLastPage(newItems.data);
      } else {
        final nextPageKey = pageKey + 1;
        pagingController.appendPage(newItems.data, nextPageKey);
      }
    } catch (error) {
      print(error);
      pagingController.error = error;
    }
  }

  Future<bool> cancelOrAcceptBooking(
      {required String id, required String status}) async {
    Functions.showProgressLoader("Please Wait");
    final res = await _saloonAppointmentApi.cancelOrAcceptBooking(
        id: id, status: status);
    Functions.hideProgressLoader();
    if (res == ExceptionCode.success) {
      return true;
    } else if (res is ErrorResponse) {
      Functions.showErrorDialog(
          title: "Error", msg: '${res.msg}', isSuccess: false);
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      return false;
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
      return false;
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
      return false;
    }
    return false;
  }
}
