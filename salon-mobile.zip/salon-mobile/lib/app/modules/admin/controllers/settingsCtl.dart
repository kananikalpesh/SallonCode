
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:saloon_app/app/data/model/admin/add-service-response.dart';
import 'package:saloon_app/app/data/model/admin/admin-get-categorized-services-res.dart';
import 'package:saloon_app/app/data/model/admin/admin-update-saloon.dart';
import 'package:saloon_app/app/data/model/admin/deals/admin-deals-response.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/filter_category_res.dart';
import 'package:saloon_app/app/data/services/admin/adminHomeApi.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

import 'admin-services/services-admin-list-and-add-ctl.dart';
import 'deal_n_offers_ctl/admin-deals-ctl.dart';

class AdminSettingsCTL extends GetxController {
  final adminHomeApi = AdminHomeApi();
  ServicesAdminListAddCTL adminServiceCTL = Get.find();
  ErrorResponse? errorResponse;
  AdminUpdateSaloonRes? adminUpdateSaloonRes;
  RxBool isDataLoaded = false.obs;
  RxBool isServiceAdded = false.obs;
  RxBool isSaloonUpdated = false.obs;
  RxBool isAllServiceLoaded = false.obs;
  List<String> TimeLimitList = ['20', '30', '40','50','60'];
  List<String> workingHoursDropDownList = ['All Days',];
  List<String> currencies = ['USD',];
  List<String> catagoryList = [];

  RxString selectedCatName = ''.obs;
  var allCategoriesList = [].obs;
  RxString startTime = 'Open Time'.obs;
  RxString endTime = 'Close Time'.obs;

  TextEditingController companyNameController = TextEditingController();
  TextEditingController businessTypeController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController workingOpenHoursController = TextEditingController();
  TextEditingController workingCloseHoursController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController mobileNumberController = TextEditingController();

  File? pickedImage;
  RxBool isPickSelected=false.obs;

  List<File>? PickedImageCover= List<File>.empty(growable: true);
  // File? PickedImageCover;
  RxBool isPickSelectedCover=false.obs;
  final count = 0.obs;

  @override
  Future<void> onInit() async {
    // AdminDealsCTL adminDealsCTL = Get.find();
    super.onInit();
  }


  String getSelectedCategory() {
    return adminServiceCTL.categoryTypeList
        .firstWhere((cat) => cat.title == selectedCatName.value)
        .id;
  }

  Future<bool> adminUpdateSaloon({required Map<String, String> apiParams}) async {
    Functions.showProgressLoader("Please Wait");
    isSaloonUpdated=false.obs;
    var res;
    var coverRes;
    if(pickedImage==null && PickedImageCover?.length==0){
      print('not found');
      res = await adminHomeApi.adminUpdateSaloon(apiParams: apiParams);
    }
    // if(PickedImageCover!=null){
    //   res = await adminHomeApi.adminUpdateSaloonWithCoverImage(apiParams: apiParams, image: PickedImageCover);
    // }
    else{
      print('image found');
      res = await adminHomeApi.adminUpdateSaloonWithImage(apiParams: apiParams, image: pickedImage);

      if(PickedImageCover?.length!=0){
        print("now here");
        coverRes = await adminHomeApi.adminUpdateSaloonWithCoverImage(apiParams: apiParams, image: PickedImageCover) ;
        print(coverRes);

        if(coverRes is AdminUpdateSaloonRes){
          print(adminUpdateSaloonRes);
        }
      }
      else{

      }
    }
    print(' CTL RESPONSE${res}');
    if (res is AdminUpdateSaloonRes) {
      adminUpdateSaloonRes = res;
      print(adminUpdateSaloonRes);
      // companyNameController.text="";
      // dealCodeController.text="";
      // descriptionController.text="";
      // priceController.text="";
      // minimumPriceController.text="";
      isSaloonUpdated.toggle();

      Functions.hideProgressLoader();
      Functions.showSimpleDialog(
        title: "Updated",
        msg: "${adminUpdateSaloonRes?.msg}",
      );
      return true;
    }
    else if (res is ErrorResponse) {
      return true;
    }  else if (res == ExceptionCode.timeOut) {
      Functions.showErrorDialog(
          title: "Error",
          msg: "Connection Timeout",
          isSuccess:false
      );
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.noInternet,
          isSuccess:false
      );
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.error,
          isSuccess:false
      );
      return false;
    }
    return false;
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

  void increment() => count.value++;

}
