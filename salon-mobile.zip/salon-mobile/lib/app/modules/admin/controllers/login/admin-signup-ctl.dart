import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/services/admin/adminHomeApi.dart';
import 'package:saloon_app/app/data/services/authApi.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class AdminSignUpCTL extends GetxController {
  var adminHomeApi = AdminHomeApi();
  TextEditingController emailController = TextEditingController();
  TextEditingController companyNameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController companyRegistrationNumber = TextEditingController();
  String dob = '';

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }
  Future<bool> adminSignUp({required Map<String, dynamic> apiParams,required BuildContext context}) async {
    Functions.showProgressLoader("Please Wait");

    final res = await adminHomeApi.adminSignUp(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is ErrorResponse) {
      if(res.error){
        Functions.showSimpleDialog(title: "Error", msg: res.msg);
        return false;
      }
      else {
        String number = "${res.msg.toString().split("Message sent for mobile number verification.")[1]}";
        print(number);
        Functions.showErrorDialogForOtpAdmin(title: "Verify Number", msg: "${res.msg.toString().split("Message sent for mobile number verification.")[0]}",
            number: number, context: context);
        return true;
      }
    }  else if (res == ExceptionCode.timeOut) {
      Functions.showErrorDialog(
          title: "Error",
          msg: "Connection Timeout",
          isSuccess:false
      );
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.noInternet,
          isSuccess:false
      );
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.error,
          isSuccess:false

      );
      return false;
    }
    return false;
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
