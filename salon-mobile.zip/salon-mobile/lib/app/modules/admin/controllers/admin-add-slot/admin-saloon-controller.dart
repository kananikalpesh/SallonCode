import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:saloon_app/app/data/model/customer/appointment/add-booking-via-staff.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/get-saloon-details-model.dart';
import 'package:saloon_app/app/data/model/customer/saloon/staff-detail-model.dart';
import 'package:saloon_app/app/data/services/customer/saloon-home-api.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/middle_container.dart';
import 'package:saloon_app/app/resuseable/saloon_row_item.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class AdminSaloonController extends GetxController {
  final homeApi = HomeApi();
  SaloonDetailsModel? getSaloonDetailsModel;
  ErrorResponse? errorResponse;
  StaffDetailModel? staffDetailModel;
  AddBookingViaStaff? addBookingViaStaff;
  RxBool isDataLoaded = false.obs;
  RxBool isDataLoadedForDateChange = false.obs;
  RxBool isSpecificSlotClicked = false.obs;
  late RxList<bool> isServiceChecked;
  late RxList<bool> isAddOnChecked;
  RxInt serviceCount=0.obs;
  RxInt addOnCount=0.obs;
  RxInt sumOfAllServices=0.obs;
  RxInt sumOfAllAddOns=0.obs;
  // RxInt sum =0.obs;
  RxString quantityText="1".obs;
  var selectedServicesList = [].obs;
  var selectedServicesIDSList = [].obs;
  var selectedAddOnsList = [].obs;
  var selectedAddOnsIDSList = [].obs;
  var selectedAddOnsPriceList = [].obs;
  var selectedServicesPriceList = [].obs;
  var selectedProductsNamePriceList = [].obs;
  var selectedProductsQuantityList = [].obs;
  RxString buttonValue = "Book Now".obs;
  RxString selectedSlot = "".obs;
  RxString chosenDateTimeFromSetAppointmentWithDashes="".obs;
  RxString chosenDateTimeForEndDateWithDashes="".obs;

  final count = 0.obs;

  @override
  void onInit() {
    getSpecificSaloonDetails();
    super.onInit();
  }

  Future<bool> getSpecificSaloonDetails() async {
    Functions.showProgressLoader("Please Wait");
    AdminLoginController adminLoginController = Get.find();
    isDataLoaded = false.obs;
    print(adminLoginController.adminLoginRes?.saloon.id);
    final res = await homeApi.getSpecificSaloonDetails("${adminLoginController.adminLoginRes?.saloon.id}");
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is SaloonDetailsModel) {
      getSaloonDetailsModel = res;
      isServiceChecked =
          List<bool>.generate((res.saloon?.services.length??0), (index) => false).obs;
      isAddOnChecked =
          List<bool>.generate((res.products?.length??0), (index) => false).obs;
      print('ADD MEMBER SUCCESS RESPONSE FOUND');
      isDataLoaded.toggle();
      return true;
    } else if (res is ErrorResponse) {
      print('ADD MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }

  Future<bool> getSpecificStaffDetails() async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    print(MiddleContainer.staffId);
    print(getTodaysDate());
    Map<String, String> apiParams = {
      "date": getTodaysDate(),
      "id": MiddleContainer.staffId
    };
    String date = getTodaysDate();
    final res = await homeApi.getSpecificStaffDetails(date: date, id:MiddleContainer.staffId);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is StaffDetailModel) {
      staffDetailModel = res;
      // isServiceChecked =
      //     List<bool>.generate(res.saloon.services.length, (index) => false).obs;
      print('GET STAFF DETAIL RESPONSE FOUND');
      isDataLoaded.toggle();
      return true;
    } else if (res is ErrorResponse) {
      print('ADD MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }
  getTodaysDate(){
    final DateTime now = DateTime.now();
    print("now wali date"+"${now}");
    final DateFormat formatter = DateFormat('yyyy-MM-dd');
    final String formatted = formatter.format(now);
    print(formatted);
    return formatted;
  }


  Future<bool> getSpecificStaffDetailsForSpecificDates( String date) async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    print(MiddleContainer.staffId);
    print(date);
    Map<String, String> apiParams = {
      "date": date,
      "id": (MiddleContainer.staffId)
    };
    print(apiParams);
    // String date = getTodaysDate();
    final res = await homeApi.getSpecificStaffDetails(date: date, id:(MiddleContainer.staffId));
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is StaffDetailModel) {
      staffDetailModel = res;
      // isServiceChecked =
      //     List<bool>.generate(res.saloon.services.length, (index) => false).obs;
      print('GET STAFF DETAIL RESPONSE FOUND');
      isDataLoaded.toggle();
      return true;
    } else if (res is ErrorResponse) {
      print('ADD MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }



  Future<bool> saloonAddBookingViaAdmin({required Map<String, dynamic> apiParams, required BuildContext context}) async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    final res = await homeApi.saloonAddBookingViaAdmin(apiParams: apiParams, context:  context);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is AddBookingViaStaff) {
      addBookingViaStaff = res;
      print('ADD MEMBER SUCCESS RESPONSE FOUND');
      isDataLoaded.toggle();
      return true;
    }
    else if (res is ErrorResponse) {
      print('ADD MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }





  getSumOfServices(){
    int sum =0;
    for(int index =0; index< selectedServicesPriceList.length; index++){
      print("${selectedServicesPriceList[index]} prices list");
      sum = selectedServicesPriceList[index]+sum;
      print(sum);
    }
    return sum.toString();
  }

  getSumOfAddOns(){
    int sum =0;
    for(int index =0; index< selectedAddOnsPriceList.length; index++){
      print("${selectedAddOnsPriceList[index]} add ons prices list");
      sum = selectedAddOnsPriceList[index]+sum;
      print(sum);
    }
    return sum.toString();
  }

  // Future<bool> saloonItems({required Map<String, dynamic> apiParams, required BuildContext context}) async {
  //   Functions.showProgressLoader("Please Wait");
  //
  //   isDataLoaded = false.obs;
  //   final res = await authApi.userLogin(apiParams: apiParams);
  //   print(' CTL RESPONSE${res}');
  //   Functions.hideProgressLoader();
  //   if (res is SaloonItemsModel) {
  //     saloonItemsModel = res;
  //     print('ADD MEMBER SUCCESS RESPONSE FOUND');
  //     isDataLoaded.toggle();
  //     return true;
  //   } else if (res is ErrorResponse) {
  //     print('ADD MEMBER ERROR RESPONSE FOUND');
  //     errorResponse = res;
  //     return false;
  //   } else if (res == ExceptionCode.timeOut) {
  //     print(res);
  //     Functions.showToast(AppStrings.slowInternet);
  //     //slow internet
  //   } else if (res == ExceptionCode.noInternet) {
  //     //no internet
  //     print(res);
  //     Functions.showToast(AppStrings.noInternet);
  //   } else if (res == ExceptionCode.error) {
  //     //server error
  //     print(res);
  //     Functions.showToast(AppStrings.error);
  //   }
  //   return false;
  // }
  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

  void increment() => count.value++;

}
