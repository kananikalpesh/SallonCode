import 'dart:convert';

import 'package:get/get.dart';
import 'package:intl/intl.dart' as intl;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-signup-ctl.dart';
import 'package:saloon_app/app/modules/customer/controllers/custome_home_controller.dart';
import 'package:saloon_app/app/modules/login/views/otp_code.dart';
import 'package:saloon_app/app/modules/login/controllers/signup_controller.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/anim_toast.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SaloonSignUp extends GetView<AdminSignUpCTL> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Functions.hideKeyboard(context);
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: ColorsX.white,
          centerTitle: true,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: ColorsX.subBlack),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: Container(
            width:SizeConfig.screenWidth,
            color: ColorsX.white,
            child:ListView(
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Align(
                      alignment: Alignment.topCenter,
                      child: Text(
                        "Create an Account",
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 30,
                            color: ColorsX.blue_text_color),
                      ),
                    ),
                    Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          //userName Field
                          Container(
                            padding: EdgeInsets.only(left: 5, right: 5),
                            decoration: new BoxDecoration(
                                color: ColorsX.greyBackground,
                                borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                            margin: EdgeInsets.only(
                                top: 20,
                                right: SizeConfig.paddingXLarge,
                                left: SizeConfig.paddingXLarge),
                            child: TextFormField(
                              style: TextStyle(color: ColorsX.subBlack),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'please enter Company Name';
                                }
                                return null;
                              },
                              minLines: 1,
                              controller: controller.companyNameController,
                              //Normal textInputField will be disp
                              decoration: InputDecoration(
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Company Name",
                                  contentPadding: EdgeInsets.only(top: 15),
                                  hintStyle: TextStyle(color: ColorsX.subBlack),
                                  prefixIcon: Image.asset(
                                    "assets/images/user.png",
                                    height: 20,
                                    width: 20,
                                  )),
                            ),
                          ),
                          //Email Field
                          Container(
                            padding: EdgeInsets.only(left: 5, right: 5),
                            decoration: new BoxDecoration(
                                color: ColorsX.greyBackground,
                                borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                            margin: EdgeInsets.only(
                                top: 20,
                                right: SizeConfig.paddingXLarge,
                                left: SizeConfig.paddingXLarge),
                            child: TextFormField(
                              style: TextStyle(color: ColorsX.subBlack),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'please enter email';
                                }
                                return null;
                              },

                              minLines: 1,
                              controller: controller.emailController,
                              //Normal textInputField will be disp
                              decoration: InputDecoration(
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Email Address",
                                  contentPadding: EdgeInsets.only(top: 15),
                                  hintStyle: TextStyle(color: ColorsX.subBlack),
                                  prefixIcon: Image.asset(
                                    "assets/images/email.png",
                                    height: 20,
                                    width: 20,
                                  )),
                            ),
                          ),
                          //Phone Number Field
                          Container(
                            padding: EdgeInsets.only(left: 5, right: 5),
                            decoration: new BoxDecoration(
                                color: ColorsX.greyBackground,
                                borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                            margin: EdgeInsets.only(
                                top: 20,
                                right: SizeConfig.paddingXLarge,
                                left: SizeConfig.paddingXLarge),
                            child: TextFormField(
                              style: TextStyle(color: ColorsX.subBlack),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'please enter Phone number';
                                }
                                return null;
                              },
                              minLines: 1,
                              controller: controller.phoneController,
                              keyboardType: TextInputType.phone,
                              decoration: InputDecoration(
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Phone Number",
                                  contentPadding: EdgeInsets.only(top: 15),
                                  hintStyle: TextStyle(color: ColorsX.subBlack),
                                  prefixIcon: Image.asset(
                                    "assets/images/phone.png",
                                    height: 20,
                                    width: 20,
                                  )),
                            ),
                          ),
                          //Date of Birth Field
                          // Container(
                          //   padding: EdgeInsets.only(left: 5, right: 5),
                          //   decoration: new BoxDecoration(
                          //       color: ColorsX.greyBackground,
                          //       borderRadius:
                          //       BorderRadius.all(Radius.circular(10))),
                          //   margin: EdgeInsets.only(
                          //       top: 20,
                          //       right: SizeConfig.paddingXLarge,
                          //       left: SizeConfig.paddingXLarge),
                          //   child: TextFormField(
                          //     readOnly: true,
                          //     style: TextStyle(color: ColorsX.subBlack),
                          //     validator: (value) {
                          //       if (value == null || value.isEmpty) {
                          //         return 'please enter Date of birth';
                          //       }
                          //       return null;
                          //     },
                          //     controller: controller.dobCTL,
                          //     decoration: InputDecoration(
                          //         enabledBorder: InputBorder.none,
                          //         focusedBorder: InputBorder.none,
                          //         hintText: "Date of Birth",
                          //         contentPadding: EdgeInsets.only(top: 15),
                          //         hintStyle: TextStyle(color: ColorsX.subBlack),
                          //         prefixIcon: Image.asset(
                          //           "assets/images/date.png",
                          //           height: 20,
                          //           width: 20,
                          //         )),
                          //     onTap: () {
                          //       _showDatePicker(context);
                          //     },
                          //   ),
                          // ),

                          //Phone Number Field
                          Container(
                            padding: EdgeInsets.only(left: 5, right: 5),
                            decoration: new BoxDecoration(
                                color: ColorsX.greyBackground,
                                borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                            margin: EdgeInsets.only(
                                top: 20,
                                right: SizeConfig.paddingXLarge,
                                left: SizeConfig.paddingXLarge),
                            child: TextFormField(
                              style: TextStyle(color: ColorsX.subBlack),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'please enter Company Registration Number';
                                }
                                return null;
                              },
                              minLines: 1,
                              controller: controller.companyRegistrationNumber,
                              keyboardType: TextInputType.phone,
                              decoration: InputDecoration(
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Company Registration Number",
                                  contentPadding: EdgeInsets.only(top: 15),
                                  hintStyle: TextStyle(color: ColorsX.subBlack),
                                  prefixIcon: Image.asset(
                                    "assets/images/phone.png",
                                    height: 20,
                                    width: 20,
                                  )),
                            ),
                          ),
                          //Password Field
                          Container(
                            padding: EdgeInsets.only(left: 5, right: 5),
                            decoration: new BoxDecoration(
                                color: ColorsX.greyBackground,
                                borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                            margin: EdgeInsets.only(
                                top: 20,
                                right: SizeConfig.paddingXLarge,
                                left: SizeConfig.paddingXLarge),
                            child: TextFormField(
                              obscureText: true,
                              style: TextStyle(color: ColorsX.subBlack),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'please enter password';
                                }
                                return null;
                              },

                              minLines: 1,
                              //Normal textInputField will be disp
                              controller: controller.passwordController,
                              decoration: InputDecoration(
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Password",
                                  contentPadding: EdgeInsets.only(top: 15),
                                  hintStyle: TextStyle(color: ColorsX.subBlack),
                                  prefixIcon: Image.asset(
                                    "assets/images/password.png",
                                    height: 20,
                                    width: 20,
                                  )),
                            ),
                          ),
                          //Confirm Password Field
                          Container(
                            padding: EdgeInsets.only(left: 5, right: 5),
                            decoration: new BoxDecoration(
                                color: ColorsX.greyBackground,
                                borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                            margin: EdgeInsets.only(
                                top: 20,
                                right: SizeConfig.paddingXLarge,
                                left: SizeConfig.paddingXLarge),
                            child: TextFormField(
                              obscureText: true,
                              style: TextStyle(color: ColorsX.subBlack),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'enter password again to confirm';
                                }
                                return null;
                              },
                              minLines: 1,
                              controller: controller.confirmPasswordController,
                              decoration: InputDecoration(
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Confirm Password",
                                  contentPadding: EdgeInsets.only(top: 15),
                                  hintStyle: TextStyle(color: ColorsX.subBlack),
                                  prefixIcon: Image.asset(
                                    "assets/images/confirm.png",
                                    height: 20,
                                    width: 20,
                                  )),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Button(context, "Sign Up"),
                    TermsText(
                        context,
                        'By continuing  ',
                        'Sign Up ',
                        'you are agree to the following ',
                        'Terms & Conditions ',
                        'without reservation',
                        0xff39D2D2,
                        0xff707070),
                    InkWell(
                      onTap: (){
                        Get.offNamed('/login-screen');

                      },
                      child: TermsText(context, 'Already have an account? ', 'Sign In',
                          '', '', '', 0xff39D2D2, 0xff707070),
                    ),
                  ],
                ),
              ],
            )),
      ),
    );
  }

  // void _showDatePicker(BuildContext context) async {
  //   intl.DateFormat dateDisplayFormat = intl.DateFormat("dd/MM/yyyy");
  //   intl.DateFormat dateFormat = intl.DateFormat("dd/MM/yyyy");
  //   int lastdate = DateTime.now().year - 9;
  //   int initialdate = DateTime.now().year - 11;
  //   // FocusScope.of(context).requestFocus(new FocusNode());
  //   try {
  //     var date = await showDatePicker(
  //       context: context,
  //       initialDate: DateTime(initialdate),
  //       firstDate: DateTime(1900),
  //       lastDate: DateTime(lastdate),
  //       builder: (BuildContext context, Widget? child) {
  //         return Theme(
  //           data: ThemeData.light().copyWith(
  //             primaryColor: ColorsX.blue_gradient_pure_dark,
  //             accentColor: ColorsX.blue_gradient_dark,
  //             colorScheme:
  //             ColorScheme.light(primary: ColorsX.blue_gradient_pure_dark),
  //             buttonTheme: ButtonThemeData(textTheme: ButtonTextTheme.primary),
  //           ),
  //           child: child!,
  //         );
  //       },
  //     );
  //     // startDate = dateFormat.format(date);
  //     controller.dobCTL.text = dateDisplayFormat.format(date!);
  //     controller.dob = dateFormat.format(date);
  //   } catch (e) {
  //     print(e);
  //   }
  // }

  Widget TermsText(BuildContext context, String text1, String text2,
      String text3, String text4, String text5, int colorCode, int colorCode2) {
    return Container(
        margin: EdgeInsets.only(
            top: 15,
            left:SizeConfig.screenWidth * .10,
            right: SizeConfig.screenWidth * .10),
        child: RichText(
          text: TextSpan(
            text: text1,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: Color(colorCode2),
            ),
            children: <TextSpan>[
              TextSpan(
                  text: text2,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: text2.contains("Up")
                          ? Color(colorCode2)
                          : Color(colorCode))),
              TextSpan(
                  text: text3,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Color(colorCode2))),
              TextSpan(
                  text: text4,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Color(colorCode2))),
              TextSpan(
                  text: text5,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Color(colorCode2))),
            ],
          ),
          textAlign: TextAlign.center,
        ));
  }

  Widget Button(BuildContext context, String buttonText) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            if (_formKey.currentState!.validate()) {
              _userSignUp(context);
            }

            // Get.toNamed(Routes.OTP_SCREEN);
          },
          child: Container(
            margin: EdgeInsets.only(
              top: 30,
            ),
            width: MediaQuery.of(context).size.width * .80,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: new BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(buttonText,
                    style: TextStyle(
                      fontSize: 16,
                      color: ColorsX.white,
                      fontWeight: FontWeight.w700,
                    )),
              ],
            ),
          ),
        ));
  }


  void _userSignUp(BuildContext context) async {

    Functions.hideKeyboard(context);
    String userName = controller.companyNameController.text;
    String email = controller.emailController.text;
    String phone = controller.phoneController.text;
    String companyRegistartionNumber = controller.companyRegistrationNumber.text;
    String password = controller.passwordController.text;
    String confirmPassword = controller.confirmPasswordController.text;

    if (!Functions.validateEmail(email)) {
      AnimToast.errorToast(
          context, 'Email Error', 'Email format is not valid');
      return;
    }
    if (phone.length > 11) {
      AnimToast.infoToast(context, 'Phone Number', 'Enter 11 digit number');
      return;
    }
    if (password.length < 8) {
      AnimToast.warningToast(context, 'Password', 'Weak password');
      return;
    }
    if (password != confirmPassword) {
      AnimToast.errorToast(
          context, 'Password Error', 'Confirm password again');
      return;
    }

    CustomerHomeController customerHomeController = Get.find();
    final json = {
      // 'Address': {
      'type': "Point",
      'coordinates': [customerHomeController.userLat, customerHomeController.userLog], //[33.7601425,73.06577873],//[customerHomeController.userLat, customerHomeController.userLog],
      'Address':  AppStrings.streetAddress+", "+AppStrings.addressCity+", "+AppStrings.addressRegion,
      'City': AppStrings.addressCity,
      'State': AppStrings.addressRegion,
      // },
    };
    Map<String,dynamic> userInfo = Map();
    userInfo['Name'] = userName;
    userInfo['Email'] = email;
    userInfo['Mobile_number'] = phone;
    userInfo['Company_Registration_Number'] = companyRegistartionNumber;
    userInfo['Password'] = password;
    userInfo['Address'] = jsonEncode(json);
    print(userInfo);
    final res = await controller.adminSignUp(apiParams: userInfo, context: context);
    if(res){
//show success dialog
      Functions.showErrorDialogForOtpAdmin(title: 'OTP Verification', msg: AppStrings.signUpMSG, number: phone, context: context);
    }else{
      print("here comes error");
    }

  }

// void showPopUp(BuildContext context,String title, String content,String ok, bool status){
//   animatedDialog.showAnimatedDialog(
//     context: context,
//     barrierDismissible: true,
//     builder: (BuildContext context) {
//       return animatedDialog.ClassicGeneralDialogWidget(
//         titleText: title,
//         contentText: content,
//         positiveText: ok,
//         onPositiveClick: () {
//           if (status==false) {
//             Navigator.of(context).pop();
//           }
//           else {
//             Navigator.of(context).push(MaterialPageRoute(builder:(context)=>OTPCode(phone: _phoneController.text)));
//             // Navigator.pushNamed(context, '/otp');
//           }
//         },
//       );
//     },
//     animationType: animatedDialog.DialogTransitionType.fade,
//     curve: Curves.fastOutSlowIn,
//     duration: Duration(seconds: 1),
//   );
// }
}
