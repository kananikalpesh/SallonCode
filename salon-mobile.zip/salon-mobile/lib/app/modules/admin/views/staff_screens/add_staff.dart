import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/core_entity/time_slot.dart';
import 'package:saloon_app/app/modules/admin/controllers/staff_screen_controllers/staff_detail_ctl.dart';

import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/modules/admin/views/staff_screens/staff_wrapper.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/gv.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';
import 'package:multiselect/multiselect.dart';

class AddStaff extends GetView<StaffCTL> {
  List<String> timeLimit = [
    'Beauty Shop & SPA',
    'Beauty Shop & SPA',
    'Beauty Shop & SPA'
  ];
  List<String> ServiceList = ['Manicure, Pedicure', 'Pedicure', 'Manicure'];
  List<String> CatagoryList = ['One Time', 'Twice', 'Weekly'];
  List<String> DiscountList = ['10%', '20%', '30%'];
  List<String> currencies = ['USD', 'NOK', 'EUR'];
  List<String> colorsList = ['Pink', 'Red', 'Blue'];
  List<String> genderList = ['Male', 'Female', 'Other'];
  List<String> TimeLimitList = ['Slot Time', '20', '30', '40', '50', '60'];
  List<String> slotIntervalList = [
    'Slot Interval',
    '10',
    '15',
    '20',
    '25',
    '30',
    '35'
  ];



  List<String> ageList =
      List<String>.generate(80, (int index) => (20 + index).toString());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: <Widget>[
            Container(
              height: SizeConfig.screenHeight,
              width: SizeConfig.screenWidth,
              margin: EdgeInsets.only(top: 175),
              // color: ColorsX.dashboardColor,
            ),
            InkWell(
              onTap: () {
                Get.offNamed(SaloonStaffNavigation.staffList,
                    id: SaloonStaffNavigation.id);
              },
              child: Container(
                margin: EdgeInsets.only(
                    left: SizeConfig.blockSizeHorizontal * 5,
                    top: SizeConfig.blockSizeVertical * 7),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: SizeConfig.blockSizeVertical),
                  child: Image.asset(AppImages.back),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  width: SizeConfig.screenWidth * .15,
                ),
                // Container(
                //   margin: EdgeInsets.only(top: 40),
                //   child: TestLeftClass("assets/images/cart.png"),
                // ),
                Container(
                  width: SizeConfig.eightyPercentWidth,
                  margin: EdgeInsets.only(
                      top: SizeConfig.blockSizeVertical * 6,
                      left: SizeConfig.blockSizeHorizontal * 3),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Align(
                        alignment: Alignment.centerLeft,
                        child: _rowItemForHeaderText(
                            "Add Employee",
                            20,
                            FontWeight.w900,
                            ColorsX.dash_textColordark1,
                            15,
                            4,
                            0),
                      ),

                      _rowItemForHeaderText("Full Name", 14, FontWeight.w700,
                          ColorsX.dash_textColor, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),
                      _textInput(
                          controller.staffNameCTL, TextInputType.text, 6),
                      // dropDownContainer(context, CatagoryList, .75, 'One Time'),
                      _rowItemForHeaderText("Email", 14, FontWeight.w700,
                          ColorsX.dash_textColor, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),
                      _textInput(
                          controller.staffEmailCTL, TextInputType.text, 6),
                      _rowItemForHeaderText("Phone Number", 14, FontWeight.w700,
                          ColorsX.dash_textColor, 15, 4, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),
                      _textInput(
                          controller.staffPhoneCTL, TextInputType.phone, 6),

                      _rowItemForHeaderText("Choose Service(s)", 14,
                          FontWeight.w700, ColorsX.dash_textColor, 15, 4, 0),
                      selectServiceDropDown(
                        context,
                        controller.getServiceNameList(),
                        .77,
                      ),

                      verticalSpace(SizeConfig.blockSizeVertical),
                      Container(
                        padding: EdgeInsets.only(
                            left: SizeConfig.blockSizeHorizontal * 2),
                        width: SizeConfig.screenWidth * .78,
                        child: Row(
                          children: [
                            Expanded(
                                child: dropDownContainer2(
                                    context, GV.daysList, "Choose Day", 0)),
                            horizontalSpace(SizeConfig.blockSizeHorizontal * 2),
                            Obx(
                              () => Expanded(
                                  child: InkWell(
                                      onTap: () async {
                                        _selectTime(context, 'start-time');
                                      },
                                      child: dateContainer(
                                          8, "${controller.startTime.value}"))),
                            )
                          ],
                        ),
                      ),
                      verticalSpace(SizeConfig.blockSizeVertical * 2),
                      Container(
                        padding: EdgeInsets.only(
                            left: SizeConfig.blockSizeHorizontal * 2),
                        width: SizeConfig.screenWidth * .78,
                        child: Row(
                          children: [
                            Obx(
                              () => Expanded(
                                  child: InkWell(
                                      onTap: () async {
                                        _selectTime(context, 'end-time');
                                      },
                                      child: dateContainer(
                                          8, "${controller.endTime.value}"))),
                            ),
                            horizontalSpace(SizeConfig.blockSizeHorizontal * 2),
                            Expanded(
                                child: dropDownContainer2(
                                    context, TimeLimitList, "Slot Time", 1))
                          ],
                        ),
                      ),
                      verticalSpace(SizeConfig.blockSizeVertical * 2),

                      Container(
                        padding: EdgeInsets.only(
                            left: SizeConfig.blockSizeHorizontal * 2),
                        width: SizeConfig.screenWidth * .78,
                        child: Row(
                          children: [
                            Expanded(
                                child: dropDownContainer2(context,
                                    slotIntervalList, "Slot Intervel Time", 2)),
                            horizontalSpace(SizeConfig.blockSizeHorizontal * 2),
                            Expanded(child: addSlotBtn(context, "Add Slot"))
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(
                            left: SizeConfig.blockSizeHorizontal * 2),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            verticalSpace(SizeConfig.blockSizeVertical),
                            Obx(()=> _timeTable()),
                            verticalSpace(SizeConfig.blockSizeVertical),

                            _rowItemForHeaderText("Designation", 14, FontWeight.w700,
                                ColorsX.dash_textColor, 15, 4, 0),
                            verticalSpace(SizeConfig.blockSizeVertical),
                            dropDownContainer2(
                                context, controller.designationNameList, "", 3),
                            _rowItemForHeaderText("Gender", 14, FontWeight.w700,
                                ColorsX.dash_textColor, 15, 4, 0),
                            verticalSpace(SizeConfig.blockSizeVertical),
                            dropDownContainer2(
                                context, genderList, "", 4),

                            _rowItemForHeaderText("Age", 14, FontWeight.w700,
                                ColorsX.dash_textColor, 15, 4, 0),
                            verticalSpace(SizeConfig.blockSizeVertical),
                            dropDownContainer2(
                                context, ageList, "", 5),
                            _rowItemForHeaderText(
                                "Assigned Color",
                                14,
                                FontWeight.w700,
                                ColorsX.dash_textColor,
                                15,
                                4,
                                0),
                            verticalSpace(SizeConfig.blockSizeVertical),
                            dropDownContainer2(
                                context, colorsList, "", 6),

                            _rowItemForHeaderText(
                                "Upload Portfolio Images",
                                14,
                                FontWeight.w700,
                                ColorsX.dash_textColor,
                                15,
                                4,
                                0),
                            verticalSpace(SizeConfig.blockSizeVertical),

                            whiteBlankContainerUploadPhotos(context, .75),

                            InkWell(
                                onTap: ()async{
                                final res= await controller.addEmployee(context);
                                if(res)
                                  {
                                    Functions.showSimpleDialog(title: 'Success', msg: 'Employee Added successfully');
                                  }
                                },
                                child: addEmployeeBtn(context, "Add Employee")),
                            verticalSpace(SizeConfig.blockSizeVertical),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                // Column(
                //   crossAxisAlignment: CrossAxisAlignment.start,
                //   children: <Widget>[
                //   ],
                // ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Container _timeTable() {
    return Container(
      width: SizeConfig.blockSizeHorizontal * 75,
      // height: SizeConfig.blockSizeVertical * 30,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Container(
          // height: SizeConfig.blockSizeVertical * 40,
          width: SizeConfig.blockSizeHorizontal * 110,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: _rowItemForHeaderText("Day", 14, FontWeight.bold,
                        ColorsX.dash_textColordark1, 10, 0, 0),
                  ),
                  Expanded(
                    flex: 3,
                    child: _rowItemForHeaderText(
                        "Start Time",
                        14,
                        FontWeight.bold,
                        ColorsX.dash_textColordark1,
                        10,
                        10,
                        0),
                  ),
                  Expanded(
                    flex: 3,
                    child: _rowItemForHeaderText(
                        "End Time",
                        14,
                        FontWeight.bold,
                        ColorsX.dash_textColordark1,
                        10,
                        10,
                        0),
                  ),
                  Expanded(
                    flex: 3,
                    child: _rowItemForHeaderText(
                        "Slot Time",
                        14,
                        FontWeight.bold,
                        ColorsX.dash_textColordark1,
                        10,
                        10,
                        0),
                  ),
                  Expanded(
                    flex: 4,
                    child: _rowItemForHeaderText(
                        "Slot Time Interval",
                        14,
                        FontWeight.bold,
                        ColorsX.dash_textColordark1,
                        10,
                        10,
                        0),
                  ),
                ],
              ),
              if(controller.timeSlotList.isNotEmpty)
              for(int i=0;i<controller.timeSlotList.length;i++)
              Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: _rowItemForHeaderText("${controller.timeSlotList[i].day}", 14, FontWeight.bold,
                        ColorsX.dash_textColor, 10, 0, 0),
                  ),
                  Expanded(
                    flex: 3,
                    child: _rowItemForHeaderText("${controller.timeSlotList[i].startTime}", 14,
                        FontWeight.bold, ColorsX.dash_textColor, 10, 10, 0),
                  ),
                  Expanded(
                    flex: 3,
                    child: _rowItemForHeaderText("${controller.timeSlotList[i].endTime}", 14, FontWeight.bold,
                        ColorsX.dash_textColor, 10, 10, 0),
                  ),
                  Expanded(
                    flex: 3,
                    child: _rowItemForHeaderText("${controller.timeSlotList[i].slotTime} min", 14, FontWeight.bold,
                        ColorsX.dash_textColor, 10, 10, 0),
                  ),
                  Expanded(
                    flex: 4,
                    child: _rowItemForHeaderText("${controller.timeSlotList[i].slotInterval} min", 14, FontWeight.bold,
                        ColorsX.dash_textColor, 10, 10, 0),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget dropDownContainer(
      BuildContext context, List<String> values, double width, String text) {
    return Card(
      elevation: 1,
      child: Container(
        width: SizeConfig.screenWidth * width,
        // height: SizeConfig.blockSizeVertical * 6,
        margin: EdgeInsets.only(left: 15, top: 10),
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            DropDownWithoutBorder(values, text),
          ],
        ),
      ),
    );
  }

  Widget selectServiceDropDown(
    BuildContext context,
    List<String> values,
    double width,
  ) {
    return Card(
      elevation: 1,
      child: Container(
        width: SizeConfig.screenWidth * width,
        // height: SizeConfig.blockSizeVertical * 6,
        margin: EdgeInsets.only(left: 15, top: 10),
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: SizedBox(
          height: 70,
          child: DropDownMultiSelect(
            onChanged: (List<String> x) {
              controller.selectedServiceName=x;
            },
            options: values,
            selectedValues: [],
            whenEmpty: 'choose service',
            decoration: new InputDecoration(
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              errorBorder: InputBorder.none,
              disabledBorder: InputBorder.none,
            ),
          ),
        ),
      ),
    );
  }

  Widget dropDownContainer2(
      BuildContext context, List<String> values, String text, int index) {
    return Obx(() => Container(
          // width: SizeConfig.screenWidth * width,
          height: SizeConfig.blockSizeVertical * 8,
          // margin: EdgeInsets.only(left: 15, top: 10),
          decoration: new BoxDecoration(
            color: ColorsX.white,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _DropDownWithoutBorder(values, text, index),
            ],
          ),
        ));
  }

  Widget whiteInputContainer(
      BuildContext context, String values, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
              child: Text(
                values,
                style: TextStyle(
                    color: ColorsX.black,
                    fontSize: 14,
                    fontWeight: FontWeight.w700),
              )),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget _textInput(
      TextEditingController ctl, TextInputType inputType, int height) {
    return Card(
      elevation: 1,
      child: Container(
        margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 5),
        height: SizeConfig.blockSizeVertical * height,
        // width: SizeConfig.blockSizeHorizontal * 30,
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: TextFormField(
          controller: ctl,
          // obscureText: isPassword,
          keyboardType: inputType,
          cursorColor: Colors.white,
          textAlign: TextAlign.start,
          style: TextStyle(color: Colors.black, fontSize: 16),
          decoration: InputDecoration(
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
            contentPadding: EdgeInsets.all(9),
            hintStyle: TextStyle(color: Colors.black, fontSize: 16),
            errorBorder: InputBorder.none,
            disabledBorder: InputBorder.none,
            // hintText: "Test Text",
          ),
        ),
      ),
    );
  }

  Widget dateContainer(int height, String date) {
    return Container(
        margin: EdgeInsets.only(left: 0),
        height: SizeConfig.blockSizeVertical * height,
        // width: SizeConfig.blockSizeHorizontal * 30,
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(AppImages.calender_picker_ic),
            horizontalSpace(
              SizeConfig.blockSizeHorizontal * 2,
            ),
            _rowItemForHeaderText(
                date, 16, FontWeight.normal, ColorsX.black, 0, 0, 0)
          ],
        ));
  }

  Widget addEmployeeBtn(BuildContext context, String text) {
    return Container(
        width: SizeConfig.screenWidth * .82,
        margin: EdgeInsets.only(left: 0, top: 15, bottom: 0),
        decoration: new BoxDecoration(
          color: ColorsX.blue_button_color,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        padding: EdgeInsets.symmetric(vertical: 13),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.w700, color: ColorsX.white),
        ));
  }

  Widget addSlotBtn(BuildContext context, String text) {
    return InkWell(
      onTap: () {
        String day = controller.day.value;
        String startTime = controller.startTime.value;
        String endTime = controller.endTime.value;
        String slotTime = controller.slotTime.value;
        String slotInterval = controller.slotInterval.value;

        TimeSlot timeSlot = TimeSlot(
            day: day,
            startTime: startTime,
            endTime: endTime,
            slotTime: slotTime,
            slotInterval: slotInterval);
        print('clickeed...${timeSlot.toJson()}');
        controller.addSlot(timeSlot);
      },
      child: Container(
          width: SizeConfig.screenWidth * .82,
          margin: EdgeInsets.only(left: 0, top: 15, bottom: 0),
          decoration: new BoxDecoration(
            color: ColorsX.blue_button_color,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: ColorsX.white),
          )),
    );
  }

  Widget whiteBlankContainer(BuildContext context, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
            child: Container(
              height: 60,
            ),
          ),
          // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget whiteBlankContainerUploadPhotos(BuildContext context, double width) {
    return Card(
      elevation: 1,
      child: Container(
        width: SizeConfig.screenWidth * width,
        margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal, top: 10),
        decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(left: 0, top: 17, bottom: 17, right: 10),
              child: Container(
                height: 60,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                          color: ColorsX.blue_text_color,
                          shape: BoxShape.circle),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ClipRRect(
                          borderRadius: new BorderRadius.circular(10.0),
                          child: Image.asset(
                            "assets/images/gallery.png",
                            height: 30,
                            width: 30,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Obx(
                        ()=> InkWell(
                        onTap: ()async{
                          controller.takePicture();
                        },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Container(
                              decoration: BoxDecoration(
                                color: ColorsX.blue_button_color,
                                borderRadius: BorderRadius.all(Radius.circular(10)),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    child: Icon(
                                      Icons.add_circle,
                                      color: ColorsX.white,
                                      size: 14,
                                    ),
                                    margin: EdgeInsets.only(
                                        top: 10, bottom: 10, left: 15, right: 15),
                                  ),
                                  Container(
                                      margin: EdgeInsets.only(right: 15),
                                      child: Text(
                                        "Add Photo",
                                        style: TextStyle(
                                            color: ColorsX.white,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 12),
                                      )),
                                ],
                              ),
                            ),
                            _rowItemForHeaderText("${controller.imageStatus.value}", 8,
                                FontWeight.w400, ColorsX.black, 10, 0, 0),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
            // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
          ],
        ),
      ),
    );
  }

  Widget simpleContainer(BuildContext context, String firstText,
      String secondText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(firstText, 10, FontWeight.w700,
                  ColorsX.greydashboard, 15, 10, 0),
              Container(
                width: SizeConfig.sixtyFivePercentWidth,
                child: _rowItemForHeaderText(secondText, 14, FontWeight.w700,
                    ColorsX.dash_textColor, 10, 10, 0),
              ),
              SizedBox(
                height: 15,
              )
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(right: 10, top: 10),
                child: Image.asset(imagePath),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: colorCode, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    margin: EdgeInsets.only(left: 2, top: 2),
                    decoration: new BoxDecoration(
                      color: ColorsX.rating_dashboard,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          bottomRight: Radius.circular(30)),
                    ),
                    child: _rowItemForHeaderText(
                        " 4.5", 7, FontWeight.w600, ColorsX.white, 0, 0, 0),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }

  Widget _DropDownWithoutBorder(List<String> values, String text, int index) {
    return Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(top: 0, left: 10, bottom: 5),
        child: DropdownButton(
          value: controller.dropdownValue?[index].value,
          underline: SizedBox(),
          hint: Text(
            '$text',
            style: TextStyle(color: Color(0xff515C6F)),
          ),
          isExpanded: true,
          iconSize: 30.0,
          // icon: Image.asset(AppImages.dropdown_field_ic),
          style: TextStyle(
              color: Color(0xff8890A6),
              fontSize: 14,
              fontWeight: FontWeight.w600),
          items: values.map(
            (val) {
              return DropdownMenuItem<String>(
                value: val,
                child: Text(val),
              );
            },
          ).toList(),
          onChanged: (val) {
            controller.dropdownValue?[index].value = val as String;
          },
        ));
  }

  Future<void> _selectTime(BuildContext context, String status) async {
    TimeOfDay selectedTime = TimeOfDay.now();
    final TimeOfDay? picked_s = await showTimePicker(
        context: context,
        initialTime: selectedTime,
        builder: (BuildContext? context, Widget? child) {
          return MediaQuery(
            data:
                MediaQuery.of(context!).copyWith(alwaysUse24HourFormat: false),
            child: child!,
          );
        });

    if (picked_s != null) {
      if (status == 'start-time') {
        controller.startTime.value = picked_s.format(context).toString();
      } else if (status == 'end-time') {
        controller.endTime.value = picked_s.format(context).toString();
      }

      print(picked_s.format(context));
    }
  }
}
