import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/staff_screen_controllers/staff_detail_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/appointments/saloon_appointment_item.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'staff_list_item.dart';

class StaffTabs extends GetView<StaffCTL> {
  TabController? _tabController;
  StaffCTL _staffCTL = Get.find();

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: controller.designationList.isEmpty
          ? 1
          : controller.designationList.length,
      child: Column(
        children: <Widget>[
          Container(
            height: 55,
            color: ColorsX.greydashboard,
            child: TabBar(
              onTap: (index){
                print('Staff tabs Index.....$index');
              },
              tabs: [
                if(controller.designationList.isEmpty)
                Container(
                    width: SizeConfig.thirtyPercentWidth,
                    child: Text(
                      "All",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                    )),
                for(var d in controller.designationList)
                  Container(
                      width: SizeConfig.thirtyPercentWidth,
                      child: Text(
                        "${d.title}",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      )),
              ],
              unselectedLabelColor: const Color(0xff000000),
              indicatorColor: Color(0xff70b4ff),
              labelColor: Color(0xff70b4ff),
              indicatorSize: TabBarIndicatorSize.tab,
              indicatorWeight: 3.0,
              indicatorPadding: EdgeInsets.only(top: 20),
              isScrollable: true,
            ),
          ),
          Expanded(
            child: TabBarView(children: <Widget>[
              if(controller.designationList.isEmpty)
              Container(child: StaffListItem()),
              for(var i=0;i<controller.designationList.length;i++)
              Container(child: StaffListItem()),
            ]),
          ),
        ],
      ),
    );
  }
}
