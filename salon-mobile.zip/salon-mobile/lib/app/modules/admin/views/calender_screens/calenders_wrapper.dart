// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/bindings/choose_customer_binding.dart';
import 'package:saloon_app/app/modules/admin/bindings/saloon_appointment_binding.dart';
import 'package:saloon_app/app/modules/admin/views/add-customer.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-book-appointment-two.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-booking-detail-second.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-booking-detail1.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-select-add-ons.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-select-services.dart';
import 'package:saloon_app/app/modules/admin/views/appointments/saloon_request_detail.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/booking_detail_admin1.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calendar_settings.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calender_main_screen.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/select_add_ons.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/select_services.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/select_time.dart';
import 'package:saloon_app/app/modules/admin/views/choose-customer.dart';

import 'booking_detail_admin2.dart';

class CalenderNavigation {
  CalenderNavigation._();
  static const id = 13;
  static const _14id = 14;
  static const _15id = 15;
  static const _17id = 17;
  static const mainCalender = '/main-calender';
  static const calenderFilter = '/calender-filter';
  static const selectServices = '/select-services';
  static const selectAddOns = '/select-add-ons';
  static const selectTime = '/select-Time';
  static const bookingDetailAdminFirst = '/booking-detail-admin1';
  static const bookingDetailAdminSecond = '/booking-detail-admin2';
  static const calenderMainScreen = '/calender-main-screen';
  static const choose_customer = '/choose_customer';
  static const add_customer = '/add_customer';
  static const AdminSelectServices = '/AdminSelectServices';
  static const AdminSelectAddOns = '/AdminSelectAddOns';
  static const AdminBookAppointmentTwo = '/AdminBookAppointmentTwo';
  static const AdminBookingDetailsFirst = '/AdminBookingDetailsFirst';
  static const AdminBookingDetailsSecond = '/AdminBookingDetailsSecond';
  static const appointmentsDetail = '/appointments-Detail';

}
// our wrapper, where our main navigation will navigate to
class CalenderWrapper extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Navigator(
      
      key: Get.nestedKey(CalenderNavigation.id),
      onGenerateRoute: (settings) {
        // navigate to a route by name with settings.name
        if (settings.name == CalenderNavigation.calenderFilter) {
          return GetPageRoute(
            routeName: CalenderNavigation.calenderFilter,
            page: () => CalenderSaloon(
              
            ),
          );
        } 
        else if (settings.name == CalenderNavigation.selectServices) {
          return GetPageRoute(
            routeName: CalenderNavigation.selectServices,
            page: () => SelectServicesOnDash(
              
            ),
          );
        } 
        else if (settings.name == CalenderNavigation.selectAddOns) {
          return GetPageRoute(
            routeName: CalenderNavigation.selectAddOns,
            page: () => SelectAddOnsOnDash(
              
            ),
          );
        } 
        else if (settings.name == CalenderNavigation.selectTime) {
          return GetPageRoute(
            routeName: CalenderNavigation.selectTime,
            page: () => SelectTimeOnDash(
              
            ),
          );
        }
        else if (settings.name == CalenderNavigation.choose_customer) {
          return GetPageRoute(
            routeName: CalenderNavigation.choose_customer,
            page: () => ChooseCustomer(),
            binding: ChooseCustomerBinding()
          );
        }
        else if (settings.name == CalenderNavigation.AdminSelectServices) {
          return GetPageRoute(
            routeName: CalenderNavigation.AdminSelectServices,
            page: () => AdminSelectServices(),
            binding: ChooseCustomerBinding()
          );
        }
        else if (settings.name == CalenderNavigation.AdminSelectAddOns) {
          return GetPageRoute(
            routeName: CalenderNavigation.AdminSelectAddOns,
            page: () => AdminSelectAddOns(),
            binding: ChooseCustomerBinding()
          );
        }
        else if (settings.name == CalenderNavigation.AdminBookAppointmentTwo) {
          return GetPageRoute(
            routeName: CalenderNavigation.AdminBookAppointmentTwo,
            page: () => AdminBookAppointmentTwo(),
            binding: ChooseCustomerBinding()
          );
        }
        else if (settings.name == CalenderNavigation.AdminBookingDetailsFirst) {
          return GetPageRoute(
            routeName: CalenderNavigation.AdminBookingDetailsFirst,
            page: () => AdminBookingDetailsFirst(),
            binding: ChooseCustomerBinding()
          );
        }
        else if (settings.name == CalenderNavigation.AdminBookingDetailsSecond) {
          return GetPageRoute(
            routeName: CalenderNavigation.AdminBookingDetailsSecond,
            page: () => AdminBookingDetailsSecond(),
            binding: ChooseCustomerBinding()
          );
        }
        else if (settings.name == CalenderNavigation.bookingDetailAdminFirst) {
          return GetPageRoute(
            routeName: CalenderNavigation.bookingDetailAdminFirst,
            page: () => BookingDetailAdminFirst(
              
            ),
          );
        }
        else if (settings.name == CalenderNavigation.add_customer) {
          return GetPageRoute(
            routeName: CalenderNavigation.add_customer,
            page: () => AddCustomer(),
          );
        }
        else if (settings.name == CalenderNavigation.bookingDetailAdminSecond) {
          return GetPageRoute(
            routeName: CalenderNavigation.bookingDetailAdminSecond,
            page: () => BookingDetailAdminSecond(
              
            ),
          );
        }   else if (settings.name == CalenderNavigation.appointmentsDetail) {
          return GetPageRoute(
              routeName: CalenderNavigation.appointmentsDetail,
              page: () => SaloonRequestDetail(),
              binding: SaloonAppointmentBinding()
          );
        }
        else {
          return GetPageRoute(
            routeName: CalenderNavigation.calenderMainScreen,
            page: () => CalenderMainScreen(
              
            ),
          );
        }
      },
    );
  }
}