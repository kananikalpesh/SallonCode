import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-add-slot/admin-saloon-controller.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-services/services-admin-list-and-add-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/deal_n_offers_ctl/admin-deals-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/deal_n_offers_ctl/deals_list_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/add-on-tabs.dart';
import 'package:saloon_app/app/modules/admin/views/deals_n_offers/deals_wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class EditDeal extends GetView<DealsListCTL> {
  List<String> timeLimit = [
    'Beauty Shop & SPA',
    'Beauty Shop & SPA',
    'Beauty Shop & SPA'
  ];
  ServicesAdminListAddCTL servicesAdminListAddCTL = Get.find();
  // List<String> ServiceList = ['Manicure, Pedicure', 'Pedicure', 'Manicure'];
  // List<String> CatagoryList = ['One Time', 'Cancellation Offer', 'Bundle Offer'];
  // List<String> TimeLimitList = ['8 hours', '1 day', '1 week'];
  // List<String> DiscountList = ['10%', '20%', '30%'];
  // List<String> currencies = ['USD', 'NOK', 'EUR'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: <Widget>[
            Container(
              height: SizeConfig.screenHeight,
              width: SizeConfig.screenWidth,
              margin: EdgeInsets.only(top: 175),
              // color: ColorsX.dashboardColor,
            ),
            GestureDetector(
              onTap: (){
                Get.toNamed(DealsNavigation.dealsNofferList,
                    id: DealsNavigation.id);
              },
              child: Container(
                margin: EdgeInsets.only(
                    left: SizeConfig.blockSizeHorizontal * 5,
                    top: SizeConfig.blockSizeVertical * 7),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: SizeConfig.blockSizeVertical),
                  child: Image.asset(AppImages.back),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  width: SizeConfig.screenWidth * .15,
                ),
                // Container(
                //   margin: EdgeInsets.only(top: 40),
                //   child: TestLeftClass("assets/images/cart.png"),
                // ),
                Container(
                  width: SizeConfig.screenWidth*.85,
                  margin:
                  EdgeInsets.only(top: SizeConfig.blockSizeVertical * 6),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Align(
                        alignment: Alignment.centerLeft,
                        child: _rowItemForHeaderText("Edit Deal", 20,
                            FontWeight.w900, 0xff515C6F, 15, 18, 0),
                      ),
                      _rowItemForHeaderText("Deal Name", 14, FontWeight.w700,
                          0xff8890A6, SizeConfig.blockSizeVertical * 2, 20, 0),
                      // whiteInputContainer(context, "Extreme Moisturiser", .75),
                      SizedBox(height: 5,),
                      _textInput(7, controller.dealNameControllerEdit),
                      _rowItemForHeaderText("Deal Code", 14, FontWeight.w700,
                          0xff8890A6, SizeConfig.blockSizeVertical * 2, 20, 0),
                      // whiteInputContainer(context, "Extreme Moisturiser", .75),
                      SizedBox(height: 5,),
                      _textInput(7, controller.dealCodeControllerEdit),
                      _rowItemForHeaderText("Choose Category", 14,
                          FontWeight.w700, 0xff8890A6, 15, 20, 0),

                      Obx(()=>Container(
                        // constraints: BoxConstraints(
                        //   minHeight: SizeConfig.blockSizeVertical * 4,
                        //   maxHeight: 50.0,
                        // ),
                        // padding: EdgeInsets.all(0.0),
                        // height: SizeConfig.blockSizeVertical * 3,
                        width: SizeConfig.screenWidth*.85,
                        margin: EdgeInsets.only(left: 15, right: 10),
                        child: Card(
                          elevation: 1,
                          child: Container(
                            width: SizeConfig.screenWidth * .80,
                            // height: SizeConfig.blockSizeVertical * 6,
                            margin: EdgeInsets.only(left: 10, top: 5),
                            decoration: new BoxDecoration(
                              color: ColorsX.white,
                              borderRadius: BorderRadius.all(Radius.circular(10)),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[

                                DropdownButton<String>(
                                  hint: Text(controller.chosenCatrgory.value),
                                  isExpanded: true,
                                  underline: SizedBox(),
                                  value: controller.chosenCatrgory.value,
                                  //elevation: 5,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 14),
                                  // icon: Container(
                                  //   margin: EdgeInsets.only(left: SizeConfig.screenWidth*.57),
                                  //   child: Icon(Icons.arrow_drop_down),
                                  // ),
                                  items: controller.CatagoryList.map<DropdownMenuItem<String>>(
                                          (String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Padding(
                                            padding: EdgeInsets.only(
                                                right:
                                                SizeConfig.marginVerticalXXsmall),
                                            child: Text(value),
                                          ),
                                        );
                                      }).toList(),
                                  onChanged: (value) {
                                    controller.chosenCatrgory.value = value!;
                                    // for(int index=0; index<controller.catagoryList.length; index++){
                                    //   controller.chosenCatrgoryID.value = "${controller.filterCategoryRes?.categories[index].id}";
                                    // }
                                    // controller.chosenCatrgoryID.value = getSelectedCategory();

                                    // getSelectedCategory();
                                    print(controller.chosenCatrgory.value);
                                    // print(controller.chosenCatrgoryID.value);

                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      ),
                      _rowItemForHeaderText("Price", 14, FontWeight.w700,
                          0xff8890A6, SizeConfig.blockSizeVertical * 2, 20, 0),
                      SizedBox(height: 5,),
                      // whiteInputContainer(context, "Extreme Moisturiser", .75),
                      _textInput(7, controller.priceControllerEdit),
                      _rowItemForHeaderText("Minimum Price", 14, FontWeight.w700,
                          0xff8890A6, SizeConfig.blockSizeVertical * 2, 20, 0),
                      SizedBox(height: 5,),
                      // whiteInputContainer(context, "Extreme Moisturiser", .75),
                      _textInput(7, controller.minimumPriceControllerEdit),
                      _rowItemForHeaderText("Discount", 14, FontWeight.w700,
                          0xff8890A6, 15, 20, 0),
                      Obx(()=>
                          Container(
                            // constraints: BoxConstraints(
                            //   minHeight: SizeConfig.blockSizeVertical * 4,
                            //   maxHeight: 50.0,
                            // ),
                            // padding: EdgeInsets.all(0.0),
                            // height: SizeConfig.blockSizeVertical * 3,
                            width: SizeConfig.screenWidth*.85,
                            margin: EdgeInsets.only(left: 15, right: 10),
                            child: Card(
                              elevation: 1,
                              child: Container(
                                width: SizeConfig.screenWidth * .80,
                                // height: SizeConfig.blockSizeVertical * 6,
                                margin: EdgeInsets.only(left: 10, top: 5),
                                decoration: new BoxDecoration(
                                  color: ColorsX.white,
                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[

                                    DropdownButton<String>(
                                      isExpanded: true,
                                      hint: Text(controller.chosenDiscount.value),
                                      underline: SizedBox(),
                                      value: controller.chosenDiscount.value,
                                      //elevation: 5,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 14),
                                      // icon: Expanded(
                                      //   child: Container(
                                      //     // margin: EdgeInsets.only(right: SizeConfig.screenWidth*.07),
                                      //     child: Icon(Icons.arrow_drop_down),
                                      //   ),
                                      // ),
                                      items: controller.discount.map<DropdownMenuItem<String>>(
                                              (String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Padding(
                                                padding: EdgeInsets.only(
                                                    right:
                                                    SizeConfig.marginVerticalXXsmall),
                                                child: Text(value),
                                              ),
                                            );
                                          }).toList(),
                                      onChanged: (value) {
                                        controller.chosenDiscount.value = value!;
                                        print(controller.chosenDiscount.value);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                      ),
                      // dropDownContainer(context, DiscountList, .75, '20%'),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Obx(()=>Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _rowItemForHeaderText("Start Date", 14,
                                    FontWeight.w700, 0xff8890A6, 15, 20, 15),
                                verticalSpace(SizeConfig.blockSizeVertical),
                                startDateContainer(7, controller.chosenDateTimeFromSetAppointmentWithDashes.value.isEmpty?
                                getTodaysDate():controller.chosenDateTimeFromSetAppointmentWithDashes.value, context)
                              ],
                            ),
                          ),
                          ),
                          // horizontalSpace(SizeConfig.blockSizeHorizontal),
                          Obx(()=>
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _rowItemForHeaderText("End Date", 14,
                                        FontWeight.w700, 0xff8890A6, 15, 20, 15),
                                    verticalSpace(SizeConfig.blockSizeVertical),
                                    endDateContainer(7, controller.chosenDateTimeForEndDateWithDashes.value.isEmpty?
                                    getTodaysEndDate():controller.chosenDateTimeForEndDateWithDashes.value, context)
                                  ],
                                ),
                              ),
                          ),
                          SizedBox(width: 10,)
                        ],
                      ),
                      _rowItemForHeaderText("Service", 14, FontWeight.w700,
                          0xff8890A6, 15, 20, 0),

                      Obx(()=>
                          Container(
                            width: SizeConfig.screenWidth*.85,
                            margin: EdgeInsets.only(left: 15, right: 10),
                            child: Card(
                              elevation: 1,
                              child: Container(
                                width: SizeConfig.screenWidth * .80,
                                // height: SizeConfig.blockSizeVertical * 6,
                                margin: EdgeInsets.only(left: 10, top: 5),
                                decoration: new BoxDecoration(
                                  color: ColorsX.white,
                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[

                                    DropdownButton<String>(
                                      isExpanded: true,
                                      hint: Text(servicesAdminListAddCTL.chosenService.value),
                                      underline: SizedBox(),
                                      value: servicesAdminListAddCTL.chosenService.value,
                                      //elevation: 5,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 14),
                                      // icon: Expanded(
                                      //   child: Container(
                                      //     // margin: EdgeInsets.only(right: SizeConfig.screenWidth*.07),
                                      //     child: Icon(Icons.arrow_drop_down),
                                      //   ),
                                      // ),
                                      items: servicesAdminListAddCTL.serviceNamesList.map<DropdownMenuItem<String>>(
                                              (String value) {
                                            return DropdownMenuItem<String>(
                                              value: value,
                                              child: Padding(
                                                padding: EdgeInsets.only(
                                                    right:
                                                    SizeConfig.marginVerticalXXsmall),
                                                child: Text(value),
                                              ),
                                            );
                                          }).toList(),
                                      onChanged: (value) {
                                        servicesAdminListAddCTL.chosenService.value = value!;
                                        servicesAdminListAddCTL.chosenServiceID.value = getSelectedService();
                                        print(servicesAdminListAddCTL.chosenService.value);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                      ),
                      // dropDownContainer(context, ServiceList, .75, 'Pedicure'),
                      _rowItemForHeaderText("Description", 14, FontWeight.w700,
                          0xff8890A6, 15, 20, 0),
                      verticalSpace(SizeConfig.blockSizeVertical),

                      _textInput(12, controller.descriptionControllerEdit),

                      deleteButton(context, "Edit Deal"),
                      SizedBox(height: 30,)
                    ],
                  ),
                ),
                // Column(
                //   crossAxisAlignment: CrossAxisAlignment.start,
                //   children: <Widget>[
                //   ],
                // ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // String getSelectedCategory() {
  //   return controller.filterCategoryRes?.categories
  //       .firstWhere((cat) => cat.title == controller.chosenCatrgory.value)
  //       .id;
  // }

  String getSelectedService() {
    return servicesAdminListAddCTL.serviceTypeList
        .firstWhere((serv) => serv.name == servicesAdminListAddCTL.chosenService.value)
        .id;
  }
  Widget dropDownContainer(
      BuildContext context, List<String> values, double width, String text) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          DropDownWithoutBorder(values, text),
        ],
      ),
    );
  }

  Widget whiteInputContainer(
      BuildContext context, String values, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
              margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
              child: Text(
                values,
                style: TextStyle(
                    color: ColorsX.black,
                    fontSize: 14,
                    fontWeight: FontWeight.w700),
              )),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget _textInput(int height, TextEditingController ctl) {
    return Container(
      margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 5, right: 15),
      height: SizeConfig.blockSizeVertical * height,
      // width: SizeConfig.blockSizeHorizontal * 30,
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: TextFormField(
        controller: ctl,
        // obscureText: isPassword,
        // keyboardType: inputType,
        cursorColor: Colors.white,
        minLines: 1,
        maxLines: 5,
        textAlign: TextAlign.start,
        style: TextStyle(color: Colors.black, fontSize: 16),
        decoration: InputDecoration(
          border: InputBorder.none,
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
          contentPadding: EdgeInsets.all(9),
          hintStyle: TextStyle(color: Colors.black, fontSize: 16),
          errorBorder: InputBorder.none,
          disabledBorder: InputBorder.none,
          hintText: "",
        ),
      ),
    );
  }

  String getTodaysDate(){
    final DateTime now = DateTime.now();
    print("now wali date"+"${now}");
    final DateFormat formatter = DateFormat('yyyy-MM-dd');
    final String formatted = formatter.format(now);
    controller.chosenDateTimeFromSetAppointmentWithDashes.value = formatted;
    print(formatted);
    return formatted;
  }
  String getTodaysEndDate(){
    final DateTime now = DateTime.now();
    print("now wali date"+"${now}");
    final DateFormat formatter = DateFormat('yyyy-MM-dd');
    final String formatted = formatter.format(now);
    controller.chosenDateTimeForEndDateWithDashes.value = formatted;
    print(formatted);
    return formatted;
  }
  Widget startDateContainer(int height, String date, BuildContext context) {
    return GestureDetector(
      onTap: (){
        Functions.getStartDateEndDateForEditDeal(date: getTodaysDate(), title: "Select Date", msg: "Select Date For Deal", context: context);
      },
      child: Container(
          margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 5),
          height: SizeConfig.blockSizeVertical * height,
          // width: SizeConfig.blockSizeHorizontal * 30,
          decoration: new BoxDecoration(
            color: ColorsX.white,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(AppImages.calender_picker_ic),
              horizontalSpace(
                SizeConfig.blockSizeHorizontal * 2,
              ),
              _rowItemForHeaderText(
                  controller.chosenDateTimeFromSetAppointmentWithDashes.value.isEmpty?getTodaysDate():
                  controller.chosenDateTimeFromSetAppointmentWithDashes.value, 16, FontWeight.normal, 0xFF000000, 0, 0, 0
              ),
            ],
          )
      ),
    );
  }
  Widget endDateContainer(int height, String date, BuildContext context) {
    return GestureDetector(
      onTap: (){
        Functions.getEndDateEndDateForEditDeal(date: getTodaysEndDate(), title: "Select Date", msg: "Select Date For Deal", context: context);
      },
      child: Container(
          margin: EdgeInsets.only(left: SizeConfig.blockSizeHorizontal * 5),
          height: SizeConfig.blockSizeVertical * height,
          // width: SizeConfig.blockSizeHorizontal * 30,
          decoration: new BoxDecoration(
            color: ColorsX.white,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(AppImages.calender_picker_ic),
              horizontalSpace(
                SizeConfig.blockSizeHorizontal * 2,
              ),
              _rowItemForHeaderText(
                  controller.chosenDateTimeForEndDateWithDashes.value.isEmpty?getTodaysDate():
                  controller.chosenDateTimeForEndDateWithDashes.value, 16, FontWeight.normal, 0xFF000000, 0, 0, 0
              ),
            ],
          )
      ),
    );
  }

  Widget deleteButton(BuildContext context, String text) {
    return GestureDetector(
      onTap: (){
        print(Functions.compareDatesEditDealNow());
        // AdminSaloonController adminSaloonController= Get.find();

        Functions.hideKeyboard(context);
        dynamic dealName = controller.dealNameControllerEdit.text;
        dynamic dealCode = controller.dealCodeControllerEdit.text;
        dynamic category = controller.chosenCatrgory.value;
        dynamic price = controller.priceControllerEdit.text;
        dynamic minprice = controller.minimumPriceControllerEdit.text;
        dynamic discount = controller.chosenDiscount.value;
        dynamic startDate = controller.chosenDateTimeFromSetAppointmentWithDashes.value;
        dynamic endDate = controller.chosenDateTimeForEndDateWithDashes.value;
        dynamic service = servicesAdminListAddCTL.chosenServiceID.value;
        // String saloon = adminSaloonController.getSaloonDetailsModel?.saloon?.id;
        String description = controller.descriptionControllerEdit.text;
        if(dealName.isEmpty){
          Functions.showErrorToast(context, "Required", "Deal Name field is required");
        }else if(dealCode.isEmpty){
          Functions.showErrorToast(context, "Required", "Deal Code field is required");
        }else if(price.isEmpty){
          Functions.showErrorToast(context, "Required", "Price field is required");
        }else if(minprice.isEmpty){
          Functions.showErrorToast(context, "Required", "Minimum Price field is required");
        }else if(description.isEmpty){
          Functions.showErrorToast(context, "Required", "Description field is required");
        }else{
          if(Functions.compareDatesEditDealNow()=="true") {
            Map<String, dynamic> serviceInfo = Map();
            serviceInfo['Coupon_name'] = dealName;
            serviceInfo['Coupon_code'] = dealCode;
            serviceInfo['Category'] = category;
            serviceInfo['Price'] = (price);
            serviceInfo['Min_Price'] = (minprice);
            serviceInfo['Percentage'] = (discount);
            serviceInfo['Start_Date'] = startDate;
            serviceInfo['End_Date'] = endDate;
            serviceInfo['Service'] = service;
            serviceInfo['Description'] = description;
            serviceInfo['id'] = controller.id;

            print(serviceInfo);
            controller.adminEditDeal(apiParams: serviceInfo);
          }
          else{
            Functions.showErrorToast(context, "Invalid date", "Can't add in previous ending date");
          }
          // controller.adminAddService(apiParams: serviceInfo);
        }
      },
      child: Container(
          width: SizeConfig.screenWidth * .85,
          margin: EdgeInsets.only(left: 15, top: 15, bottom: 0, right: 15),
          decoration: new BoxDecoration(
            color: ColorsX.blue_button_color,
            borderRadius: BorderRadius.all(Radius.circular(10)),
            boxShadow: [
              BoxShadow(
                color: text == "View More"
                    ? ColorsX.blue_button_color
                    : ColorsX.blue_button_color,
                blurRadius: 6,
                offset: Offset(1, 1), // Shadow position
              ),
            ],
          ),
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Color(0xffffffff)),
          )),
    );
  }

  Widget whiteBlankContainer(BuildContext context, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
            child: Container(
              height: 60,
            ),
          ),
          // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget whiteBlankContainerUploadPhotos(BuildContext context, double width) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, top: 17, bottom: 17, right: 10),
            child: Container(
              height: 60,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                        color: ColorsX.blue_text_color, shape: BoxShape.circle),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ClipRRect(
                        borderRadius: new BorderRadius.circular(10.0),
                        child: Image.asset(
                          "assets/images/gallery.png",
                          height: 30,
                          width: 30,
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        decoration: BoxDecoration(
                          color: ColorsX.blue_button_color,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              child: Icon(
                                Icons.add_circle,
                                color: ColorsX.white,
                                size: 14,
                              ),
                              margin: EdgeInsets.only(
                                  top: 10, bottom: 10, left: 15, right: 15),
                            ),
                            Container(
                                margin: EdgeInsets.only(right: 15),
                                child: Text(
                                  "Add Photos",
                                  style: TextStyle(
                                      color: ColorsX.white,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 12),
                                )),
                          ],
                        ),
                      ),
                      _rowItemForHeaderText("(Max limit 5mb per image)", 8,
                          FontWeight.w400, 0xff000000, 10, 0, 0),
                    ],
                  ),
                ],
              ),
            ),
          ),
          // Text(values, style: TextStyle(color: ColorsX.black, fontSize: 14, fontWeight: FontWeight.w700),)),
          // _rowItemForHeaderText(values, 14, FontWeight.w700, 0xff000000, 0, 0, 0),
        ],
      ),
    );
  }

  Widget _offsetPopup() => PopupMenuButton<int>(
    color: ColorsX.subBlack,
    itemBuilder: (context) => [
      PopupMenuItem(
        value: 1,
        child: InkWell(
            onTap: () {
              print("clicked");
            },
            child: _rowItemForHeaderText("Add New Product", 10,
                FontWeight.w700, 0xffffffff, 0, 0, 0)),
      ),
      // PopupMenuItem(
      //   value: 2,
      //   child: _rowItemForHeaderText("Preferences", 10, FontWeight.w700, 0xffffffff, 0, 0, 0),
      // ),
    ],
    icon: Container(
      height: double.infinity,
      width: double.infinity,
      decoration: ShapeDecoration(
          color: ColorsX.blue_text_color,
          shape: StadiumBorder(
            side: BorderSide(color: ColorsX.blue_text_color, width: 2),
          )),
      child: Image.asset(
          "assets/images/floating2.png"), // <-- You can give your icon here
    ),
  );
  Widget simpleContainer(BuildContext context, String firstText,
      String secondText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _rowItemForHeaderText(
                  firstText, 10, FontWeight.w700, 0xffe1e1e1, 15, 10, 0),
              Container(
                width: SizeConfig.sixtyFivePercentWidth,
                child: _rowItemForHeaderText(
                    secondText, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),
              ),
              SizedBox(
                height: 15,
              )
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(right: 10, top: 10),
                child: Image.asset(imagePath),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _imageHere(
      BuildContext context,
      String imagePath,
      ) {
    return Container(
      margin: EdgeInsets.only(left: 10, top: 15),
      child: ClipRRect(
        borderRadius: new BorderRadius.circular(10.0),
        child: Image(
          fit: BoxFit.cover,
          image: AssetImage(imagePath),
          width: SizeConfig.seventyFivePercentWidth,
          height: 200.0,
        ),
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 20, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 20, FontWeight.w900, 0xff515C6F, 0, 0, 0),
          Image.asset(
            imagePath,
            height: 21,
            width: 17,
          ),
        ],
      ),
    );
  }

  Widget _search(BuildContext context) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      padding: EdgeInsets.only(left: 8, right: 3),
      decoration: new BoxDecoration(
          color: ColorsX.greydashboard,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: 0, right: 15, left: 10),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.text,
        obscureText: false,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1, //Normal textInputField will be disp
        decoration: InputDecoration(
          contentPadding: EdgeInsets.only(top: 15, left: 2),

          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Color(0xffb4b4b4))),
          suffixIcon: Icon(
            Icons.search_rounded,
            color: ColorsX.dash_textColor,
          ),
          hintText: "Search",
          hintStyle: TextStyle(color: ColorsX.subBlack),
          // labelStyle: TextStyle(
          //     fontSize: 13,
          //     color: ColorsX.white,
          //     fontWeight: FontWeight.bold),
          // labelText: 'Email',
        ),
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
            alignment: Alignment.bottomRight,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
              margin: EdgeInsets.only(left: 2, top: 2),
              decoration: new BoxDecoration(
                color: ColorsX.rating_dashboard,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    bottomRight: Radius.circular(30)),
              ),
              child: _rowItemForHeaderText(
                  " 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
            ),
          )
              : Container(),
        ],
      ),
    );
  }
}
