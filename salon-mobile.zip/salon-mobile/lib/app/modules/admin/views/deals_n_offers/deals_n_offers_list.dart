import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/modules/admin/controllers/dashboard_controller.dart';
import 'package:saloon_app/app/modules/admin/controllers/deal_n_offers_ctl/deals_list_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calenders_wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/deals_n_offers/deals_wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/resuseable/loading-state.dart';

import 'package:saloon_app/app/data/model/admin/deals/admin-get-coupons-resp.dart'as allCouponsResp;
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class DealNOffersList extends GetView<DealsListCTL> {
  String drawerValue = "assets/images/appoint_white.png";
  String dropdownValue = "Edit";
  List<String> format = ['Monthly', 'Weekly',];
  List<String> dropDownItemsEditDelete = ['Edit', 'Delete',];

  Widget offsetPopup() => PopupMenuButton<int>(
        color: ColorsX.subBlack,
        itemBuilder: (context) => [
          PopupMenuItem(
            value: 1,
            child: InkWell(
                onTap: () {
                  // print("clicked");
                  // Get.toNamed(Routes.new_add_on);
                  Get.toNamed(DealsNavigation.createNewDeal,
                      id: DealsNavigation.id);
                },
                child: _rowItemForHeaderText("Add New Offer", 10,
                    FontWeight.w700, ColorsX.white, 0, 0, 0)),
          ),
          // PopupMenuItem(
          //   value: 2,
          //   child: _rowItemForHeaderText("Preferences", 10, FontWeight.w700, 0xffffffff, 0, 0, 0),
          // ),
        ],
        icon: Container(
          height: double.infinity,
          width: double.infinity,
          decoration: ShapeDecoration(
              color: ColorsX.blue_text_color,
              shape: StadiumBorder(
                side: BorderSide(color: ColorsX.blue_text_color, width: 2),
              )),
          child: Image.asset(
              AppImages.add_deal_ic), // <-- You can give your icon here
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Obx(() => controller.isDataLoaded.isTrue
        ? allDeals(context)
        : LoadingState());
    // return allDeals(context);
  }

  Widget allDeals(BuildContext context){
    return Scaffold(
      // backgroundColor: ColorsX.greydashboard,
      body: Stack(
        children: [
          Container(
            width: SizeConfig.screenWidth,
            height: SizeConfig.screenHeight,
            child: SingleChildScrollView(
              child: Column(
                // crossAxisAlignment: CrossAxisAlignment.start,
                // mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  SizedBox(
                    height: SizeConfig.blockSizeVertical * 5,
                  ),
                  _textAndIcon(context, "Deals & Offers", AppImages.back),
                  Container(
                    margin: EdgeInsets.only(
                        left: SizeConfig.blockSizeHorizontal * 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: SizeConfig.blockSizeVertical * 2,
                        ),
                        // _rowItemForHeaderText("Select Services", 18,
                        //     FontWeight.bold, ColorsX.black, 10, 15, 0),
                        _myTabBars(),
                        Container(
                          height: SizeConfig.screenHeight,
                          child: TabBarView(
                              controller: controller.tabController,
                              children: [
                                _tabItemOneTime(context),
                                _tabItemCancellation(context),
                                _tabItemBundle(context),
                                // Text("Hello"),
                                // Text("Hello"),
                                // Text("Hello"),
                                // _tabItem(),
                                // _tabItem(),
                              ]),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Container(
          //   margin: EdgeInsets.only(top: SizeConfig.screenHeight * .9),
          //   child: Align(alignment: Alignment.bottomCenter, child: BottomCart()),
          // )
          Align(
            alignment: Alignment.bottomRight,
            child: Container(
              height: 70,
              width: 70,
              margin: EdgeInsets.only(bottom: 10, right: 10),
              child: offsetPopup(),
              // child: FloatingActionButton(

              //   onPressed: () {
              //     // Add your onPressed code here!
              //   },
              //   child: Image.asset("assets/images/floating.png"),
              //   backgroundColor: ColorsX.blue_text_color,
              // ),
            ),
          ),
        ],
      ),
    );

  }

  Widget Button(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: Container(
          margin: EdgeInsets.only(
            top: 20,
          ),
          width: SizeConfig.eightyPercentWidth,
          padding: EdgeInsets.symmetric(vertical: 15),
          decoration: BoxDecoration(
            color: ColorsX.blue_button_color,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text("Continue to Select Add-ons",
                  style: TextStyle(
                    fontSize: 16,
                    color: ColorsX.white,
                    fontWeight: FontWeight.w700,
                  )),
            ],
          ),
        ));
  }
  Widget dropDownContainer(
      BuildContext context, List<String> values, double width, String text) {
    return Container(
      width: SizeConfig.screenWidth * width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          DropDownWithoutBorder(values, text),
        ],
      ),
    );
  }

  Widget simpleContainer(
      BuildContext context, String firstText, String imagePath) {
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(
        left: 15,
        top: 10,
      ),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(bottom: 15, top: 5),
            child: _rowItemForHeaderText(firstText, 14, FontWeight.w600,
                ColorsX.dash_textColordark1, 10, 10, 0),
          ),
          Container(
            margin: EdgeInsets.only(top: 12, right: 10),
            child: Image.asset(imagePath),
          ),
        ],
      ),
    );
  }

  Widget deleteButton(BuildContext context, String text, int colorCode) {
    return GestureDetector(
      child: Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(left: 15, top: 15),
        decoration: new BoxDecoration(
          color: Color(colorCode),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: [
            BoxShadow(
              color: text == "Add New" ? ColorsX.blue_button_color : Colors.red,
              blurRadius: 6,
              offset: Offset(1, 1), // Shadow position
            ),
          ],
        ),
        padding: EdgeInsets.symmetric(vertical: 13),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(child: SizedBox()),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Color(0xffffffff)),
            ),
            Expanded(child: SizedBox()),
            Icon(
              Icons.add_circle,
              color: ColorsX.white,
            ),
            SizedBox(
              width: 10,
            )
          ],
        ),
        // child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700,color: Color(0xffffffff)),)
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      Color color,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style:
            TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
      ),
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      // width: SizeConfig.seventyFivePercentWidth,
      margin:
          EdgeInsets.only(top: 20, left: SizeConfig.blockSizeHorizontal * 6),
      child: Row(
        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          InkWell(
            onTap: () {
              print("Drawer Pressed");
            },
            child: Container(
                height: 21, width: 17, child: Image.asset(AppImages.drawer_ic)),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 11),
          _rowItemForHeaderText(
              text, 20, FontWeight.w900, ColorsX.dash_textColordark1, 0, 0, 0),
          Spacer(),
          Container(
            // padding: EdgeInsets.all(5),
            decoration:
                BoxDecoration(shape: BoxShape.circle, color: ColorsX.white),
            child: Image.asset(
              AppImages.bell_dash_ic,
              width: 35,
              height: 35,
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 3),
          Container(
            // padding: EdgeInsets.all(5),
            decoration:
                BoxDecoration(shape: BoxShape.circle, color: ColorsX.white),
            child: InkWell(
              onTap: () {
                DaishBoardController daishBoardController = Get.find();
                daishBoardController.tabIndex.value = 10;
              },
              child: Image.asset(
                AppImages.chat_dash_ic,
                width: 35,
                height: 35,
              ),
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 4),
        ],
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    margin: EdgeInsets.only(left: 2, top: 2),
                    decoration: new BoxDecoration(
                      color: ColorsX.rating_dashboard,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          bottomRight: Radius.circular(30)),
                    ),
                    child: _rowItemForHeaderText(
                        " 4.5", 7, FontWeight.w600, ColorsX.white, 0, 0, 0),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }

  _myTabBars() {
    // int length= controller.saloonAllDealsResponse?.
    return Container(
      margin: EdgeInsets.only(
          // top: SizeConfig.blockSizeVertical * 9.5,
          left: SizeConfig.blockSizeHorizontal * 2,
          right: SizeConfig.blockSizeHorizontal * 3),
      child: TabBar(
          controller: controller.tabController,
          indicatorColor: ColorsX.blue_text_color,
          labelColor: ColorsX.blue_text_color,
          unselectedLabelColor: ColorsX.black,
          isScrollable: true,
          labelPadding: EdgeInsets.symmetric(horizontal: 10.0),
          tabs: [
            // for(int index=0; index<controller.lengthOfData.value; index++)
            Tab(
              text: "One-Time",
            ),
            Tab(
              text: "Cancellation Offer",
            ),
            Tab(
              text: "Bundle Offer",
            ),
          ]),
    );
  }

  Widget _tabItemOneTime(BuildContext context) {
    return PagedListView<int, allCouponsResp.Datum>(
      padding: EdgeInsets.zero,
      pagingController: controller.pagingController,
      builderDelegate: PagedChildBuilderDelegate<allCouponsResp.Datum>(
          itemBuilder: (context, item, index) {
            return InkWell(
              // behavior: HitTestBehavior.translucent,
              onTap: () {

                // controller.saloonAppointment = item;
                // Get.toNamed(SaloonAppointmentsNavigation.appointmentsDetail,
                //     id: SaloonAppointmentsNavigation.id);
              },
              child: "${item.category}"=="One Time"?_PopularItemView(
                  context: context,
                  imageOne: AppImages.Packages_img,
                  dealID: "${item.couponCode ?? ''}",
                  dealName: "${item.couponName ?? ''}",
                  originalPrice: "${item.price ?? ''}",
                  serviceName: "${item.service.name ?? ''}",
                  discount: "${item.percentage ?? ''}",
                  validDate: "${item.endDate ?? ''}",
                  status: "${item.status ?? ''}",
                  minPrice: "${item.minPrice ?? ''}",
                  description: "${item.description ?? ''}",
                  id: "${item.id ?? ''}",
                  category: "One Time"):Container(),
            );
          }),
    );

  }
  Widget _tabItemCancellation(BuildContext context) {
    return PagedListView<int, allCouponsResp.Datum>(
      padding: EdgeInsets.zero,
      pagingController: controller.pagingController,
      builderDelegate: PagedChildBuilderDelegate<allCouponsResp.Datum>(
          itemBuilder: (context, item, index) {
            return InkWell(
              // behavior: HitTestBehavior.translucent,
              onTap: () {

                // controller.saloonAppointment = item;
                // Get.toNamed(SaloonAppointmentsNavigation.appointmentsDetail,
                //     id: SaloonAppointmentsNavigation.id);
              },
              child: "${item.category}"=="Cancellation Offer"?_PopularItemView(
                context: context,
                imageOne: AppImages.Packages_img,
                dealID: "${item.couponCode ?? ''}",
                dealName: "${item.couponName ?? ''}",
                originalPrice: "${item.price ?? ''}",
                serviceName: "${item.service.name ?? ''}",
                discount: "${item.percentage ?? ''}",
                validDate: "${item.endDate ?? ''}",
                status: "${item.status ?? ''}",
                minPrice: "${item.minPrice ?? ''}",
                description: "${item.description ?? ''}",
                id: "${item.id ?? ''}",
                category: "Cancellation Offer",):Container(),
            );
          }),
    );
  }
  Widget _tabItemBundle(BuildContext context) {
    return PagedListView<int, allCouponsResp.Datum>(
      padding: EdgeInsets.zero,
      pagingController: controller.pagingController,
      builderDelegate: PagedChildBuilderDelegate<allCouponsResp.Datum>(
          itemBuilder: (context, item, index) {
            return InkWell(
              // behavior: HitTestBehavior.translucent,
              onTap: () {

                // controller.saloonAppointment = item;
                // Get.toNamed(SaloonAppointmentsNavigation.appointmentsDetail,
                //     id: SaloonAppointmentsNavigation.id);
              },
              child: "${item.category}"=="Bundle Offer"?_PopularItemView(
                context: context,
                imageOne: AppImages.Packages_img,
                dealID: "${item.couponCode ?? ''}",
                dealName: "${item.couponName ?? ''}",
                originalPrice: "${item.price ?? ''}",
                serviceName: "${item.service.name ?? ''}",
                discount: "${item.percentage ?? ''}",
                validDate: "${item.endDate ?? ''}",
                status: "${item.status ?? ''}",
                minPrice: "${item.minPrice ?? ''}",
                description: "${item.description ?? ''}",
                id: "${item.id ?? ''}",
                category: "Bundle Offer",):Container(),
            );
          }),
    );
  }

  Widget _PopularItemView({
    required BuildContext context,
    required String? imageOne,
    required String dealID,
    required String? dealName,
    required String? originalPrice,
    required String serviceName,
    required String? discount,
    required String validDate,
    required String status,
    required String minPrice,
    required String description,
    required String id,
    required String category,
  }) {
    return GestureDetector(
      onTap: () {
        //SALOON_ID = saloonId!;
        // Navigator.pushNamed(context, '/aboutSaloon');

        // Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomSheetReusable(value: "aboutSaloon")));
      },
      child: Container(
        margin: EdgeInsets.only(top: 15, right: 20),
        height: SizeConfig.screenHeight * .29,
        width: SizeConfig.eightyPercentWidth,
        child: Stack(
          children: <Widget>[
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                height: SizeConfig.screenHeight * .30,

                // width: ,
                child: ClipRRect(
                    borderRadius:  BorderRadius.all(Radius.circular(15)),
                    child: Image.asset(
                      imageOne!,
                      fit: BoxFit.cover,
                      width: SizeConfig.screenWidth,
                      height: 160.0,
                    )),
              ),
              // child: Image.asset(imageOne, fit: BoxFit.contain,),),
            ),

            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.blockSizeHorizontal * 2,
                  vertical: SizeConfig.blockSizeVertical * 2),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _rowItemText("Deal", 12, FontWeight.bold, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 0.25),
                      _rowItemText(dealID, 12, FontWeight.bold, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 5),
                      _rowItemText(
                          dealName, 16, FontWeight.normal, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 1),
                      _rowItemText(
                          serviceName, 16, FontWeight.bold, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 2),
                      _rowItemText(
                          "Minimum Price", 16, FontWeight.normal, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 1),
                      Row(
                        children: [
                          _rowItemText("$originalPrice\$", 16,
                              FontWeight.bold, ColorsX.white),
                          // horizontalSpace(SizeConfig.blockSizeVertical * 2),
                          // _rowItemLineThroughText("$originalPrice\$", 16,
                          //     FontWeight.bold, ColorsX.red_dashboard)
                        ],
                      )
                    ],
                  ),
                  Spacer(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      SizedBox(height: 10,),
                      _rowItemText("$discount%", 28, FontWeight.bold,
                          ColorsX.light_orange_text),
                      _rowItemText("OFF", 28, FontWeight.bold,
                          ColorsX.light_orange_text),
                      verticalSpace(SizeConfig.blockSizeVertical * 2),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.blockSizeHorizontal * 4,
                            vertical: SizeConfig.blockSizeVertical * 0.5),
                        decoration: BoxDecoration(
                            color: status=="Active"?ColorsX.active_green:ColorsX.red_dashboard,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                        child: _rowItemText(
                            status, 13, FontWeight.bold, ColorsX.white),
                      ),
                      verticalSpace(SizeConfig.blockSizeVertical * 2),
                      Row(
                        children: [
                          Image.asset(AppImages.check_green_ic),
                          _rowItemText("    Valid only", 16, FontWeight.normal,
                              ColorsX.white),
                        ],
                      ),
                      verticalSpace(SizeConfig.blockSizeVertical * 1),
                      _rowItemText(
                          validDate, 16, FontWeight.normal, ColorsX.white),
                    ],
                  )
                ],
              ),
            ),


            GestureDetector(
              onTap: (){
                print(dealName);
              },
              child: Align(
                alignment: Alignment.topRight,
              child: Container(

                margin: EdgeInsets.only(right: SizeConfig.screenWidth*.06),
                child: PopupMenuButton(
                  onSelected: (newValue){
                    print(newValue);
                    if(newValue==0){

                    //   required String dealID,
                    // required String? ,
                    // required String? originalPrice,
                    // required String serviceName,
                    // required String? discount,
                    // required String validDate,
                    // required String status,
                    // required String category,
                      controller.dealNameControllerEdit.text= "${dealName}";
                      controller.dealCodeControllerEdit.text= "${dealID}";
                      controller.priceControllerEdit.text= "${originalPrice}";
                      controller.minimumPriceControllerEdit.text= "${minPrice}";
                      controller.descriptionControllerEdit.text= "${description}";
                      controller.dealNameControllerEdit.text= "${dealName}";
                      controller.chosenCatrgory.value = "${category}";
                      controller.chosenDiscount.value = "${discount}";
                      controller.id = id;
                      Get.toNamed(DealsNavigation.editDeal,
                          id: DealsNavigation.id);
                    }
                    else if(newValue ==1){

                      controller.id = id;
                      Map<String, dynamic> apiParams = Map();
                      apiParams['id'] = controller.id;
                      controller.adminDeleteDeal(apiParams: apiParams);
                    }
                  },
                  icon: Icon(Icons.more_horiz, color: ColorsX.white,),
                  itemBuilder: (BuildContext context) => <PopupMenuEntry>[
                    const PopupMenuItem(value: 0 ,child: Text('Edit'),),
                    const PopupMenuItem(value: 1,child: Text('Delete')),
                  ],
                ),
              ),
          ),
            ),
            // GestureDetector(
            //   onTap: (){
            //     print("clicked");
            //     // return showMenuItems(context);
            //   },
            //   child: Align(
            //     alignment: Alignment.topRight,
            //     child: Container(
            //       margin: EdgeInsets.only(top: 2,right: SizeConfig.screenWidth*.10),
            //       child: Icon(Icons.more_horiz, color: ColorsX.white,),
            //     ),
            // ),
            // )
            // _containerStyling("4.0",4.0,14, FontWeight.w400),
          ],
        ),
      ),
    );
  }
  Widget _rowItemText(
      String? text1, double fontSize, FontWeight fontWeight, Color color) {
    return Text(
      '${text1}',
      style:
          TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
    );
  }

  Widget _rowItemLineThroughText(
      String? text1, double fontSize, FontWeight fontWeight, Color color) {
    return Text(
      '${text1}',
      style: TextStyle(
          color: color,
          fontWeight: fontWeight,
          fontSize: fontSize,
          decoration: TextDecoration.lineThrough),
    );
  }
}
