
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/saloon_appointment_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/appointments/saloon_appointment_item.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';


class SaloonAppointmentTabs extends GetView<SaloonAppointmentCTL> {

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Column(
        children: <Widget>[
          Container(
            height: 55,
            color: ColorsX.greydashboard,
            child: TabBar(
              onTap: (index){
                if (index == 0) {
                  controller.getSaloonAllBookings(1, 'New');
                  controller.pagingController.refresh();
                } else if (index == 1) {
                  controller.getSaloonAllBookings(1, 'Confirmed');
                  controller.pagingController.refresh();
                } else if (index == 2) {
                  controller.getSaloonAllBookings(1, 'Cancelled');
                  controller.pagingController.refresh();
                } else if (index == 3) {
                  controller.getSaloonAllBookings(1, 'Upcoming');
                  controller.pagingController.refresh();
                }

              },
              tabs: [

                Container(
                    width: SizeConfig.thirtyPercentWidth,
                    child: Text("New",textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400,),)
                ),
                Container(
                    width: SizeConfig.thirtyPercentWidth,
                    child: Text("Confirmed", textAlign: TextAlign.center,style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, ),)
                ),
                Container(
                    width: SizeConfig.thirtyPercentWidth,
                    child: Text("Cancelled", textAlign: TextAlign.center,style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, ),)
                ),
                Container(
                    width: SizeConfig.thirtyPercentWidth,
                    child: Text("Upcoming", textAlign: TextAlign.center,style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, ),)
                ),
              ],
              unselectedLabelColor: const Color(0xff000000),
              indicatorColor: Color(0xff70b4ff),
              labelColor: Color(0xff70b4ff),
              indicatorSize: TabBarIndicatorSize.tab,
              indicatorWeight: 3.0,
              indicatorPadding: EdgeInsets.only(top: 20),
              isScrollable: true,
            ),
          ),
          Expanded(
            child: TabBarView(
                controller: controller.tabController,
                physics: NeverScrollableScrollPhysics(),
                children: <Widget>[
                  Container(
                      child: SaloonAppointmentItem()
                  ),
                  Container(
                      child: SaloonAppointmentItem()
                  ),
                  Container(
                      child: SaloonAppointmentItem()
                  ),
                  Container(
                      child: SaloonAppointmentItem()
                  )
                ]
            ),
          ),
        ],
      ),
    );
  }
}
Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
  return Container(
    margin: EdgeInsets.only(top: top, left: left, right: right),
    child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
  );
}