import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import 'package:saloon_app/app/modules/admin/controllers/calender/calender_ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/saloon_appointment_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calenders_wrapper.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/dot_widget.dart';
import 'package:saloon_app/app/utils/size_config.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import 'appointments_wrapper.dart';

class SaloonRequestDetail extends GetView<SaloonAppointmentCTL>{
  String drawerValue="assets/images/chat.png";
  CalenderCTL _calenderCTL=Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsX.greydashboard,
      drawer: Theme(
        data: Theme.of(context).copyWith(
          canvasColor: Colors.transparent, //This will change the drawer background to blue.
          //other styles
        ),
        child: Drawer(
            child: Container(
              decoration: new BoxDecoration(
                  color: Color(0xff515C6F),
                  borderRadius: BorderRadius.only(bottomRight: Radius.circular(60), topRight: Radius.circular(60))
              ),
              child: ListView(
                // Important: Remove any padding from the ListView.
                padding: EdgeInsets.zero,
                children: <Widget>[
                  Container(
                    child: DrawerHeader(
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.only(topRight: Radius.circular(60)),
                          image: DecorationImage(
                              image: AssetImage("assets/images/popular.png"),
                              colorFilter: new ColorFilter.mode(Colors.black.withOpacity(0.6), BlendMode.dstATop),
                              fit: BoxFit.cover)
                      ),
                      child: Stack(
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(top: 60),
                            child: Center(
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    drawerImage(0xffffffff, "assets/images/avatar.png"),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                _rowItemForHeaderText("Lux Saloon", 24, FontWeight.w600, 0xffffffff, 60, 60, 0),
                                _rowItemForHeaderText("@luxsaloon", 14, FontWeight.w400, 0xffffffff, 0, 60, 0),
                              ]
                          ),
                        ],
                      ),
                    ),
                  ),

                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    title: _rowItemForHeaderText("Dashboard", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/home_dash.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/home_dash.png"),
                    ),//Image.asset("assets/images/home_dash.png"),
                    onTap: () {
                      Navigator.pushNamed(context, '/saloonDashboard');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/appoint_white.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/appoint_white.png"),
                    ),
                    title: _rowItemForHeaderText("Calendar", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                    onTap: () {
                      Navigator.pushNamed(context, '/calender');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/cart.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/cart.png"),
                    ),
                    title: _rowItemForHeaderText("Products", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                    onTap: () {
                      Navigator.pushNamed(context, '/products');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/group.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/group.png"),
                    ),
                    title: _rowItemForHeaderText("Manage Staff", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/manageStaff');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/user_white.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/user_white.png"),
                    ), //Image.asset("assets/images/user_white.png"),
                    title: _rowItemForHeaderText("Edit Profile", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/adminProfile');
                      // Navigator.push(context, MaterialPageRoute(builder: (context) => AdminProfile("assets/images/user_white.png"),));
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/disk.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/disk.png"),
                    ),
                    title: _rowItemForHeaderText("Requests", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/requests');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/chat.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/chat.png"),
                    ),
                    title: _rowItemForHeaderText("Messages", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/chatAdmin');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/bell_simple.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/bell_simple.png"),
                    ),
                    title: _rowItemForHeaderText("Notifications", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/notificationsAdmin');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color:drawerValue=="assets/images/stop.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/stop.png"),
                    ),
                    title: _rowItemForHeaderText("Deals & Offers", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/dealsOffers');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/info.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/info.png"),
                    ),
                    title: _rowItemForHeaderText("Help & Support", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      // Update the state of the app.
                      // ...
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: drawerValue=="assets/images/back_logout.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/back_logout.png"),
                    ),
                    title: _rowItemForHeaderText("Logout", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                    onTap: () {
                      // Update the state of the app.
                      // ...
                    },
                  ),
                ],
              ),
            )
        ),
      ),
      body: Stack(
        children: <Widget>[
          // Container(
          //   height: SizeConfig.screenHeight,
          //   width: SizeConfig.screenWidth,
          //   margin: EdgeInsets.only(top: 175),
          //   color: ColorsX.dashboardColor,
          // ),
          Container(
            width: SizeConfig.screenWidth,
            color: ColorsX.dashboardBG,
            child: new ListView(
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    InkWell(
                      child: Container(
                        width: SizeConfig.screenWidth*.15,
                        margin: EdgeInsets.only(top:  20),
                        child: Icon(Icons.arrow_back),
                      ),
                      onTap: (){
                        if(controller.isFromAdminCalender){
                          controller.isFromAdminCalender=false;
                          for (var d in _calenderCTL.uniqueDates) {
                            print('OnPageChanged...${d.toString().split(' ')[0]}');
                            _calenderCTL.isEventLoaded?[d.toString().split(' ')[0]] = false;
                          }
                          Get.offNamed(
                              SaloonAppointmentsNavigation.calenderMainScreen,
                              id: CalenderNavigation.id);
                        }else{
                          Get.offNamed(SaloonAppointmentsNavigation.appointmentsList,
                              id: SaloonAppointmentsNavigation.id);
                        }

                      },
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        // _search(context),
                        _rowItemForHeaderText("Appointment No:", 20, FontWeight.w900, 0xff515C6F, 20, 10, 0),
                        _rowItemForHeaderText("#${controller.saloonAppointment?.appointmentId}", 16, FontWeight.w700, 0xff8890A6, 5, 10, 0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(top: 30,left: 5),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0),
                                child: CachedNetworkImage(
                                  imageUrl: AppUrls.BASE_URL_IMAGE + '${controller.saloonAppointment?.user?.profilePic}',
                                  errorWidget: (context, url, error) =>
                                      Icon(Icons.error),
                                  fit: BoxFit.cover,
                                  width: 100,
                                  height: 100,
                                  placeholder: (context, url) => Container(
                                      height: 30,
                                      width: 30,
                                      child:
                                      Center(child: CircularProgressIndicator())),
                                ),
                              ),
                            ),
                            Container(
                                margin: EdgeInsets.only(top: 15),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    _rowItemForHeaderText("Appointment Status:", 12, FontWeight.w400, 0xff8890A6, 50, 10, 0),
                                    _rowItemForHeaderText("${controller.saloonAppointment?.status}", 12, FontWeight.w900, 0xffFF5667, 0, 10, 0),
                                  ],
                                )
                            ),
                          ],
                        ),
                        customerDetails(context, "Customer Name:", "${controller.saloonAppointment?.user?.name}"),
                        // customerDetails(context, "Gender:", "Male"),
                        customerDetails(context, "Age:", "${controller.saloonAppointment?.user?.dob}"),
                        customerDetails(context, "Booking Time:", "${controller.saloonAppointment?.appointmentDate.toString().split(' ')[0]} ${controller.saloonAppointment?.timeSlot}"),
                        // customerDetails(context, "Services:", "Haircut, Facial"),
                        customerDetails(context, "Barber Assigned:", "${controller.saloonAppointment?.staff?.name}"),//+'\$'),
                        Container(
                          height: 50,
                            margin: EdgeInsets.only(left: 20),
                            width: SizeConfig.screenWidth*.70,
                            child: MySeparator(color: Colors.grey)
                        ),
                        Container(
                          width: SizeConfig.screenWidth*.70,
                          margin: EdgeInsets.only(left: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              _rowItemForHeaderText("Services", 14, FontWeight.w700, 0xff8890A6, 10, 0, 0),
                              _rowItemForHeaderText("Price", 14, FontWeight.w700, 0xff8890A6, 10, 0, 0),
                            ],
                          ),
                        ),
                        serviceAndPrice(context, "${controller.saloonAppointment?.services?.name}", "${controller.saloonAppointment?.services?.price}"'\$'),
                        SizedBox(height: 20,),
                        Container(
                          width: SizeConfig.screenWidth*.70,
                          margin: EdgeInsets.only(left: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              _rowItemForHeaderText("Add-Ons", 14, FontWeight.w700, 0xff8890A6, 10, 0, 0),
                              _rowItemForHeaderText("Price", 14, FontWeight.w700, 0xff8890A6, 10, 0, 0),
                            ],
                          ),
                        ),
                        SizedBox(height: 20,),
                        //populate add ON
                        for(int i=0;i<(controller.saloonAppointment?.products?.length??0);i++)
                        addOnsAndPrice(context, "${controller.saloonAppointment?.products![i].quantity}","${controller.saloonAppointment?.products![i].product?.name}", "${controller.saloonAppointment?.products![i].product?.price}"'\$'),
                        SizedBox(height: 20,),
                        Container(
                          width: SizeConfig.screenWidth*.70,
                          margin: EdgeInsets.only(left: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              _rowItemForHeaderText("Total", 14, FontWeight.w700, 0xff8890A6, 10, 0, 0),
                              _rowItemForHeaderText("${controller.saloonAppointment?.totalPrice}"'\$', 14, FontWeight.w700, 0xff8890A6, 10, 0, 0),
                            ],
                          ),
                        ),
                        SizedBox(height: 20,),
                        InkWell(
                            onTap: ()async{
                              String id= controller.saloonAppointment!.id!;
                            final res = await  controller.cancelOrAcceptBooking(id: id, status: 'Accepted');
                              if(res){
                                Functions.showSimpleDialog(title: 'Info', msg: 'Appointment accepted successfully.');
                              }
                            },
                            child: Button(context, "Accept Request", 0xff70b4ff)),
                        SizedBox(height: 20,),
                        InkWell(
                            onTap: ()async{
                              String id= controller.saloonAppointment!.id!;
                            final res = await  controller.cancelOrAcceptBooking(id: id, status: 'Cancelled');
                            if(res){
                              Functions.showSimpleDialog(title: 'Info', msg: 'Appointment cancelled successfully.');
                            }
                            },
                            child: Button(context, "Ignore Request", 0xffFF5667)),
                        SizedBox(height: 40,),
                        Container(
                          width: SizeConfig.seventyFivePercentWidth,
                          child: Text("Return to Appointments", textAlign: TextAlign.center, style: TextStyle(color: Color(0xff70B4FF), fontSize: 14, fontWeight: FontWeight.w700),),
                        ),
                        SizedBox(height: 20,),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  Widget Button(BuildContext context, String text, int colorCode){
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 10, right: 10),
      decoration: new BoxDecoration(
        color: Color(colorCode),
        borderRadius: BorderRadius.all(Radius.circular(10)),
        boxShadow: [
          BoxShadow(
            color: text=="Accept Request"?ColorsX.blue_button_color:Colors.red,
            blurRadius: 6,
            offset: Offset(1, 1), // Shadow position
          ),
        ],
      ),
      padding: EdgeInsets.symmetric(vertical: 13),
      child: Text(text, textAlign: TextAlign.center,style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: ColorsX.white),),// _rowItemForHeaderText(text, 16, FontWeight.w700, 0xffffffff, 0, 0, 0),
    );
  }
  Widget customerDetails(BuildContext context, String text1, String text2){
    return Container(
      width: SizeConfig.seventyPercentWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(child: _rowItemForHeaderText(text1, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0),),
          Expanded(child: _rowItemForHeaderText(text2, 13, FontWeight.w400, 0xff515C6F, 10, 10, 0),),

          // Expanded(child: _rowItemForHeaderText(text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0)),
          // Expanded(child: _rowItemForHeaderText(text2, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0)),
        ],
      ),
    );
  }
  Widget serviceAndPrice(BuildContext context, String text1, String text2){
    return Container(
      width: SizeConfig.seventyPercentWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0),
          _rowItemForHeaderText(text2, 13, FontWeight.w400, 0xff8890A6, 10, 10, 0),

          // Expanded(child: _rowItemForHeaderText(text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0)),
          // Expanded(child: _rowItemForHeaderText(text2, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0)),
        ],
      ),
    );
  }
  Widget addOnsAndPrice(BuildContext context, String numberOfItems, String text1, String text2){
    return Container(
      width: SizeConfig.seventyPercentWidth,
      margin: EdgeInsets.only(left: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 6),
            decoration: BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(6.0),
              child: _rowItemForHeaderText(numberOfItems, 12, FontWeight.w400, 0xffffffff, 0, 0, 0),
            ),
          ),
          _rowItemForHeaderText(text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0),
          Expanded(child: Container()),
          _rowItemForHeaderText(text2, 13, FontWeight.w400, 0xff8890A6, 10, 10, 0),

          // Expanded(child: _rowItemForHeaderText(text1, 14, FontWeight.w400, 0xff8890A6, 10, 10, 0)),
          // Expanded(child: _rowItemForHeaderText(text2, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0)),
        ],
      ),
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
  Widget drawerImage(int colorCode, String imagePath ){
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath=="assets/images/avatar.png"?Align(
            alignment: Alignment.bottomRight,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
              margin: EdgeInsets.only(left: 2, top: 2),
              decoration: new BoxDecoration(
                color: ColorsX.rating_dashboard,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(50), bottomRight: Radius.circular(30)),
              ),
              child: _rowItemForHeaderText(" 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
            ),
          ):Container(),
        ],
      ),
    );
  }
}