import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/admin/views/bar_graph.dart';
import 'package:saloon_app/app/modules/admin/views/second_graph.dart';
import 'package:saloon_app/app/modules/admin/views/services_chart.dart';
import 'package:saloon_app/app/utils/colors.dart';

import 'package:charts_flutter/flutter.dart' as charts;
import 'package:saloon_app/app/utils/size_config.dart';

class TopGraph extends StatefulWidget{
  @override
  _TopGraph createState()=> _TopGraph();
}
class _TopGraph extends State<TopGraph>{
  List<Color> gradientColors = [
    const Color(0xff70b4ff),
    // const Color(0xff70b4ff),
  ];

  bool showAvg = false;

  @override
  Widget build(BuildContext context) {
    List<String> myList =["2014","2015","2016","2017","2018"];
    bool animate = false;
    return Scaffold(
      backgroundColor: ColorsX.dashboardColor,
      body:
      SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only( left: 15),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  _rowItemForHeaderText("Total Sales", 14, FontWeight.w900, 0xff8890A6, 10, 0, 0),
                  Container(
                    decoration: new BoxDecoration(
                      color: ColorsX.blue_text_color,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                    child: Text("Export", style: TextStyle(color: ColorsX.white, fontWeight: FontWeight.w400, fontSize: 10),),// _rowItemForHeaderText(, 10, FontWeight.w400, 0xffffffff, 0, 10, 0),
                  ),
                ],
              ),
              AspectRatio(
                aspectRatio: 1.20,
                child: Container(
                  margin: EdgeInsets.only(left: 0, top: 10, right: 10),
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(
                        Radius.circular(18),
                      ),
                      color: Color(0xffffffff)),
                  child: Padding(
                    padding: const EdgeInsets.only(right: 2.0, left: 2.0, top: 10, bottom: 12),
                    child: LineChart(
                      showAvg ? avgData() : mainData(),
                    ),
                  ),
                ),
              ),
              // Stats(),
              SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  _rowItemForHeaderText("Average Sales", 14, FontWeight.w900, 0xff8890A6, 10, 0, 0),
                  Container(
                    decoration: new BoxDecoration(
                      color: ColorsX.blue_text_color,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                    child: Text("Export", style: TextStyle(color: ColorsX.white, fontWeight: FontWeight.w400, fontSize: 10),),// _rowItemForHeaderText(, 10, FontWeight.w400, 0xffffffff, 0, 10, 0),
                  ),
                ],
              ),
              SecondGraph(),
              SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  _rowItemForHeaderText("Client Retention", 14, FontWeight.w900, 0xff8890A6, 10, 0, 0),
                  Container(
                    decoration: new BoxDecoration(
                      color: ColorsX.blue_text_color,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                    child: Text("Export", style: TextStyle(color: ColorsX.white, fontWeight: FontWeight.w400, fontSize: 10),),// _rowItemForHeaderText(, 10, FontWeight.w400, 0xffffffff, 0, 10, 0),
                  ),
                ],
              ),
              SizedBox(height: 10,),
              BarGraph(_createSampleData()),
              SizedBox(height: 10,),
              _rowItemForHeaderText("Total Services",  14, FontWeight.w900, 0xff8890A6, 10, 0, 0),
              SizedBox(height: 10,),
              ServicesChart(_createSampleDataForPieChart(),),
              SizedBox(height: 10,),
              SizedBox(height: 10,),
              // BarGraph(myList),
              // BarGraph(seriesList: myList, animate: animate,),
              // BarGraph("2014",5),
            ],
          ),
        ),
      ),
    );
  }
  LineChartData mainData() {
    return LineChartData(
      gridData: FlGridData(
        show: true,
        drawVerticalLine: true,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,

          getTextStyles: (context, value) =>
          const TextStyle(color: Color(0xff67727d), fontSize: 10,fontWeight: FontWeight.w400),
          getTitles: (value) {
            switch (value.toInt()) {

              case 0:
                return '18 \n Dec';
              case 2:
                return '19 \n Dec';
              case 4:
                return '1 \n Han';
              case 6:
                return '12 \n Jan';
              case 8:
                return '2 \n Feb';
              case 10:
                return '12 \n Mar';
              case 12:
                return '22 \n Mar';
            }
            return '';
          },
          margin: 8,
        ),
        rightTitles: SideTitles(
          showTitles: true,

          getTextStyles: (context, value) =>
          const TextStyle(color: Color(0xff67727d), fontSize: 10,fontWeight: FontWeight.w400),

          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '122';
              case 2:
                return '124';
              case 4:
                return '126';
              case 6:
                return '128';
              case 8:
                return '130';
              case 10:
                return '132';
            }
            return '';
          },
          reservedSize: 28,
          margin: 4,
        ),
        leftTitles: SideTitles(
          showTitles: true,

          getTextStyles: (context, value) =>
          const TextStyle(color: Color(0xff67727d), fontSize: 10,fontWeight: FontWeight.w400),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '';
              case 1:
                return '';
              case 2:
                return '';
              case 3:
                return '';
              case 4:
                return '';
              case 5:
                return '';
              case 6:
                return '';
              case 7:
                return '';
              case 8:
                return '';
              case 9:
                return '';
              case 10:
                return '';
              case 11:
                return '';
              case 10:
                return '';
            }
            return '';
          },
          reservedSize: 28,
          margin: 4,
        ),
      ),
      borderData:
      FlBorderData(show: true, border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 11,
      lineBarsData: [
        LineChartBarData(
          spots: [
            FlSpot(0, 2),
            FlSpot(2.6, 4),
            FlSpot(3.9, 1),
            FlSpot(5.8, 5.1),
            FlSpot(8, 2),
            FlSpot(9.5, 7.5),
            FlSpot(11, 6.3),
          ],
          isCurved: true,
          colors: gradientColors,
          barWidth: 2,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(
            show: true,
            colors: gradientColors.map((color) => color.withOpacity(0.4)).toList(),
          ),
        ),
      ],
    );
  }

  LineChartData avgData() {
    return LineChartData(
      lineTouchData: LineTouchData(enabled: false),
      gridData: FlGridData(
        show: true,
        drawHorizontalLine: true,
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,

          getTextStyles: (context, value) =>
          const TextStyle(color: Color(0xff67727d), fontSize: 10,fontWeight: FontWeight.w400),
          getTitles: (value) {
            switch (value.toInt()) {

              case 0:
                return '18 \n Dec';
              case 2:
                return '19 \n Dec';
              case 4:
                return '1 \n Han';
              case 6:
                return '12 \n Jan';
              case 8:
                return '2 \n Feb';
              case 10:
                return '12 \n Mar';
              case 12:
                return '22 \n Mar';
            }
            return '';
          },
          margin: 8,
        ),
        rightTitles: SideTitles(
          showTitles: true,

          getTextStyles: (context, value) =>
          const TextStyle(color: Color(0xff67727d), fontSize: 10,fontWeight: FontWeight.w400),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '122';
              case 2:
                return '124';
              case 4:
                return '126';
              case 6:
                return '128';
              case 8:
                return '130';
              case 10:
                return '132';
            }
            return '';
          },
          reservedSize: 28,
          margin: 12,
        ),
      ),
      borderData:
      FlBorderData(show: true, border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 6,
      lineBarsData: [
        LineChartBarData(
          spots: [
            FlSpot(0, 3.44),
            FlSpot(2.6, 3.44),
            FlSpot(4.9, 3.44),
            FlSpot(6.8, 3.44),
            FlSpot(8, 3.44),
            FlSpot(9.5, 3.44),
            FlSpot(11, 3.44),
          ],
          isCurved: true,
          colors: [
            ColorTween(begin: gradientColors[0], end: gradientColors[1]).lerp(0.2)!,
            ColorTween(begin: gradientColors[0], end: gradientColors[1]).lerp(0.2)!,
          ],
          barWidth: 5,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(show: true, colors: [
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!
                .withOpacity(0.1),
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!
                .withOpacity(0.1),
          ]),
        ),
      ],
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
  /// Create one series with sample hard coded data.
  static List<charts.Series<OrdinalSales, String>> _createSampleData() {

    final data = [
      new OrdinalSales('Week 01', 25),
      new OrdinalSales('Week 02', 50),
      new OrdinalSales('Week 03', 75),
      new OrdinalSales('Week 04', 95),
    ];

    return [
      new charts.Series<OrdinalSales, String>(
        id: 'Sales',
        colorFn: (_, __) => charts.ColorUtil.fromDartColor(ColorsX.rating_dashboard),
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        data: data,
      )
    ];
  }

  /// Create one series with sample hard coded data.
  static List<charts.Series<LinearSales, int>> _createSampleDataForPieChart() {
    final data = [
      new LinearSales(0, 100),
      new LinearSales(1, 75),
      new LinearSales(2, 25),
      new LinearSales(3, 5),
    ];

    return [
      new charts.Series<LinearSales, int>(
        id: 'Sales',
        domainFn: (LinearSales sales, _) => sales.year,
        measureFn: (LinearSales sales, _) => sales.sales,
        data: data,
        // Set a label accessor to control the text of the arc label.
        labelAccessorFn: (LinearSales row, _) => '${row.year}: ${row.sales}',
      )
    ];
  }
}
class OrdinalSales {
  final String year;
  final int sales;

  OrdinalSales(this.year, this.sales);
}