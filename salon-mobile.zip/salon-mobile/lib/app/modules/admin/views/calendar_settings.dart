import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/drop_down_without_border.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/side_menu.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class CalenderSaloon extends StatefulWidget{
  String drawerValue="assets/images/appoint_white.png";
  @override
  _CalenderSettings createState()=> _CalenderSettings();
}
class _CalenderSettings extends State<CalenderSaloon>{
  List<String> timeLimit = ['Beauty Shop & SPA','Beauty Shop & SPA','Beauty Shop & SPA' ];
  List<String> discount = ['Working Staff','Working Staff','Working Staff'];
  List<String> service = ['Today - Wed, 27 Apr, 2021','28 Apr, 2021'];
  List<String> timeTable = ['Daily','Weekends'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsX.greydashboard,
      drawer: Theme(
        data: Theme.of(context).copyWith(
          canvasColor: Colors.transparent, //This will change the drawer background to blue.
          //other styles
        ),
        child: Drawer(
            child: Container(
              decoration: new BoxDecoration(
                  color: Color(0xff515C6F),
                  borderRadius: BorderRadius.only(bottomRight: Radius.circular(60), topRight: Radius.circular(60))
              ),
              child: ListView(
                // Important: Remove any padding from the ListView.
                padding: EdgeInsets.zero,
                children: <Widget>[
                  Container(
                    child: DrawerHeader(
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.only(topRight: Radius.circular(60)),
                          image: DecorationImage(
                              image: AssetImage("assets/images/popular.png"),
                              colorFilter: new ColorFilter.mode(Colors.black.withOpacity(0.6), BlendMode.dstATop),
                              fit: BoxFit.cover)
                      ),
                      child: Stack(
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(top: 60),
                            child: Center(
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    drawerImage(0xffffffff, "assets/images/avatar.png"),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                _rowItemForHeaderText("Lux Saloon", 24, FontWeight.w600, 0xffffffff, 60, 60, 0),
                                _rowItemForHeaderText("@luxsaloon", 14, FontWeight.w400, 0xffffffff, 0, 60, 0),
                              ]
                          ),
                        ],
                      ),
                    ),
                  ),

                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    title: _rowItemForHeaderText("Dashboard", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/home_dash.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/home_dash.png"),
                    ),//Image.asset("assets/images/home_dash.png"),
                    onTap: () {
                      Navigator.pushNamed(context, '/saloonDashboard');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/appoint_white.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/appoint_white.png"),
                    ),
                    title: _rowItemForHeaderText("Calendar", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                    onTap: () {
                      Navigator.pushNamed(context, '/calender');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/cart.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/cart.png"),
                    ),
                    title: _rowItemForHeaderText("Products", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                    onTap: () {
                      Navigator.pushNamed(context, '/products');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/group.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/group.png"),
                    ),
                    title: _rowItemForHeaderText("Manage Staff", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/manageStaff');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/user_white.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/user_white.png"),
                    ), //Image.asset("assets/images/user_white.png"),
                    title: _rowItemForHeaderText("Edit Profile", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/adminProfile');
                      // Navigator.push(context, MaterialPageRoute(builder: (context) => AdminProfile("assets/images/user_white.png"),));
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/disk.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/disk.png"),
                    ),
                    title: _rowItemForHeaderText("Requests", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/requests');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/chat.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/chat.png"),
                    ),
                    title: _rowItemForHeaderText("Messages", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/chatAdmin');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/bell_simple.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/bell_simple.png"),
                    ),
                    title: _rowItemForHeaderText("Notifications", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/notificationsAdmin');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/stop.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/stop.png"),
                    ),
                    title: _rowItemForHeaderText("Deals & Offers", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      Navigator.pushNamed(context, '/dealsOffers');
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/info.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/info.png"),
                    ),
                    title: _rowItemForHeaderText("Help & Support", 16, FontWeight.w400, 0xffffffff, 0, 0, 0) ,
                    onTap: () {
                      // Update the state of the app.
                      // ...
                    },
                  ),
                  ListTile(
                    visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                    leading: Container(
                      height: 40,
                      width: 40,
                      decoration: new BoxDecoration(
                        color: widget.drawerValue=="assets/images/back_logout.png"?ColorsX.dashboardHome:Colors.transparent,
                        borderRadius: BorderRadius.all(Radius.circular(15)),
                      ),
                      child: Image.asset("assets/images/back_logout.png"),
                    ),
                    title: _rowItemForHeaderText("Logout", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                    onTap: () {
                      // Update the state of the app.
                      // ...
                    },
                  ),
                ],
              ),
            )
        ),
      ),
      body: Stack(
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 175),
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            // color: ColorsX.dashboardColor,
          ),
          Container(
            width: SizeConfig.screenWidth,
            height: SizeConfig.screenHeight,
            child: new ListView(
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            // LeftList(),
                            // LeftListOther(),
                            SideMenu("assets/images/appoint_white.png"),
                          ],
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        SizedBox(height: 10,),
                        _textAndIcon(context, "Calendar", AppImages.back),
                        SizedBox(height: 10,),
                        _rowItemForHeaderText("Filter Settings", 16, FontWeight.w400, 0xff8890A6, 10, 15, 0),
                        SizedBox(height: 10,),
                        _rowItemForHeaderText("Filter your calendar here", 14, FontWeight.w700, 0xff8890A6, 10, 15, 0),
                        dropDownContainer(context, timeLimit, .75,'Beauty Shop & SPA'),
                        SizedBox(height: 10,),
                        dropDownContainer(context,  discount, .75,'Working Staff'),
                        SizedBox(height: 10,),
                        dropDownContainer(context, service, .75,'Today - Wed, 27 Apr, 2021'),
                        SizedBox(height: 10,),
                        dropDownContainer(context,  timeTable, .75,'Daily'),
                        // SizedBox(height: 10,),
                        // simpleContainer(context, "Setting", AppImages.setting_round),
                        // SizedBox(height: 10,),
                        // deleteButton(context, "Add New",0xff70B4FF),
                        SizedBox(height: 10,),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Widget dateDropDown(BuildContext context, String firstText,  String secondText, List<String> values, String text){
  //   return Container(
  //     width: SizeConfig.eightyPercentWidth,
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //       children: <Widget>[
  //         dropDownContainer(context,  date, .35, text),
  //         dropDownContainer(context,  date, .35, text),
  //       ],
  //     ),
  //   );
  // }
  Widget dropDownContainer(BuildContext context, List<String> values, double width, String text){
    return Container(
      width: SizeConfig.screenWidth*width,
      margin: EdgeInsets.only(left: 15, top: 10),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          DropDownWithoutBorder(values, text),
        ],
      ),
    );
  }
  Widget simpleContainer(BuildContext context, String firstText, String imagePath){
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(left: 15,top: 10, ),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(bottom: 15, top: 5),
            child: _rowItemForHeaderText(firstText, 14, FontWeight.w600, 0xff515C6F, 10, 10, 0),
          ),
          Container(
            margin: EdgeInsets.only(top: 12, right: 10),
            child: Image.asset(imagePath),
          ),
        ],
      ),
    );
  }
  Widget deleteButton(BuildContext context, String text, int colorCode){
    return GestureDetector(
      child: Container(
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(left: 15, top: 15),
        decoration: new BoxDecoration(
          color: Color(colorCode),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: [
            BoxShadow(
              color: text=="Add New"?ColorsX.blue_button_color:Colors.red,
              blurRadius: 6,
              offset: Offset(1, 1), // Shadow position
            ),
          ],
        ),
        padding: EdgeInsets.symmetric(vertical: 13),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(child: SizedBox()),
            Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700,color: Color(0xffffffff)),),
            Expanded(child: SizedBox()),
            Icon(Icons.add_circle, color: ColorsX.white,),
            SizedBox(width: 10,)
          ],
        ),
        // child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700,color: Color(0xffffffff)),)
      ),
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
  Widget _textAndIcon(BuildContext context, String text, String imagePath){
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
      margin: EdgeInsets.only(top: 20, left: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(text, 20, FontWeight.w900, 0xff515C6F, 0, 0, 0),

          Image.asset(imagePath, height: 21, width: 17,),
        ],
      ),
    );
  }
  Widget drawerImage(int colorCode, String imagePath ){
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath=="assets/images/avatar.png"?Align(
            alignment: Alignment.bottomRight,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
              margin: EdgeInsets.only(left: 2, top: 2),
              decoration: new BoxDecoration(
                color: ColorsX.rating_dashboard,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(50), bottomRight: Radius.circular(30)),
              ),
              child: _rowItemForHeaderText(" 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
            ),
          ):Container(),
        ],
      ),
    );
  }
}