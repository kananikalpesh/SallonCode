import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/modules/admin/controllers/add_on/add_on_ctl.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/add_ons_wrapper.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/size_config.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:saloon_app/app/data/model/admin/add_ons/add_ons_by_category_res.dart'
    as addOns;

class AddOnsItems extends GetView<AddOnCTL> {
  String img = '';

  @override
  Widget build(BuildContext context) {
    return PagedListView<int, addOns.Product>(
      padding: EdgeInsets.zero,
      pagingController: controller.pagingController,
      builderDelegate: PagedChildBuilderDelegate<addOns.Product>(
          itemBuilder: (context, item, index) {
        if (item.photos != null) {
          if (item.photos!.isNotEmpty) {
            img = item.photos![0];
          } else {
            img = '';
          }
        } else {
          img = '';
        }
        return InkWell(
          // behavior: HitTestBehavior.translucent,
          onTap: () {
            controller.productItem = item;
            controller.populateAddONsDataForEdit();
            Get.toNamed(AddOnsNavigation.addOnsDetail, id: AddOnsNavigation.id);
          },
          child: imageHere(
              context,
              "${item.profilePic}",
              "${item.name}",
              double.parse('${item.rating}'),
              "${item.price}",
              '${item.quantity}'),
        );
      }),
    );
  }

  Widget imageHere(BuildContext context, String imagePath, String service,
      double rating, String price, var quantity) {
    return Container(
      height: 220,
      child: Stack(
        // crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: 10, right: 10, top: 125),
            decoration: BoxDecoration(
                color: ColorsX.white,
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10),
                    bottomLeft: Radius.circular(10))),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    _rowItemForHeaderText(
                        service, 14, FontWeight.w700, 0xff8890A6, 25, 10, 0),
                    Expanded(child: Container()),
                    Container(
                      margin: EdgeInsets.only(left: 10, top: 30),
                      child: SizedBox(
                        height: 20,
                        child: RatingBar.builder(
                          initialRating: rating,
                          minRating: 1,
                          direction: Axis.horizontal,
                          allowHalfRating: true,
                          itemSize: 10,
                          ignoreGestures: true,
                          tapOnlyMode: false,
                          itemCount: 5,
                          itemPadding: EdgeInsets.symmetric(horizontal: 2.0),
                          itemBuilder: (context, _) => Icon(
                            Icons.star,
                            color: Colors.amber,
                          ),
                          onRatingUpdate: (rating) {
                            print(rating);
                          },
                        ),
                      ),
                    ),
                    _rowItemForHeaderText(rating.toString(), 14,
                        FontWeight.w700, 0xff8890A6, 28, 10, 10),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    _rowItemForHeaderText(
                        price, 14, FontWeight.w700, 0xff000000, 10, 10, 10),
                    Expanded(child: Container()),
                    _rowItemForHeaderText(
                        "In-Stock", 14, FontWeight.w700, 0xff8890A6, 10, 0, 0),
                    _rowItemForHeaderText("$quantity", 14, FontWeight.w700,
                        0xff000000, 10, 5, 10),
                  ],
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Container(
                height: 140,
                width: SizeConfig.screenWidth * .75,
                margin: EdgeInsets.only(top: 10, left: 10),
                child: Stack(
                  children: <Widget>[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(15.0),
                      child: CachedNetworkImage(
                        imageUrl: AppUrls.BASE_URL_IMAGE + '${imagePath}',
                        errorWidget: (context, url, error) => Icon(Icons.error),
                        fit: BoxFit.fill,
                        height: 140,
                        width: SizeConfig.screenWidth * .75,
                        placeholder: (context, url) => Container(
                            height: 140,
                            width: SizeConfig.screenWidth * .75,
                            child: Center(child: CircularProgressIndicator())),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Container(
                        margin: EdgeInsets.only(right: 10, bottom: 10),
                        decoration: new BoxDecoration(
                          color: ColorsX.blue_button_color,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(15),
                              bottomRight: Radius.circular(15)),
                        ),
                        padding:
                            EdgeInsets.symmetric(horizontal: 15, vertical: 6),
                        child: _rowItemForHeaderText(
                            "New", 10, FontWeight.w700, 0xffffffff, 0, 0, 0),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget deleteButton(BuildContext context, String text) {
    return GestureDetector(
      child: Container(
          width: SizeConfig.screenWidth * .85,
          margin: EdgeInsets.only(left: 10, top: 15, bottom: 30),
          decoration: new BoxDecoration(
            color: ColorsX.blue_button_color,
            borderRadius: BorderRadius.all(Radius.circular(10)),
            boxShadow: [
              BoxShadow(
                color: text == "View More"
                    ? ColorsX.blue_button_color
                    : Colors.red,
                blurRadius: 6,
                offset: Offset(1, 1), // Shadow position
              ),
            ],
          ),
          padding: EdgeInsets.symmetric(vertical: 13),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Color(0xffffffff)),
          )),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }
}
