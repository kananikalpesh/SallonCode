// ignore_for_file: non_constant_identifier_names, file_names

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-add-slot/admin-saloon-controller.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calenders_wrapper.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class AdminBookingDetailsFirst extends GetView<AdminSaloonController> {
  bool loadingdone = false;
  @override
  Widget build(BuildContext context) {

    if(controller.selectedAddOnsIDSList.isNotEmpty) {
      for (int indx = 0; indx <
          controller.selectedAddOnsIDSList.length; indx++) {
        controller.selectedProductsQuantityList.add("1");
      }
      print(controller.selectedProductsQuantityList);
    }
    return Scaffold(
      // bottomNavigationBar: BottomSheetReusable(value: "Appointments",),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: <Widget>[
                // Container(
                //   height: SizeConfig.screenHeight * .70,
                //   decoration: BoxDecoration(
                //       color: ColorsX.lightStackColor,
                //       borderRadius: BorderRadius.only(
                //           bottomLeft: Radius.circular(20),
                //           bottomRight: Radius.circular(20))),
                // ),
                // Container(
                //   width: SizeConfig.screenWidth,
                //   height: SizeConfig.screenHeight * .4,
                //   margin: EdgeInsets.only(top: 0),
                //   child: Image.asset(
                //     "assets/images/stack_bg.png",
                //     fit: BoxFit.fill,
                //   ),
                // ),

                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[

                      Align(
                        alignment: Alignment.topLeft,
                        child: InkWell(
                          onTap: () {

                            Get.toNamed(
                                CalenderNavigation.AdminBookAppointmentTwo,
                                id: CalenderNavigation.id);
                          },
                          child: Container(
                            margin: EdgeInsets.only(
                                top: SizeConfig.screenHeight * .05, left: 15),
                            child: Icon(
                              Icons.arrow_back,
                              color: ColorsX.dash_textColordark1,
                            ),
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topLeft,
                        child: InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Container(
                            margin: EdgeInsets.only(
                                top: SizeConfig.screenHeight * .05, left: 0),
                            child: _rowItemForHeaderText("Add Slot", 18, FontWeight.w900, 0xff8890A6, 0, SizeConfig.screenWidth*.08, 0),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    // getImage(context, "assets/images/popular.png"),
                    _rowItemForHeaderText(
                        "Make Reservation",
                        14,
                        FontWeight.w400,
                        0xff000000,
                        SizeConfig.screenHeight * .14,
                        SizeConfig.screenWidth * .18,
                        0),
                    Row(
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              top: 10, left: SizeConfig.screenWidth*.18),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(15.0),
                            child: CachedNetworkImage(
                              imageUrl: AppUrls.BASE_URL_IMAGE + '${controller.getSaloonDetailsModel?.saloon?.profilePic}',
                              errorWidget: (context, url, error) => Icon(Icons.error),
                              fit: BoxFit.cover,
                              width: 150,
                              height: 110,
                              placeholder: (context, url) => Container(
                                  height: 30,
                                  width: 30,
                                  child: Center(child: CircularProgressIndicator())),
                            ),
                            // Image.asset(
                            //   "assets/images/popular.png",
                            //   fit: BoxFit.cover,
                            //   height: 110,
                            //   width: 150,
                            // ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.only(top: 10),
                            padding: EdgeInsets.only(
                                left: SizeConfig.blockSizeHorizontal * 5),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    margin: EdgeInsets.only(top: 5),
                                    child: _rowItemForHeaderText(
                                        "${controller.getSaloonDetailsModel?.saloon?.name}",
                                        14,
                                        FontWeight.w700,
                                        0xff000000,
                                        0,
                                        0,
                                        0) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                ),
                                Container(
                                    margin: EdgeInsets.only(
                                      top: 5,
                                    ),
                                    child: _rowItemForHeaderText(
                                        "${controller.getSaloonDetailsModel?.saloon?.address?.address??''}",
                                        12,
                                        FontWeight.w400,
                                        0xff707070,
                                        0,
                                        0,
                                        0) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                ),
                                Row(
                                  children: [
                                    Container(
                                        margin: EdgeInsets.only(
                                          top: 5,
                                        ),
                                        child: Icon(
                                          Icons.location_pin,
                                          color: ColorsX.subBlack,
                                        ) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                    ),
                                    Container(
                                        margin: EdgeInsets.only(
                                          top: 5,
                                        ),
                                        child: _rowItemForHeaderText(
                                            "12km",
                                            12,
                                            FontWeight.w400,
                                            0xff707070,
                                            0,
                                            0,
                                            0) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Container(
                                        margin: EdgeInsets.only(
                                          top: 5,
                                        ),
                                        child: Icon(
                                          Icons.star,
                                          color: ColorsX.yellow,
                                        ) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                    ),
                                    Container(
                                        margin: EdgeInsets.only(
                                          top: 5,
                                        ),
                                        child: _rowItemForHeaderText(
                                            "${controller.getSaloonDetailsModel?.saloon?.rating}",
                                            12,
                                            FontWeight.w400,
                                            0xff707070,
                                            0,
                                            0,
                                            0) //Text(,style: TextStyle(color: ColorsX.myblack, fontWeight: FontWeight.w700, fontSize: 14),),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),

                    _dateTimer(context, controller.chosenDateTimeFromSetAppointmentWithDashes.isEmpty?"${controller.getTodaysDate()} @ ${controller.selectedSlot}":
                    "${controller.chosenDateTimeFromSetAppointmentWithDashes} @ ${controller.selectedSlot}"),
                  ],
                ),
              ],
            ),
            Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18, right: 10,top: 10),
              child: _itemTextRow("Services", "Price", ColorsX.black),
            ),
            Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18, right: 10, top: 10),
              child: ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  shrinkWrap: true,
                  itemCount: controller.selectedServicesList.length,
                  itemBuilder: (BuildContext context, int index) {
                    return Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: SizeConfig.blockSizeVertical * 0.5),
                      child: _itemTextRow(
                          controller.selectedServicesList[index], controller.selectedServicesPriceList[index].toString(), ColorsX.greytext),
                    );
                  }),
            ),
            Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18, top: 10, right: 10),
              child: _itemTextRow("Service Total", "${controller.getSumOfServices()}", ColorsX.black),
            ),
            Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18,right: 10),
              child: Padding(
                padding: EdgeInsets.symmetric(
                    vertical: SizeConfig.blockSizeVertical),
                child: Container(
                  height: SizeConfig.blockSizeVertical * 0.1,
                  color: ColorsX.subBlack,
                ),
              ),
            ),
            controller.selectedAddOnsList.length.isGreaterThan(0)?Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18,top: 10,right: 10),
              child: _itemTextRow("Add-ons", "Price", ColorsX.black),
            ):Container(),
            controller.selectedAddOnsList.length.isGreaterThan(0)?Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18,top: 10,right: 10),
              child: ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  shrinkWrap: true,
                  itemCount: controller.selectedAddOnsList.length,
                  itemBuilder: (BuildContext context, int index) {
                    return Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: SizeConfig.blockSizeVertical * 0.5),
                      child: _addOnItemTextRow(index,
                          controller.selectedProductsQuantityList[index], "${controller.selectedAddOnsList[index]}", controller.selectedAddOnsPriceList[index].toString(), ColorsX.greytext),
                    );
                  }),
            ):Container(),
            controller.selectedAddOnsList.length.isGreaterThan(0)?Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18, top: 10, right: 10),
              child: Container(
                height: SizeConfig.blockSizeVertical * 0.1,
                color: ColorsX.subBlack,
              ),
            ):Container(),
            controller.selectedAddOnsList.length.isGreaterThan(0)?Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18,top: 10, right: 10),
              child: _itemTextRow("Add-Ons Total", "${controller.getSumOfAddOns()}", ColorsX.black),
            ):Container(),
            Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18,right: 10,top: 10),
              child: _itemTextRow("Total Bill", (int.parse(controller.getSumOfServices())+int.parse(controller.getSumOfAddOns())).toString(), ColorsX.black),
            ),
            Button(context),
            verticalSpace(SizeConfig.blockSizeVertical * 2),
          ],
        ),
      ),
    );
  }

  Row _itemTextRow(String text1, String text2, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          text1,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
        Text(
          text2,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ],
    );
  }

  Row _addOnItemTextRow(int position,String text1, String text2, String text3, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            text2,
            style: TextStyle(
                color: ColorsX.subBlack,
                fontWeight: FontWeight.bold,
                fontSize: 16),
          ),
        ),
        // Text(
        //   text2,
        //   style: TextStyle(
        //       color: color, fontWeight: FontWeight.bold, fontSize: 16),
        // ),

        Expanded(
          child: Row(
            children: [
              GestureDetector(
                onTap: (){

                  print("minus clicked");
                  var temp= int.parse(controller.selectedProductsQuantityList[position]);
                  print("Index $position   value  $temp " );
                  if(temp>1) {
                    temp -= 1;
                    controller.selectedProductsQuantityList[position] =
                        temp.toString();
                  }
                  // controller.quantityText.value=temp.toString();
                  print(controller.selectedProductsQuantityList[position]);
                },
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 7, horizontal: 7),
                  decoration: BoxDecoration(
                      color: ColorsX.greyBackground, shape: BoxShape.circle),
                  child: Text(
                    "-",
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: ColorsX.subBlack),
                  ),
                ),
              ),
              horizontalSpace(SizeConfig.blockSizeHorizontal * 2),
              Obx(()=> Text(
                controller.selectedProductsQuantityList[position],
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: ColorsX.greytext),),
              ),
              horizontalSpace(SizeConfig.blockSizeHorizontal * 2),
              GestureDetector(
                onTap: (){
                  print("plus clicked");
                  var temp= int.parse(controller.selectedProductsQuantityList[position]);
                  print("Index $position   value  $temp " );
                  temp += 1;
                  controller.selectedProductsQuantityList[position]=temp.toString();
                  // controller.quantityText.value=temp.toString();
                  print(controller.selectedProductsQuantityList[position]);
                },
                child: Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                      color: ColorsX.greyBackground, shape: BoxShape.circle),
                  child: Center(
                    child: Text("+", style: TextStyle(color: ColorsX.subBlack)),
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          width: 40,
          child: Text(
            text3,
            style: TextStyle(
                color: color, fontWeight: FontWeight.bold, fontSize: 16),
          ),
        ),
      ],
    );
  }

  Widget? getAlertBox(BuildContext context) {
    Dialog errorDialog = Dialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0)), //this right here
      child: Container(
        height: SizeConfig.screenHeight * .45,
        width: SizeConfig.screenWidth * .90,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              "assets/images/cancel.png",
              height: 80,
              width: 80,
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 10),
              child: Text(
                "Are you sure you want to cancel your booking?",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Color(0xff707070),
                    fontWeight: FontWeight.w700,
                    fontSize: 20),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 15, right: 15),
              child: Text(
                "Booking can not be cancelled two hours after booking",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: ColorsX.subBlack,
                    fontWeight: FontWeight.w400,
                    fontSize: 16),
              ),
              // child: _rowItemForHeaderText("Booking can not be cancelled two hours after booking", 16, FontWeight.w400, 0xff707070, 0, 0, 0),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                GestureDetector(
                  onTap: () {
                    Get.back();
                  },
                  child: Container(
                    margin: EdgeInsets.only(
                        top: 15, bottom: 15, left: 15, right: 15),
                    width: SizeConfig.thirtyPercentWidth,
                    padding: EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      color: ColorsX.greyBackground,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Text(
                      "No",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: ColorsX.subBlack,
                          fontWeight: FontWeight.w600,
                          fontSize: 16),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    // Navigator.of(context).pop();
                    // Navigator.pop(context);
                    Get.back();
                    Get.back(id: 0);
                    // progressDilog();
                    // cancellationAlert(context);
                  },
                  child: Container(
                    margin: EdgeInsets.only(
                        top: 15, bottom: 15, left: 15, right: 15),
                    width: SizeConfig.thirtyPercentWidth,
                    padding: EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      color: ColorsX.blue_gradient_dark,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Text(
                      "Yes",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: ColorsX.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 16),
                    ),
                    // child: _rowItemForHeaderText("Yes", 16, FontWeight.w600, 0xffffffff, 0, 0, 0),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
    showDialog(
        context: context, builder: (BuildContext context) => errorDialog);
  }

  Widget? cancellationAlert(BuildContext context) {
    Dialog errorDialog = Dialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0)), //this right here
      child: Container(
        height: SizeConfig.screenHeight * .45,
        width: SizeConfig.screenWidth * .90,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              "assets/images/cancel.png",
              height: 80,
              width: 80,
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 10),
              child: Text(
                "Your booking has been cancelled",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Color(0xff707070),
                    fontWeight: FontWeight.w700,
                    fontSize: 20),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 15, right: 15),
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: 'Bookings cannot be cancelled after two hours',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: ColorsX.subBlack),
                ),
              ),
            ),
            // DialogButton(context),
            // _rowItemForHeaderText("Go to Booking", 14, FontWeight.w600, 0xff70b4ff, 0, 0, 0)

            Padding(padding: EdgeInsets.only(top: 50.0)),

            GestureDetector(
              onTap: () {
                Navigator.of(context).pop();
                // Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomSheetReusable(value: "billing")));
              },
              child: Container(
                width: SizeConfig.eightyPercentWidth,
                margin: EdgeInsets.only(left: 20, right: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  color: ColorsX.blue_button_color,
                ),
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  "Return to Appointments",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: ColorsX.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            // FlatButton(onPressed: (){
            //   Navigator.of(context).pop();
            // },
            //     child: Text('Got It!', style: TextStyle(color: Colors.purple, fontSize: 18.0),))
          ],
        ),
      ),
    );
    showDialog(
        context: context, builder: (BuildContext context) => errorDialog);
  }

  Widget DialogButton(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            // Navigator.pushNamed(context, '/billing');
            getAlertBox(context);
          },
          child: Container(
            margin: EdgeInsets.only(top: 15, bottom: 15, left: 15, right: 15),
            width: SizeConfig.screenWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: ColorsX.blue_gradient_dark,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  child: Text("Return to Appointments",
                      style: TextStyle(
                        fontSize: 16,
                        color: ColorsX.white,
                        fontWeight: FontWeight.w700,
                      )),
                ),
              ],
            ),
          ),
        ));
  }

  Widget Button(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            // Navigator.pushNamed(context, '/verify');
            // getAlertBox(context);
            if(controller.selectedServicesIDSList.isEmpty){
              Functions.showSimpleDialog(title: 'No Service', msg: 'Please select a service to continue.');
              return;
            }else if(controller.selectedSlot.value.isEmpty){
              Functions.showSimpleDialog(title: 'No Slot Selected', msg: 'Please select a slot to continue.');

            }else{
              Get.toNamed(
                  CalenderNavigation.AdminBookingDetailsSecond,
                  id: CalenderNavigation.id);
            }
          },
          child: Container(
            margin: EdgeInsets.only(
              top: 20,
              left: SizeConfig.screenWidth * .18,
              right: 10
            ),
            width: SizeConfig.eightyPercentWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Make Reservation",
                    style: TextStyle(
                      fontSize: 16,
                      color: ColorsX.white,
                      fontWeight: FontWeight.w700,
                    )),
              ],
            ),
          ),
        ));
  }

  Widget _dateTimer(BuildContext context, String time) {
    return Container(
      width: SizeConfig.screenWidth,
      margin: EdgeInsets.only(left: SizeConfig.screenWidth * .18, right: 15, top: 20),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(width: 30,),
          Container(
            margin: EdgeInsets.only(top: 10, bottom: 10),
            child: Image.asset(
              "assets/images/appoint.png",
              color: ColorsX.blue_button_color,
            ),
          ),
          SizedBox(width: 30,),
          _rowItemForHeaderText(time, 14, FontWeight.w400, 0xff707070, 0, 0, 0),
          SizedBox(width: 30,),
        ],
      ),
    );
  }

  Widget getTotal(BuildContext context, String hardcoded, String total,
      int firstColor, int secondColor) {
    return Container(
      margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth, top: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(
              hardcoded, 16, FontWeight.w600, firstColor, 0, 5, 0),
          _rowItemForHeaderText(
              total, 16, FontWeight.w600, secondColor, 0, 5, 0),
        ],
      ),
    );
  }

  Widget rating(BuildContext context, double rating, String ratingText) {
    return Container(
      margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth, top: 15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            height: SizeConfig.blockSizeVertical * 4,
            child: RatingBar.builder(
              itemSize: SizeConfig.blockSizeVertical * 4,
              initialRating: 4,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                print(rating);
              },
            ),
          ),
          _rowItemForHeaderText(
              ratingText, 16, FontWeight.w400, 0xff707070, 0, 5, 0),
        ],
      ),
    );
  }

  Widget distance(BuildContext context, String distance) {
    return Container(
      margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth, top: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Image.asset("assets/images/pin.png"),
          _rowItemForHeaderText(
              distance + "km", 12, FontWeight.w400, 0xff707070, 0, 5, 0),
        ],
      ),
    );
  }

  Widget nameAndStatusRow(BuildContext context, String text, String status) {
    return Container(
      margin: EdgeInsets.only(
          top: 20,
          left: SizeConfig.tenPercentWidth,
          right: SizeConfig.tenPercentWidth),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _rowItemForHeaderText(text, 16, FontWeight.w700, 0xff000000, 0, 0, 0),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 15, vertical: 6),
            decoration: BoxDecoration(
              color: ColorsX.creamColor,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: _rowItemForHeaderText(
                status, 10, FontWeight.w600, 0xffffffff, 0, 0, 0),
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
        overflow: TextOverflow.ellipsis,
        maxLines: 2,
      ),
    );
  }

  Widget getImage(BuildContext context, String imagePath) {
    return Container(
      width: SizeConfig.screenWidth,
      margin: EdgeInsets.only(
          left: SizeConfig.tenPercentWidth,
          right: SizeConfig.tenPercentWidth,
          top: 20),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15.0),
        child: Image.asset(
          imagePath,
          fit: BoxFit.cover,
          height: 200,
          width: 150,
        ),
      ),
    );
  }

// Future<void> progressDilog() async {
//   Functions.showProgressDialog(context, "Loading Data", "Please wait. This may take few moments");
//   Functions.progressDialog.show();
//   await Future.delayed(Duration(seconds: 3)).then((value) => Functions.progressDialog.dismiss());
//   Functions.progressDialog.dismiss();

//   cancellationAlert(context);
//   setState(() {
//     loadingdone = true;
//   });
// }
}
