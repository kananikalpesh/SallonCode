import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-add-slot/admin-saloon-controller.dart';
import 'package:saloon_app/app/modules/admin/views/admin-bottom-cart.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calenders_wrapper.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/middle_container.dart';
import 'package:saloon_app/app/resuseable/bottom_cart.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class AdminBookAppointmentTwo extends GetView<AdminSaloonController> {
  @override
  Widget build(BuildContext context) {
    controller.buttonValue.value == "Book Now";
    int length = (controller.getSaloonDetailsModel?.staff?.length) ?? 0;
    String staffImg = '';
    return new ListView(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[

            Align(
              alignment: Alignment.topLeft,
              child: InkWell(
                onTap: () {

                  Get.toNamed(
                      CalenderNavigation.AdminSelectAddOns,
                      id: CalenderNavigation.id);
                },
                child: Container(
                  margin: EdgeInsets.only(
                      top: SizeConfig.screenHeight * .05, left: 15),
                  child: Icon(
                    Icons.arrow_back,
                    color: ColorsX.dash_textColordark1,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topLeft,
              child: InkWell(
                onTap: () {
                  Get.back();
                },
                child: Container(
                  margin: EdgeInsets.only(
                      top: SizeConfig.screenHeight * .05, left: 0),
                  child: _rowItemForHeaderText("Add Slot", 18, FontWeight.w900, 0xff8890A6, 0, SizeConfig.screenWidth*.08, 0),
                ),
              ),
            ),
          ],
        ),
        _rowItemForHeaderText(
            "Select specialist", 16, FontWeight.w600, 0xff8890A6, 15, SizeConfig.screenWidth*.18, 0),
        Container(
          margin: EdgeInsets.only(left: SizeConfig.screenWidth*.15),
          child: SizedBox(
            height: 100,
            child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: length,
                itemBuilder: (ctx, index) {
                  if (controller.getSaloonDetailsModel?.staff?[index].photos
                      .isNotEmpty ??
                      false) {
                    staffImg =
                    controller.getSaloonDetailsModel?.staff?[index].staffPic;
                    print(staffImg);
                  }
                  else{
                    staffImg = "${controller.getSaloonDetailsModel?.staff?[index].staffPic}";
                    print(staffImg);
                  }
                  return _getImagesWithName(
                      context,
                      "$staffImg",
                      "${controller.getSaloonDetailsModel?.staff?[index].name}",
                      0xff707070,
                      "${controller.getSaloonDetailsModel?.staff?[index].id}");
                }),
          ),
        ),
        _rowItemForHeaderText(
            "Select your date", 16, FontWeight.w600, 0xff707070, 15,  SizeConfig.screenWidth*.18, 0),
        _getDate(context),
        _rowItemForHeaderText(
            "Available Slot", 16, FontWeight.w600, 0xff707070, 15,  SizeConfig.screenWidth*.18, 0),
        Obx(
              () => controller.isDataLoadedForDateChange == true
              ? Container(
            margin: EdgeInsets.only(left:  SizeConfig.screenWidth*.18, right: 15),
            child: Wrap(
              runSpacing: 5.0,
              spacing: 5.0,
              direction: Axis.horizontal,
              children: <Widget>[
                for (int index = 0;
                index <
                    int.parse(
                        "${controller.staffDetailModel?.data.slots.length ?? 0}");
                index++)
                  GestureDetector(
                    onTap: () {
                      print(
                          "$index clicked......");
                      controller.selectedSlot.value =
                      "${controller.staffDetailModel?.data.slots[index].timeSlotStart}";
                      for(int i=0; i<=(controller.staffDetailModel?.data.slots.length??0);i++){
                        if(index==i) {
                          print('If Index $index');
                          controller.staffDetailModel?.data.slots[index]
                              .isSelected.value = !(controller
                              .staffDetailModel
                              ?.data
                              .slots[index]
                              .isSelected
                              .value ??
                              false);
                          print('If Index ${controller.staffDetailModel?.data.slots[index]
                              .isSelected.value}');

                        }else{
                          print("Else Index $i");
                          controller.staffDetailModel?.data.slots[i]
                              .isSelected.value = false;
                        }
                      }

                      print(
                          "${controller.staffDetailModel?.data.slots[index].isSelected.value} Selected");
                    },
                    child: Container(
                      child: _boxDecorationTextSerices(
                          context,
                          "${controller.staffDetailModel?.data.slots[index].timeSlotStart}",
                          11,
                          FontWeight.w400,
                          0xff707070,
                          0xffffffff,
                          (controller.staffDetailModel?.data.slots[index]
                              .isSelected.isTrue ??
                              false)
                              ? ColorsX.blue_button_color
                              : ColorsX.bookedSlotbg,
                          15,
                          index),
                    ),
                  ),
              ],
            ),
          )
              :  Container(
            margin: EdgeInsets.only(left:  SizeConfig.screenWidth*.18, right: 15),
            child: Wrap(
              runSpacing: 5.0,
              spacing: 5.0,
              direction: Axis.horizontal,
              children: <Widget>[
                for (int index = 0;
                index <
                    (controller?.staffDetailModel?.data?.slots
                        ?.length ??
                        0);
                index++)
                  GestureDetector(
                    onTap: () {
                      print(
                          "${index} clicked");
                      controller.selectedSlot.value =
                      "${controller.staffDetailModel?.data.slots[index].timeSlotStart}";
                      for(int i=0; i<(controller.staffDetailModel?.data.slots.length??0);i++){
                        if(index==i) {
                          print('If Index $index');
                          controller.staffDetailModel?.data.slots[index]
                              .isSelected.value = !(controller
                              .staffDetailModel
                              ?.data
                              .slots[index]
                              .isSelected
                              .value ??
                              false);
                          print('If Index ${controller.staffDetailModel?.data.slots[index]
                              .isSelected.value}');

                        }else{
                          print("Else Index $i");
                          controller.staffDetailModel?.data.slots[i]
                              .isSelected.value = false;
                        }
                      }
                      print(
                          "${controller.staffDetailModel?.data.slots[index].isSelected.value} Selected");
                      controller.isSpecificSlotClicked.toggle();

                    },
                    child: Container(
                      child: _boxDecorationTextSerices(
                          context,
                          "${controller.staffDetailModel?.data.slots[index].timeSlotStart}",
                          11,
                          FontWeight.w400,
                          0xff707070,
                          0xffffffff,
                          (controller.staffDetailModel?.data
                              .slots[index].isSelected.isTrue ??
                              false)
                              ? ColorsX.blue_button_color
                              : ColorsX.bookedSlotbg,
                          15,
                          index),
                    ),
                  ),
              ],
            ),
          ),
        ),
        Button(context),
        Spacer(),
        AdminBottomCart(),
      ],
    );
  }

  Widget _getImagesWithName(BuildContext context, String imageName, String name,
      int colorCode, String id) {
    print("${imageName} image");

    return GestureDetector(
      onTap: () {
        print(id);
        MiddleContainer.staffId = id;
        Functions.openPopUpForDateSelectForAppointmentAdmin(
            date: getTodaysDate(),
            title: "Select Date",
            msg: "Select Date For Appointment",
            context: context);
      },
      child: Container(

        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            _getColumnItem(context, imageName, name, colorCode),
          ],
        ),
      ),
    );
  }

  Widget _boxDecorationTextSerices(
      BuildContext context,
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      int selectedColorCode,
      Color decoration,
      double horizontal,
      int index) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: horizontal),
      margin: EdgeInsets.only(top: 10),
      decoration: new BoxDecoration(
        color: decoration,
        borderRadius: BorderRadius.all(Radius.circular(25)),
      ),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _getColumnItem(
      BuildContext context, String imagePath, String name, int colorCode) {
    print("${imagePath} image");
    return Container(
      margin: EdgeInsets.only(top: 10, left: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          // CircleAvatar(
          //   backgroundColor: Colors.white,
          //   radius: 30.0,
          //   child: CircleAvatar(
          //     backgroundImage: AssetImage(imagePath),
          //     radius: 28.0,
          //   ),
          // ),
          Container(
            height: 60,
            width: 60,
            decoration: BoxDecoration(
                color: ColorsX.blue_button_color, shape: BoxShape.circle),
            child: ClipRRect(
              borderRadius: new BorderRadius.circular(10.0),
              child: CachedNetworkImage(
                imageUrl: AppUrls.BASE_URL_IMAGE + '${imagePath}',
                errorWidget: (context, url, error) => Icon(Icons.error),
                fit: BoxFit.cover,
                width: 55,
                height: 55.0,
                placeholder: (context, url) => Container(
                    height: 30,
                    width: 30,
                    child: Center(child: CircularProgressIndicator())),
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            name,
            style: TextStyle(
                color: Color(colorCode),
                fontSize: 14,
                fontWeight: FontWeight.w600),
          )
        ],
      ),
    );
  }

  Widget _getDate(BuildContext context) {
    return Obx(
          () => Container(
          height: 40,
          padding: EdgeInsets.only(left: 5, right: 5),
          decoration: new BoxDecoration(
              color: ColorsX.lightStackColor,
              borderRadius: BorderRadius.all(Radius.circular(10))),
          margin: EdgeInsets.only(top: 15, right: 15, left:  SizeConfig.screenWidth*.18),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                width: 20,
              ),
              Align(
                  alignment: Alignment.centerLeft,
                  child: _rowItemForHeaderText(
                      controller.chosenDateTimeFromSetAppointmentWithDashes
                          .value ==
                          ""
                          ? '${controller.getTodaysDate()}'
                          : controller
                          .chosenDateTimeFromSetAppointmentWithDashes.value,
                      14,
                      FontWeight.w600,
                      0xff707070,
                      0,
                      0,
                      0)),
              Expanded(child: Container()),
              GestureDetector(
                onTap: () {
                  print("clicked");
                  Functions.openPopUpForDateSelectForAppointmentForAdmin(
                      date: getTodaysDate(),
                      title: "Select Date",
                      msg: "Select Date For Appointment",
                      context: context);
                },
                child: Image.asset(
                  "assets/images/appoint.png",
                  height: 20,
                  width: 20,
                ),
              ),
              SizedBox(
                width: 20,
              ),
            ],
          )),
    );
  }

  String getTodaysDate() {
    final DateTime now = DateTime.now();
    print("now wali date" + "${now}");
    final DateFormat formatter = DateFormat('yyyy-MM-dd');
    final String formatted = formatter.format(now);
    print(formatted);
    return formatted;
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _columnItem(String value1, String value2, int colorCode) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        _rowItemForHeaderText(value1, 8, FontWeight.w400, colorCode, 5, 0, 0),
        _rowItemForHeaderText(value2, 12, FontWeight.w400, colorCode, 5, 0, 0),
      ],
    );
  }

  Widget _circleDraw(
      String imagePath,
      int circleColor,
      int imageColor,
      ) {
    return Container(
      width: 60,
      height: 60,
      child: Image.asset(imagePath),
      decoration:
      BoxDecoration(shape: BoxShape.circle, color: Color(circleColor)),
    );
  }

  Widget Button(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            // Navigator.pushNamed(context, '/appointmentTwo');
            if (controller.selectedSlot.value.isEmpty) {
              print("Select slot");
              Functions.showErrorToast(
                  context, "Error", "Select slot to continue");
            } else {
              print(controller.selectedSlot.value);

              Get.toNamed(
                  CalenderNavigation.AdminBookingDetailsFirst,
                  id: CalenderNavigation.id);
            }
          },
          child: Container(
            margin: EdgeInsets.only(top: 15, bottom: 15, left:  SizeConfig.screenWidth*.18, right: 15),
            width: SizeConfig.screenWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: new BoxDecoration(
              color: ColorsX.blue_gradient_dark,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  child: Text("Continue",
                      style: TextStyle(
                        fontSize: 16,
                        color: ColorsX.white,
                        fontWeight: FontWeight.w700,
                      )),
                ),
              ],
            ),
          ),
        ));
  }
}
