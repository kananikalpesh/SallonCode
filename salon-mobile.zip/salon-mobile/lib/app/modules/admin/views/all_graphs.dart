
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/tab_bar_dashboard.dart';
import 'package:saloon_app/app/resuseable/left_list.dart';
import 'package:saloon_app/app/resuseable/left_list_other.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class AllGraphs extends StatelessWidget{
  String drawerValue = "assets/images/appoint_white.png";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: ColorsX.greyBackground,

        drawer: Theme(
          data: Theme.of(context).copyWith(
            canvasColor: Colors
                .transparent, //This will change the drawer background to blue.
            //other styles
          ),
          child: Drawer(
              child: Container(
                decoration: new BoxDecoration(
                    color: Color(0xff515C6F),
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(60),
                        topRight: Radius.circular(60))),
                child: ListView(
                  // Important: Remove any padding from the ListView.
                  padding: EdgeInsets.zero,
                  children: <Widget>[
                    Container(
                      child: DrawerHeader(
                        decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius:
                            BorderRadius.only(topRight: Radius.circular(60)),
                            image: DecorationImage(
                                image: AssetImage("assets/images/popular.png"),
                                colorFilter: new ColorFilter.mode(
                                    Colors.black.withOpacity(0.6), BlendMode.dstATop),
                                fit: BoxFit.cover)),
                        child: Stack(
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(top: 60),
                              child: Center(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: <Widget>[
                                      drawerImage(
                                          0xffffffff, "assets/images/avatar.png"),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  _rowItemForHeaderText("Lux Saloon", 24,
                                      FontWeight.w600, 0xffffffff, 60, 60, 0),
                                  _rowItemForHeaderText("@luxsaloon", 14,
                                      FontWeight.w400, 0xffffffff, 0, 60, 0),
                                ]),
                          ],
                        ),
                      ),
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      title: _rowItemForHeaderText(
                          "Dashboard", 16, FontWeight.w700, 0xffffffff, 0, 0, 0),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/home_dash.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/home_dash.png"),
                      ), //Image.asset("assets/images/home_dash.png"),
                      onTap: () {
                        Navigator.pushNamed(context, '/saloonDashboard');
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/appoint_white.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/appoint_white.png"),
                      ),
                      title: _rowItemForHeaderText(
                          "Calendar", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        Navigator.pushNamed(context, '/calender');
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/cart.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/cart.png"),
                      ),
                      title: _rowItemForHeaderText(
                          "Products", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        Navigator.pushNamed(context, '/products');
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/group.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/group.png"),
                      ),
                      title: _rowItemForHeaderText(
                          "Manage Staff", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        Navigator.pushNamed(context, '/manageStaff');
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/user_white.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/user_white.png"),
                      ), //Image.asset("assets/images/user_white.png"),
                      title: _rowItemForHeaderText(
                          "Edit Profile", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        Navigator.pushNamed(context, '/adminProfile');
                        // Navigator.push(context, MaterialPageRoute(builder: (context) => AdminProfile("assets/images/user_white.png"),));
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/disk.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/disk.png"),
                      ),
                      title: _rowItemForHeaderText(
                          "Requests", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        Navigator.pushNamed(context, '/requests');
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/chat.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/chat.png"),
                      ),
                      title: _rowItemForHeaderText(
                          "Messages", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        Navigator.pushNamed(context, '/chatAdmin');
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/bell_simple.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/bell_simple.png"),
                      ),
                      title: _rowItemForHeaderText(
                          "Notifications", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        Navigator.pushNamed(context, '/notificationsAdmin');
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/stop.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/stop.png"),
                      ),
                      title: _rowItemForHeaderText(
                          "Deals & Offers", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        Navigator.pushNamed(context, '/dealsOffers');
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/info.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/info.png"),
                      ),
                      title: _rowItemForHeaderText(
                          "Help & Support", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        // Update the state of the app.
                        // ...
                      },
                    ),
                    ListTile(
                      visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                      leading: Container(
                        height: 40,
                        width: 40,
                        decoration: new BoxDecoration(
                          color: drawerValue == "assets/images/back_logout.png"
                              ? ColorsX.dashboardHome
                              : Colors.transparent,
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                        ),
                        child: Image.asset("assets/images/back_logout.png"),
                      ),
                      title: _rowItemForHeaderText(
                          "Logout", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                      onTap: () {
                        // Update the state of the app.
                        // ...
                      },
                    ),
                  ],
                ),
              )),
        ),
        body: SingleChildScrollView(
          child: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  height: SizeConfig.screenHeight,
                  color: ColorsX.dashboardColor,
                ),

                Container(
                  margin: EdgeInsets.only(
                      left: SizeConfig.blockSizeHorizontal * 5,
                      top:5),
                  child: Padding(
                    padding:
                    EdgeInsets.symmetric(vertical: SizeConfig.blockSizeVertical),
                    child: Image.asset(AppImages.drawer_ic),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  // color: ColorsX.white,
                  height: SizeConfig.screenHeight,
                ),
                // Align(
                //   alignment: Alignment.topRight,
                //   child: Container(
                //     margin: EdgeInsets.only(top: 5, right: 15),
                //     child: Icon(Icons.arrow_back, color: ColorsX.subBlack,),
                //   ),
                // ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(width: SizeConfig.screenWidth*.15,),
                    // Column(
                    //   crossAxisAlignment: CrossAxisAlignment.start,
                    //   children: <Widget>[
                    //     LeftList(),
                    //     LeftListOther(),
                    //   ],
                    // ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[

                        Container(
                          width: SizeConfig.seventyFivePercentWidth,
                          margin: EdgeInsets.only(top: 15, left: 2),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              _rowItemForHeaderText("Analytics", 20, FontWeight.w900, 0xff8890A6, 0, 10, 0),
                              Container(
                                width: SizeConfig.eightyPercentWidth,
                                height: SizeConfig.screenHeight+55,
                                margin: EdgeInsets.only(top: 20),
                                child: TabBarDashboard(),
                              ),
                              // TabBarDashboard(),
                              // AspectRatio(
                              //   aspectRatio: 1.20,
                              //   child: Container(
                              //     margin: EdgeInsets.only(left: 0, top: 10, right: 10),
                              //     decoration: const BoxDecoration(
                              //         borderRadius: BorderRadius.all(
                              //           Radius.circular(18),
                              //         ),
                              //         color: Color(0xffffffff)),
                              //     child: Padding(
                              //       padding: const EdgeInsets.only(right: 2.0, left: 2.0, top: 10, bottom: 12),
                              //       child: LineChart(
                              //         showAvg ? avgData() : mainData(),
                              //       ),
                              //     ),
                              //   ),
                              // ),
                              // Stats(),
                              // BarGraph(),
                              // BarGraph("2014",5),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        )
    );
  }
  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
            alignment: Alignment.bottomRight,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
              margin: EdgeInsets.only(left: 2, top: 2),
              decoration: new BoxDecoration(
                color: ColorsX.rating_dashboard,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    bottomRight: Radius.circular(30)),
              ),
              child: _rowItemForHeaderText(
                  " 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
            ),
          )
              : Container(),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
}