import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/dashboard_controller.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/add-ons-screen.dart';
import 'package:saloon_app/app/modules/admin/views/admin_chat_screens/admin_chat_list.dart';
import 'package:saloon_app/app/modules/admin/views/all_graphs.dart';
import 'package:saloon_app/app/modules/admin/views/appointments/saloon_appointment_view.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calendar_settings.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calenders_wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/deals_n_offers/deals_wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/left_list.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/left_list_other.dart';
import 'package:saloon_app/app/modules/admin/views/resuseable/side_menu.dart';
import 'package:saloon_app/app/modules/admin/views/services_screens/services_wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/settings/settings-wrapper.dart';
import 'package:saloon_app/app/modules/admin/views/test_cases.dart';
import 'package:saloon_app/app/modules/admin/views/welcome_graph_daishboard.dart';
import 'package:saloon_app/app/utils/colors.dart';

import 'package:fl_chart/fl_chart.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'add-ons-tabs-all-screens/add_ons_wrapper.dart';
import 'appointments/appointments_wrapper.dart';
import 'settings_screen.dart';
import 'staff_screens/staff_wrapper.dart';

class SaloonDashBoard extends GetView<DaishBoardController> {
  String drawerValue = "assets/images/home_dash.png";

  List<Color> gradientColors = [
    const Color(0xff70b4ff),
    // const Color(0xff70b4ff),
  ];

  bool showAvg = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsX.dashboardBG,
      drawer: Theme(
        data: Theme.of(context).copyWith(
          canvasColor: Colors
              .transparent, //This will change the drawer background to blue.
          //other styles
        ),
        child: Drawer(
            child: Container(
          decoration: new BoxDecoration(
              color: Color(0xff515C6F),
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(60),
                  topRight: Radius.circular(60))),
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: <Widget>[
              Container(
                child: DrawerHeader(
                  decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius:
                          BorderRadius.only(topRight: Radius.circular(60)),
                      image: DecorationImage(
                          image: AssetImage("assets/images/popular.png"),
                          colorFilter: new ColorFilter.mode(
                              Colors.black.withOpacity(0.6), BlendMode.dstATop),
                          fit: BoxFit.cover)),
                  child: Stack(
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.only(top: 60),
                        child: Center(
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                drawerImage(
                                    0xffffffff, "assets/images/avatar.png"),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            _rowItemForHeaderText("Lux Saloon", 24,
                                FontWeight.w600, 0xffffffff, 60, 60, 0),
                            _rowItemForHeaderText("@luxsaloon", 14,
                                FontWeight.w400, 0xffffffff, 0, 60, 0),
                          ]),
                    ],
                  ),
                ),
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                title: _rowItemForHeaderText(
                    "Dashboard", 16, FontWeight.w700, 0xffffffff, 0, 0, 0),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/home_dash.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/home_dash.png"),
                ), //Image.asset("assets/images/home_dash.png"),
                onTap: () {
                  Navigator.pushNamed(context, '/saloonDashboard');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/appoint_white.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/appoint_white.png"),
                ),
                title: _rowItemForHeaderText(
                    "Calendar", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/calender');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/cart.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/cart.png"),
                ),
                title: _rowItemForHeaderText(
                    "Products", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/products');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/group.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/group.png"),
                ),
                title: _rowItemForHeaderText(
                    "Manage Staff", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/manageStaff');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/user_white.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/user_white.png"),
                ), //Image.asset("assets/images/user_white.png"),
                title: _rowItemForHeaderText(
                    "Edit Profile", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/adminProfile');
                  // Navigator.push(context, MaterialPageRoute(builder: (context) => AdminProfile("assets/images/user_white.png"),));
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/disk.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/disk.png"),
                ),
                title: _rowItemForHeaderText(
                    "Requests", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  print('Appointment clicked.....');
                  // Navigator.pushNamed(context, '/requests');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/chat.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/chat.png"),
                ),
                title: _rowItemForHeaderText(
                    "Messages", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/chatAdmin');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/bell_simple.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/bell_simple.png"),
                ),
                title: _rowItemForHeaderText(
                    "Notifications", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/notificationsAdmin');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/stop.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/stop.png"),
                ),
                title: _rowItemForHeaderText(
                    "Deals & Offers", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  Navigator.pushNamed(context, '/dealsOffers');
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/info.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/info.png"),
                ),
                title: _rowItemForHeaderText(
                    "Help & Support", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  // Update the state of the app.
                  // ...
                },
              ),
              ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -3),
                leading: Container(
                  height: 40,
                  width: 40,
                  decoration: new BoxDecoration(
                    color: drawerValue == "assets/images/back_logout.png"
                        ? ColorsX.dashboardHome
                        : Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                  ),
                  child: Image.asset("assets/images/back_logout.png"),
                ),
                title: _rowItemForHeaderText(
                    "Logout", 16, FontWeight.w400, 0xffffffff, 0, 0, 0),
                onTap: () {
                  // Update the state of the app.
                  // ...
                },
              ),
            ],
          ),
        )),
      ),
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              // height: SizeConfig.screenHeight,
              color: ColorsX.dashboardBG,
            ),
            // Welcome(),
            // LeftList(),

            Obx(() => IndexedStack(
                  index: controller.tabIndex.value,
                  children: [
                    WelcomeGraphDaishboard(), //0
                    AllGraphs(), //1
                    CalenderWrapper(), //2

                    AddOnsWrapper(), //3
                    SaloonStaffWrapper(), //4
                    AdminServiceWrapper(), //5
                    SaloonAppointmentsWrapper(), //6

                  DealsNOfferWrapper(), // 7
                  SettingsWrapper(), // 8
                  ChatListAdmin(),
                  // NewsPage(),
                  // AlertsPage(),
                  // AccountPage(),
                ],
              )),

            SideMenu("assets/images/home_dash.png"),
          ],
        ),
      ),
    );
  }

  LineChartData mainData() {
    return LineChartData(
      gridData: FlGridData(
        show: true,
        drawVerticalLine: true,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,
          getTextStyles: (value, double) => TextStyle(
              color: Color(0xff68737d),
              fontWeight: FontWeight.w400,
              fontSize: 8),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '18 \n Dec';
              case 2:
                return '19 \n Dec';
              case 4:
                return '1 \n Han';
              case 6:
                return '12 \n Jan';
              case 8:
                return '2 \n Feb';
              case 10:
                return '12 \n Mar';
              case 12:
                return '22 \n Mar';
            }
            return '';
          },
          margin: 8,
        ),
        rightTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value, double) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.w400,
            fontSize: 8,
          ),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '122';
              case 2:
                return '124';
              case 4:
                return '126';
              case 6:
                return '128';
              case 8:
                return '130';
              case 10:
                return '132';
            }
            return '';
          },
          reservedSize: 28,
          margin: 4,
        ),
        leftTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value, double) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.w400,
            fontSize: 8,
          ),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '';
              case 1:
                return '';
              case 2:
                return '';
              case 3:
                return '';
              case 4:
                return '';
              case 5:
                return '';
              case 6:
                return '';
              case 7:
                return '';
              case 8:
                return '';
              case 9:
                return '';
              case 10:
                return '';
              case 11:
                return '';
              case 10:
                return '';
            }
            return '';
          },
          reservedSize: 28,
          margin: 4,
        ),
      ),
      borderData: FlBorderData(
          show: true,
          border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 11,
      lineBarsData: [
        LineChartBarData(
          spots: [
            FlSpot(0, 2),
            FlSpot(2.6, 4),
            FlSpot(3.9, 1),
            FlSpot(5.8, 5.1),
            FlSpot(8, 2),
            FlSpot(9.5, 7.5),
            FlSpot(11, 6.3),
          ],
          isCurved: true,
          colors: gradientColors,
          barWidth: 2,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(
            show: true,
            colors:
                gradientColors.map((color) => color.withOpacity(0.4)).toList(),
          ),
        ),
      ],
    );
  }

  LineChartData avgData() {
    return LineChartData(
      lineTouchData: LineTouchData(enabled: false),
      gridData: FlGridData(
        show: true,
        drawHorizontalLine: true,
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xffffffff),
            strokeWidth: 0,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,
          getTextStyles: (value, double) => const TextStyle(
              color: Color(0xff68737d),
              fontWeight: FontWeight.bold,
              fontSize: 16),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '18 \n Dec';
              case 2:
                return '19 \n Dec';
              case 4:
                return '1 \n Han';
              case 6:
                return '12 \n Jan';
              case 8:
                return '2 \n Feb';
              case 10:
                return '12 \n Mar';
              case 12:
                return '22 \n Mar';
            }
            return '';
          },
          margin: 8,
        ),
        rightTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value, double) => const TextStyle(
            color: Color(0xff67727d),
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
          getTitles: (value) {
            switch (value.toInt()) {
              case 0:
                return '122';
              case 2:
                return '124';
              case 4:
                return '126';
              case 6:
                return '128';
              case 8:
                return '130';
              case 10:
                return '132';
            }
            return '';
          },
          reservedSize: 28,
          margin: 12,
        ),
      ),
      borderData: FlBorderData(
          show: true,
          border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 6,
      lineBarsData: [
        LineChartBarData(
          spots: [
            FlSpot(0, 3.44),
            FlSpot(2.6, 3.44),
            FlSpot(4.9, 3.44),
            FlSpot(6.8, 3.44),
            FlSpot(8, 3.44),
            FlSpot(9.5, 3.44),
            FlSpot(11, 3.44),
          ],
          isCurved: true,
          colors: [
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!,
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!,
          ],
          barWidth: 5,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(show: true, colors: [
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!
                .withOpacity(0.1),
            ColorTween(begin: gradientColors[0], end: gradientColors[1])
                .lerp(0.2)!
                .withOpacity(0.1),
          ]),
        ),
      ],
    );
  }

  Widget rowText(String text1, String text2) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
              child: _rowItemForHeaderText(
                  text1, 14, FontWeight.w700, 0xff8890A6, 10, 0, 0)),
          Expanded(
              child: _rowItemForHeaderText(
                  text2, 14, FontWeight.w700, 0xff8890A6, 10, 0, 0)),
        ],
      ),
    );
  }

  Widget getItemOfDataToBeShown(BuildContext context, String text1,
      String text2, String imagePath, int colorCode) {
    return Stack(
      children: <Widget>[
        Container(
          decoration: new BoxDecoration(
            color: Color(colorCode),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          height: 60,
          margin: EdgeInsets.only(right: 10, top: 10),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Expanded(child: SizedBox()),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Align(
                  alignment: Alignment.center,
                  child: _rowItemForHeaderText(text1, 18, FontWeight.w900,
                      text2 == "Products" ? 0xffffffff : 0xff8890A6, 23, 0, 0),
                ),
                Align(
                  alignment: Alignment.center,
                  child: _rowItemForHeaderText(text2, 9, FontWeight.w900,
                      text2 == "Products" ? 0xffffffff : 0xff8890A6, 2, 0, 0),
                ),
              ],
            ),
            Expanded(child: SizedBox()),
            Container(
              margin: EdgeInsets.only(top: 13),
              child: Image.asset(imagePath),
            ),
            Expanded(child: SizedBox()),
          ],
        ),
      ],
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget drawerImage(int colorCode, String imagePath) {
    return Container(
      height: 50,
      width: 50,
      decoration: new BoxDecoration(
        color: Color(0xff9aaec9),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      // margin: EdgeInsets.only(top: 10),
      child: Stack(
        children: <Widget>[
          Center(
            child: Image.asset(imagePath),
          ),
          imagePath == "assets/images/avatar.png"
              ? Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                    margin: EdgeInsets.only(left: 2, top: 2),
                    decoration: new BoxDecoration(
                      color: ColorsX.rating_dashboard,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          bottomRight: Radius.circular(30)),
                    ),
                    child: _rowItemForHeaderText(
                        " 4.5", 7, FontWeight.w600, 0xffffffff, 0, 0, 0),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
