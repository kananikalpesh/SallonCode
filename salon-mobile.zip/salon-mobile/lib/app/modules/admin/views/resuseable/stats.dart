// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:saloon_app/app/utils/colors.dart';


// class Stats extends StatelessWidget{
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       mainAxisAlignment: MainAxisAlignment.start,
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: <Widget>[

//         rowText("Sales", "Financials"),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[

//             Expanded(
//               child: getItemOfDataToBeShown(context, "2.5k+", "Sales Today", "assets/images/dollar.png",0xffffffff),
//             ),
//             SizedBox(width: 10,),
//             Expanded(
//               child: getItemOfDataToBeShown(context, "12+", "Services", "assets/images/finance.png",0xffffffff),),
//           ],
//         ),
//         rowText("Products", "Categories"),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[

//             Expanded(
//               child: getItemOfDataToBeShown(context, "150+", "Products", "assets/images/bottle.png",0xff70b4ff),
//             ),
//             SizedBox(width: 10,),
//             Expanded(
//               child: getItemOfDataToBeShown(context, "256+", "Clients", "assets/images/clients.png",0xffffffff),),
//           ],
//         ),
//         rowText("Team Members", "Services"),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[

//             Expanded(
//               child: getItemOfDataToBeShown(context, "20+", "Barbers", "assets/images/members.png",0xffffffff),
//             ),
//             SizedBox(width: 10,),
//             Expanded(
//               child: getItemOfDataToBeShown(context, "12+", "Services", "assets/images/sizure.png",0xffffffff),),
//           ],
//         ),
//         rowText("Bookings", ""),
//         SizedBox(height: 10,),
//         Container(
//           margin: EdgeInsets.only(right: 10),
//           decoration: new BoxDecoration(
//             color: ColorsX.white,
//             borderRadius: BorderRadius.all(Radius.circular(10)),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: <Widget>[
//               SizedBox(height: 10,),
//               BookingDash(date:"JAN 12",time:"08:00PM",name: "John Doe",service:"Haircut, Massage"),
//               divider(),
//               BookingDash(date:"JAN 12",time:"08:00PM",name: "John Doe",service:"Haircut, Massage"),
//               SizedBox(height: 10,),
//             ],
//           ),
//         ),
//       ],
//     );
//   }
//   Widget divider(){
//     return
//       Container(
//         margin: EdgeInsets.only(top: 15),
//         child: Divider(
//           color: ColorsX.greyBackground,
//           thickness: 1,
//         ),
//       );
//   }
//   Widget rowText(String text1, String text2){
//     return Container(
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.start,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: <Widget>[
//           Expanded(child: _rowItemForHeaderText(text1, 14, FontWeight.w700, 0xff8890A6, 10, 0, 0)),
//           Expanded(child: _rowItemForHeaderText(text2, 14, FontWeight.w700, 0xff8890A6, 10, 10, 0)),
//         ],
//       ),
//     );
//   }
  
  
  
//   Widget getItemOfDataToBeShown(BuildContext context, String text1, String text2, String imagePath, int colorCode){
//     return Stack(
//       children: <Widget>[
//         Container(
//           decoration: new BoxDecoration(
//             color: Color(colorCode),
//             borderRadius: BorderRadius.all(Radius.circular(10)),
//           ),
//           height: 60,
//           margin: EdgeInsets.only(right: 10, top: 10),
//         ),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.start,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             // Expanded(child: SizedBox()),
//             SizedBox(width: 10,),
//             Column(
//               crossAxisAlignment: CrossAxisAlignment.center,
//               mainAxisAlignment: MainAxisAlignment.spaceAround,
//               children: <Widget>[
//                 Align(
//                   alignment: Alignment.center,
//                   child: _rowItemForHeaderText(text1, 18, FontWeight.w900, text2=="Products"?0xffffffff:0xff8890A6, 23, 0, 0),
//                 ),
//                 Align(
//                   alignment: Alignment.center,
//                   child: _rowItemForHeaderText(text2, 9, FontWeight.w900,  text2=="Products"?0xffffffff:0xff8890A6, 2, 0, 0),
//                 ),
//               ],
//             ),
//             Expanded(child: SizedBox()),
//             Container(
//               margin: EdgeInsets.only(top: 13),
//               child: Image.asset(imagePath),
//             ),
//             SizedBox(width: 15 ,),
//             // Expanded(child: SizedBox()),
//           ],
//         ),
//       ],
//     );
//   }
  
  
  
//   Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
//     return Container(
//       margin: EdgeInsets.only(top: top, left: left, right: right),
//       child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
//     );
//   }
// }
