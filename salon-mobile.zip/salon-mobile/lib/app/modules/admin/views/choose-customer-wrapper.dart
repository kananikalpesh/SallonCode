// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/bindings/admin_binding.dart';
import 'package:saloon_app/app/modules/admin/bindings/choose_customer_binding.dart';
import 'package:saloon_app/app/modules/admin/views/choose-customer.dart';
import 'package:saloon_app/app/modules/admin/views/services_screens/create_new_service.dart';
import 'package:saloon_app/app/modules/admin/views/services_screens/servicec_list.dart';





class AdminChooseCustomerNavigation {
  AdminChooseCustomerNavigation._();
  static const id = 18;
  static const choose_customer = '/choose_customer';
  static const createNewService = '/create-new-services';


}
// our wrapper, where our main navigation will navigate to
class AdminChooseCustomerWrapper extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Navigator(

      key: Get.nestedKey(AdminChooseCustomerNavigation.id),
      onGenerateRoute: (settings) {
        // navigate to a route by name with settings.name
        if (settings.name == AdminChooseCustomerNavigation.choose_customer) {
          return GetPageRoute(
              routeName: AdminChooseCustomerNavigation.choose_customer,
              page: () => ChooseCustomer(
              ),
              binding: ChooseCustomerBinding()
          );
        }

        else {
          return GetPageRoute(
            routeName: AdminChooseCustomerNavigation.createNewService,
            page: () => CreateNewService(

            ),
          );
        }
      },
    );
  }
}