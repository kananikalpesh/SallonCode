import 'dart:math';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';

import 'package:charts_flutter/flutter.dart' as charts;

class BarGraph extends StatelessWidget {
  final List<charts.Series<dynamic, String>> seriesList;
  final bool? animate;

  BarGraph(this.seriesList, {this.animate});

  /// Creates a [BarChart] with sample data and no transition.
  factory BarGraph.withSampleData() {
    return new BarGraph(
      _createSampleData(),
      // Disable animations for image tests.
      animate: false,
    );
  }


  @override
  Widget build(BuildContext context) {
    return AspectRatio(
        aspectRatio: 1.20,
        child: Container(
          decoration: new BoxDecoration(
            color: ColorsX.white,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: charts.BarChart(
            seriesList,
            animate: animate,
            flipVerticalAxis: false,
          ),
        )
    );
  }

  /// Create one series with sample hard coded data.
  static List<charts.Series<OrdinalSales, String>> _createSampleData() {
    final data = [
      new OrdinalSales('Week 01', 5),
      new OrdinalSales('2015', 25),
      new OrdinalSales('2016', 100),
      new OrdinalSales('2017', 75),
    ];

    return [
      new charts.Series<OrdinalSales, String>(
        id: 'Sales',
        colorFn:(_, __) => charts.ColorUtil.fromDartColor(ColorsX.rating_dashboard),
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        data: data,
      )
    ];
  }
}

/// Sample ordinal data type.
class OrdinalSales {
  final String year;
  final int sales;

  OrdinalSales(this.year, this.sales);
}