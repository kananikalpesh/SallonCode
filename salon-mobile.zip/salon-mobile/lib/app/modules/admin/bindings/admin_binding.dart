import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/add_on/add_on_ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin-services/services-admin-list-and-add-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin_controller.dart';
import 'package:saloon_app/app/modules/admin/controllers/calender/calender_ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/dashboard_controller.dart';
import 'package:saloon_app/app/modules/admin/controllers/deal_n_offers_ctl/admin-deals-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/deal_n_offers_ctl/deals_list_ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/saloon_appointment_ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/settingsCtl.dart';
import 'package:saloon_app/app/modules/admin/controllers/staff_screen_controllers/staff_detail_ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/welcome_graph_dashboard_ctl.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';

class AdminBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AdminController>(
      () => AdminController(),
    );
    Get.lazyPut<DaishBoardController>(
      () => DaishBoardController(),
    );
    Get.lazyPut<WelcomeGraphDaishboardCTL>(
      () => WelcomeGraphDaishboardCTL(),
    );
    Get.lazyPut<DealsListCTL>(
      () => DealsListCTL(),
    );
    Get.lazyPut<SaloonAppointmentCTL>(
      () => SaloonAppointmentCTL(),
    );
    Get.lazyPut<AdminSettingsCTL>(
      () => AdminSettingsCTL(),
    );
    Get.put<ServicesAdminListAddCTL>(
      ServicesAdminListAddCTL(),
    );
    Get.put<AdminDealsCTL>(
      AdminDealsCTL(),
    );
    Get.put<AddOnCTL>(
      AddOnCTL(),
    );
    Get.put<StaffCTL>(
      StaffCTL(),
    );
    Get.put<CalenderCTL>(
      CalenderCTL(),
    );
  }
}
