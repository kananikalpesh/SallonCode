import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/bindings_interface.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:saloon_app/app/modules/admin/controllers/add_on/add_on_ctl.dart';

class AddOnBinding extends Bindings {
  @override
  void dependencies() {
    print('ADD ON CTL ADDED...');
    Get.put(
      () => AddOnCTL(),
    );
  }
}
