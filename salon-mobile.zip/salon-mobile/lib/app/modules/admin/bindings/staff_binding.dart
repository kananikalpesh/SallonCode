import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/admin_controller.dart';
import 'package:saloon_app/app/modules/admin/controllers/dashboard_controller.dart';
import 'package:saloon_app/app/modules/admin/controllers/deal_n_offers_ctl/deals_list_ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/staff_screen_controllers/staff_detail_ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/welcome_graph_dashboard_ctl.dart';



class StaffBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<StaffCTL>(
      () => StaffCTL(),
    );
  
  }
}
