import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-signup-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/saloon_appointment_ctl.dart';
import 'package:saloon_app/app/modules/login/controllers/login-controller.dart';
import 'package:saloon_app/app/modules/staff/controller/staff-login/staff-login-ctl.dart';


class StaffLoginBinding extends Bindings {
  @override
  void dependencies() {

    Get.lazyPut<StaffLoginController>(
          () => StaffLoginController(),
    );
    Get.put(SaloonAppointmentCTL());

    // Get.lazyPut<AdminLoginController>(
    //       () => AdminLoginController(),
    // );
    // Get.lazyPut<AdminSignUpCTL>(
    //       () => AdminSignUpCTL(),
    // );
  }
}
