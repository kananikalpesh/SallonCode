import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/login.dart';
import 'package:saloon_app/app/data/model/staff/staff-login-response.dart';
import 'package:saloon_app/app/data/services/authApi.dart';
import 'package:saloon_app/app/data/services/staff/saloon_staff_api.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:saloon_app/app/data/model/staff/staff_bookings.dart'
as staffBooking;
import 'package:saloon_app/app/data/model/admin/appointment/saloon_all_booking.dart'
as salonBooking;
class StaffLoginController extends GetxController {
  final authApi = AuthApi();
  final saloonStaffApi = SaloonStaffApi();
  final emailCTL = TextEditingController();
  final passwordCTL = TextEditingController();
  StaffLoginRes? staffLoginRes;
  ErrorResponse? errorResponse;
  RxBool isDataLoaded = false.obs;
  final count = 0.obs;

  Rx<DateTime> focusedDay = DateTime.now().obs;
  DateTime? selectedDay;
  DateTime? rangeStart;
  DateTime? rangeEnd;
  Map<String, List<staffBooking.Datum>>? events = {};
  Map<String, bool>? isEventLoaded = {};
  List<staffBooking.Datum> dayBookingList = [];
  List<DateTime> uniqueDates = [];
  RxBool isBookingsLoaded = false.obs;
  Rx<CalendarFormat> calendarFormat = CalendarFormat.month.obs;
  RxString calenderFormat='Monthly'.obs;
  List<staffBooking.Datum>? staffAllBooking = [];
  staffBooking.Datum? saloonAppointment;

  @override
  void onInit() {
    print("in staff");
    super.onInit();
  }
  Future<bool> loginUser({required Map<String, dynamic> apiParams, required BuildContext context}) async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    final res = await authApi.staffLogin(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is StaffLoginRes) {
      staffLoginRes = res;
      if (res.token != null) {
        print('token' "${res.token}");
        AppStrings.tokenOfCurrentUser="${res.token}";
        //getallBooking
      }
      print('ADD MEMBER SUCCESS RESPONSE FOUND');
      isDataLoaded.toggle();
      return true;
    } else if (res is ErrorResponse) {
      print('ADD MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
        Functions.showErrorDialog(
            title: "Error",
            msg: "${errorResponse?.msg}",
            isSuccess:false
        );
        print("${errorResponse?.msg}");
      // }
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);

      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.slowInternet,
          isSuccess:false
      );
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet

      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.noInternet,
          isSuccess:false
      );
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);

      Functions.showErrorDialog(
          title: "Error",
          msg: AppStrings.error,
          isSuccess:false
      );
      Functions.showToast(AppStrings.error);
    }
    return false;
  }
  @override
  void onReady() {

    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;



  Function? filterBooking() {
    for (var date in uniqueDates) {
      isEventLoaded?[date.toString().split(' ')[0]]=false;
      List<staffBooking.Datum> booking = [];
      for (var b in staffAllBooking!) {
        if (date == b.appointmentDate) {
          booking.add(b);
        }
      }
      String newDate = date.toString().split(' ')[0];
      this.events?[newDate] = booking;
    }
  }

  List<staffBooking.Datum>? getDayEvents(DateTime day) {
    return this.events?[day.toString().split(' ')[0]];
  }

  void setCalenderFormat(String format){
    if(format=='Monthly'){
      calendarFormat.value = CalendarFormat.month;
    }else if(format=='Weekly'){
      calendarFormat.value = CalendarFormat.week;
    }
  }





  Future<bool> getStaffAllBookings() async {

    final res = await saloonStaffApi.getStaffAllBookings();
    // Functions.hideProgressLoader();
    if (res is staffBooking.StaffAllBooking) {
      staffAllBooking = res.data;
      //get unique dates
      for (var b in staffAllBooking!) {
        if (!uniqueDates.contains(b.appointmentDate)) {
          this.uniqueDates.add(b.appointmentDate!);
        }
      }
      print("Unique Date : ${uniqueDates.length}");
      print("Unique Date : ${uniqueDates}");
      //filter booking
      this.filterBooking();
      this.uniqueDates.forEach((date) {
        print('Events ${events?[date]?.length}');
      });

      isBookingsLoaded.value=true;

      return true;
    } else if (res is ErrorResponse) {
      Functions.showErrorDialog(
          title: "Error", msg: '${res.msg}', isSuccess: false);
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      return false;
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
      return false;
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
      return false;
    }
    return false;
  }



}
