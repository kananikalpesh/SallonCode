import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/modules/admin/views/login/otp-code-admin.dart';
import 'package:saloon_app/app/modules/login/controllers/login-controller.dart';
import 'package:saloon_app/app/modules/login/views/otp_code.dart';
import 'package:saloon_app/app/modules/staff/controller/staff-login/staff-login-ctl.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';

import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';
import 'package:saloon_app/app/utils/user-preferences.dart';
import 'package:shared_preferences/shared_preferences.dart';


class StaffLogin extends GetView<StaffLoginController> {
  //
  // GlobalKey<FormState> _userLoginFormKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    print("in staff");
    return Scaffold(
      body: Stack(
        children: [
          Container(
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            child: Image.asset(
              AppImages.Girl_bg2,
              fit: BoxFit.cover,
            ),
          ),
          bottomContainer(context),
        ],
      ),
    );
  }

  Widget bottomText(BuildContext context) {
    return Align(
        alignment: Alignment.center,
        child: GestureDetector(
          onTap: () {
            Get.toNamed('/signup-screen-admin');
          },
          child: Container(
              margin: EdgeInsets.only(top: SizeConfig.marginVerticalXXLarge),
              child: RichText(
                text: TextSpan(
                  text: 'Don' "\'" 't have an account?  ',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: ColorsX.subBlack),
                  children: const <TextSpan>[
                    TextSpan(
                        text: 'Sign Up',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            color: ColorsX.blue_gradient_dark)),
                  ],
                ),
              )),
        ));
  }

  Widget bottomContainer(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: SizeConfig.screenHeight * .40),
      decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30), topRight: Radius.circular(30))),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          bottomContainerItem(context, "Welcome Back", 30, FontWeight.w700,
              0xff6EC8FD, SizeConfig.marginVerticalStander, ""),
          bottomContainerItem(
              context,
              "STYLE THAT FIT YOUR LIFESTYLE",
              16,
              FontWeight.w400,
              0xff707070,
              SizeConfig.marginVerticalStander,
              ""),
          TextFields(
              false,
              SizeConfig.marginVerticalXXLarge,
              SizeConfig.screenWidth * .10,
              SizeConfig.screenWidth * .10,
              "Email",
              controller.emailCTL),
          TextFields(
              true,
              SizeConfig.marginVerticalLarge,
              SizeConfig.screenWidth * .10,
              SizeConfig.screenWidth * .10,
              "Password",
              controller.passwordCTL),
          Button(context, "Login"),
          bottomContainerItem(
              context,
              "Forgot your password?",
              16,
              FontWeight.w400,
              0xff707070,
              SizeConfig.marginVerticalStander,
              "forget"),
          // bottomText(context),
        ],
      ),
    );
  }

  Widget bottomContainerItem(
      BuildContext context,
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      String action) {
    return Align(
      alignment: Alignment.topCenter,
      child: GestureDetector(
        onTap: () {
          if (action == "forget") {
            // Navigator.pushNamed(context, '/forgotPassword');
            Get.toNamed(Routes.FORGOT_PASSWORD_SCREEN);
          } else {}
        },
        child: Container(
          margin: EdgeInsets.only(top: top),
          child: Text(
            value,
            style: TextStyle(
                color: Color(colorCode),
                fontSize: fontSize,
                fontWeight: fontWeight),
          ),
        ),
      ),
    );
  }

  Widget Button(BuildContext context, String buttonText) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            // Navigator.pushNamed(context, '/asCustomer');
            if (controller.emailCTL.text.isEmpty) {
              Functions.showErrorToast(
                  context, "Required", "This field is required");
            } else if (controller.passwordCTL.text.isEmpty) {
              Functions.showErrorToast(
                  context, "Required", "This field is required");
            } else {
              String email = controller.emailCTL.text;
              String password = controller.passwordCTL.text;
              Map<String, dynamic> apiParams = {
                'Email': email,
                'Password': password,
              };
              loginNow(context, apiParams);
            }
            // apiCall(context);
          },
          child: Container(
            margin: EdgeInsets.only(
              top: SizeConfig.marginVerticalXXLarge,
            ),
            width: SizeConfig.screenWidth * .80,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(buttonText,
                    style: TextStyle(
                      fontSize: 16,
                      color: ColorsX.white,
                      fontWeight: FontWeight.w700,
                    )),
              ],
            ),
          ),
        ));
  }

  void loginNow(BuildContext context, Map<String, dynamic> apiParams) async {
    Functions.showProgressLoader(AppStrings.wait);
    print('params ${apiParams}');

    final res =
    await controller.loginUser(apiParams: apiParams, context: context);
    Functions.hideProgressLoader();
    print('UI RESPONSE ${res}');
    // Get.to(AdminMainDisplay());
    // Get.toNamed(Routes.ADMIN_DASHBOARD);
    if (res) {
      // Get.toNamed(Routes.ADMIN_DASHBOARD);
      // GV.userName = name;
      print("res admin updated");

      // if (controller.staffLoginRes?.status == true) {
      //   print(controller.staffLoginRes?.status);
        if (controller.staffLoginRes?.error == false) {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          AppStrings.tokenOfCurrentUser=controller.staffLoginRes?.token;
          // UserPreferences().userToken = controller.loginResponse?.token;
          // UserPreferences().userName = controller.loginResponse?.user?.name;
          // UserPreferences().userID = controller.loginResponse?.user?.id;
          // UserPreferences().userMobileNumber = controller.loginResponse?.user?.mobileNumber;
          // UserPreferences().emailId = controller.loginResponse?.user?.email;
          // AppStrings.tokenOfCurrentUser = controller.loginResponse?.token;
          Get.toNamed(Routes.STAFF_MAIN_DAISHBOARD);
          controller.getStaffAllBookings();
        }
      // } else {
      //   // print(controller.loginResponse?.saloon.saloon.mobileNumber);
      //   // Navigator.push(
      //   //     context,
      //   //     MaterialPageRoute(
      //   //         builder: (context) => OTPCodeAdmin(
      //   //           phone: "${controller.loginResponse?.saloon.saloon.mobileNumber}",
      //   //         )
      //   //     )
      //   // );
      // }
    } else if (res is ErrorResponse) {
      print(res);
      print('error occurred error res');
    } else {
      print(res);
      print('error occurred from ui');
    }
  }

  Widget TextFields(bool obscure, double top, double left, double right,
      String hint, TextEditingController ctl) {
    return Container(
      padding: EdgeInsets.only(
        left: 5,
        right: 5,
      ),
      decoration: new BoxDecoration(
          color: ColorsX.greyBackground,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: top, right: right, left: left),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.emailAddress,
        obscureText: obscure,
        controller: ctl,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1,
        //Normal textInputField will be disp
        decoration: InputDecoration(
          enabledBorder: InputBorder.none,
          contentPadding: EdgeInsets.only(top: 15),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide.none,
          ),
          prefixIcon: Image.asset(
            hint == "Email"
                ? "assets/images/email.png"
                : "assets/images/password.png",
            height: 20,
            width: 20,
          ),
          hintText: hint,
          hintStyle: TextStyle(color: ColorsX.subBlack),
        ),
      ),
    );
  }
}
