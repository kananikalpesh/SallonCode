import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/AppointmentItem.dart';
import 'package:saloon_app/app/modules/staff/controller/staff-login/staff-login-ctl.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class StaffAllBookingView extends GetView<StaffLoginController> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: SizeConfig.blockSizeVertical * 5,
        ),
        _textAndIcon(context, "Bookings", AppImages.back),
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.zero,
              itemCount: controller.staffAllBooking?.length ?? 0,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: (){
                    controller.saloonAppointment = controller.staffAllBooking?[index];
                    Get.toNamed(Routes.STAFF_BOOKING_DETAILS);
                  },
                  child: AppointmentItem(
                    imagePath: "assets/images/popular.png",
                    name: controller.staffAllBooking?[index].saloon?.name ?? '',
                    address: controller
                            .staffAllBooking?[index].saloon?.address?.address ??
                        '',
                    time: (controller.staffAllBooking![index].timeSlot
                                .toString()
                                .contains(' ')
                            ? controller.staffAllBooking![index].timeSlot
                                ?.split(' ')[0]
                            : '') ??
                        '',
                    date: controller.staffAllBooking![index].appointmentDate?.day
                            .toString() ??
                        '',
                    AmPm: (controller.staffAllBooking![index].timeSlot
                                .toString()
                                .contains(' ')
                            ? controller.staffAllBooking![index].timeSlot
                                ?.split(' ')[1]
                            : '') ??
                        '',
                    month:
                        "${controller.staffAllBooking![index].appointmentDate?.month ?? ''} ${controller.staffAllBooking![index].appointmentDate?.year ?? ''}",
                    rating: controller.staffAllBooking![index].saloon?.rating
                            .toString() ??
                        '',
                    appointmentId:
                        "#${controller.staffAllBooking![index].appointmentId}",
                    status: '${controller.staffAllBooking![index].status}',
                  ),
                );
              }),
        ),
      ],
    );
  }

  Widget _textAndIcon(BuildContext context, String text, String imagePath) {
    return Container(
      margin:
          EdgeInsets.only(top: 20,left: 20),
      child: Row(
        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          InkWell(
            onTap: () {
              Get.back();
            },
            child: Image.asset(
              imagePath,
              height: 21,
              width: 17,
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 11),
          _rowItemForHeaderText(text, 20, FontWeight.w900, 0xff515C6F, 0, 0, 0),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }
}
