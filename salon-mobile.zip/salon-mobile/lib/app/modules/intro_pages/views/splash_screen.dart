import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';

import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';
import 'package:saloon_app/app/utils/user-preferences.dart';
import 'package:saloon_app/main.dart';

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: Stack(children: [
        Container(
          height: SizeConfig.screenHeight,
          width: SizeConfig.screenWidth,
          child: Image.asset(
            AppImages.Splash_bg_img,
            fit: BoxFit.cover,
          ),
        ),
        Align(
          alignment: Alignment.topCenter,
          child: Container(
            margin: EdgeInsets.only(top: SizeConfig.screenHeight * .20),
            child: Image.asset(
              AppImages.Splash_logo,
              fit: BoxFit.cover,
              height: 150,
              width: 150,
            ),
          ),
        ),
        Align(
          alignment: Alignment.topCenter,
          child: Container(
              margin: EdgeInsets.only(top: SizeConfig.screenHeight * .50),
              child: Text(
                "ONLINE BARBER BOOKING",
                style: TextStyle(
                    color: ColorsX.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900),
              )),
        ),
        Align(
          alignment: Alignment.topCenter,
          child: Container(
              margin: EdgeInsets.only(top: SizeConfig.screenHeight * .56),
              child: Text(
                "STYLE THAT FIT YOUR LIFESTYLE ",
                style: TextStyle(
                    color: ColorsX.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              )),
        ),
        Align(
            alignment: Alignment.topCenter,
            child: GestureDetector(
              onTap: () {
                // if(UserPreferences().userName!=null && UserPreferences().userName!=''){
                //   print("ACCESS_TOKEN : " +"${AppStrings.tokenOfCurrentUser}");
                //   Get.toNamed(Routes.WELCOME_CUSTOMER_SCREEN);
                // }
                // else {
                //   Get.toNamed(Routes.INTRO_SCREEN);
                // }

                if (sharedPreferences!.get('token') != null) {
                  AppStrings.tokenOfCurrentUser = sharedPreferences!.get('token') as String?;
                  // CurrentUser.userId = sharedPreferences.get('userId');
                  print('token : ${AppStrings.tokenOfCurrentUser}');

                  Get.toNamed(Routes.WELCOME_CUSTOMER_SCREEN);
                  // if (sharedPreferences.get('confirmed') != null) {
                  //   if (sharedPreferences.get('confirmed') == '1') {
                  //     if (sharedPreferences.get('username') == '1') {
                  //       return PageX();
                  //     } else {
                  //       return UserNameScreen();
                  //     }
                  //   } else {
                  //     return OTPVerification();
                  //   }
                  // }
                }
                else {
                  print("not found");
                  Get.toNamed(Routes.INTRO_SCREEN);
                }
              },
              child: Container(
                margin: EdgeInsets.only(top: SizeConfig.screenHeight * .65),
                width: SizeConfig.eightyPercentWidth,
                padding: EdgeInsets.symmetric(vertical: 15),
                decoration: BoxDecoration(
                  color: ColorsX.blue_gradient_dark,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      child: Text("Get Started",
                          style: TextStyle(
                            fontSize: 16,
                            color: ColorsX.white,
                            fontWeight: FontWeight.w700,
                          )),
                    ),
                  ],
                ),
              ),
            )),
        // Align(
        //   alignment: Alignment.topCenter,
        //   child: Container(
        //     margin: EdgeInsets.only(top: SizeConfig.screenHeight*.80),
        //     child: Text("Powered by IvylabTechnologies@2021", style: TextStyle(color: ColorsX.white, fontWeight: FontWeight.w400, fontSize: 14))
        //   )
        // )
      ]),
    );
  }
}
