import 'package:cached_network_image/cached_network_image.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SliderContent extends StatelessWidget {
  String? imagePath;
  int? pageNumber;
  int? numberOfDots;
  String? buttonText;
  int? reviews;
  int? rating;

  SliderContent({
    required this.imagePath,
    required this.pageNumber,
    required this.numberOfDots,
    required this.buttonText,
    required this.reviews,
    required this.rating,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          height: SizeConfig.screenHeight,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              itemsOfScreen(context, imagePath, pageNumber, numberOfDots,
                  buttonText, reviews, rating),
            ],
          )),
    );
  }

  Widget itemsOfScreen(BuildContext context, String? imagePath, int? pageNumber,
      int? numberOfDots, String? buttonText, int? reviews, int? rating) {
    return Container(
        height: SizeConfig.fortyPercentHeight,
        width: SizeConfig.screenWidth,
        child: Stack(
          children: [
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                width: SizeConfig.screenWidth,
                height: SizeConfig.fortyPercentHeight,
                margin: EdgeInsets.only(top: 0),
                decoration:
                    BoxDecoration(color: Color(0xFF0E3311).withOpacity(0.7)),
                child: Opacity(
                  opacity: 0.4,
                  child: CachedNetworkImage(
                    imageUrl: AppUrls.BASE_URL_IMAGE + '${imagePath}',
                    errorWidget: (context, url, error) => Icon(Icons.error),
                    fit: BoxFit.cover,
                    width: SizeConfig.screenWidth,
                    height: SizeConfig.fortyPercentHeight,
                    placeholder: (context, url) => Container(
                        height: 30,
                        width: 30,
                        child: Center(child: CircularProgressIndicator())),
                  ),
                  // child: Image.asset("assets/images/popular.png", height: SizeConfig.fortyPercentHeight, width:  SizeConfig.screenWidth,
                  //   fit: BoxFit.cover,),
                ),
              ),
            ),
            InkWell(
              onTap: (){
                Get.back();
              },
              child: Align(
                alignment: Alignment.topLeft,
                child: Container(
                  margin: EdgeInsets.only(
                      top: SizeConfig.screenHeight * .07, left: 15),
                  child: Icon(
                    Icons.arrow_back,
                    color: ColorsX.white,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Container(
                margin: EdgeInsets.only(
                  top: SizeConfig.screenHeight * .07,
                  right: 15,
                ),
                child: Image.asset(AppImages.notify),
              ),
            ),
            // Column(
            //   crossAxisAlignment: CrossAxisAlignment.start,
            //   children: <Widget>[
            //     _rowItemForHeaderText(
            //         "",
            //         20,
            //         FontWeight.w700,
            //         0xffffffff,
            //         SizeConfig.screenHeight * .12,
            //         18,
            //         0),
            //     _rowItemForHeaderText("", 18,
            //         FontWeight.w400, 0xffffffff, 10, 18, 0),
            //     RowItemsOfRatingReview(rating!.toDouble(), '${reviews } reviews', '${buttonText}')
            //   ],
            // ),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                margin: EdgeInsets.only(top: SizeConfig.screenHeight * .32),
                child: new DotsIndicator(
                  dotsCount: numberOfDots!,
                  position: pageNumber!.toDouble(),
                  decorator: DotsDecorator(
                    size: const Size.square(5.0),
                    activeSize: const Size(30, 5.0),
                    color: ColorsX.textfieldbak,
                    activeColor: ColorsX.dotssliderColor,
                    spacing: EdgeInsets.only(left: 2, right: 2),
                    activeShape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5.0)),
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xff56D91F),
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  margin: EdgeInsets.only(
                      top: SizeConfig.screenHeight * .30, right: 20),
                  child: _rowItemForHeaderText(
                      "OPEN", 14, FontWeight.w700, 0xffffffff, 5, 10, 10, 5)),
            ),
          ],
        ));
  }

  Widget RowItemsOfRatingReview(
      double rating, String reviews, String ButtonText) {
    return Container(
      height: 30,
      margin: EdgeInsets.only(top: 10, left: 18, right: 18),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          SizedBox(
            height: 20,
            child: RatingBar.builder(
              initialRating: rating,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemSize: 20,
              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                print(rating);
              },
            ),
          ),
          _rowItemForHeaderText(
              reviews, 14, FontWeight.w400, 0xffffffff, 0, 0, 0, 0),
          Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            decoration: new BoxDecoration(
              color: ColorsX.parrotColor,
              borderRadius: BorderRadius.all(Radius.circular(25)),
            ),
            child: _rowItemForHeaderText(
                ButtonText, 12, FontWeight.w700, 0xffffffff, 0, 0, 0, 0),
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right,
      double bottom) {
    return Container(
      margin:
          EdgeInsets.only(top: top, left: left, right: right, bottom: bottom),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }
}
