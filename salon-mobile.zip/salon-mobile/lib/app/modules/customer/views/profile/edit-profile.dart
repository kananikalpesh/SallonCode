import 'dart:ffi';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'dart:io' as Io;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:saloon_app/app/modules/customer/controllers/user-profile-ctl.dart';
import 'package:saloon_app/app/resuseable/loading-state.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class EditProfile extends GetView<UserProfileCtl> {

  final emailCtl = TextEditingController();
  final mobileCtl = TextEditingController();
  final dobCtl = TextEditingController();
  final nameCtl = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Obx(() => controller.isDataLoaded.isTrue
        ? userDetails(context)
        : LoadingState());
  }
  Widget userDetails(BuildContext context){

    emailCtl.text = '${controller.userProfileModel?.data.email}';
    mobileCtl.text = '${controller.userProfileModel?.data.mobileNumber}';
    nameCtl.text = '${controller.userProfileModel?.data.name}';
    dobCtl.text = '${controller.userProfileModel?.data.dob}';
    return ListView(
      children: <Widget>[
        Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Stack(
              children: <Widget>[
                Container(
                  height: 80,
                  color: ColorsX.lightStackColor,
                ),
                Container(
                  margin: EdgeInsets.only(top: 30),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Align(
                        alignment: Alignment.center,
                        child: _rowItemForHeaderText("My Profile", 16,
                            FontWeight.w700, 0xff707070, 0, 0, 0),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: _rowItemForHeaderText("Editing Now", 12,
                            FontWeight.w400, 0xff707070, 5, 0, 0),
                      )
                    ],
                  ),
                ),
              ],
            ),
            _myDp(context, "${controller.userProfileModel?.data.profilePic}"),
            // _rowItemForHeaderText(
            //     "${controller.userProfileModel?.data.name}", 18, FontWeight.w700, 0xff383838, 20, 0, 0),
            // _rowItemForHeaderText("Account Created on "+formatISOTimeNew(DateTime.parse(controller.accountCreated)), 12,
            //     FontWeight.w400, 0xff707070, 10, 0, 0),
            // GestureDetector(
            //     onTap: () {
            //       Get.toNamed(Routes.TRANSECTION_DETAIL);
            //     },
            //     child: _myButton("Show reciept")),
            // _rating(context, controller.userProfileModel?.data.rating.toDouble()),
            SizedBox(
              height: 20,
            ),
            _rowOfProfile(
                context, '${controller.userProfileModel?.data.name}', "assets/images/profile.png",nameCtl,"Profile"),
            _rowOfProfile(
                context, '${controller.userProfileModel?.data.email}', "assets/images/email.png",emailCtl,"Email"),
            _rowOfProfile(
                context, "${controller.userProfileModel?.data.mobileNumber}", "assets/images/mobile.png",mobileCtl,"Mobile"),
            Obx(()=>
               Container(
                  child: _rowOfProfileText(context, "${controller.userProfileModel?.data.dob}", "assets/images/dob.png",
                      controller.chosenDateTime.value==""?"${controller.userProfileModel?.data.dob}":controller.chosenDateTime.value,"Dob")
              ),
            ),
            // _rowOfProfile(context, "Log Out", "assets/images/logout.png"),
            Container(
                height: 150,
                margin: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  border: Border.all(color: ColorsX.blue_button_color),
                  borderRadius: BorderRadius.all(Radius.circular(10))
                ),
                child: CupertinoDatePicker(
                  mode: CupertinoDatePickerMode.date,
                  initialDateTime: DateTime(int.parse(controller.year!), int.parse(controller.month!), int.parse(controller.day!)),
                  onDateTimeChanged: (DateTime newDateTime) {
                    // Do something
                    String newDob =newDateTime.day.toString()+"/"+newDateTime.month.toString()+"/"+newDateTime.year.toString();
                    print(newDob);
                    controller.chosenDateTime.value = newDob;
                    dobCtl.text = newDob;
                  },
                ),
              ),
            Align(
                alignment: Alignment.topCenter,
                child: GestureDetector(
                  onTap: () {
                    // Navigator.pushNamed(context, '/notifications');
                    print(nameCtl.text);
                    print(emailCtl.text);
                    print(mobileCtl.text);
                    print(dobCtl.text);
                    if(nameCtl.text.isEmpty){
                      Functions.showErrorToast(context, "Required", "Name field is required");
                    }else if(emailCtl.text.isEmpty){
                      Functions.showErrorToast(context, "Required", "Email field is required");
                    }else if(mobileCtl.text.isEmpty){
                      Functions.showErrorToast(context, "Required", "Mobile number field is required");
                    }else {
                      print("ok");
                      if (controller.pickedImage != null) {
                        print("clicked");
                        Map<String, String> apiParams = {
                          'name': nameCtl.text,
                          'email': emailCtl.text,
                          'mobile_number': mobileCtl.text,
                          'DOB': dobCtl.text,
                        };
                        print(apiParams);
                        controller.editSpecificUserDetailswithImage(apiParams: apiParams);
                      }
                      else{

                        print("clicked");
                        Map<String, String> apiParams = {
                          'name': nameCtl.text,
                          'email': emailCtl.text,
                          'mobile_number': mobileCtl.text,
                          'DOB': dobCtl.text,
                        };
                        print(apiParams);
                        controller.editSpecificUserDetails(apiParams: apiParams);
                      }

                    }
                    // Get.toNamed(Routes.TRANSECTION_LIST);
                  },
                  child: Container(
                    margin: EdgeInsets.only(
                      top: SizeConfig.screenHeight*.02,
                      bottom: 20
                    ),
                    width: SizeConfig.eightyPercentWidth,
                    padding: EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      color: ColorsX.blue_button_color,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text('Update Profile',
                            style: TextStyle(
                              fontSize: 16,
                              color: ColorsX.white,
                              fontWeight: FontWeight.w700,
                            )
                        ),
                      ],
                    ),
                  ),
                ))
          ],
        ),
      ],
    );
  }



  Future<void>? _takePicture() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      controller.pickedImage = Io.File(image.path);
      controller.isPickSelected.toggle();
      print('image selected. ${controller.pickedImage}');
    } else {
      print('No image selected.');
    }

    // controller.imageFile = File(image.path);
  }

  Widget _getImageWidget() {
    if (controller.pickedImage != null) {
      return Container(
        width: 115.0,
        height: 115.0,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(60.0),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(60.0),
          child: Image.file(
            controller.pickedImage!,
            width: 115,
            height: 115,
            fit: BoxFit.fill,
          ),
        ),
      );
    } else if (controller.pickedImage == null) {
      return Image.asset("assets/images/nodp_img.png");
    }
    return Container();
  }

  // Show the modal that contains the CupertinoDatePicker
  String formatISOTime(DateTime date) {
    var duration = date.timeZoneOffset;
    if (duration.isNegative)
      return (date.toIso8601String() + "-${duration.inHours.toString().padLeft(2, '0')}:${(duration.inMinutes - (duration.inHours * 60)).toString().padLeft(2, '0')}");
    else
      return (date.toIso8601String() + "+${duration.inHours.toString().padLeft(2, '0')}:${(duration.inMinutes - (duration.inHours * 60)).toString().padLeft(2, '0')}");
  }
  Widget _myButton(String text) {
    return Container(
      margin: EdgeInsets.only(
        top: SizeConfig.blockSizeVertical * 2,
      ),
      width: SizeConfig.blockSizeHorizontal * 45,
      padding: EdgeInsets.symmetric(vertical: SizeConfig.blockSizeVertical),
      decoration: BoxDecoration(
        color: ColorsX.blue_button_color,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(text,
              style: TextStyle(
                fontSize: 16,
                color: ColorsX.white,
                fontWeight: FontWeight.w700,
              )),
        ],
      ),
    );
  }

  Widget _rowOfProfileText(BuildContext context, String text, String imagePath, String? ctl, String hint) {
    return Container(
      width: SizeConfig.screenWidth,
      padding: EdgeInsets.symmetric(vertical: 15),
      decoration: new BoxDecoration(
          color: ColorsX.greyBackground,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: 10, right: 25, left: 25),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(width: 20,),
          Image.asset("assets/images/dob.png",),
          SizedBox(width: 20,),
          _rowItemForHeaderText(text, 14, FontWeight.w600, 0xff707070, 0, 0, 0),
        ],
      ),
    );
  }

  Widget _rowOfProfile(BuildContext context, String text, String imagePath, TextEditingController ctl, String hint) {
    return Container(
      padding: EdgeInsets.only(
        left: 5,
        right: 5,
      ),
      decoration: new BoxDecoration(
          color: ColorsX.greyBackground,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      margin: EdgeInsets.only(top: 10, right: 25, left: 25),
      child: TextFormField(
        style: TextStyle(color: ColorsX.subBlack),
        keyboardType: TextInputType.emailAddress,
        obscureText: false,
        controller: ctl,
        // controller: numberController,
        // validator: (String value) => value.length < 10
        //     ? 'Çharacter Length Must Be 10 Character Long'
        //     : null,
        minLines: 1,

        //Normal textInputField will be disp
        decoration: InputDecoration(
          enabledBorder: InputBorder.none,
          contentPadding: EdgeInsets.only(top: 15),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide.none,
          ),
          prefixIcon: Image.asset(
            hint == "Email"
                ? "assets/images/email.png"
                : hint == "Mobile"? "assets/images/mobile.png": hint == "Profile"?"assets/images/profile.png":"assets/images/dob.png",
            height: 20,
            width: 20,
            color: ColorsX.blue_button_color,
          ),
          hintText: hint,
          hintStyle: TextStyle(color: ColorsX.subBlack),
        ),
      ),
    );
  }

  Widget _rating(BuildContext context, dynamic rating) {
    return Container(
      margin: EdgeInsets.only(top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            height: 26,
            child: RatingBar.builder(
              initialRating: rating,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemSize: 20,
              ignoreGestures: true,
              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                print(rating);
              },
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 3),
          _rowItemForHeaderText("${controller.userProfileModel?.data.rating}", 16, FontWeight.w400, 0xff707070, 0, 0, 0)
        ],
      ),
    );
  }

  Widget _myDp(BuildContext context, String imagePath) {
    return
      GestureDetector(
        onTap: (){
          _takePicture();
        },
        child: Container(
          margin: EdgeInsets.only(top: 30),
          child:
          Obx(() => controller.isPickSelected.isTrue ? _getImageWidget() :
          ClipRRect(
            borderRadius: BorderRadius.circular(60),
            child: Container(
              decoration: new BoxDecoration(
                shape: BoxShape.circle,
              ),
              child: CachedNetworkImage(
                imageUrl: AppUrls.BASE_URL_IMAGE+'${imagePath}',
                errorWidget: (context, url, error) => Icon(Icons.error),// Icon(Icons.error),
                fit: BoxFit.cover,width: 115, height: 115,

                placeholder: (context, url) => Container(
                    height: 30,
                    width: 30,
                    child: Center(child: CircularProgressIndicator())),
              ),
              // child: Image.asset("assets/images/mike.png"),
            ),
          ),
          ),
        ),
      );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  String formatISOTimeNew(DateTime s) {
    String formattedDate = DateFormat('dd-MM-yyyy').format(s);
    return formattedDate;
  }
}
