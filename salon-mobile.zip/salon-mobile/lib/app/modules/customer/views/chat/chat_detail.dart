import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/modules/customer/views/chat/chat_messages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';



class ChatWithSaloon extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            height: 100,
            color: ColorsX.lightStackColor,
            margin: EdgeInsets.only(top: 5),
          ),
          GestureDetector(
            onTap: (){
              Navigator.of(context).pop();
            },
            child: Container(
              margin: EdgeInsets.only(top: 60, left: 15),
              child: Icon(Icons.arrow_back, color: ColorsX.blue_button_color,),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 60),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Align(
                  alignment: Alignment.topCenter,
                  child: _rowItemForHeaderText("Looks Unisex Saloon", 16, FontWeight.w700, 0xff707070, 0, 0, 0),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: _rowItemForHeaderText("last seen 15 min ago", 12, FontWeight.w400, 0xff707070, 0, 0, 0),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: SizeConfig.screenHeight*.94, bottom: 5, left: 5),
            // color: ColorsX.blue_button_color,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Expanded(child: TextField("Type your message..", context),),
                SizedBox(width: 10,),
                _rowImages(context, "assets/images/camera.png"),
                SizedBox(width:10,),
                _rowImages(context, "assets/images/mic.png"),
                SizedBox(width: 20,),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 100, bottom: SizeConfig.screenHeight*.06),
            child: ChatMessages(),
          ),
        ],
      ),
    );
  }
  Widget _rowImages(BuildContext context, String imagePath){
    return Container(
      child: Image.asset(imagePath),
    );
  }
  Widget TextField(String hint, BuildContext context){
    return Container(
      width: SizeConfig.seventyFivePercentWidth,
        decoration: new BoxDecoration(
            color:ColorsX.white,
            border: Border.all(color: Color(0xffb4b4b4)),
            borderRadius: BorderRadius.all(Radius.circular(20))
        ),
        // decoration: new BoxDecoration(
        //     color:ColorsX.white,
        //     borderRadius: BorderRadius.all(Radius.circular(50))
        // ),
        child: TextFormField(
          style: TextStyle(color: Color(0xffb4b4b4)),
          keyboardType: TextInputType.multiline,
          obscureText: false,
          // controller: numberController,
          // validator: (String value) => value.length < 10
          //     ? 'Çharacter Length Must Be 10 Character Long'
          //     : null,
          minLines: null,
          maxLines: null,
          expands: true,
          //Normal textInputField will be disp
          decoration: InputDecoration(
            enabledBorder: InputBorder.none,
            // OutlineInputBorder(
            //     borderSide: BorderSide(color: Color(0xffb4b4b4))
            // ),
            focusedBorder: InputBorder.none,
            //   OutlineInputBorder(
            //     borderSide: BorderSide(color: Color(0xffb4b4b4))
            // ),
            hintText: hint,
            contentPadding: EdgeInsets.only(top: 10, left: 15, right: 15),
            hintStyle: TextStyle(color: ColorsX.darkGreyColor),
          ),
        )
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }
}