// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/custome_home_controller.dart';
import 'package:saloon_app/app/modules/customer/views/header_welcome.dart';
import 'package:saloon_app/app/modules/customer/views/location_screen.dart';
import 'package:saloon_app/app/modules/customer/views/search_screen.dart';

class CustomerHomeScreen extends StatelessWidget {
  CustomerHomeController customerHomeController = Get.find();

  List<Widget> homeScreenList = [
    HeaderWelcome(),
    SearchScreen(),
    LocationScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() => homeScreenList[customerHomeController.homecurrentScreenIndex.value]),
    );
  }
}
