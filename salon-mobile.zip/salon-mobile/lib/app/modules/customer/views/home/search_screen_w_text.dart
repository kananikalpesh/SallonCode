import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/custome_home_controller.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/modules/customer/views/Categories.dart';
import 'package:saloon_app/app/modules/customer/views/HeaderStack.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/appointments_wrapper.dart';
import 'package:saloon_app/app/modules/customer/views/bottom_navigation_bar.dart';
import 'package:saloon_app/app/modules/customer/views/home/home_wrapper.dart';
import 'package:saloon_app/app/resuseable/package_and_offers_row.dart';
import 'package:saloon_app/app/resuseable/saloon_listview_items.dart';
import 'package:saloon_app/app/resuseable/saloon_row_item.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SearchScreenWText extends GetView<DashboardItemController> {
  //DashboardItem _dashboardItem = DashboardItem();
  CustomerHomeController customerHomeController = Get.find();
  DashboardItemController _dashboardItemController = Get.find();

  //final GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: SizeConfig.screenHeight,
          width: SizeConfig.screenWidth,
          child: myStackOnTop(context),
        ),
      ),
    );
  }

  Widget myStackOnTop(BuildContext context) {
    return Column(
      children: <Widget>[
        HeaderStack(
          categoryShow: "yes",
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _myLocationText(context, "Search Result", 0xff000000, 25, 0, 0,
                FontWeight.w600, 16),
            Container(
              margin: EdgeInsets.only(right: 25),
              // width: 50,
              // height: 20,
              decoration: BoxDecoration(
                  //color: Colors.blue,
                  borderRadius: BorderRadius.all(Radius.circular(8))),
              child: Row(
                children: [
                  InkWell(
                    onTap: () {
                      // customerHomeController
                      //     .homecurrentScreenIndex.value = 1;
                      // Get.offNamed(HomeNavigation.searchScreen, id: 2);
                    },
                    child: Container(
                      width: SizeConfig.blockSizeHorizontal * 8,
                      height: SizeConfig.blockSizeVertical * 4,
                      decoration: BoxDecoration(
                          color: ColorsX.blue_button_color,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(8),
                              bottomLeft: Radius.circular(8))),
                      child: Center(
                        child: Image.asset(
                          AppImages.List_ic,
                          color: ColorsX.icon_grey,
                        ),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {

                      //going to map
                      Get.offNamed(HomeNavigation.locationScreen, id: 2);

                    },
                    child: Container(
                      width: SizeConfig.blockSizeHorizontal * 8,
                      height: SizeConfig.blockSizeVertical * 4,
                      decoration: BoxDecoration(
                          border: Border.all(color: ColorsX.icon_grey),
                          color: ColorsX.white,
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(8),
                              bottomRight: Radius.circular(8))),
                      child: Center(
                          child: Image.asset(
                        AppImages.Location_ic,
                        color: ColorsX.icon_grey,
                      )),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
        Container(
          //margin: EdgeInsets.only(top: SizeConfig.screenHeight * .30),
          //height: 220,
          child: Obx(() => SaloonListViewItem(
                saloonItemsModel: controller.searchedSaloonItems!.value,
              )),
        ),
      ],
    );
  }

  Widget _myLocationText(
      BuildContext context,
      String text,
      int colorCode,
      double left,
      double top,
      double right,
      FontWeight fontWeight,
      double fontSize) {
    return Container(
      margin: EdgeInsets.only(left: left, top: top, right: right),
      child: Text(
        text,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: FontWeight.w600,
            fontSize: fontSize),
      ),
    );
  }
}
