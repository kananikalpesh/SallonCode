// ignore_for_file: file_names

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class Categories extends GetView<DashboardItemController> {
  // late DashboardItem dashboardItem;
  //Categories({required this.dashboardItem});
  static String ID = "";
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 230,
      // child: ListView.builder(
      //     scrollDirection: Axis.horizontal,
      //     itemCount: dashboardItem.categories?.length,
      //     itemBuilder: (BuildContext context, int index){
      //       return _CategoriesItemView(context, dashboardItem.categories?[index].backgroundPic, dashboardItem.categories?[index].icon, dashboardItem.categories?[index].title,
      //       dashboardItem.categories?[index].id);
      //     }
      // ),
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: controller.saloonItemsModel?.categories?.length??0,
          itemBuilder: (BuildContext context, int index) {
            if( controller.saloonItemsModel?.categories!=null)
            return InkWell(
              onTap: () {
                AppStrings.categoryID = controller.saloonItemsModel?.categories?[index].id;
                print(AppStrings.categoryID);
                Get.toNamed(Routes.VIEW_ALL_SALOONS_SCREEN);
              },
              child: _CategoriesItemView(context, controller.saloonItemsModel?.categories?[index].backgroundPic,
                  controller.saloonItemsModel?.categories?[index].icon,
                  controller.saloonItemsModel?.categories?[index].title,
                  controller.saloonItemsModel?.categories?[index].id),
            );
            return Container();
          }),
    );
  }

  Widget _CategoriesItemView(BuildContext context, String? imageOne,
      String? imageTwo, String? buttonText, String? id) {
    return Container(
      // margin: EdgeInsets.only(
      //   top: SizeConfig.screenHeight * .05,
      // ),
      height: 230,
      width: 180,
      child: Stack(
        children: <Widget>[
          Align(
            alignment: Alignment.center,
            child: Container(
              height: 150,
              width: 150,
              child: ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                child:
                // Image.asset(
                //   imageOne!,
                //   fit: BoxFit.fill,
                //   width: 150,
                //   height: 150,
                // ),
                CachedNetworkImage(
                  imageUrl: AppUrls.BASE_URL_IMAGE+'${imageOne}',
                  errorWidget: (context, url, error) => Icon(Icons.error),
                  fit: BoxFit.fill,width: 150,
                  height: 150,
                  placeholder: (context, url) => Container(
                      height: 30,
                      width: 30,
                      child: Center(child: CircularProgressIndicator())),
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Container(
              width: SizeConfig.blockSizeHorizontal * 15,
              height: SizeConfig.blockSizeVertical * 10,
              child: ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                child:
                // Image.asset(
                //   imageTwo!,
                //   fit: BoxFit.cover,
                // ),
                 CachedNetworkImage(
                  imageUrl: AppUrls.BASE_URL_IMAGE+'${imageTwo}',
                  errorWidget: (context, url, error) => Icon(Icons.error),
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Container(
                      height: 30,
                      width: 30,
                      child: Center(child: CircularProgressIndicator())),
                ),
              ),
            ),
          ),
          Align(
              alignment: Alignment.topCenter,
              child: GestureDetector(
                onTap: () {
                  // Navigator.pushNamed(context, '/verify');
                },
                child: Container(
                  width: 150,
                  margin: EdgeInsets.only(
                      top: SizeConfig.screenHeight * .21,
                      left: 13,
                      right: 13),
                  padding: EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: ColorsX.blue_button_color,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Expanded(
                        child:
                            Text('${buttonText == null ? '' : buttonText}',
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.fade,
                                softWrap: false,
                                maxLines: 1,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: ColorsX.white,
                                  fontWeight: FontWeight.w700,
                                )),
                      ),
                    ],
                  ),
                ),
              )),
        ],
      ),
    );
  }
}
