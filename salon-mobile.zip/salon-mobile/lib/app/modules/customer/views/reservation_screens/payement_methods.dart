// ignore_for_file: non_constant_identifier_names, file_names

import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class PayementMethods extends StatelessWidget {
  bool loadingdone = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // bottomNavigationBar: BottomSheetReusable(value: "Appointments",),
      body: SingleChildScrollView(
        child: Container(
          height: SizeConfig.screenHeight,
          width: SizeConfig.screenWidth,
          color: ColorsX.lightStackColor,
          child: Stack(
            children: <Widget>[
              // Container(
              //   height: SizeConfig.screenHeight * .70,
              //   decoration: BoxDecoration(
              //       color: ColorsX.lightStackColor,
              //       borderRadius: BorderRadius.only(
              //           bottomLeft: Radius.circular(20),
              //           bottomRight: Radius.circular(20))),
              // ),

              Align(
                alignment: Alignment.topCenter,
                child: _rowItemForHeaderText(
                    "Payment Method",
                    16,
                    FontWeight.w700,
                    0xff707070,
                    SizeConfig.blockSizeVertical * 6,
                    0,
                    0),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  GestureDetector(
                    onTap: () {
                      // Navigator.of(context).pop();
                      Get.back(id: 0);
                    },
                    child: Container(
                      margin: EdgeInsets.only(
                          top: SizeConfig.blockSizeVertical * 6, left: 15),
                      child: Icon(
                        Icons.arrow_back,
                        color: ColorsX.blue_text_color,
                      ),
                    ),
                  ),
                  verticalSpace(SizeConfig.blockSizeVertical),
                  _buttonRadioGroupForVisa(context, "Visa", "****3184",
                      0xff000000, 0xffffffff, "assets/images/cash.png", false),
                  _buttonRadioGroupForVisa(context, "Visa", "****3184",
                      0xff000000, 0xffffffff, "assets/images/cash.png", true),
                  _buttonAddCard(
                      context, "Credit or Debit Card", 0xff000000, 0xffffffff),
                  _buttonRadioGroup(context, "Cash on Service", 0xff000000,
                      0xffffffff, "assets/images/cash.png", false),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Row _itemTextRow(String text1, String text2, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          text1,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
        Text(
          text2,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ],
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _buttonRadioGroup(BuildContext context, String text, int textColor,
      int containerColor, String imagePath, bool isSelected) {
    return Container(
      width: SizeConfig.screenWidth,
      margin: EdgeInsets.only(left: 15, right: 15, top: 10),
      decoration: BoxDecoration(
        color: Color(containerColor),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 20,
          ),
          Container(
            margin: EdgeInsets.only(top: 15, bottom: 15),
            child: Image.asset(
              imagePath,
            ),
          ),
          SizedBox(
            width: 30,
          ),
          _rowItemForHeaderText(text, 14, FontWeight.bold, textColor, 5, 0, 0),
          Expanded(child: SizedBox()),
          isSelected
              ? Icon(
                  Icons.radio_button_on,
                  color: ColorsX.blue_button_color,
                )
              : Icon(
                  Icons.circle_outlined,
                  color: ColorsX.black,
                ),
          SizedBox(
            width: 20,
          )
        ],
      ),
    );
  }

  Widget _buttonAddCard(
    BuildContext context,
    String text,
    int textColor,
    int containerColor,
  ) {
    return Container(
      width: SizeConfig.screenWidth,
      height: SizeConfig.blockSizeVertical * 8,
      margin: EdgeInsets.only(left: 15, right: 15, top: 10),
      decoration: BoxDecoration(
        color: Color(containerColor),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 20,
          ),
          _rowItemForHeaderText(text, 14, FontWeight.bold, textColor, 5, 0, 0),
          Expanded(child: SizedBox()),
          GestureDetector(
            onTap: () {
              Get.bottomSheet(AddCardBottomSheet());
            },
            child: Icon(
              Icons.arrow_forward,
              color: ColorsX.blue_button_color,
            ),
          ),
          SizedBox(
            width: 20,
          )
        ],
      ),
    );
  }

  Widget _buttonRadioGroupForVisa(
      BuildContext context,
      String text,
      String text2,
      int textColor,
      int containerColor,
      String imagePath,
      bool isSelected) {
    return Container(
      width: SizeConfig.screenWidth,
      margin: EdgeInsets.only(left: 15, right: 15, top: 10),
      decoration: BoxDecoration(
        color: Color(containerColor),
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 20,
          ),
          Container(
            margin: EdgeInsets.only(top: 15, bottom: 15),
            child: Image.asset(
              AppImages.Visa_ic,
            ),
          ),
          SizedBox(
            width: 30,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _rowItemForHeaderText(
                  text, 14, FontWeight.bold, textColor, 5, 0, 0),
              _rowItemForHeaderText(
                  text2, 14, FontWeight.bold, textColor, 5, 0, 0),
            ],
          ),
          Expanded(child: SizedBox()),
          isSelected
              ? Icon(
                  Icons.radio_button_on,
                  color: ColorsX.blue_button_color,
                )
              : Icon(
                  Icons.circle_outlined,
                  color: ColorsX.black,
                ),
          SizedBox(
            width: 20,
          )
        ],
      ),
    );
  }
}

class AddCardBottomSheet extends StatelessWidget {
  const AddCardBottomSheet({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: 100,
      width: SizeConfig.screenWidth,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20), topRight: Radius.circular(20)),
          color: ColorsX.white),
      child: Column(
        children: [
          verticalSpace(SizeConfig.blockSizeVertical * 1),
          Container(
            padding: EdgeInsets.only(top: SizeConfig.blockSizeVertical * 2),
            height: 3,
            width: SizeConfig.screenWidth * .3,
            decoration: BoxDecoration(color: ColorsX.black),
          ),
          verticalSpace(SizeConfig.blockSizeVertical * 3),
          Container(
              padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.blockSizeHorizontal * 5),
              child: _textInput("Card Number", TextInputType.number)),
          verticalSpace(SizeConfig.blockSizeVertical * 2),
          Container(
            padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.blockSizeHorizontal * 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                    width: SizeConfig.screenWidth * .4,
                    child: _textInput("MM/YY", TextInputType.number)),
                Container(
                    width: SizeConfig.screenWidth * .4,
                    child: _textInput("CVC", TextInputType.number))
              ],
            ),
          ),
          verticalSpace(SizeConfig.blockSizeVertical * 3),
          Container(
            margin: EdgeInsets.symmetric(
                horizontal: SizeConfig.blockSizeHorizontal * 5),
            height: 1.5,
            color: ColorsX.inputfielboarder,
          ),
          verticalSpace(SizeConfig.blockSizeVertical * 3),
          Container(
            padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.blockSizeHorizontal * 5),
            child: Row(
              children: [
                Checkbox(
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    value: true,
                    onChanged: (value) {}),
                Text(
                  "Save my card",
                  style: TextStyle(
                      fontSize: 14,
                      color: ColorsX.black,
                      fontWeight: FontWeight.bold),
                )
              ],
            ),
          ),
          verticalSpace(SizeConfig.blockSizeVertical * 3),
          Row(
            children: [
              Expanded(
                child: GestureDetector(child: _bottomSheetButton()),
              ),
            ],
          ),
          verticalSpace(SizeConfig.blockSizeHorizontal * 2),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(AppImages.Check_sheild_ic),
              horizontalSpace(SizeConfig.blockSizeHorizontal * 2),
              Text(
                "We'll keep your payment details safe",
                style: TextStyle(
                    fontSize: 14,
                    color: ColorsX.black,
                    fontWeight: FontWeight.bold),
              )
            ],
          )
        ],
      ),
    );
  }

  Container _bottomSheetButton() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: SizeConfig.blockSizeVertical * 2),
      margin:
          EdgeInsets.symmetric(horizontal: SizeConfig.blockSizeHorizontal * 5),
      decoration: BoxDecoration(
          color: ColorsX.greyButtonBackground,
          borderRadius: BorderRadius.circular(10)),
      child: Center(
        child: Text("Done",
            style: TextStyle(
              color: ColorsX.white,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            )),
      ),
    );
  }

  Widget _textInput(String hint, TextInputType inputType) {
    return Container(
      height: SizeConfig.blockSizeVertical * 7,
      //width: SizeConfig.blockSizeHorizontal * 30,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: ColorsX.white,
          border: Border.all(color: ColorsX.inputfielboarder)),

      child: TextFormField(
        // controller: ctl,

        keyboardType: inputType,
        cursorColor: Colors.white,
        textAlign: TextAlign.start,
        style: TextStyle(color: Colors.white, fontSize: 16),
        decoration: InputDecoration(
          border: InputBorder.none,
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
          contentPadding: EdgeInsets.all(9),
          hintStyle: TextStyle(
              color: ColorsX.inputfielboarder, fontWeight: FontWeight.bold),
          errorBorder: InputBorder.none,
          disabledBorder: InputBorder.none,
          hintText: hint,
        ),
      ),
    );
  }
}
