// ignore_for_file: non_constant_identifier_names, file_names

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_countdown_timer/current_remaining_time.dart'
    as timeLeft;
import 'package:flutter_countdown_timer/current_remaining_time.dart';
import 'package:flutter_countdown_timer/flutter_countdown_timer.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/appointment_ctl.dart';
import 'package:saloon_app/app/utils/anim_toast.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class AppointmentDetails extends GetView<AppointmentCTL> {
  bool loadingdone = false;

  @override
  Widget build(BuildContext context) {
    controller.initializeTimer();

    return SafeArea(
      child: Scaffold(
        // bottomNavigationBar: BottomSheetReusable(value: "Appointments",),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                children: <Widget>[
                  Container(
                    height: SizeConfig.screenHeight * .70,
                    decoration: BoxDecoration(
                        color: ColorsX.lightStackColor,
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20))),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () {
                          // Navigator.of(context).pop();
                          Get.back(id: 0);

                          controller.fetchAllAppointment(1, 'All');
                          controller.pagingController.refresh();
                        },
                        child: Container(
                          margin: EdgeInsets.only(top: 20, left: 15),
                          child: Icon(
                            Icons.arrow_back,
                            color: ColorsX.blue_text_color,
                          ),
                        ),
                      ),
                      getImage(context,
                          controller.myAppointment!.saloon?.profilePic ?? ''),
                      nameAndStatusRow(
                          context,
                          "${controller.myAppointment!.saloon?.name ?? ''}",
                          "${controller.myAppointment!.status ?? ''}"),
                      _rowItemForHeaderText(
                          "${controller.myAppointment!.saloon?.address.address ?? ''}",
                          14,
                          FontWeight.w400,
                          0xff707070,
                          20,
                          SizeConfig.tenPercentWidth,
                          SizeConfig.tenPercentWidth),
                      distance(context, "12"),
                      rating(
                          context,
                          double.parse(
                              '${controller.myAppointment!.saloon?.rating ?? 0}'),
                          "${controller.myAppointment!.saloon?.rating}"),
                      // getTotal(context, "Total ", '\$' + ' 280', 0xff707070,
                      //     0xff70b4ff),

                      _dateTimer(context,
                          "${_getDate()} @ ${controller.myAppointment!.timeSlot ?? ''}"),
                    ],
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.blockSizeHorizontal * 5,
                    vertical: SizeConfig.blockSizeVertical),
                child: _itemTextRow("Services", "Price", ColorsX.black),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.blockSizeHorizontal * 5),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: SizeConfig.blockSizeVertical * 0.5),
                  child: _itemTextRow(
                      "${controller.myAppointment!.services?.name} ,",
                      "${controller.myAppointment!.services?.price}",
                      ColorsX.greytext),
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.blockSizeHorizontal * 5,
                    vertical: SizeConfig.blockSizeVertical * 2),
                child: _itemTextRow("Service Total",
                    "${controller.servicesTotal}", ColorsX.black),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.blockSizeHorizontal * 5,
                    vertical: SizeConfig.blockSizeVertical),
                child: Container(
                  height: SizeConfig.blockSizeVertical * 0.1,
                  color: ColorsX.subBlack,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.blockSizeHorizontal * 5,
                    vertical: SizeConfig.blockSizeVertical),
                child: _itemTextRow("Add-ons", "Price", ColorsX.black),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.blockSizeHorizontal * 5),
                child: ListView.builder(
                    physics: NeverScrollableScrollPhysics(),
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    itemCount: controller.myAppointment!.products?.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: EdgeInsets.symmetric(
                            vertical: SizeConfig.blockSizeVertical * 0.5),
                        child: _addOnItemTextRow(
                            "${controller.myAppointment!.products?[index].quantity}x ",
                            "${controller.myAppointment!.products?[index].product?.description},",
                            "${controller.myAppointment!.products?[index].product?.price*controller.myAppointment!.products?[index].quantity}",
                            ColorsX.greytext),
                      );
                    }),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.blockSizeHorizontal * 5,
                    vertical: SizeConfig.blockSizeVertical),
                child: Container(
                  height: SizeConfig.blockSizeVertical * 0.1,
                  color: ColorsX.subBlack,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.blockSizeHorizontal * 5,
                    vertical: SizeConfig.blockSizeVertical * 2),
                child: _itemTextRow(
                    "Add-Ons Total", "${controller.addOnsTotal}", ColorsX.black),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.blockSizeHorizontal * 5,
                    vertical: SizeConfig.blockSizeVertical * 2),
                child: _itemTextRow("Total Bill",
                    "${controller.myAppointment!.totalPrice}", ColorsX.black),
              ),
              controller.isBookingCancelled.isTrue
                  ? Container()
                  : Button(context),
              verticalSpace(SizeConfig.blockSizeVertical * 2),
              controller.isBookingCancelled.isTrue?Container():Text(
                "Time Left",
                style: TextStyle(
                    color: Color(0xff313131),
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 2),
              // Text(
              //   "${_calculateTimeLeft()}",
              //   style: TextStyle(
              //       color: Color(0xffE90505),
              //       fontSize: 25,
              //       fontWeight: FontWeight.bold),
              // ),
              controller.isBookingCancelled.isTrue?Container():Obx(() => CountdownTimer(
                    endTime: controller.endTime.value,
                    widgetBuilder: (_, CurrentRemainingTime? time) {
                      if (time == null) {
                        return Text(
                          '00 : 00',
                          style: TextStyle(
                              color: Color(0xffE90505),
                              fontSize: 25,
                              fontWeight: FontWeight.bold),
                        );
                      } else {
                        if(time.days == null && time.hours ==null){
                          return Text(
                            '${time.min} m : ${time.sec} s',
                            style: TextStyle(
                                color: Color(0xffE90505),
                                fontSize: 25,
                                fontWeight: FontWeight.bold),
                          );
                        } else if(time.days == null){
                          return Text(
                            '${time.hours} h : ${time.min} m : ${time.sec} s',
                            style: TextStyle(
                                color: Color(0xffE90505),
                                fontSize: 25,
                                fontWeight: FontWeight.bold),
                          );
                        }else if(time.hours == null ){
                          return Text(
                            '${time.min} m : ${time.sec} s',
                            style: TextStyle(
                                color: Color(0xffE90505),
                                fontSize: 25,
                                fontWeight: FontWeight.bold),
                          );
                        }

                        return Text(
                          '${time.days} d : ${time.hours} h : ${time.min} m : ${time.sec} s',
                          style: TextStyle(
                              color: Color(0xffE90505),
                              fontSize: 25,
                              fontWeight: FontWeight.bold),
                        );
                      }
                    },
                  )),
              verticalSpace(SizeConfig.blockSizeVertical * 2),
              controller.isBookingCancelled.isTrue?Container():Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(AppImages.Information_ic),
                  horizontalSpace(SizeConfig.blockSizeHorizontal * 3),
                  Container(
                    width: SizeConfig.screenWidth * .6,
                    child: Text(
                      "Deposited 10% of the services will be taken away 24 hours before the appointment",
                      style: TextStyle(
                          color: ColorsX.black,
                          fontSize: 11,
                          fontWeight: FontWeight.normal),
                    ),
                  ),
                ],
              ),
              verticalSpace(SizeConfig.blockSizeVertical * 2),
            ],
          ),
        ),
      ),
    );
  }

  Row _itemTextRow(String text1, String text2, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          text1,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
        Text(
          text2,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ],
    );
  }

  String _getDate() {
    return "${controller.myAppointment!.appointmentDate?.year ?? ''}-${controller.myAppointment!.appointmentDate?.month ?? ''}-${controller.myAppointment!.appointmentDate?.day ?? ''}";
  }

  Row _addOnItemTextRow(String text1, String text2, String text3, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Text(
              text1,
              style: TextStyle(
                  color: ColorsX.subBlack,
                  fontWeight: FontWeight.bold,
                  fontSize: 16),
            ),
            Text(
              text2,
              style: TextStyle(
                  color: color, fontWeight: FontWeight.bold, fontSize: 16),
            ),
          ],
        ),
        Text(
          text3,
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ],
    );
  }

  Widget? getAlertBox(BuildContext context) {
    Dialog errorDialog = Dialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0)), //this right here
      child: Container(
        height: SizeConfig.screenHeight * .45,
        width: SizeConfig.screenWidth * .90,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              "assets/images/cancel.png",
              height: 80,
              width: 80,
            ),
            Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 30,
                  horizontal: SizeConfig.blockSizeHorizontal * 10),
              child: Text(
                "Are you sure you want to cancel your booking?",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Color(0xff707070),
                    fontWeight: FontWeight.w700,
                    fontSize: 20),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 15, right: 15),
              child: Text(
                "Booking can not be cancelled two hours after booking",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: ColorsX.subBlack,
                    fontWeight: FontWeight.w400,
                    fontSize: 16),
              ),
              // child: _rowItemForHeaderText("Booking can not be cancelled two hours after booking", 16, FontWeight.w400, 0xff707070, 0, 0, 0),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                GestureDetector(
                  onTap: () {
                    Get.back();
                  },
                  child: Container(
                    margin:
                        EdgeInsets.only(top: 15, bottom: 15, left: 0, right: 0),
                    width: SizeConfig.thirtyPercentWidth,
                    padding: EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      color: ColorsX.greyBackground,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Text(
                      "No",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: ColorsX.subBlack,
                          fontWeight: FontWeight.w600,
                          fontSize: 16),
                    ),
                  ),
                ),
                horizontalSpace(SizeConfig.blockSizeHorizontal * 5),
                GestureDetector(
                  onTap: () async {
                    // Navigator.of(context).pop();
                    // Navigator.pop(context);
                    Get.back();
                    // Get.back(id: 0);
                    // progressDilog();
                    // cancellationAlert(context);
                    String id = controller.myAppointment!.id;
                    final res = await controller.cancelBooking(id: id);
                    if (res) {
                      // AnimToast.infoToast(context, 'Info', 'Booking canceled successfully');
                      cancellationAlert(context);
                    }
                  },
                  child: Container(
                    margin:
                        EdgeInsets.only(top: 15, bottom: 15, left: 0, right: 0),
                    width: SizeConfig.thirtyPercentWidth,
                    padding: EdgeInsets.symmetric(vertical: 15),
                    decoration: BoxDecoration(
                      color: ColorsX.blue_gradient_dark,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: Text(
                      "Yes",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: ColorsX.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 16),
                    ),
                    // child: _rowItemForHeaderText("Yes", 16, FontWeight.w600, 0xffffffff, 0, 0, 0),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
    showDialog(
        context: context, builder: (BuildContext context) => errorDialog);
  }

  Widget? cancellationAlert(BuildContext context) {
    Dialog errorDialog = Dialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0)), //this right here
      child: Container(
        height: SizeConfig.screenHeight * .45,
        width: SizeConfig.screenWidth * .90,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              "assets/images/cancel.png",
              height: 80,
              width: 80,
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 10),
              child: Text(
                "Your booking has been cancelled",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Color(0xff707070),
                    fontWeight: FontWeight.w700,
                    fontSize: 20),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 15, right: 15),
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: 'Bookings cannot be cancelled after two hours',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: ColorsX.subBlack),
                ),
              ),
            ),
            // DialogButton(context),
            // _rowItemForHeaderText("Go to Booking", 14, FontWeight.w600, 0xff70b4ff, 0, 0, 0)

            Padding(padding: EdgeInsets.only(top: 50.0)),

            GestureDetector(
              onTap: () {
                Get.back();
                controller.endTime.value =
                    DateTime.now().millisecondsSinceEpoch;

                // Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomSheetReusable(value: "billing")));
              },
              child: Container(
                width: SizeConfig.eightyPercentWidth,
                margin: EdgeInsets.only(left: 20, right: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  color: ColorsX.blue_button_color,
                ),
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  "Return to Appointments",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: ColorsX.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            // FlatButton(onPressed: (){
            //   Navigator.of(context).pop();
            // },
            //     child: Text('Got It!', style: TextStyle(color: Colors.purple, fontSize: 18.0),))
          ],
        ),
      ),
    );
    showDialog(
        context: context, builder: (BuildContext context) => errorDialog);
  }

  Widget DialogButton(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            // Navigator.pushNamed(context, '/billing');
            // getAlertBox(context);
          },
          child: Container(
            margin: EdgeInsets.only(top: 15, bottom: 15, left: 15, right: 15),
            width: SizeConfig.screenWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: ColorsX.blue_gradient_dark,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  child: Text("Return to Appointments",
                      style: TextStyle(
                        fontSize: 16,
                        color: ColorsX.white,
                        fontWeight: FontWeight.w700,
                      )),
                ),
              ],
            ),
          ),
        ));
  }

  Widget Button(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            // Navigator.pushNamed(context, '/verify');
            getAlertBox(context);
          },
          child: Container(
            margin: EdgeInsets.only(
              top: 20,
            ),
            width: SizeConfig.eightyPercentWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: Color(0xffE90505),
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Cancel Booking",
                    style: TextStyle(
                      fontSize: 16,
                      color: ColorsX.white,
                      fontWeight: FontWeight.w700,
                    )),
              ],
            ),
          ),
        ));
  }

  Widget _dateTimer(BuildContext context, String time) {
    return Container(
      width: SizeConfig.screenWidth,
      margin: EdgeInsets.only(left: 15, right: 15, top: 20),
      decoration: new BoxDecoration(
        color: ColorsX.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 10, bottom: 10),
            child: Image.asset(
              "assets/images/appoint.png",
              color: ColorsX.blue_button_color,
            ),
          ),
          horizontalSpace(SizeConfig.blockSizeHorizontal * 4),
          _rowItemForHeaderText(time, 14, FontWeight.w400, 0xff707070, 0, 0, 0)
        ],
      ),
    );
  }

  Widget getTotal(BuildContext context, String hardcoded, String total,
      int firstColor, int secondColor) {
    return Container(
      margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth, top: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(
              hardcoded, 16, FontWeight.w600, firstColor, 0, 5, 0),
          _rowItemForHeaderText(
              total, 16, FontWeight.w600, secondColor, 0, 5, 0),
        ],
      ),
    );
  }

  Widget rating(BuildContext context, double rating, String ratingText) {
    return Container(
      margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth, top: 15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            height: SizeConfig.blockSizeVertical * 4,
            child: RatingBar.builder(
              ignoreGestures: true,
              itemSize: SizeConfig.blockSizeVertical * 4,
              initialRating: rating,
              minRating: rating,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                print(rating);
              },
            ),
          ),
          _rowItemForHeaderText(
              ratingText, 16, FontWeight.w400, 0xff707070, 0, 5, 0),
        ],
      ),
    );
  }

  Widget distance(BuildContext context, String distance) {
    return Container(
      margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth, top: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Image.asset("assets/images/pin.png"),
          _rowItemForHeaderText(
              distance + "km", 12, FontWeight.w400, 0xff707070, 0, 5, 0),
        ],
      ),
    );
  }

  Widget nameAndStatusRow(BuildContext context, String text, String status) {
    return Container(
      margin: EdgeInsets.only(
          top: 20,
          left: SizeConfig.tenPercentWidth,
          right: SizeConfig.tenPercentWidth),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _rowItemForHeaderText(text, 16, FontWeight.w700, 0xff000000, 0, 0, 0),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 15, vertical: 6),
            decoration: BoxDecoration(
              color: ColorsX.creamColor,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: _rowItemForHeaderText(
                status, 10, FontWeight.w600, 0xffffffff, 0, 0, 0),
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget getImage(BuildContext context, String imagePath) {
    return Container(
      width: SizeConfig.screenWidth,
      margin: EdgeInsets.only(
          left: SizeConfig.tenPercentWidth,
          right: SizeConfig.tenPercentWidth,
          top: 20),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15.0),
        child: CachedNetworkImage(
          imageUrl: AppUrls.BASE_URL_IMAGE + '${imagePath}',
          errorWidget: (context, url, error) => Icon(Icons.error),
          fit: BoxFit.cover,
          height: 200,
          width: 150,
          placeholder: (context, url) => Container(
              height: 30,
              width: 30,
              child: Center(child: CircularProgressIndicator())),
        ),
      ),
    );
  }

  String _calculateTimeLeft() {
    var temp = controller.myAppointment!.timeSlot.split(':');
    var time;
    int hours = int.parse('${temp[0]}');
    int minutes = int.parse('${temp[1].split(' ')[0]}');
    DateTime currentDate = DateTime.now();
    DateTime queryDate = DateTime.utc(
        controller.myAppointment!.appointmentDate.year,
        controller.myAppointment!.appointmentDate.month,
        controller.myAppointment!.appointmentDate.day,
        hours,
        minutes);
    print(currentDate.difference(queryDate).inHours);
    print(currentDate.difference(queryDate).inMinutes);
    print(currentDate.difference(queryDate).inSeconds);
    var daysleft = (currentDate.difference(queryDate).inHours / 24)
        .abs()
        .toString()
        .split('.')[0];
    var h1 =
        '0.${(currentDate.difference(queryDate).inHours / 24).abs().toString().split('.')[1]}';
    var h2 = double.parse('${h1}').toStringAsFixed(3);
    var hourLeft = (double.parse(h2) * 24);
    var m1 =
        '0.${(double.parse(hourLeft.toString()) * 24).toString().split('.')[1]}';
    var minuteLeft = (double.parse(m1) * 24).toStringAsFixed(0);
    print('Days : $daysleft  Hours:${hourLeft.toStringAsFixed(0)}  Min: ${m1}');

    if (currentDate.difference(queryDate).inHours < -23) {
      time = "$daysleft d : ${hourLeft.toStringAsFixed(0)} h : $minuteLeft m";
    } else {
      time =
          "${currentDate.difference(queryDate).inHours.abs().toStringAsFixed(0)} hours";
    }

    return time;
  }

// Future<void> progressDilog() async {
//   Functions.showProgressDialog(context, "Loading Data", "Please wait. This may take few moments");
//   Functions.progressDialog.show();
//   await Future.delayed(Duration(seconds: 3)).then((value) => Functions.progressDialog.dismiss());
//   Functions.progressDialog.dismiss();

//   cancellationAlert(context);
//   setState(() {
//     loadingdone = true;
//   });
// }
}
