// ignore_for_file: non_constant_identifier_names, file_names

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';

class AppointmentItem extends StatelessWidget {
  String imagePath;
  String name;
  String address;
  String time;
  String date;
  String AmPm;
  String month;
  String? rating;
  String appointmentId;

  String status;
  AppointmentItem(
      {required this.imagePath,
      required this.name,
      required this.address,
      required this.time,
      required this.date,
      required this.AmPm,
      required this.month,
      required this.rating,
      required this.appointmentId,
      required this.status});
  @override
  Widget build(BuildContext context) {
    return Card(
        elevation: 5,
        margin: EdgeInsets.only(left: 15, right: 15, top: 10),
        shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.white70, width: 1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _myItemRowValues(context, imagePath, name, address, time, date,
                AmPm, month, rating),
            appointmentAndServicesRow(context, appointmentId, status),
          ],
        ));
  }

  Widget appointmentAndServicesRow(
      BuildContext context, String appointmentId, String status) {
    return Container(
      margin: EdgeInsets.only(left: 20, right: 15, bottom: 15, top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText(
              "Appointment ID: ", 8, FontWeight.w400, 0xff707070, 10, 0, 0),
          _rowItemForHeaderText(
              appointmentId, 8, FontWeight.w700, 0xff707070, 10, 0, 0),
          Expanded(child: SizedBox()),
          // _rowItemForHeaderText("Services: ", 8, FontWeight.w400, 0xff707070, 10, 0, 0),
          // _rowItemForHeaderText(services, 8, FontWeight.w700, 0xff707070, 10, 0, 0),
          Expanded(child: SizedBox()),

          appointmentStatus(status),
        ],
      ),
    );
  }

  Container appointmentStatus(String status) {
    if (status == "Awaiting") {
      return Container(
        margin: EdgeInsets.only(top: 10),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: status == "Awaiting" ? ColorsX.creamColor : ColorsX.booked,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: _rowItemForHeaderText(
            status, 8, FontWeight.w600, 0xffffffff, 0, 0, 0),
      );
    } else if (status == "Cancelled") {
      return Container(
        margin: EdgeInsets.only(top: 10),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: ColorsX.red_danger,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: _rowItemForHeaderText(
            status, 8, FontWeight.w600, 0xffffffff, 0, 0, 0),
      );
    } else {
      return Container(
        margin: EdgeInsets.only(top: 10),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: ColorsX.booked,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        child: _rowItemForHeaderText(
            status, 8, FontWeight.w600, 0xffffffff, 0, 0, 0),
      );
    }
  }

  Widget _myItemRowValues(
      BuildContext context,
      String imagePath,
      String name,
      String address,
      String time,
      String date,
      String amPm,
      String month,
      String? rating) {
    return Container(
      margin: EdgeInsets.only(top: 10, left: 10, right: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              getImage(context, imagePath),
            ],
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _boldText(name, 14, FontWeight.w700, 0xff707070, 0, 0, 0),
                _rowItemForHeaderText(
                    address, 12, FontWeight.w400, 0xff707070, 0, 0, 0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    _rowItemForHeaderText(
                        time, 12, FontWeight.w400, 0xff707070, 0, 0, 0),
                    SizedBox(
                      width: 35,
                    ),
                    _rowItemForHeaderText(
                        date, 12, FontWeight.w400, 0xff707070, 0, 0, 0),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                      decoration: new BoxDecoration(
                        color: ColorsX.greyBackground,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      child: _rowItemForHeaderText(
                          AmPm, 12, FontWeight.w400, 0xff000000, 0, 0, 0),
                    ),
                    SizedBox(
                      width: 30,
                    ),
                    _rowItemForHeaderText(
                        month, 12, FontWeight.w400, 0xff707070, 0, 0, 0),
                  ],
                )
              ],
            ),
          ),
          _rowItemForHeaderText(
              rating??'', 15, FontWeight.w400, 0xff707070, 0, 0, 0),
          Icon(
            Icons.star,
            color: ColorsX.yellow,
          ),
        ],
      ),
    );
  }

  Widget getImage(BuildContext context, String imagePath) {
    return Container(
      width: 65,
      margin: EdgeInsets.only(left: 10, right: 10),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15.0),
        child: Image.asset(
          imagePath,
          fit: BoxFit.cover,
          height: 65,
          width: 65,
        ),
      ),
    );
  }

  Widget _boldText(String value, double fontSize, FontWeight fontWeight,
      int colorCode, double top, double left, double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }
}
