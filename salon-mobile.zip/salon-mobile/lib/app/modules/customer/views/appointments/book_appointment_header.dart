import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class BookAppointmentHeader extends GetView<SaloonController>{
  // GetSaloonDetailsModel? getSaloonDetailsModel;
  // BookAppointmentHeader({this.getSaloonDetailsModel});
  @override
  Widget build(BuildContext context) {
    // print('Book appointment ${getSaloonDetailsModel?.saloon}');
    String? imagePath = controller.getSaloonDetailsModel?.saloon?.profilePic;
    return Scaffold(

      body: Stack(
        children: <Widget>[

          Align(
            alignment: Alignment.topCenter,
            child: Container(
              width: SizeConfig.screenWidth,
              height: SizeConfig.fortyPercentHeight,
              margin: EdgeInsets.only(top: 0),
              decoration: BoxDecoration(
                  color: Color(0xFF0E3311).withOpacity(0.7)
              ),
              child: Opacity(
                opacity: 0.4,
                child: CachedNetworkImage(
                  imageUrl: AppUrls.BASE_URL_IMAGE+'${imagePath}',
                  errorWidget: (context, url, error) => Icon(Icons.error),
                  fit: BoxFit.cover,width: SizeConfig.screenWidth, height: SizeConfig.fortyPercentHeight,

                  placeholder: (context, url) => Container(
                      height: 30,
                      width: 30,
                      child: Center(child: CircularProgressIndicator())),
                ),
              ),
            ),
          ),
          // Container(
          //   width: SizeConfig.screenWidth,
          //   child: Image.asset("assets/images/popular.png", fit: BoxFit.contain,),
          //   // child: Image.asset(, fit: BoxFit.contain,),
          // ),

          Align(
            alignment: Alignment.topLeft,
            child: InkWell(
              onTap: (){
                Get.back();
              },
              child: Container(
                margin: EdgeInsets.only(
                    top: SizeConfig.screenHeight * .07, left: 15),
                child: Icon(
                  Icons.arrow_back,
                  color: ColorsX.white,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.topRight,
            child: Container(
              margin: EdgeInsets.only(
                top: SizeConfig.screenHeight * .07, right: 15,),
              child: Image.asset(AppImages.notify),
            ),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: Container(
                margin: EdgeInsets.only(top: 100),
                child: Text("Looks Unisex Saloon", style: TextStyle(color: ColorsX.white,fontWeight: FontWeight.w700, fontSize: 20),)
            ),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: Container(
                margin: EdgeInsets.only(top: 140),
                child: Text("Book Appointment", style: TextStyle(color: ColorsX.white,fontWeight: FontWeight.w700, fontSize: 20),)
            ),
          ),
        ],
      ),
    );
  }
}