// the navigation inside the dialog
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/bindings/appointment_binding.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/AppointmentDetails.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/my_appointments.dart';

class AppointmentNavigation {
  AppointmentNavigation._();
  static const id = 0;
  static const dialogOne = '/dialog-one';
  static const dialogTwo = '/dialog-two';
}
// our wrapper, where our main navigation will navigate to
class AppointmentWrapper extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Navigator(
      
      key: Get.nestedKey(AppointmentNavigation.id),
      onGenerateRoute: (settings) {
        // navigate to a route by name with settings.name
        if (settings.name == AppointmentNavigation.dialogTwo) {
          return GetPageRoute(
            routeName: AppointmentNavigation.dialogTwo,
            page: () => AppointmentDetails(),
          );
        } else {
          return GetPageRoute(
            routeName: AppointmentNavigation.dialogOne,
            page: () => MyAppointments(),
            binding: AppointmentBinding()
          );
        }
      },
    );
  }
}