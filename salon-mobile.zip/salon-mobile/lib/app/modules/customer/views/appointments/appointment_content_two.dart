import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';
import 'book_appointment_header.dart';
import 'book_appointment_two.dart';

class AppointmentContentTwo extends StatelessWidget{
  // GetSaloonDetailsModel? getSaloonDetailsModel;
  // AppointmentContentTwo({this.getSaloonDetailsModel});
  @override
  Widget build(BuildContext context) {
    // print(getSaloonDetailsModel?.saloon);
    return Scaffold(
      body: Stack(
        children: [
          // getSaloonDetailsModel?.saloon!=null?BookAppointmentHeader(getSaloonDetailsModel: getSaloonDetailsModel,):Container(),
          BookAppointmentHeader(),
          Container(
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            margin: EdgeInsets.only(top: SizeConfig.screenHeight*.25,),
            decoration: new BoxDecoration(
              color: ColorsX.white,
              borderRadius: BorderRadius.all( Radius.circular(25)),
            ),
            // child: BottomSheetReusable(value: "appointmentTwo"),
            child: BookAppointmentTwo(),
          ),
        ],
      ),
    );
  }
}