import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/modules/customer/controllers/appointment_ctl.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/appointments_wrapper.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'AppointmentItem.dart';
import 'package:saloon_app/app/data/model/customer/appointment/my_appointment.dart'
    as appointment;

class MyAppointments extends GetView<AppointmentCTL> {

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DefaultTabController(
        length: 4,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Stack(
              children: <Widget>[
                // Container(
                //   height: 80,
                //   color: ColorsX.lightStackColor,
                // ),
                Container(
                  width: SizeConfig.screenWidth,
                  child: Image.asset(
                    AppImages.Appointments_bg,
                    fit: BoxFit.contain,
                  ),
                ),
                Align(
                  alignment: Alignment.center,
                  child: _rowItemForHeaderText(
                      "My Appointments",
                      16,
                      FontWeight.w700,
                      0xff707070,
                      20,
                      0,
                      0),
                ),
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    margin: EdgeInsets.only(
                        top: SizeConfig.blockSizeVertical * 8,
                        left: SizeConfig.blockSizeHorizontal * 3,
                        right: SizeConfig.blockSizeHorizontal * 3),
                    child: TabBar(
                        indicatorColor: ColorsX.blue_text_color,
                        labelColor: ColorsX.blue_text_color,
                        unselectedLabelColor: ColorsX.black,
                        labelPadding: EdgeInsets.zero,
                        onTap: (index) {
                          if (index == 0) {
                            controller.fetchAllAppointment(1, 'All');
                            controller.pagingController.refresh();
                          } else if (index == 1) {
                            controller.fetchAllAppointment(1, 'Upcoming');
                            controller.pagingController.refresh();
                          } else if (index == 2) {
                            controller.fetchAllAppointment(1, 'Cancelled');
                            controller.pagingController.refresh();
                          } else if (index == 3) {
                            controller.fetchAllAppointment(1, 'History');
                            controller.pagingController.refresh();
                          }
                        },
                        tabs: [
                          Tab(
                            text: "All",
                          ),
                          Tab(
                            text: "Upcoming",
                          ),
                          Tab(
                            text: "Cancelled",
                          ),
                          Tab(
                            text: "History",
                          ),
                        ]),
                  ),
                )
              ],
            ),
            Expanded(
              child: TabBarView(
                physics: NeverScrollableScrollPhysics(),
                  controller: controller.tabController,
                  children: [
                    _allAppointments(),
                    _allAppointments(),
                    _allAppointments(),
                    _allAppointments()
                  ]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _allAppointments() {
    return PagedListView<int, appointment.Datum>(
      padding: EdgeInsets.zero,
      pagingController: controller.pagingController,
      builderDelegate: PagedChildBuilderDelegate<appointment.Datum>(
          itemBuilder: (context, item, index) => InkWell(
                // behavior: HitTestBehavior.translucent,
                onTap: () {
                  // print("Item Selected");
                  _getTotalSercice(item);
                  _getTotalAddOns(item);
                  controller.myAppointment = item;
                  Get.toNamed(AppointmentNavigation.dialogTwo, id: 0);
                },
                child: AppointmentItem(
                  imagePath: "assets/images/popular.png",
                  name: item.saloon?.name??'',
                  address: item.saloon?.address.address??'',
                  time: (item.timeSlot.toString().contains(' ')?item.timeSlot?.split(' ')[0]:'')??'',
                  date: item.appointmentDate?.day.toString()??'',
                  AmPm: (item.timeSlot.toString().contains(' ')?item.timeSlot?.split(' ')[1]:'')??'',
                  month:
                      "${item.appointmentDate?.month??''} ${item.appointmentDate?.year??''}",
                  rating: item.saloon?.rating.toString()??'',
                  appointmentId: "#${item.appointmentId}",
                  status: item.status,
                ),
              )),
    );
  }

  Widget getImage(BuildContext context, String imagePath) {
    return Container(
      width: SizeConfig.screenWidth,
      margin: EdgeInsets.only(
          left: SizeConfig.tenPercentWidth,
          right: SizeConfig.tenPercentWidth,
          top: 20),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15.0),
        child: Image.asset(
          imagePath,
          fit: BoxFit.cover,
          height: 200,
          width: 150,
        ),
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  void _getTotalSercice(appointment.Datum data) {
    // for (var s in data.services) {
    //   controller.servicesTotal += int.parse('${s.price}');
    // }
    controller.servicesTotal = int.parse('${data.services?.price}');
  }void _getTotalAddOns(appointment.Datum data) {
    controller.addOnsTotal=0;
    var temp=0;
    if(data.products !=null) {
      for (var p in data.products!) {
        temp=int.parse('${p.product?.price*p.quantity}');
        controller.addOnsTotal += temp;
        temp=0;
      }
    }

  }
}
