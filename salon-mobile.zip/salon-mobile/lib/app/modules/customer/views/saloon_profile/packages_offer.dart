import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/resuseable/bottom_cart.dart';
import 'package:saloon_app/app/resuseable/package_and_offers_row.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class PackageOfferList extends GetView<SaloonController> {
  // GetSaloonDetailsModel getSaloonDetailsModel;
  //
  // PackageOfferList({required this.getSaloonDetailsModel});

  @override
  Widget build(BuildContext context) {
    String append = 'Completed Package Offer till ';
    String myDollar = '\$';
    controller.buttonValue.value=="Book Now";
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        for (int index = 0; index < (controller.getSaloonDetailsModel?.coupons?.length??0); index++)
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _PopularItemView(
                context: context,
                imageOne: AppImages.Packages_img,
                dealID: controller.getSaloonDetailsModel?.coupons?[index].couponCode,
                serviceName: controller.getSaloonDetailsModel?.coupons?[index].service.name,
                dealName: controller.getSaloonDetailsModel?.coupons?[index].couponName,
                originalPrice: controller.getSaloonDetailsModel?.coupons?[index].price.toString()=="0"?"":controller.getSaloonDetailsModel?.coupons?[index].price.toString(),
                discountedPrice: "200",
                discount: controller.getSaloonDetailsModel?.coupons?[index].percentage.toString(),
                validDate: controller.getSaloonDetailsModel?.coupons?[index].endDate,
                status: controller.getSaloonDetailsModel?.coupons?[index].status),
            // dealsContainer(context, "1440", "Package for product", 1400,
            //     30, "Active", "12/01/1995"),
            // dealsContainer(context, "1440", "Package for product", 1400,
            //     30, "Expired", "12/01/1995"),
            // dealsContainer(context, "1440", "Package for product", 1400,
            //     30, "Active", "12/01/1995"),
            // dealsContainer(context, "1440", "Package for product", 1400,
            //     30, "Expired", "12/01/1995"),
            // dealsContainer(context, getSaloonDetailsModel.coupons?[i]?.couponCode, getSaloonDetailsModel.coupons?[i]?.couponName, getSaloonDetailsModel.coupons?[i]?.price,
            //     getSaloonDetailsModel.coupons?[i]?.percentage, getSaloonDetailsModel.coupons?[i]?.status, getSaloonDetailsModel.coupons?[i]?.expiry.toString())
            // getImage(context, "assets/images/bridal.png"),
            // TextToBeShown(context, getSaloonDetailsModel.coupons?[i].couponName, "Book Now",16, FontWeight.w600,16, FontWeight.w600),
            // TextToBeShown(context, '${append}${getSaloonDetailsModel.coupons?[i].expiry} ', '${myDollar}${getSaloonDetailsModel.coupons?[i].price}',12, FontWeight.w400, 14, FontWeight.w700),
          ],
        ),
        BottomCart()
      ],
    );

    //   getSaloonDetailsModel.coupons!.length != 0
    //     ? Column(
    //   crossAxisAlignment: CrossAxisAlignment.start,
    //   children: <Widget>[
    //     for (var i = 0; i < getSaloonDetailsModel.coupons!.length; i++)
    //       Column(
    //         mainAxisSize: MainAxisSize.min,
    //         children: [
    //           dealsContainer(context, getSaloonDetailsModel.coupons?[i]?.couponCode, getSaloonDetailsModel.coupons?[i]?.couponName, getSaloonDetailsModel.coupons?[i]?.price,
    //               getSaloonDetailsModel.coupons?[i]?.percentage, getSaloonDetailsModel.coupons?[i]?.status, getSaloonDetailsModel.coupons?[i]?.expiry.toString())
    //           // getImage(context, "assets/images/bridal.png"),
    //           // TextToBeShown(context, getSaloonDetailsModel.coupons?[i].couponName, "Book Now",16, FontWeight.w600,16, FontWeight.w600),
    //           // TextToBeShown(context, '${append}${getSaloonDetailsModel.coupons?[i].expiry} ', '${myDollar}${getSaloonDetailsModel.coupons?[i].price}',12, FontWeight.w400, 14, FontWeight.w700),
    //         ],
    //       )
    //   ],
    // )
    //     : Container();
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget dealsContainer(
      BuildContext context,
      String? coupunCode,
      String? coupunName,
      int? price,
      int? percentage,
      String? status,
      String? date) {
    return Card(
      elevation: 5,
      margin: EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 15),
      color: Colors.grey[200],
      shape: RoundedRectangleBorder(
        side: BorderSide(color: Colors.white70, width: 1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Container(
        width: SizeConfig.screenWidth,
        margin: EdgeInsets.only(
          left: 15,
          right: 15,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width * .40,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _rowItemForHeaderText(
                      "Deal", 12, FontWeight.w400, 0xff707070, 5, 5, 0),
                  SizedBox(
                    height: 7,
                  ),
                  _rowItemForHeaderText('${coupunCode}', 12, FontWeight.w700,
                      0xff6EC8FD, 5, 5, 0),
                  SizedBox(
                    height: 7,
                  ),
                  _rowItemForHeaderText('${coupunName}', 12, FontWeight.w700,
                      0xff6EC8FD, 5, 5, 0),
                  SizedBox(
                    height: 7,
                  ),
                  _rowItemForHeaderText(
                      price.toString() == "null" ? "" : "Price",
                      12,
                      FontWeight.w400,
                      0xff707070,
                      5,
                      5,
                      0),
                  SizedBox(
                    height: 7,
                  ),
                  _rowItemForHeaderText(
                      price.toString() == "null" ? "" : price.toString() + '\$',
                      12,
                      FontWeight.w700,
                      0xff6EC8FD,
                      5,
                      5,
                      0),
                  SizedBox(
                    height: 7,
                  ),
                ],
              ),
            ),
            Container(
                width: MediaQuery.of(context).size.width * .40,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    _rowItemForHeaderText(
                        percentage.toString() == "null"
                            ? ""
                            : percentage.toString() + ' %' + '\nOff',
                        16,
                        FontWeight.w700,
                        0xff6EC8FD,
                        5,
                        5,
                        0),
                    SizedBox(
                      height: 7,
                    ),
                    getstatus('${status}'),
                    SizedBox(
                      height: 7,
                    ),
                    _rowItemForHeaderText(
                        "Valid 0nly", 12, FontWeight.w400, 0xff707070, 5, 5, 0),
                    SizedBox(
                      height: 7,
                    ),
                    _rowItemForHeaderText(
                        '${date}', 12, FontWeight.w700, 0xff707070, 5, 0, 0),
                    SizedBox(
                      height: 7,
                    ),
                  ],
                )),
          ],
        ),
      ),
    );
  }

  Widget getstatus(String status) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        color: status == "Active" ? Color(0xff00ff00) : Color(0xffff0000),
      ),
      child: Text(
        status,
        textAlign: TextAlign.center,
        style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: Color(0xffffffff)),
      ),
    );
  }

  Widget _PopularItemView({
    required BuildContext context,
    required String? imageOne,
    required String? dealID,
    required String? serviceName,
    required String? dealName,
    required String? originalPrice,
    required String discountedPrice,
    required String? discount,
    required String? validDate,
    required String? status,
  }){
    return GestureDetector(
      onTap: () {
        //SALOON_ID = saloonId!;
        // Navigator.pushNamed(context, '/aboutSaloon');

        // Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomSheetReusable(value: "aboutSaloon")));
      },
      child: Container(
        margin: EdgeInsets.only(top: 15, right: 20),
        height: SizeConfig.screenHeight * .29,
        width: SizeConfig.eightyPercentWidth,
        child: Stack(
          children: <Widget>[
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                height: SizeConfig.screenHeight * .30,

                // width: ,
                child: ClipRRect(
                    borderRadius: new BorderRadius.circular(10.0),
                    child: Image.asset(
                      imageOne!,
                      fit: BoxFit.cover,
                      width: SizeConfig.screenWidth,
                      height: 160.0,
                    )),
              ),
              // child: Image.asset(imageOne, fit: BoxFit.contain,),),
            ),

            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.blockSizeHorizontal * 2,
                  vertical: SizeConfig.blockSizeVertical * 2),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _rowItemText("Deal", 12, FontWeight.bold, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 0.25),
                      _rowItemText(dealID, 12, FontWeight.bold, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 5),
                      _rowItemText(
                          dealName, 16, FontWeight.normal, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 1),
                      _rowItemText(
                          serviceName, 16, FontWeight.bold, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 2),
                      originalPrice=="0"?_rowItemText(
                          "Price", 16, FontWeight.normal, ColorsX.white):Container(),
                      verticalSpace(SizeConfig.blockSizeVertical * 1),
                      Row(
                        children: [
                          originalPrice=="0"?_rowItemText("$discountedPrice\$", 16,
                              FontWeight.bold, ColorsX.white):Container(),
                          horizontalSpace(SizeConfig.blockSizeVertical * 2),
                          originalPrice=="0"?_rowItemLineThroughText("$originalPrice\$", 16,
                              FontWeight.bold, ColorsX.red_dashboard):Container(),
                        ],
                      )
                    ],
                  ),
                  Spacer(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _rowItemText("$discount%", 28, FontWeight.bold,
                          ColorsX.light_orange_text),
                      _rowItemText("OFF", 28, FontWeight.bold,
                          ColorsX.light_orange_text),
                      verticalSpace(SizeConfig.blockSizeVertical * 3),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.blockSizeHorizontal * 4,
                            vertical: SizeConfig.blockSizeVertical * 0.5),
                        decoration: BoxDecoration(
                            color: ColorsX.active_green,
                            borderRadius:
                            BorderRadius.all(Radius.circular(10))),
                        child: _rowItemText(
                            status, 13, FontWeight.bold, ColorsX.white),
                      ),
                      verticalSpace(SizeConfig.blockSizeVertical * 2),
                      _rowItemText(
                          "Valid only", 16, FontWeight.normal, ColorsX.white),
                      verticalSpace(SizeConfig.blockSizeVertical * 1),
                      _rowItemText(
                          validDate, 16, FontWeight.normal, ColorsX.white),
                    ],
                  )
                ],
              ),
            ),
            // _containerStyling("4.0",4.0,14, FontWeight.w400),
          ],
        ),
      ),
    );
  }

  Widget _rowItemText(
      String? text1, double fontSize, FontWeight fontWeight, Color color) {
    return Text(
      '${text1}',
      style:
          TextStyle(color: color, fontWeight: fontWeight, fontSize: fontSize),
    );
  }

  Widget _rowItemLineThroughText(
      String? text1, double fontSize, FontWeight fontWeight, Color color) {
    return Text(
      '${text1}',
      style: TextStyle(
          color: color,
          fontWeight: fontWeight,
          fontSize: fontSize,
          decoration: TextDecoration.lineThrough),
    );
  }
}
// class PackageOfferList extends StatelessWidget{
//   GetSaloonDetailsModel getSaloonDetailsModel;
//   PackageOfferList({required this.getSaloonDetailsModel});
//   @override
//   Widget build(BuildContext context) {
//     String append = 'Completed Package Offer till ';
//     String myDollar = '\$';
//     return getSaloonDetailsModel.coupons!.length!=0? Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: <Widget>[
//         for ( var i=0;i<getSaloonDetailsModel.coupons!.length;i++ )Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             getImage(context, "assets/images/bridal.png"),
//             TextToBeShown(context, getSaloonDetailsModel.coupons?[i].couponName, "Book Now",16, FontWeight.w600,16, FontWeight.w600),
//             TextToBeShown(context, '${append}${getSaloonDetailsModel.coupons?[i].expiry} ', '${myDollar}${getSaloonDetailsModel.coupons?[i].price}',12, FontWeight.w400, 14, FontWeight.w700),
//           ],
//         )
//       ],
//     ):Container();
//   }
//   Widget TextToBeShown(BuildContext context, String? firstText, String? secondText, double firstFontSize, FontWeight fontWeight, double secondFontSize, FontWeight secondfontWeight){
//     return Container(
//       margin: EdgeInsets.only(left: 15, right: 15),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: <Widget>[
//           GestureDetector(
//             child: Container(
//               constraints: BoxConstraints(minWidth: 100, maxWidth: 270),
//               child: _rowItemForHeaderText('${firstText}', firstFontSize, fontWeight, 0xff707070, 5, 15, 0),
//             ),
//           ),
//           _rowItemForHeaderText('${secondText}', secondFontSize, secondfontWeight, 0xff70b4ff, 5, 0, 15),
//         ],
//       ),
//     );
//   }
//   Widget getImage(BuildContext context, String imagePath){
//     return Container(
//       margin: EdgeInsets.only(left: 15, right: 15, top: 20),
//       decoration: new BoxDecoration(
//         borderRadius: BorderRadius.all(Radius.circular(15)),
//       ),
//       child: Image.asset(imagePath, fit: BoxFit.cover, width: SizeConfig.screenWidth,),
//     );
//   }
//   Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
//     return Container(
//       margin: EdgeInsets.only(top: top, left: left, right: right),
//       child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
//     );
//   }
// }
// // Widget _columnItemOf
