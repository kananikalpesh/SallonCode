import 'package:accordion/accordion.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animated_dialog/flutter_animated_dialog.dart'
    as animatedDialog;
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/modules/intro_pages/views/slidercontent.dart';
import 'package:saloon_app/app/resuseable/bottom_cart.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'middle_container.dart';
import 'my_tab_bars.dart';
import 'topstack.dart';

class SelectServices extends GetView<SaloonController> {
  bool loadingdone = false;

  // GetSaloonDetailsModel _getSaloonDetailsModel = GetSaloonDetailsModel();

  @override
  Widget build(BuildContext context) {
    controller.buttonValue.value = "View Cart";
    return Scaffold(
      body: SizedBox(
        height: SizeConfig.screenHeight,
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                // shrinkWrap: true,
                // physics: NeverScrollableScrollPhysics(),
                mainAxisSize: MainAxisSize.max,
                children: [
                  Stack(
                    children: <Widget>[
                      // _getSaloonDetailsModel.saloon!=null?
                      // TopStack( getSaloonDetailsModel: _getSaloonDetailsModel,),
                      _topStack(
                          "${controller.getSaloonDetailsModel?.saloon?.profilePic}"),
                      Align(
                        alignment: Alignment.topLeft,
                        child: InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Container(
                            margin: EdgeInsets.only(
                                top: SizeConfig.screenHeight * .05, left: 15),
                            child: Icon(
                              Icons.arrow_back,
                              color: ColorsX.white,
                            ),
                          ),
                        ),
                      ),

                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          margin: EdgeInsets.only(
                            top: SizeConfig.screenHeight * .06,
                            right: 15,
                          ),
                          child: Image.asset(AppImages.notify),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                            margin: EdgeInsets.only(
                                top: SizeConfig.screenHeight * .185, left: 0),
                            child: _rowItemForHeaderText(
                                "${controller.getSaloonDetailsModel?.saloon?.name}",
                                20,
                                FontWeight.bold,
                                0xFFFFFFFF,
                                0,
                                0,
                                0)),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                            margin: EdgeInsets.only(
                                top: SizeConfig.screenHeight * .23, left: 0),
                            child: _rowItemForHeaderText("Book Appointment", 20,
                                FontWeight.bold, 0xFFFFFFFF, 0, 0, 0)),
                      ),
                      Container(
                        margin:
                            EdgeInsets.only(top: SizeConfig.screenHeight * .3),
                        decoration: BoxDecoration(
                            color: ColorsX.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(15),
                                topRight: Radius.circular(15))),
                        child:
                            // _getSaloonDetailsModel.staff!=null?
                            // MiddleContainer(getSaloonDetailsModel: _getSaloonDetailsModel,),
                            Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Row(
                              children: [
                                _rowItemForHeaderText(
                                    "Select Services",
                                    16,
                                    FontWeight.bold,
                                    0xFF000000,
                                    SizeConfig.blockSizeVertical * 2,
                                    15,
                                    15)
                              ],
                            ),
                            _middleContainer(context),
                          ],
                        ),
                        // :Container(),
                      ),

                      // :Container(),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(
                  top: controller.addOnCount == 0
                      ? SizeConfig.screenHeight * .9
                      : SizeConfig.screenHeight * .88),
              child: GestureDetector(
                onTap: () {
                  // Get.toNamed(Routes.SELECT_ADD_ONS);
                },
                child: Align(
                    alignment: Alignment.bottomCenter, child: BottomCart()),
              ),
            )
          ],
        ),
      ),
    );
    // _getSaloonDetailsModel.saloon!=null?
    // :Container(
    //   width: SizeConfig.screenWidth,
    //   height: SizeConfig.screenHeight,
    //   child: Center(
    //     child: Text("No data Found", style: TextStyle(fontWeight: FontWeight.w400, color: Colors.black),),
    //   ),
    // );
  }

  void showPopUp(BuildContext context, String title, String content, String ok,
      bool status) {
    animatedDialog.showAnimatedDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return animatedDialog.ClassicGeneralDialogWidget(
          titleText: title,
          contentText: content,
          positiveText: ok,
          onPositiveClick: () {
            if (status == false) {
              Navigator.of(context).pop();
            } else {
              // Navigator.of(context).push(MaterialPageRoute(builder:(context)=>OTPCode(phone: _phoneController.text)));
              // Navigator.pushNamed(context, '/continue');
            }
          },
        );
      },
      animationType: animatedDialog.DialogTransitionType.fade,
      curve: Curves.fastOutSlowIn,
      duration: Duration(seconds: 1),
    );
  }

  Widget _middleContainer(BuildContext context) {
    // return ListView.builder(
    //     shrinkWrap: true,
    //     physics: NeverScrollableScrollPhysics(),
    //     itemCount: 10,
    //     itemBuilder: (BuildContext context, int index) {
    //       return CheckboxListTile(
    //         controlAffinity: ListTileControlAffinity.leading,
    //         title: _rowItemForHeaderText("Cut with scissors, 60 min", 12,
    //             FontWeight.w400, 0xff000000, 0, 0, 0),
    //         subtitle: _rowItemForHeaderText("Recommended with long hairstyles",
    //             12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
    //         value: false,
    //         onChanged: (value) {
    //           // setState(() {
    //           //   this.valuesecond = value!;
    //           // });
    //         },
    //       );
    //     });

    return Container(
      child: Column(
        children: [
          if (AppStrings.fromStaff == "")
            for (int index = 0;
                index <
                    (controller.getSaloonDetailsModel?.services?.length ?? 0);
                index++)
              _buildExpandableList(
                  index,
                  "Service Type",
                  controller
                      .getSaloonDetailsModel?.services?[index].category.title,
                  ""
                      "",
                  "",
                  "",
                  ""),
          if (AppStrings.fromStaff == "yes")
            for (int index = 0;
                index <
                    (controller.staffDetailModel?.data.services.length ?? 0);
                index++)
              _buildExpandableListForStaff(
                  index,
                  "Service ",
                  "",
                  // "${controller.getSaloonDetailsModel?.saloon?.services[index].description}, "
                  //     "${controller.getSaloonDetailsModel?.saloon?.services[index].timeRequired} min",
                  "",
                  "",
                  // "${controller.getSaloonDetailsModel?.saloon?.services[index].id}",
                  // "${controller.getSaloonDetailsModel?.saloon?.services[index].price}"),
                  "",
                  ""),
          GestureDetector(
              onTap: () {
                if (controller.selectedServicesList.isEmpty) {
                  print("Select at least one service");
                  Functions.showSimpleDialog(
                      title: 'No Service',
                      msg: 'Please select a service to continue.');
                } else if (controller.selectedServicesList.length
                    .isGreaterThan(1)) {
                  print("Select only one service");
                  Functions.showSimpleDialog(
                      title: 'More than One Service Selected',
                      msg: 'Please select only one service to continue.');
                } else {
                  Get.toNamed(Routes.SELECT_ADD_ONS);
                }
              },
              child: Button(context)),
          verticalSpace(SizeConfig.blockSizeVertical * 10)
        ],
      ),
    );
  }

  Widget Button(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: Container(
          margin: EdgeInsets.only(
            top: 20,
          ),
          width: SizeConfig.eightyPercentWidth,
          padding: EdgeInsets.symmetric(vertical: 15),
          decoration: BoxDecoration(
            color: ColorsX.blue_button_color,
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text("Continue to Select Add-ons",
                  style: TextStyle(
                    fontSize: 16,
                    color: ColorsX.white,
                    fontWeight: FontWeight.w700,
                  )),
            ],
          ),
        ));
  }

  Widget _buildExpandableList(int index, String title, String? subtitle,
      String itemTitle, String itemSubtitle, String? id, String? itemPrice) {
    int length =
        controller.getSaloonDetailsModel?.services?[index].services.length ?? 0;
    // controller.staffDetailModel?.data.services.length
    return Card(
      color: Color(0xffEFF6F6),
      margin: EdgeInsets.only(left: 10, right: 10, top: 10),
      child: ExpansionTile(
        leading: Container(
          decoration: BoxDecoration(
              color: ColorsX.blue_button_color, shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(3.0),
            child: Image.asset(
              "assets/images/hair.png",
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _rowItemForHeaderText(
                "${title}", 10, FontWeight.w400, 0xff000000, 0, 0, 0),
            _rowItemForHeaderText(
                "${subtitle}", 12, FontWeight.w400, 0xffA8A7A7, 0, 0, 0),
          ],
        ),
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              for (int i = 0; i < length; i++)
                ListTile(
                  leading: Obx(() => Checkbox(
                        value: controller.getSaloonDetailsModel
                            ?.services?[index].services[i].isChecked.value,
                        onChanged: (bool? value) {
                          print('Outer Value _buildExpandableList :  ${index}');
                          print('I Value :  ${i}');
                          print(
                              'chekbox clicked. ${controller.getSaloonDetailsModel?.services?[index].services[i].isChecked.value}');
                          //single check start
                          for (var serviceType = 0;
                              serviceType <
                                  (controller.getSaloonDetailsModel?.services
                                          ?.length ??
                                      0);
                              serviceType++)
                            for (int x = 0;
                                x <
                                    (controller
                                            .getSaloonDetailsModel
                                            ?.services?[serviceType]
                                            .services
                                            .length ??
                                        0);
                                x++) {
                              if (serviceType == index && x == i) {
                                print('serviceType :  ${serviceType}');
                                controller
                                    .getSaloonDetailsModel
                                    ?.services?[serviceType]
                                    .services[x]
                                    .isChecked
                                    .value = true;

                                addService(index, i);
                              }else{
                                controller
                                    .getSaloonDetailsModel
                                    ?.services?[serviceType]
                                    .services[x]
                                    .isChecked
                                    .value = false;
                              }
                            }

                          print(controller.serviceCount.value);
                          print(
                              "controller.selectedServicesList ${controller.selectedServicesList}");
                          print(controller.selectedServicesIDSList);
                          print(controller.selectedServicesPriceList);
                        },
                      )),
                  title: _rowItemForHeaderText(
                      "${controller.getSaloonDetailsModel?.services?[index].services[i].name}",
                      12,
                      FontWeight.w400,
                      0xff000000,
                      0,
                      0,
                      0),
                  subtitle: _rowItemForHeaderText(
                      "${controller.getSaloonDetailsModel?.services?[index].services[i].description}",
                      12,
                      FontWeight.w400,
                      0xffA8A7A7,
                      0,
                      0,
                      0),
                  trailing: Container(
                    width: SizeConfig.blockSizeHorizontal * 12,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _rowItemForHeaderText(
                            "${controller.getSaloonDetailsModel?.services?[index].services[i].prefix} "
                            "${controller.getSaloonDetailsModel?.services?[index].services[i].price}",
                            12,
                            FontWeight.w400,
                            0xff70b4ff,
                            0,
                            0,
                            0),
                        // Image.asset(AppImages.delete_list_ic),
                      ],
                    ),
                  ),
                  isThreeLine: true,
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildExpandableListForStaff(int index, String title, String? subtitle,
      String itemTitle, String itemSubtitle, String? id, String? itemPrice) {
    int length = controller.staffDetailModel?.data.services.length ?? 0;
    return Card(
      color: Color(0xffEFF6F6),
      margin: EdgeInsets.only(left: 10, right: 10, top: 10),
      child: ExpansionTile(
        leading: Container(
          decoration: BoxDecoration(
              color: ColorsX.blue_button_color, shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(3.0),
            child: Image.asset(
              "assets/images/hair.png",
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _rowItemForHeaderText(
                "${title}", 10, FontWeight.w400, 0xff000000, 0, 0, 0),
            _rowItemForHeaderText(
                "${subtitle}", 12, FontWeight.w400, 0xffA8A7A7, 0, 0, 0),
          ],
        ),
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              for (int i = 0; i < length; i++)
                ListTile(
                  leading: Obx(() => Checkbox(
                        value: controller
                            .staffDetailModel?.data.services[i].isChecked.value,
                        onChanged: (bool? value) {
                          print('Outer Value _buildExpandableList :  ${index}');
                          print('I Value :  ${i}');
                          print(
                              'chekbox clicked. ${controller.getSaloonDetailsModel?.services?[index].services[i].isChecked.value}');
                          //single check start
                          for (var serviceType = 0;
                              serviceType <
                                  (controller.staffDetailModel?.data.services
                                          .length ??
                                      0);
                              serviceType++) {
                            if (serviceType == i) {
                              print('serviceType :  ${serviceType}');
                              addService(index, i);
                              controller
                                  .staffDetailModel?.data.services[i]
                                  .isChecked
                                  .value = true;
                            }else{
                              controller
                                  .staffDetailModel?.data.services[i]
                                  .isChecked
                                  .value = false;
                            }
                          }

                          print(controller.serviceCount.value);
                          print(
                              "controller.selectedServicesList ${controller.selectedServicesList}");
                          print(controller.selectedServicesIDSList);
                          print(controller.selectedServicesPriceList);
                        },
                      )),
                  title: _rowItemForHeaderText(
                      "${controller.staffDetailModel?.data.services[i].name}",
                      12,
                      FontWeight.w400,
                      0xff000000,
                      0,
                      0,
                      0),
                  subtitle: _rowItemForHeaderText(
                      "${controller.staffDetailModel?.data.services[i].description}",
                      12,
                      FontWeight.w400,
                      0xffA8A7A7,
                      0,
                      0,
                      0),

                  trailing: Container(
                    width: SizeConfig.blockSizeHorizontal * 12,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _rowItemForHeaderText(
                            "${controller.staffDetailModel?.data.services[i].prefix} "
                                "${controller.staffDetailModel?.data.services[i].price}",
                            12,
                            FontWeight.w400,
                            0xff70b4ff,
                            0,
                            0,
                            0),

                        // Image.asset(AppImages.delete_list_ic),
                      ],
                    ),
                  ),
                  isThreeLine: true,
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _topStack(String imagePath) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        width: SizeConfig.screenWidth,
        height: SizeConfig.fortyPercentHeight,
        margin: EdgeInsets.only(top: 0),
        decoration: BoxDecoration(color: Color(0xFF0E3311).withOpacity(0.7)),
        child: Opacity(
          opacity: 0.4,
          child: CachedNetworkImage(
            imageUrl: AppUrls.BASE_URL_IMAGE + '${imagePath}',
            errorWidget: (context, url, error) => Icon(Icons.error),
            fit: BoxFit.cover,
            width: SizeConfig.screenWidth,
            height: SizeConfig.fortyPercentHeight,
            placeholder: (context, url) => Container(
                height: 30,
                width: 30,
                child: Center(child: CircularProgressIndicator())),
          ),
        ),
      ),
    );
  }

  void addService(int outerIndex, int innerIndex) {
    print(
        "Service Name .... ${controller.selectedServicesList.contains(controller.getSaloonDetailsModel?.services?[outerIndex].services[innerIndex].name)}");
    print("Service Index ${innerIndex}");

    if (!controller.selectedServicesList.contains(controller
        .getSaloonDetailsModel
        ?.services?[outerIndex]
        .services[innerIndex]
        .name)) {

      controller.selectedServicesList.clear();
      controller.selectedServicesIDSList.clear();
      controller.selectedServicesPriceList.clear();
      controller.selectedServicesList.add(controller.getSaloonDetailsModel
          ?.services?[outerIndex].services[innerIndex].name);
      controller.selectedServicesIDSList.add(controller.getSaloonDetailsModel
          ?.services?[outerIndex].services[innerIndex].id);
      controller.selectedServicesPriceList.add(int.parse(
          "${controller.getSaloonDetailsModel?.services?[outerIndex].services[innerIndex].price}"));
      controller.serviceCount.value = controller.selectedServicesList.length;
    } else {
      print('Already Added......');
      controller.selectedServicesList.remove(controller.getSaloonDetailsModel
          ?.services?[outerIndex].services[innerIndex].name);
      controller.selectedServicesIDSList.remove(controller.getSaloonDetailsModel
          ?.services?[outerIndex].services[innerIndex].id);
      controller.selectedServicesPriceList.remove(int.parse(
          "${controller.getSaloonDetailsModel?.services?[outerIndex].services[innerIndex].price}"));
      controller.serviceCount.value = controller.selectedServicesList.length;
    }
  }
}
