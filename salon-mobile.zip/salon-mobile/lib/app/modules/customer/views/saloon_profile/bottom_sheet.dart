import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:saloon_app/Model/saloons/get_saloon_details.dart';
// import 'package:saloon_app/Model/saloons/saloon_by_category_item.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/AppointmentDetails.dart';
import 'package:saloon_app/app/modules/customer/views/chat/chat_list.dart';
import 'package:saloon_app/app/modules/customer/views/profile/my_profile.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/saloon.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/view_all_saloon.dart';
import 'package:saloon_app/app/utils/colors.dart';

import '../Categories.dart';
// import 'package:saloon_app/screens/customer/AppointmentContentTwo.dart';
// import 'package:saloon_app/screens/customer/Billing.dart';
// import 'package:saloon_app/screens/customer/BookingDetails.dart';
// import 'package:saloon_app/screens/customer/BridalMakeup.dart';
// import 'package:saloon_app/screens/customer/Categories.dart';
// import 'package:saloon_app/screens/customer/ViewAll.dart';
// import 'package:saloon_app/screens/customer/aboutSaloon/Saloon.dart' as saloon;
// import 'package:saloon_app/screens/customer/aboutSaloon/appointments/AppointmentDetails.dart';
// import 'package:saloon_app/screens/customer/chat/ChatList.dart';
// import 'package:saloon_app/screens/customer/product_details.dart';
// import 'package:saloon_app/screens/customer/profile/MyProfile.dart';
// import 'package:saloon_app/styles/colors.dart';
// import 'package:saloon_app/utils/constants.dart';

class BottomSheetReusable extends StatefulWidget{
  String value;
  // GetSaloonDetailsModel? getSaloonDetailsModel;
  // BottomSheetReusable({required this.value, this.getSaloonDetailsModel});
  BottomSheetReusable({required this.value,});
  // BottomSheetReusable({required this.value, required this._allSaloonsByCategory});
  @override
  _HomeScreenState createState() => _HomeScreenState(value: value);
}

class _HomeScreenState extends State<BottomSheetReusable> {
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  final white = Colors.white;
  String value ;
  _HomeScreenState({required this.value,});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _getItem(value),
      bottomNavigationBar: Container(
        height: 50,
        decoration: new BoxDecoration(
          color: ColorsX.white,
          border: Border.all(color: ColorsX.greyBackground, width: 2),
          borderRadius: BorderRadius.only(topLeft:Radius.circular(20), topRight: Radius.circular(20)),
        ),
        child: new ListView(
          // scrollDirection: Axis.horizontal,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                SizedBox(width: 15,),
                Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () => setState(() => value = 'Profile'),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Image.asset("assets/images/profile.png", color: value =='Profile'? ColorsX.blue_button_color : ColorsX.subBlack),),
                      ),
                      GestureDetector(
                        onTap: () => setState(() => value = 'Profile'),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child:Text("Profile", style: TextStyle(color: value == 'Profile'? ColorsX.blue_button_color: ColorsX.subBlack, fontSize: 11, fontWeight: FontWeight.w400)),),
                      ),
                    ],
                  ),
                  margin: EdgeInsets.only(top: 5),
                ),
                SizedBox(width: 15,),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () => setState(() => value = 'Favourite'),
                        child: Align(
                            alignment: Alignment.topCenter,
                            child: Image.asset("assets/images/favorite.png", color: value == 'Favourite' ? ColorsX.blue_button_color : ColorsX.subBlack)),
                      ),
                      GestureDetector(
                        onTap: () => setState(() => value = 'Favourite'),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child:Text("Favourite", style: TextStyle(color: value == 'Favourite'? ColorsX.blue_button_color: ColorsX.subBlack, fontSize: 11, fontWeight: FontWeight.w400)),),
                      ),
                    ],
                  ),),
                SizedBox(width: 15,),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () => setState(() => value = 'Home'),
                        child: Align(
                            alignment: Alignment.topCenter,
                            child: Image.asset("assets/images/home.png", color: value == 'Home' ? ColorsX.blue_button_color :  value =='aboutSaloon'? ColorsX.blue_button_color:
                            value =='appointmentTwo'? ColorsX.blue_button_color: value == 'bridal'? ColorsX.blue_button_color: value=='bookingDetail'? ColorsX.blue_button_color:
                            value == 'billing'? ColorsX.blue_button_color: value == 'productDetails'?ColorsX.blue_button_color:  ColorsX.subBlack)),
                      ),
                      GestureDetector(
                        onTap: () => setState(() => value = 'Home'),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child:Text("Home", style: TextStyle(color: value == 'Home'? ColorsX.blue_button_color: ColorsX.subBlack, fontSize: 11, fontWeight: FontWeight.w400)),),
                      ),
                    ],
                  ),),
                SizedBox(width: 15,),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () => setState(() => value = 'Messages'),
                        child: Align(
                            alignment: Alignment.topCenter,
                            child: Image.asset("assets/images/message.png", color: value == 'Messages' ? ColorsX.blue_button_color : ColorsX.subBlack)),
                      ),
                      GestureDetector(
                        onTap: () => setState(() => value = 'Messages'),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child:Text("Messages", style: TextStyle(color: value == 'Messages'? ColorsX.blue_button_color: ColorsX.subBlack, fontSize: 11, fontWeight: FontWeight.w400)),),
                      ),
                    ],
                  ),),
                SizedBox(width: 15,),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () => setState(() => value = 'Appointments'),
                        child: Align(
                            alignment: Alignment.topCenter,
                            child: Image.asset("assets/images/appoint.png", color: value == 'Appointments' ? ColorsX.blue_button_color : ColorsX.subBlack)),
                      ),
                      GestureDetector(
                        onTap: () => setState(() => value = 'Appointments'),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child:Text("Appointments", style: TextStyle(color: value == 'Appointments'? ColorsX.blue_button_color: ColorsX.subBlack, fontSize: 11, fontWeight: FontWeight.w400)),),
                      ),
                    ],
                  ),),
                SizedBox(width: 15,),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _getItem(String s) {
    switch (s) {
      case 'Profile':
        return MyProfile();
      case 'Favourite':
        return MyProfile();
      case 'Home':
        // return ViewAll(categoryId: Categories.ID,);
        return ViewAllSaloon();
      case 'Messages':
        return ChatList();
      case 'Appointments':
        return AppointmentDetails();
      case 'aboutSaloon':
      // print('${widget.getSaloonDetailsModel} bottom');
      // return Saloon();
        // return saloon.Saloon(getSaloonDetailsModel: widget.getSaloonDetailsModel);
    // return Saloon(getSaloonDetailsModel: widget.getSaloonDetailsModel);
    //   case 'productDetails':
    //     return ProductDetails(product_id: Constants.product_id,);
      case 'appointmentTwo':
        print("appointmentTwo");
        // print('${widget.getSaloonDetailsModel} bottom');
        // return AppointmentContentTwo(getSaloonDetailsModel: widget.getSaloonDetailsModel);
    // return AppointmentContentTwo(allSaloonsByCategory: widget.getSaloonDetailsModel,);
    //   case 'bridal':
    //     return BridalMakeup();
    //   case 'bookingDetail':
    //     return BookingDetails();
    //   case 'billing':
    //     return Billing();
    }
    return Container();

  }
}