import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';

class ReadMore extends StatefulWidget {
  final String? text;

  ReadMore({required this.text});

  @override
  _DescriptionTextWidgetState createState() => new _DescriptionTextWidgetState();
}

class _DescriptionTextWidgetState extends State<ReadMore> {
  String firstHalf='';
  String secondHalf='';

  bool flag = true;

  @override
  void initState() {
    super.initState();
    if(widget.text!=null){
      if (widget.text!.length > 120) {
        firstHalf = widget.text!.substring(0, 120);
        secondHalf = widget.text!.substring(120, widget.text!.length);
      } else {
        firstHalf = widget.text!;
        secondHalf = "";
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return new Container(
      padding: new EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
      child: secondHalf.isEmpty
          ? new Text('${firstHalf}')
          : new Column(
        children: <Widget>[
          new Text(flag ? ('${firstHalf}' + "") : ('${firstHalf}' + '${secondHalf}'), style: TextStyle(color: ColorsX.subBlack, fontWeight: FontWeight.w400, fontSize: 14),),
          new InkWell(
            child: new Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                new Text(
                  flag ? "Read More" : "Read Less",
                  style: new TextStyle(color: Colors.blue),
                ),
              ],
            ),
            onTap: () {
              setState(() {
                flag = !flag;
              });
            },
          ),
        ],
      ),
    );
  }
}