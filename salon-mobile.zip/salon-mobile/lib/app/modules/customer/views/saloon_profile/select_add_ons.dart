
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animated_dialog/flutter_animated_dialog.dart'
    as animatedDialog;
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/topstack.dart';
import 'package:saloon_app/app/modules/intro_pages/views/slidercontent.dart';
import 'package:saloon_app/app/resuseable/bottom_cart.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class SelectAddOns extends GetView<SaloonController> {
  bool loadingdone = false;
  // GetSaloonDetailsModel _getSaloonDetailsModel = GetSaloonDetailsModel();

  @override
  Widget build(BuildContext context) {

    controller.buttonValue.value = "View Cart";
    return Scaffold(
      body: SizedBox(
        height: SizeConfig.screenHeight,
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                // shrinkWrap: true,
                mainAxisSize: MainAxisSize.max,

                // physics: NeverScrollableScrollPhysics(),
                children: [
                  Stack(
                    children: <Widget>[
                      // _getSaloonDetailsModel.saloon!=null?
                      // TopStack( getSaloonDetailsModel: _getSaloonDetailsModel,),
                      // _topStack(),
                      TopStack(),

                      Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                            margin: EdgeInsets.only(
                                top: SizeConfig.screenHeight * .165, left: 20),
                            child: _rowItemForHeaderText(
                                "${controller.getSaloonDetailsModel?.saloon?.name}",
                                20,
                                FontWeight.bold,
                                0xFFFFFFFF,
                                0,
                                0,
                                0)),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                            margin: EdgeInsets.only(
                                top: SizeConfig.screenHeight * .21, left: 20),
                            child: _rowItemForHeaderText("${controller.getSaloonDetailsModel?.saloon?.address?.address??''}",
                                20, FontWeight.bold, 0xFFFFFFFF, 0, 0, 0)),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          margin: EdgeInsets.only(top: SizeConfig.screenHeight*.26, left: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(
                                height: SizeConfig.blockSizeVertical * 2,
                                child: RatingBar.builder(
                                  initialRating: double.parse("${controller.getSaloonDetailsModel?.saloon?.rating}"),
                                  minRating: 1,
                                  direction: Axis.horizontal,
                                  allowHalfRating: true,
                                  ignoreGestures: true,
                                  itemCount: 5,
                                  itemSize: SizeConfig.blockSizeVertical * 2,
                                  itemPadding: EdgeInsets.symmetric(horizontal: 2),
                                  itemBuilder: (context, _) => Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                  ),
                                  onRatingUpdate: (rating) {
                                    print(rating);
                                  },
                                ),
                              ),
                              horizontalSpace(SizeConfig.blockSizeHorizontal * 3),
                              _rowItemForHeaderText(
                                  "${controller.getSaloonDetailsModel?.saloon?.reviews} reviews", 14, FontWeight.w400, 0xffffffff, 0, 0, 0)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(
                            top: SizeConfig.screenHeight * .37),
                        decoration: BoxDecoration(
                            color: ColorsX.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(15),
                                topRight: Radius.circular(15))),
                        child:
                            // _getSaloonDetailsModel.staff!=null?
                            // MiddleContainer(getSaloonDetailsModel: _getSaloonDetailsModel,),
                            Column(
                              mainAxisSize: MainAxisSize.max,

                              children: [
                            Padding(
                              padding: EdgeInsets.fromLTRB(
                                  15,
                                  SizeConfig.blockSizeVertical * 2,
                                  15,
                                  SizeConfig.blockSizeVertical * 2),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  _rowItemForHeaderText("Add-ons", 16,
                                      FontWeight.bold, 0xFF000000, 0, 0, 0),
                                  InkWell(
                                    onTap: (){
                                      Get.toNamed(Routes.appointment_content_two);
                                    },
                                    child: Container(
                                      // margin: EdgeInsets.only(right: 15),
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 8),
                                      decoration: BoxDecoration(
                                          color: ColorsX.blue_lightest,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(20))),
                                      child: _rowItemForHeaderText(
                                          "Skip Add-Ons",
                                          14,
                                          FontWeight.bold,
                                          0xFF000000,
                                          0,
                                          0,
                                          0),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            _middleContainer(context),
                          ],
                        ),
                        // :Container(),
                      ),

                      // :Container(),
                    ],
                  ),
                ],
              ),
            ),
            Obx(()=>Container(
                margin: EdgeInsets.only(top: controller.addOnCount==0?SizeConfig.screenHeight * .9:SizeConfig.screenHeight * .88),
                child: GestureDetector(
                  onTap: () {
                    // Get.toNamed(Routes.SELECT_ADD_ONS);
                  },
                  child: Align(
                      alignment: Alignment.bottomCenter, child: BottomCart()),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  void showPopUp(BuildContext context, String title, String content, String ok,
      bool status) {
    animatedDialog.showAnimatedDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return animatedDialog.ClassicGeneralDialogWidget(
          titleText: title,
          contentText: content,
          positiveText: ok,
          onPositiveClick: () {
            if (status == false) {
              Navigator.of(context).pop();
            } else {
              // Navigator.of(context).push(MaterialPageRoute(builder:(context)=>OTPCode(phone: _phoneController.text)));
              // Navigator.pushNamed(context, '/continue');
            }
          },
        );
      },
      animationType: animatedDialog.DialogTransitionType.fade,
      curve: Curves.fastOutSlowIn,
      duration: Duration(seconds: 1),
    );
  }

  Widget _middleContainer(BuildContext context) {
    return Container(
      child: Column(
        children: [

          for(int index =0; index < (controller.getSaloonDetailsModel?.products?.length??0); index++)
            _buildExpandableList(index,"Product Type", controller.getSaloonDetailsModel?.products?[index].category.title,
                "description"
                    "price", "",
                "id","price"),
          GestureDetector(
              onTap: () {
                if(controller.selectedServicesList.isEmpty){
                  print("Select at least one service");
                  Functions.showErrorToast(context, "Can't Continue", "Select at least one service to continue");
                }
                else {
                  Get.toNamed(Routes.SELECT_ADD_ONS);
                }
              },
              child: Button(context)),
          verticalSpace(SizeConfig.blockSizeVertical * 10)
        ],
      ),
    );

  }

  Widget Button(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            // Navigator.pushNamed(context, '/verify');
            // getAlertBox(context);
            Get.toNamed(Routes.appointment_content_two);
            // Get.toNamed(Routes.BOOKING_DETAIL_SECOND);
          },
          child: Container(
            margin: EdgeInsets.only(
              top: 20,
              bottom: 20
            ),
            width: SizeConfig.eightyPercentWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Continue to Select Time",
                    style: TextStyle(
                      fontSize: 16,
                      color: ColorsX.white,
                      fontWeight: FontWeight.w700,
                    )),
              ],
            ),
          ),
        ));
  }



  Widget _buildExpandableList(int index,String title, String? subtitle, String itemTitle, String itemSubtitle, String? id, String? itemPrice) {
    int length = controller.getSaloonDetailsModel?.products?[index].products.length??0;

    return Card(
      color: Color(0xffEFF6F6),
      margin: EdgeInsets.only(left: 20, right: 20, top: 10),
      child: ExpansionTile(
        leading: Container(
          decoration: BoxDecoration(
              color: ColorsX.blue_button_color, shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(3.0),
            child: Image.asset(
              "assets/images/hair.png",
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _rowItemForHeaderText(
                title, 10, FontWeight.w400, 0xff000000, 0, 0, 0),
            _rowItemForHeaderText(
                "${subtitle}", 12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
          ],
        ),
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              for(int i=0; i<length;i++)
                ListTile(
                  leading: Obx(() => Checkbox(
                    value: controller
                        .getSaloonDetailsModel?.products?[index].products[i].isChecked.value,
                    onChanged: (bool? value) {
                        // controller.isAddOnChecked[index] =
                        // !controller.isAddOnChecked[index];
                      print("${ controller
                          .getSaloonDetailsModel?.products?[index].products[i].isChecked.value} product clickeddddddddd");
                        controller.addOnCount.value = controller
                            .isAddOnChecked
                            .where((check) => check == true)
                            .length;

                            if(controller.getSaloonDetailsModel?.products?[index].products[i].isChecked.value??false)
                            {
                              print("1 if");
                              controller.getSaloonDetailsModel?.products?[index].products[i].isChecked.value=false;

                                if(!controller.selectedAddOnsList.contains(controller.getSaloonDetailsModel?.products?[index]
                                    .products[i].name)) {
                                  controller.selectedAddOnsList.add("${controller.getSaloonDetailsModel?.products?[index]
                                      .products[i].name}");
                                  controller.selectedAddOnsPriceList.add(int.parse("${controller.getSaloonDetailsModel?.products?[index]
                                      .products[i].price}"));
                                  controller.selectedAddOnsIDSList.add("${controller.getSaloonDetailsModel?.products?[index]
                                      .products[i].id}");
                                  controller.addOnCount.value = controller.selectedAddOnsList.length;

                                }
                                else{
                                  print("already exist");

                                  if(controller.selectedAddOnsList.contains("${controller.getSaloonDetailsModel?.products?[index]
                                      .products[i].name}")) {
                                    controller.selectedAddOnsList.remove("${controller.getSaloonDetailsModel?.products?[index]
                                        .products[i].name}");
                                    controller.selectedAddOnsIDSList.remove("${controller.getSaloonDetailsModel?.products?[index]
                                        .products[i].id}");
                                    controller.selectedAddOnsPriceList.remove(int.parse("${controller.getSaloonDetailsModel?.products?[index]
                                        .products[i].price}"));
                                    controller.addOnCount.value = controller.selectedAddOnsList.length;

                                  }else{
                                    print("does not exist in cart");
                                  }
                                }
                            }else{
                              print("1 else");
                              controller.getSaloonDetailsModel?.products?[index].products[i].isChecked.value=true;

                              if(!controller.selectedAddOnsList.contains(controller.getSaloonDetailsModel?.products?[index]
                                  .products[i].name)) {
                                controller.selectedAddOnsList.add("${controller.getSaloonDetailsModel?.products?[index]
                                    .products[i].name}");
                                controller.selectedAddOnsPriceList.add(int.parse("${controller.getSaloonDetailsModel?.products?[index]
                                    .products[i].price}"));
                                controller.selectedAddOnsIDSList.add("${controller.getSaloonDetailsModel?.products?[index]
                                    .products[i].id}");
                                controller.addOnCount.value = controller.selectedAddOnsList.length;

                              }
                              else{
                                print("already exist");

                                if(controller.selectedAddOnsList.contains("${controller.getSaloonDetailsModel?.products?[index]
                                    .products[i].name}")) {
                                  controller.selectedAddOnsList.remove("${controller.getSaloonDetailsModel?.products?[index]
                                      .products[i].name}");
                                  controller.selectedAddOnsIDSList.remove("${controller.getSaloonDetailsModel?.products?[index]
                                      .products[i].id}");
                                  controller.selectedAddOnsPriceList.remove(int.parse("${controller.getSaloonDetailsModel?.products?[index]
                                      .products[i].price}"));
                                  controller.addOnCount.value = controller.selectedAddOnsList.length;

                                }else{
                                  print("does not exist in cart");
                                }
                              }
                            }
                            // print("2 else");
                            // controller.getSaloonDetailsModel?.products?[index].products[i].isChecked.value=true;
                            //
                            // if(!controller.selectedAddOnsList.contains(controller.getSaloonDetailsModel?.products?[index]
                            //     .products[i].name)) {
                            //   controller.selectedAddOnsList.add("${controller.getSaloonDetailsModel?.products?[index]
                            //       .products[i].name}");
                            //   controller.selectedAddOnsPriceList.add(int.parse("${controller.getSaloonDetailsModel?.products?[index]
                            //       .products[i].price}"));
                            //   controller.selectedAddOnsIDSList.add("${controller.getSaloonDetailsModel?.products?[index]
                            //       .products[i].id}");
                            //   controller.addOnCount.value = controller.selectedAddOnsList.length;





                        // print(controller.addOnCount.value);
                        // if(controller.isAddOnChecked[index]){
                        //   if(!controller.selectedAddOnsList.contains(controller.getSaloonDetailsModel?.products?[index]
                        //       .products[i].name)) {
                        //     controller.selectedAddOnsList.add("${controller.getSaloonDetailsModel?.products?[index]
                        //         .products[i].name}");
                        //     controller.selectedAddOnsPriceList.add(int.parse("${controller.getSaloonDetailsModel?.products?[index]
                        //         .products[i].price}"));
                        //     controller.selectedAddOnsIDSList.add("${controller.getSaloonDetailsModel?.products?[index]
                        //         .products[i].id}");
                        //     controller.addOnCount.value = controller.selectedAddOnsList.length;
                        //
                        //   }
                        //   else{
                        //     print("already exist");
                        //
                        //     if(controller.selectedAddOnsList.contains("${controller.getSaloonDetailsModel?.products?[index]
                        //         .products[i].name}")) {
                        //       controller.selectedAddOnsList.remove("${controller.getSaloonDetailsModel?.products?[index]
                        //           .products[i].name}");
                        //       controller.selectedAddOnsIDSList.remove("${controller.getSaloonDetailsModel?.products?[index]
                        //           .products[i].id}");
                        //       controller.selectedAddOnsPriceList.remove(int.parse("${controller.getSaloonDetailsModel?.products?[index]
                        //           .products[i].price}"));
                        //       controller.addOnCount.value = controller.selectedAddOnsList.length;
                        //
                        //     }else{
                        //       print("does not exist in cart");
                        //     }
                        //   }
                        // }
                        // else{
                        // }
                        print(controller.addOnCount.value);
                        print(controller.selectedAddOnsList);
                        print(controller.selectedAddOnsIDSList);
                        print(controller.selectedAddOnsPriceList);
                        // This is where we update the state when the checkbox is tapped
                        // setState(() {
                        //   isChecked = value!;
                        // });

                    },
                  )),
                  title: _rowItemForHeaderText(
                      '${controller.getSaloonDetailsModel?.products?[index].products[i].name}', 12, FontWeight.w400, 0xff000000, 0, 0, 0),
                  subtitle: _rowItemForHeaderText(
                      '${controller.getSaloonDetailsModel?.products?[index].products[i].description}', 12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
                  trailing: _rowItemForHeaderText(
                    "${controller.getSaloonDetailsModel?.products?[index].products[i].price} \$", 12, FontWeight.w700, 0xff70b4f3, 0, 0, 0),
                  isThreeLine: true,
                ),
              // ListTile(
              //   leading: Checkbox(
              //     value: true,
              //     onChanged: (bool? value) {
              //       // This is where we update the state when the checkbox is tapped
              //       // setState(() {
              //       //   isChecked = value!;
              //       // });
              //     },
              //   ),
              //   title: _rowItemForHeaderText(
              //       itemTitle, 12, FontWeight.w400, 0xff000000, 0, 0, 0),
              //   subtitle: _rowItemForHeaderText(
              //       itemSubtitle, 12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
              //   isThreeLine: true,
              // ),
            ],
          ),
        ],
      ),
    );
  }


  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget _topStack() {
    return Container(
        height: SizeConfig.screenHeight * .33,
        width: SizeConfig.screenWidth,
        child: Image.asset(
          "assets/images/popular.png",
          //height: SizeConfig.fortyPercentHeight,
          //width: SizeConfig.screenWidth,
          fit: BoxFit.fill,
        ));
  }

// Future<void> progressDilog() async {
//   Functions.showProgressDialog(context, "Loading Data", "Please wait. This may take few moments");
//   Functions.progressDialog.show();
//   await Future.delayed(Duration(seconds: 3)).then((value) => Functions.progressDialog.dismiss());
//   Functions.progressDialog.dismiss();
//   setState(() {
//     loadingdone = true;
//   });
// }
}
