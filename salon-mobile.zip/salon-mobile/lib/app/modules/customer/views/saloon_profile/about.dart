import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'bottom_sheet.dart';
import 'read_more.dart';

class About extends GetView<SaloonController>{
  // GetSaloonDetailsModel getSaloonDetailsModel;
  // About({required this.getSaloonDetailsModel});
  final String aboutText = "Step into our saloon and experience the most contemporary hair cutting, coloring. The perfect introduction for someone new to professional skin care.";
  @override
  Widget build(BuildContext context) {

    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _rowItemForHeaderText("About", 16, FontWeight.w600, 0xff000000, 20, 20, 0),
          ReadMore(text: "${controller.getSaloonDetailsModel?.saloon?.aboutUs??"No information given"}"),
          _rowItemForHeaderText("Opening Hours", 16, FontWeight.w600, 0xff000000, 20, 20, 0),
          OpeningHours(context, "All Days", "${controller.getSaloonDetailsModel?.saloon?.openTime} - "
              "${controller.getSaloonDetailsModel?.saloon?.closeTime}"),
           _mapAndAddress(context, "${controller.getSaloonDetailsModel?.saloon?.address?.address??''}", "12km"),
          photosViewAll("Photos", "View All"),
          Container(
            height: 80,
            child: ListView.builder(
                // itemCount: getSaloonDetailsModel.saloon?.photos?.length,
              itemCount: controller.getSaloonDetailsModel?.saloon?.photos.length??0,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index){
                  return Container(
                    margin: EdgeInsets.only(top: 20, left: 10, right: 10),
                    decoration: new BoxDecoration(
                      // borderRadius: BorderRadius.all(Radius.circular(10)),
                      borderRadius: BorderRadius.all(Radius.circular(10)),

                    ),
                    // child: getPhotos(context,getSaloonDetailsModel.saloon?.photos?[index]),
                    child: getPhotos(context, controller.getSaloonDetailsModel?.saloon?.photos[index]),
                  );
                }),
          ),
          // _rowItemForHeaderText("Reviews", 16, FontWeight.w600, 0xff000000, 20, 20, 0),
          // SingleChildScrollView(
          //   scrollDirection: Axis.horizontal,
          //   child: Container(
          //     child: reviewsContainer(context, "assets/images/mike.png", "15th May 2020", "02:26 PM", "Jim Fernandez",3.0,"Fast shipping & excellent customer service. I had an issue with my order, they replied quickly."),
          //   ),
          // ),
          // Button(context, getSaloonDetailsModel),
          Button(context, ),
          SizedBox(height: 10,),
        ],
      ),
    );
  }


  Widget Button(BuildContext context, ){
    return
      Align(
          alignment: Alignment.topCenter,
          child: GestureDetector(
            onTap: (){
              AppStrings.fromStaff="";
              if(controller.getSaloonDetailsModel?.staff?.isEmpty??true){
                Functions.showSimpleDialog(title: "Saloon Staff", msg: 'Currently no specialist available.');
              }else {
                Get.toNamed(Routes.SELECT_SERVICES);
              }
            },
            child: Container(
              margin: EdgeInsets.only(top: 30, left: 15, right: 15),
              width: SizeConfig.screenWidth,
              padding: EdgeInsets.symmetric(vertical: 15),
              decoration: new BoxDecoration(
                color: ColorsX.blue_gradient_dark,
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    child: Text("Book Now", style: TextStyle(fontSize: 16, color: ColorsX.white, fontWeight: FontWeight.w700,
                    )),),
                ],
              ),
            ),
          )
      );
  }
  Widget reviewsContainer(BuildContext context,String imagePath, String date, String time, String nameOfPerson, double rating, String review){
    return SizedBox(
      width: SizeConfig.eightyFivePercentWidth,
      child: Card(
          elevation: 5,
          margin: EdgeInsets.only( left: 15,right: 15, top: 20),
          shape: RoundedRectangleBorder(
            side: BorderSide(color: Colors.white70, width: 1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Container(
            width: SizeConfig.eightyPercentWidth,
            margin: EdgeInsets.only(top: 10, bottom: 10),
            decoration: new BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(10)),
              // border: Border.all(color: ColorsX.greyBackground),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.only(top: 10, left: 10),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(15.0),
                        child: Image.asset(imagePath, fit: BoxFit.fill,height: 60,width: 60,),
                      ),
                    ),
                    _rowItemForHeaderText(date, 8, FontWeight.w600, 0xff70b4ff, 20, 10, 0),
                    _rowItemForHeaderText(time, 8, FontWeight.w600, 0xff70b4ff, 10, 10, 0),
                  ],
                ),
                Container(
                  width: SizeConfig.fiftyPercentWidth,
                  margin: EdgeInsets.only(right: 20,),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      _rowItemForHeaderText(nameOfPerson, 14, FontWeight.w600, 0xff707070, 10, 20, 0),
                      Container(
                        margin: EdgeInsets.only(left: 20,top: 10),
                        child:
                        SizedBox(height: 26,
                          child:   RatingBar.builder(
                            initialRating: 0,
                            minRating: 1,
                            direction: Axis.horizontal,
                            allowHalfRating: true,
                            itemSize: 20,
                            itemCount: 5,
                            itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                            itemBuilder: (context, _) => Icon(
                              Icons.star,
                              color: Colors.amber,
                            ),
                            onRatingUpdate: (rating) {
                              print(rating);
                            },
                          ),),
                      ),
                      _rowItemForHeaderText(review, 10, FontWeight.w400, 0xff707070, 10, 20, 20)
                    ],
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
  Widget getPhotos(BuildContext context, String? imagePath){
    return
      InkWell(
        onTap: (){
          Functions.showZoomImage(imageName: "${imagePath}");
        },
        child: ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(15)),
          child: CachedNetworkImage(
            imageUrl: AppUrls.BASE_URL_IMAGE+'${imagePath}',
            errorWidget: (context, url, error) => Icon(Icons.error),
            fit: BoxFit.cover,width: 60, height: 60,

            placeholder: (context, url) => Container(
                height: 30,
                width: 30,
                child: Center(child: CircularProgressIndicator())),
          ),
        ),
      );
  }
  Widget OpeningHours(BuildContext context,String days, String? timing){
    return Container(
      margin: EdgeInsets.only(top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(width: 20,),
          Icon(Icons.circle, color: ColorsX.blue_text_color,),
          _rowItemForHeaderText(days, 14, FontWeight.w400, 0xff707070, 0, 20, 0),
          Expanded(child: SizedBox()),
          _rowItemForHeaderText(timing==null?'':'${timing}', 14, FontWeight.w400, 0xff707070, 0, 0, 20),
        ],
      ),
    );
  }
  Widget photosViewAll(String text, String clickabletext){
    return Container(
      margin: EdgeInsets.only(top: 20, left: 20, right: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          _rowItemForHeaderText(text, 16, FontWeight.w600, 0xff000000, 0, 0,0),
          GestureDetector(
            onTap: (){},
            child: _rowItemForHeaderText(clickabletext, 16, FontWeight.w600, 0xff70b4ff, 0, 0, 0),
          ),
        ],
      ),
    );
  }
  Widget _mapAndAddress(BuildContext context, String? address, String? distance){
    return Container(
      child: Stack(
        children: <Widget>[
          Container(
            child: _rowItemForHeaderText("Address", 16, FontWeight.w600, 0xff000000, 30, 20, 0),
          ),
          Container(
            width: SizeConfig.seventyPercentWidth,
            margin: EdgeInsets.only(top: 40),
            child: _rowItemForHeaderText('${address}', 16, FontWeight.w600, 0xff707070, 20, 20, 0),
          ),
          Container(
            margin: EdgeInsets.only(top: 65,left: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(top: 40),
                  child: Image.asset("assets/images/change.png"),
                ),
                _rowItemForHeaderText("Get Directions-"+'${distance}', 14, FontWeight.w400, 0xff70b4ff, 40, 10, 0),
              ],
            ),
            // child: _rowItemForHeaderText(distance, 16, FontWeight.w600, 0xff707070, 20, 20, 0),
          ),
          GestureDetector(
            onTap: (){
              Functions.launchURL(double.parse("${controller.getSaloonDetailsModel?.saloon?.address?.coordinates[0]}"),
                  double.parse("${controller.getSaloonDetailsModel?.saloon?.address?.coordinates[1]}"));
            },
            child: Container(
              margin: EdgeInsets.only(left: SizeConfig.screenWidth*.73, right: 20, top: 20,),
              child: Image.asset(AppImages.map, height: 90,),
            ),
          ),
        ],
      ),
    );
  }
  Widget _rowItemForHeaderText(String value, double fontSize, FontWeight fontWeight, int colorCode, double top,double left,double right){
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(value, style: TextStyle(color: Color(colorCode), fontWeight: fontWeight, fontSize: fontSize),),
    );
  }



}
// Widget Button(BuildContext context, GetSaloonDetailsModel getSaloonDetailsModel){


