import 'dart:convert';
import 'dart:ffi';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/saloon/staff-detail-model.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class MiddleContainer extends GetView<SaloonController> {
  // GetSaloonDetailsModel getSaloonDetailsModel;
  // MiddleContainer({required this.getSaloonDetailsModel});
//   @override
//   _HomeScreenState createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<MiddleContainer> {
  String _value = 'Follow';
  static String staffId = '';
  @override
  Widget build(BuildContext context) {
    return Container(
      height: SizeConfig.screenHeight * .44,
      width: SizeConfig.screenWidth,
      decoration: new BoxDecoration(
        color: ColorsX.lightStackColor,
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25), topRight: Radius.circular(25)),
      ),
      child: Stack(
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              _rowItemForHeaderText("${controller.getSaloonDetailsModel?.saloon?.name}", 16, FontWeight.w700,
                  0xff000000, 5, 140, 10),
              _rowItemForHeaderText("${controller.getSaloonDetailsModel?.saloon?.address?.address??''}", 14,
                  FontWeight.w400, 0xff000000, 5, 140, 10),
              RowItemsOfRatingReview(4.0, "${controller.getSaloonDetailsModel?.saloon?.reviews} reviews"),
              Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(width: 2,),
                    // GestureDetector(
                    //   /*
                    //   Follow and following ki set state wala kaam controller k through krna hai.
                    //    */
                    //   // onTap: () => setState(() => _value = 'Following'),
                    //   child: FirstRowItemsOfIconsAndText(
                    //       context,
                    //       _value == "Follow"
                    //           ? AppImages.follow
                    //           : AppImages.following,
                    //       _value,
                    //       _value == "Follow" ? 0xff000000 : 0xff70b4ff),
                    // ),
                    // FirstRowItemsOfIconsAndText(
                    //     context, AppImages.message, "Message", 0xff000000),
                    GestureDetector(
                      onTap: (){
                        Functions.launchURL(double.parse("${controller.getSaloonDetailsModel?.saloon?.address?.coordinates[0]}"),
                            double.parse("${controller.getSaloonDetailsModel?.saloon?.address?.coordinates[1]}"));
                        // Functions.navigateTo(double.parse("${controller.getSaloonDetailsModel?.saloon?.address?.coordinates[0]}"),
                        //     double.parse("${controller.getSaloonDetailsModel?.saloon?.address?.coordinates[1]}"));

                        // Functions.navigateTo(31.5204,74.3587);
                      },
                      child: FirstRowItemsOfIconsAndText(
                          context, AppImages.direction, "Directions", 0xff000000),
                    ),
                    GestureDetector(
                      onTap: (){
                        Functions.openwhatsapp(context, "${controller.getSaloonDetailsModel?.saloon?.mobileNumber}","Hye there, Salon name is "
                            "${controller.getSaloonDetailsModel?.saloon?.name}");
                      },
                      child: FirstRowItemsOfIconsAndText(
                          context, AppImages.share, "Share", 0xff000000),
                    ),
                    SizedBox(
                      width: 2,
                    ),
                  ]),
              _rowItemForHeaderText("Saloon Specialists", 16, FontWeight.w600,
                  0xff000000, 20, 20, 0),
              (controller.getSaloonDetailsModel?.staff?.isNotEmpty??false)?Container(
                height: 130,
                child: ListView.builder(
                  // itemCount: widget.getSaloonDetailsModel.staff?.length,
                  itemCount: controller.getSaloonDetailsModel?.staff?.length??0,
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    String img='';
                    img = controller.getSaloonDetailsModel?.staff?[index].staffPic;
                    // if((controller.getSaloonDetailsModel?.staff?[index].photos)?.isNotEmpty??false){
                    //   // img=controller.getSaloonDetailsModel?.staff?[index].photos[0];
                    //   img=controller.getSaloonDetailsModel?.staff?[index].staffPic;
                    // }

                    return Container(
                      // child: _getImagesWithName(context, widget.getSaloonDetailsModel.staff![index].staffPic, widget.getSaloonDetailsModel.staff![index].name,
                      //     0xff707070, widget.getSaloonDetailsModel.staff![index].designation?.title, 0xff70b4ff, "")
                      child: _getImagesWithName(context,img, controller.getSaloonDetailsModel?.staff?[index].name,
                          0xff707070, controller.getSaloonDetailsModel?.staff?[index].designation?.title, 0xff70b4ff,
                          controller.getSaloonDetailsModel?.staff?[index].id,
                      "    ${controller.getSaloonDetailsModel?.staff?[index].rating.toString()}"),
                    );

                    // _getImagesWithName(context, "assets/images/paul.png", "Paul", 0xff707070,"Barber",0xff70b4ff,"Featured"),
                    // _getImagesWithName(context, "assets/images/michael.png", "Michael", 0xff707070,"Makeup",0xff70b4ff,""),
                    // _getImagesWithName(context, "assets/images/jim.png", "Jim", 0xff707070,"Hair Specialist",0xff70b4ff,""),
                    // _getImagesWithName(context, "assets/images/ellie.png", "Ellie", 0xff707070,"Makeup Artist",0xff70b4ff,""),
                    // _getImagesWithName(context, "assets/images/michael.png", "Michael", 0xff707070,"Manager",0xff70b4ff,""),
                  },
                ),
              ):Container(
                alignment: Alignment.center,
                child: Text('No Specialist'),
              ),
              // MyTabBars(),
            ],
          ),
        ],
      ),
    );
  }

  Widget RowItemsOfRatingReview(double rating, String reviews) {
    return Container(
      height: 20,
      margin: EdgeInsets.only(top: 10, left: 0, right: 18),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 140,
          ),
          SizedBox(
            height: 20,
            child: RatingBar.builder(
              initialRating: rating,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemSize: 20,
              ignoreGestures: true,
              itemPadding: EdgeInsets.symmetric(horizontal: 2.0),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                print(rating);
              },
            ),
          ),
          _rowItemForHeaderText(
              reviews, 14, FontWeight.w400, 0xff000000, 0, 0, 0),
          // Container(
          //   padding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
          //   decoration: new BoxDecoration(
          //     color: ColorsX.parrotColor,
          //     borderRadius: BorderRadius.all(Radius.circular(25)),
          //   ),
          //   child: _rowItemForHeaderText(
          //       ButtonText, 12, FontWeight.w700, 0xffffffff, 0, 0, 0),
          // ),
        ],
      ),
    );
  }

  Widget _getImagesWithName(
      BuildContext context,
      String? imageName,
      String? name,
      int colorCode,
      String? position,
      int positionColorCode,
      String? staffid,
      String isFeatured) {
    return GestureDetector(
      onTap: () async {
        staffId = staffid!;
        print(imageName);
        print(staffId);

        await controller.getSpecificStaffDetails().then((value) =>
            Functions.openPopUpForStaffDetail(title: "", msg: "", data: controller.staffDetailModel));;
      },
      child: Container(
        margin: EdgeInsets.only(left: 10, top: SizeConfig.screenHeight * .01),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            _getColumnItem(context, imageName, name, colorCode, position,
                positionColorCode, isFeatured),
          ],
        ),
      ),
    );
  }

  Widget _getColumnItem(
      BuildContext context,
      String? imagePath,
      String? name,
      int colorCode,
      String? position,
      int positionColorCode,
      String isFeatured) {
    return Container(
      height: SizeConfig.screenHeight * .18,
      margin: EdgeInsets.only(top: 10, left: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Stack(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(35),
                child: Container(
                  decoration: new BoxDecoration(
                    shape: BoxShape.circle,
                  ),
                  child: CachedNetworkImage(
                    imageUrl: AppUrls.BASE_URL_IMAGE+'${imagePath}',
                    errorWidget: (context, url, error) => Icon(Icons.error),// Icon(Icons.error),
                    fit: BoxFit.cover,width: 60, height: 60,

                    placeholder: (context, url) => Container(
                        height: 30,
                        width: 30,
                        child: Center(child: CircularProgressIndicator())),
                  ),
                  // child: Image.asset("assets/images/mike.png"),
                ),
              ),
              // ClipRRect(
              //   borderRadius: new BorderRadius.circular(10.0),
              //   child: CachedNetworkImage(
              //     imageUrl: Constants.BASE_URL_IMAGE+'${imagePath}',
              //     errorWidget: (context, url, error) => Icon(Icons.error),// Icon(Icons.error),
              //     fit: BoxFit.contain,width: 60, height: 60,
              //
              //     placeholder: (context, url) => Container(
              //         height: 30,
              //         width: 30,
              //         child: Center(child: CircularProgressIndicator())),
              //   ),
              // ),
              // isFeatured.isNotEmpty
              //     ? Container(
              //         padding:
              //             EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              //         margin: EdgeInsets.only(top: 40),
              //         decoration: new BoxDecoration(
              //           color: ColorsX.white,
              //           borderRadius: BorderRadius.all(Radius.circular(10)),
              //         ),
              //         child: Row(
              //           mainAxisAlignment: MainAxisAlignment.start,
              //           children: <Widget>[
              //             Icon(
              //               Icons.star,
              //               color: ColorsX.yellowColor,
              //               size: 14,
              //             ),
              //             SizedBox(
              //               width: 8,
              //             ),
              //             _rowItemForHeaderText(isFeatured, 10, FontWeight.w400,
              //                 0xff000000, 0, 0, 0),
              //           ],
              //         ))
              //     : Container(),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            '${name}',
            style: TextStyle(
                color: Color(colorCode),
                fontSize: 16,
                fontWeight: FontWeight.w400),
          ),
          SizedBox(
            height: 3,
          ),
          _rowItemForHeaderText(
              '${position}', 12, FontWeight.w400, positionColorCode, 0, 0, 0),
        ],
      ),
    );
  }

  Widget FirstRowItemsOfIconsAndText(
      BuildContext context, String imagePath, String text, int colorCode) {
    print(imagePath);
    return Container(
      margin: EdgeInsets.only(top: 20, left: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Image.asset(imagePath),
          _rowItemForHeaderText(text, 14, FontWeight.w400, colorCode, 5, 0, 0),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }
}
