import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:saloon_app/app/data/model/customer/core_entity/saloon_model.dart'
    as topSaloon;
import 'package:saloon_app/app/data/model/customer/saloon/salon-by-category.dart';
import 'package:saloon_app/app/data/services/customer/saloon-home-api.dart';
import 'package:saloon_app/app/modules/customer/views/HeaderStack.dart';
import 'package:saloon_app/app/resuseable/saloon_item_widget.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/gv.dart';
import 'package:saloon_app/app/utils/size_config.dart';

import 'package:flutter_animated_dialog/flutter_animated_dialog.dart'
    as animatedDialog;

class ViewAllSaloon extends StatefulWidget {
  // String categoryId;
  // ViewAll({required this.categoryId});

  @override
  _ViewAllSaloonState createState() => _ViewAllSaloonState();
}

class _ViewAllSaloonState extends State<ViewAllSaloon> {
  bool loadingdone = false;
  SaloonsByCategory? saloonsByCategory;
  final homeApi = HomeApi();
  int length = 0;
  static const _pageSize = 10;
  String img='';

  final PagingController<int, topSaloon.SaloonModel> _pagingController =
      PagingController(firstPageKey: 1);

  @override
   void initState()  {
    if(AppStrings.categoryID.isEmpty) {
      _pagingController.addPageRequestListener((pageKey) {
        if (GV.isFromFavorite) {
          _fetchAllFavoriteSaloon(pageKey);
        } else {
          _fetchAllSalons(pageKey);
        }
      });
    }
    else{
      print(AppStrings.categoryID);
      showSalonsCategory();
    }
    super.initState();
    // WidgetsBinding.instance!.addPostFrameCallback((timeStamp) { getSaloonDetailsNow();});
  }

  Future<void> _fetchAllSalons(int pageKey) async {
    try {
      final newItems = await homeApi.getAllTopSaloon(pageKey);
      final isLastPage = newItems.top.length < _pageSize;
      if (isLastPage) {
        _pagingController.appendLastPage(newItems.top);
      } else {
        final nextPageKey = pageKey + 1;
        _pagingController.appendPage(newItems.top, nextPageKey);
      }
    } catch (error) {
      print(error);
      _pagingController.error = error;
    }
  }

  Future<void> showSalonsCategory() async {

    Functions.showProgressLoader("Please Wait");
    final res = await homeApi.getSalonsByCategory();
    if(res is SaloonsByCategory){
      saloonsByCategory = res;
      print(res);
      print("RESPONSE FOUND UI");
    }else{
      print(res);
      print("RESPONSE NOT FOUND UI");
    }
    Functions.hideProgressLoader();
    setState(() {
      length = saloonsByCategory?.data.length??0;
    });
  }
  Future<void> _fetchAllFavoriteSaloon(int pageKey) async {
    try {
      final newItems = await homeApi.getFavoriteSaloon(pageKey);
      final isLastPage = newItems.data.length < _pageSize;
      if (isLastPage) {
        _pagingController.appendLastPage(newItems.data);
      } else {
        final nextPageKey = pageKey + 1;
        _pagingController.appendPage(newItems.data, nextPageKey);
      }
    } catch (error) {
      print(error);
      _pagingController.error = error;
    }
  }

  @override
  Widget build(BuildContext context) {
    // print(widget.categoryId);
    return SafeArea(
      child: Scaffold(
          body: Container(
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            child: myStackOnTop(context),
      )),
    );
  }

  void showPopUp(BuildContext context, String title, String content, String ok,
      bool status) {
    animatedDialog.showAnimatedDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return animatedDialog.ClassicGeneralDialogWidget(
          titleText: title,
          contentText: content,
          positiveText: ok,
          onPositiveClick: () {
            if (status == false) {
              Navigator.of(context).pop();
            } else {
              // Navigator.of(context).push(MaterialPageRoute(builder:(context)=>OTPCode(phone: _phoneController.text)));
              // Navigator.pushNamed(context, '/continue');
            }
          },
        );
      },
      animationType: animatedDialog.DialogTransitionType.fade,
      curve: Curves.fastOutSlowIn,
      duration: Duration(seconds: 1),
    );
  }

  Widget myStackOnTop(BuildContext context,) {
    return Stack(
      children: <Widget>[
        HeaderStack(
          categoryShow: "no",
        ),
        Container(
          // margin: EdgeInsets.only(top: SizeConfig.screenHeight*.60),
          margin: EdgeInsets.only(top: SizeConfig.screenHeight * .35),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                AppStrings.categoryID.isEmpty?Expanded(
                    child: Container(
                  padding: const EdgeInsets.only(left: 20),
                  child: PagedListView<int, topSaloon.SaloonModel>(
                    pagingController: _pagingController,
                    padding: EdgeInsets.zero,
                    builderDelegate:
                        PagedChildBuilderDelegate<topSaloon.SaloonModel>(
                      itemBuilder: (context, saloon, index){
                        if(saloon.photos!=null){
                          if(saloon.photos!.isNotEmpty){
                            img=saloon.photos![0];
                          }else{
                            img='';
                          }
                        }else{
                          img='';
                        }
                        return SaloonItemWidget(
                          image: '${img}',
                          saloonName:'${saloon.name}',
                          rating:'${saloon.rating.toString()}',
                          address:'${saloon.address?.address}',
                          saloonId:'${saloon.id}',
                          buttonText: 'New',
                          time:
                          '${saloon.openTime} - ${saloon.closeTime}',
                          days: 'Monday-Sunday',
                          distance: '12',
                        );
                      },
                    ),
                  ),
                )):
                Expanded(
                  child: Container(
                      margin: EdgeInsets.only(left: 20,top: 10, right: 10),
                      child: length==0?Container(
                        margin: EdgeInsets.only(top: 50),
                        child: Align(
                            alignment: Alignment.topCenter,
                            child: Text("No salon found for this category", style: TextStyle(color: ColorsX.black, fontSize: 15, fontWeight: FontWeight.w700),)),
                      ):ListView.builder(
                        // physics: NeverScrollableScrollPhysics(),
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          itemCount: saloonsByCategory?.data.length??0,
                          itemBuilder: (BuildContext context, int index) {
                            return SaloonItemWidget(
                              image: '${saloonsByCategory?.data[index].profilePic}',
                              saloonName:'${saloonsByCategory?.data[index].name}',
                              rating:'${saloonsByCategory?.data[index].rating}',
                              address:'${saloonsByCategory?.data[index].address.address}',
                              saloonId:'${saloonsByCategory?.data[index].id}',
                              buttonText: 'New',
                              time:
                              '${saloonsByCategory?.data[index].openTime} - ${saloonsByCategory?.data[index].closeTime}',
                              days: 'All Days',
                              distance: '',
                            );
                          })
                  ),
                ),
                Container(height: 10,),
              ]),
        ),
      ],
    );
  }


}
