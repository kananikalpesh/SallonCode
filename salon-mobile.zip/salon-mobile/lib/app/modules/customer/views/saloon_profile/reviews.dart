import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class Reviews extends GetView<SaloonController> {
  List<String> sortigByList = ["lowest to heighest", "heighest to lowest"];
  double ratingSend = 0.0;
  TextEditingController ctl = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        // _rowItemForHeaderText("Reviews", 13, FontWeight.w700, 0xff000000, 20, 30, 0),

        Container(
          padding: EdgeInsets.symmetric(
              horizontal: SizeConfig.blockSizeHorizontal * 5,
              vertical: SizeConfig.blockSizeVertical * 2),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _rowItemForHeaderText(
                  "Reviews", 13, FontWeight.w700, 0xff000000, 0, 0, 0),
              Container(
                  width: SizeConfig.screenWidth * 0.25,
                  // height: SizeConfig.blockSizeVertical * 5,
                  child: dropDownContainer2(context, sortigByList, "Sort By"))
            ],
          ),
        ),

        Container(
          margin: EdgeInsets.only(left: 20),
          child: SizedBox(
            height: SizeConfig.blockSizeVertical * 2,
            child: RatingBar.builder(
              initialRating: 0,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemSize: SizeConfig.blockSizeVertical * 2,
              itemPadding: EdgeInsets.symmetric(horizontal: 2),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                ratingSend = rating;
                print(rating);
              },
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
              color: ColorsX.greyBackground,
              borderRadius: BorderRadius.all(Radius.circular(10))),
          margin: EdgeInsets.only(top: 5, right: 20, left: 20),
          child: TextFormField(
            style: TextStyle(color: ColorsX.subBlack),
            keyboardType: TextInputType.text,
            // obscureText: obscure,
            controller: ctl,
            // validator: (String value) => value.length < 10
            //     ? 'Çharacter Length Must Be 10 Character Long'
            //     : null,
            minLines: 1,
            onChanged: (text){
              if(text.length>0){
                print("changed text");
                controller.isEnabled.value = true;
              }
              else{
                controller.isEnabled.value=false;
              }
            },
            //Normal textInputField will be disp
            decoration: InputDecoration(
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              hintText: "Write Review",
              contentPadding: EdgeInsets.only(top: 1),
              hintStyle: TextStyle(color: ColorsX.subBlack),
            ),
          ),
        ),

        Obx(()=>controller.isEnabled.isTrue?PostButton(context):Container()),
        for (int index = 0;
            index < (controller.getSaloonDetailsModel?.reviews?.length??0);
            index++)
          Container(
              margin: EdgeInsets.only(left: 15, right: 15, top: 15),
              child: reviewsData(index)),
      ],
    );
  }
  Widget PostButton(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () async {
            // Navigator.pushNamed(context, '/verify');
            // getAlertBox(context);
            if(ratingSend.isGreaterThan(0.0)){
              int ratingint = ratingSend.toInt();
              Map<String,dynamic> apiParams = new Map();

              apiParams["Saloon"] = controller.getSaloonDetailsModel?.saloon?.id;
              apiParams["Rating"] = "${ratingSend}";
              apiParams["User"] = AppStrings.userId;
              apiParams["Description"] = ctl.text;
              print(apiParams);
              final res = await controller.sendRevie(apiParams: apiParams);
              if(res == true){
                print(res);
              }else{
                print(res);
              }
            }
            else{
              Functions.showToast("Select rating");
            }
          },
          child: Container(
            margin: EdgeInsets.only(
              top: 20,
              bottom: 20
            ),
            width: SizeConfig.sixtyPercentWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              color: ColorsX.blue_button_color,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Post Review",
                    style: TextStyle(
                      fontSize: 16,
                      color: ColorsX.white,
                      fontWeight: FontWeight.w700,
                    )),
              ],
            ),
          ),
        ));
  }

  Widget reviewsData(int index) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              // ClipRRect(
              //   borderRadius: BorderRadius.all(Radius.circular(10)),
              //   child: Image.asset(
              //     AppImages.jim, height: 40, width: 40, fit: BoxFit.contain,),
              // ),

              Container(
                height: 40,
                width: 40,
                child: ClipRRect(
                  borderRadius: new BorderRadius.circular(20.0),
                  child: CachedNetworkImage(
                    imageUrl: AppUrls.BASE_URL_IMAGE +
                        '${controller.getSaloonDetailsModel?.reviews?[index].user.profilePic}',
                    errorWidget: (context, url, error) => Icon(Icons.error),
                    fit: BoxFit.fill,
                    width: 40,
                    height: 40,
                    placeholder: (context, url) => Container(
                        height: 30,
                        width: 30,
                        child: Center(child: CircularProgressIndicator())),
                  ),
                  // Image.asset("assets/images/mike.png", height: 100, width: 100,fit: BoxFit.contain,),
                ),
              ),
              SizedBox(
                width: 15,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  _rowItemForHeaderText(
                      "${controller.getSaloonDetailsModel?.reviews?[index].user.name}",
                      13,
                      FontWeight.w600,
                      0xff707070,
                      0,
                      0,
                      0),
                  RatingBar.builder(
                    itemSize: 11,
                    initialRating: double.parse("${controller.getSaloonDetailsModel?.reviews?[index].rating??0}")
                        ,
                    minRating: 1,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    tapOnlyMode: false,
                    ignoreGestures: true,
                    itemCount: 5,
                    itemPadding: EdgeInsets.symmetric(horizontal: 1.0),
                    itemBuilder: (context, _) => Icon(
                      Icons.star,
                      color: Colors.amber,
                    ),
                    onRatingUpdate: (rating) {
                      print(rating);
                    },
                  ),
                ],
              ),
              Expanded(child: Container()),
              _rowItemForHeaderText(
                  "2 hours ago", 10, FontWeight.w600, 0xff707070, 0, 0, 0)
            ],
          ),
          _rowItemForHeaderText(
              "${controller.getSaloonDetailsModel?.reviews?[index].description}",
              12,
              FontWeight.w400,
              0xff707070,
              5,
              0,
              0),
          Container(
            margin: EdgeInsets.only(top: 15),
            width: SizeConfig.screenWidth,
            height: 3,
            color: ColorsX.cart_background,
          ),
        ],
      ),
      // child: Row(
      //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //   children: [
      //     _rowItemForHeaderText("Reviews", 12, FontWeight.w700, 0xff000000, 0, 0, 0),
      //     _rowItemForHeaderText("Lowest to Highest", 12, FontWeight.w400, 0xff70b4FF, 0, 0, 0),
      //   ],
      // ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }

  Widget dropDownContainer2(
      BuildContext context, List<String> values, String text) {
    return Container(
      // width: SizeConfig.screenWidth * width,
      height: SizeConfig.blockSizeVertical * 5,
      // margin: EdgeInsets.only(left: 15, top: 10),
      padding: EdgeInsets.all(0.0),

      decoration: new BoxDecoration(
          color: ColorsX.white,
          borderRadius: BorderRadius.all(
            Radius.circular(10),
          ),
          border: Border.all()),
      child: _DropDownWithoutBorder(values, text),
    );
  }

  Widget _DropDownWithoutBorder(List<String> values, String text) {
    return Container(
        // color: ColorsX.red_danger,
        width: SizeConfig.seventyFivePercentWidth,
        margin: EdgeInsets.only(top: 0, left: 10, bottom: 0),
        padding: EdgeInsets.all(0.0),
        height: SizeConfig.blockSizeVertical * 5,
        child: DropdownButton(
          elevation: 0,
          underline: SizedBox(
            height: 0,
          ),
          hint: Text(
            '$text',
            style: TextStyle(color: Color(0xff515C6F)),
          ),
          isExpanded: true,
          iconSize: SizeConfig.blockSizeVertical * 3,
          // icon: Image.asset(AppImages.dropdown_field_ic),
          style: TextStyle(
              color: Color(0xff8890A6),
              fontSize: 14,
              fontWeight: FontWeight.w600),
          items: values.map(
            (val) {
              return DropdownMenuItem<String>(
                value: val,
                child: Text(val),
              );
            },
          ).toList(),
          onChanged: (val) {
            // setState(
            //   () {
            //     _dropDownValue = val as String;
            //   },
            // );
          },
        ));
  }
}
