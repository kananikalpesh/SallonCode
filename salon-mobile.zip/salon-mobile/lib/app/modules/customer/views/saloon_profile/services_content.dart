import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/saloon-controller.dart';
import 'package:saloon_app/app/resuseable/bottom_cart.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/colors.dart';

class ServicesContent extends GetView<SaloonController> {
  String clickValue = "";
  bool valuefirst = false;
  bool isChecked = false;
  bool valuesecond = false;

  @override
  Widget build(BuildContext context) {
    controller.buttonValue.value=="Book Now";
    return Container(
      child: Column(
        children: [
          for (int index = 0;
              index < (controller.getSaloonDetailsModel?.services?.length??0);
              index++)

            _buildExpandableList(index,"Service Type", controller.getSaloonDetailsModel?.services?[index].category.title,
                "", "",
                "",""),
          BottomCart()
        ],
      ),
    );
  }
  Widget _buildExpandableList(int index,String title, String? subtitle, String itemTitle, String itemSubtitle, String? id, String? itemPrice) {
    int length = controller.getSaloonDetailsModel?.services?[index].services.length??0;
    return Card(
      color: Color(0xffEFF6F6),
      margin: EdgeInsets.only(left: 20, right: 20, top: 10),
      child: ExpansionTile(
        leading: Container(
          decoration: BoxDecoration(
              color: ColorsX.blue_button_color, shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(3.0),
            child: Image.asset(
              "assets/images/hair.png",
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _rowItemForHeaderText(
                title, 10, FontWeight.w400, 0xff000000, 0, 0, 0),
            _rowItemForHeaderText(
                "${subtitle}", 12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
          ],
        ),
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              for(int i=0; i<length;i++)
              ListTile(
                leading: _rowItemForHeaderText(
                    '${i+1}', 14, FontWeight.w700, 0xff070b4ff, 0, 0, 0),
                // Obx(() => Checkbox(
                //   value: controller.isServiceChecked[index],
                //   onChanged: (bool? value) {
                //     controller.isServiceChecked[index] =
                //     !controller.isServiceChecked[index];
                //     controller.serviceCount.value = controller
                //         .isServiceChecked
                //         .where((check) => check == true)
                //         .length;
                //     print(controller.serviceCount.value);
                //     if(controller.isServiceChecked[index]){
                //       if(!controller.selectedServicesList.contains(itemTitle)) {
                //         controller.selectedServicesList.add(itemTitle);
                //         controller.selectedServicesIDSList.add(id);
                //         controller.selectedServicesPriceList.add(int.parse(itemPrice!));
                //       }
                //       else{
                //         print("already exist");
                //       }
                //     }else{
                //       if(controller.selectedServicesList.contains(itemTitle)) {
                //         controller.selectedServicesList.remove(itemTitle);
                //         controller.selectedServicesIDSList.remove(id);
                //         controller.selectedServicesPriceList.remove(int.parse(itemPrice!));
                //       }else{
                //         print("does not exist in cart");
                //       }
                //     }
                //     print(controller.serviceCount.value);
                //     print(controller.selectedServicesList);
                //     print(controller.selectedServicesIDSList);
                //     print(controller.selectedServicesPriceList);
                //     // This is where we update the state when the checkbox is tapped
                //     // setState(() {
                //     //   isChecked = value!;
                //     // });
                //   },
                // )),
                title: _rowItemForHeaderText(
                    "${controller.getSaloonDetailsModel?.services?[index].services[i].name}", 12, FontWeight.w400, 0xff000000, 0, 0, 0),
                subtitle: _rowItemForHeaderText(
                    "${controller.getSaloonDetailsModel?.services?[index].services[i].description}", 12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
                isThreeLine: true,
                trailing: _rowItemForHeaderText(
                    "${controller.getSaloonDetailsModel?.services?[index].services[i].price} \$", 12, FontWeight.w700, 0xff70b4ff, 0, 0, 0),
              ),
              // ListTile(
              //   leading: Checkbox(
              //     value: true,
              //     onChanged: (bool? value) {
              //       // This is where we update the state when the checkbox is tapped
              //       // setState(() {
              //       //   isChecked = value!;
              //       // });
              //     },
              //   ),
              //   title: _rowItemForHeaderText(
              //       itemTitle, 12, FontWeight.w400, 0xff000000, 0, 0, 0),
              //   subtitle: _rowItemForHeaderText(
              //       itemSubtitle, 12, FontWeight.w400, 0xffa8a7a7, 0, 0, 0),
              //   isThreeLine: true,
              // ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _rowItemForHeaderText(
      String value,
      double fontSize,
      FontWeight fontWeight,
      int colorCode,
      double top,
      double left,
      double right) {
    return Container(
      margin: EdgeInsets.only(top: top, left: left, right: right),
      child: Text(
        value,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: fontWeight,
            fontSize: fontSize),
      ),
    );
  }


}

