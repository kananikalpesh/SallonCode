import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/dashboard-item-controller.dart';

import 'package:saloon_app/app/modules/customer/views/saloon_profile/saloon.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app_urls.dart';


import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class FavoriteSaloon extends GetView<DashboardItemController> {
  //late DashboardItem dashboardItem ;
  //bool isPopular = true;
  bool isHorizontal;
  static String SALOON_ID = '';
  //SaloonRowItem({required this.dashboardItem, required this.isPopular});
  FavoriteSaloon({required this.isHorizontal});

  @override
  Widget build(BuildContext context) {
    // var data = isPopular?dashboardItem.popular:dashboardItem.favorite;
    return Container(
      height: SizeConfig.screenHeight * 0.36,
      //color: Colors.red,
      margin: EdgeInsets.only(
        left: 15,
        right: 15,
      ),
      child: ListView.builder(
        //shrinkWrap: true,
          scrollDirection: isHorizontal ? Axis.horizontal : Axis.vertical,
          itemCount: controller.saloonItemsModel?.favorite?.length??0,
          itemBuilder: (BuildContext context, int index) {
            //print('APIDATA${dashboardItem.popular}');
            return Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    _PopularItemView(
                        context,
                        controller.saloonItemsModel?.favorite?[index].profilePic,
                        "New",
                        " Saloon",
                        controller.saloonItemsModel?.favorite?[index].rating.toString(),
                        controller.saloonItemsModel?.favorite?[index].address?.address.toString(),
                        controller.saloonItemsModel?.favorite?[index].id,
                        "All Days",
                        "12",
                        "${controller.saloonItemsModel?.favorite?[index].openTime} - ${controller.saloonItemsModel?.favorite?[index].closeTime}")
                    // _PopularItemView(
                    //     context, "assets/images/popular.png", "New",
                    //     "Nails Saloon", "4", "288 Empola Street, NewYork"),
                  ],
                ),
              ],
            );
          }),
      //  ListView.builder(
      //     scrollDirection: Axis.horizontal,
      //     itemCount: data?.length,
      //     itemBuilder: (BuildContext context, int index) {
      //       print('APIDATA${dashboardItem.popular}');
      //       return   Column(
      //         mainAxisAlignment: MainAxisAlignment.start,
      //         crossAxisAlignment: CrossAxisAlignment.start,
      //         children: <Widget>[
      //           Row(
      //             mainAxisAlignment: MainAxisAlignment.start,
      //             crossAxisAlignment: CrossAxisAlignment.start,
      //             children: <Widget>[
      //               _PopularItemView(context,data?[index].profilePic, "New", data?[index].name, data?[index].rating.toString(),
      //                   data?[index].address, data?[index].id,)
      //               // _PopularItemView(
      //               //     context, "assets/images/popular.png", "New",
      //               //     "Nails Saloon", "4", "288 Empola Street, NewYork"),
      //             ],
      //           ),

      //         ],
      //       );
      //     }
      // ),
      // child: _PopularItemView(context, "assets/images/popular.png", "New"),
    );
  }

  Widget _myLocationText(
      BuildContext context,
      String text,
      int colorCode,
      double left,
      double top,
      double right,
      FontWeight fontWeight,
      double fontSize) {
    return Container(
      margin: EdgeInsets.only(left: left, top: top, right: right),
      child: Text(
        text,
        style: TextStyle(
            color: Color(colorCode),
            fontWeight: FontWeight.w600,
            fontSize: fontSize),
      ),
    );
  }

  Widget _PopularItemView(
      BuildContext context,
      String? imageOne,
      String buttonText,
      String? bottomContainerRowValue1,
      String? bottomContainerRowValue2,
      String? bottomContainerRowValue3,
      String? saloonId,
      String days,
      String distance,
      String time) {
    return GestureDetector(
      onTap: () {
        SALOON_ID = saloonId!;
        // Navigator.pushNamed(context, Routes.WELCOME_aboutSaloon);
        Get.toNamed(Routes.WELCOME_aboutSaloon);
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(builder: (context) => Saloon()),
        // );

        // Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomSheetReusable(value: "aboutSaloon")));
      },
      child: Container(
        margin: EdgeInsets.only(top: 15, right: 20),
        height: SizeConfig.screenHeight * .33,
        width: SizeConfig.eightyPercentWidth,
        child: Stack(
          children: <Widget>[
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                height: 160,

                // width: ,
                child: ClipRRect(
                  borderRadius: new BorderRadius.circular(10.0),
                  // child: Image.asset(
                  //   imageOne!,
                  //   fit: BoxFit.cover,
                  //   width: SizeConfig.screenWidth,
                  //   height: 160.0,
                  // )
                  child: CachedNetworkImage(
                    imageUrl: AppUrls.BASE_URL_IMAGE+'${imageOne}',
                    errorWidget: (context, url, error) => Icon(Icons.error),
                    fit: BoxFit.cover,width: SizeConfig.screenWidth, height: 160.0,
                    placeholder: (context, url) => Container(
                        height: 30,
                        width: 30,
                        child: Center(child: CircularProgressIndicator())),
                  ),
                ),
              ),
              // child: Image.asset(imageOne, fit: BoxFit.contain,),),
            ),
            Align(
                alignment: Alignment.topLeft,
                child: GestureDetector(
                  onTap: () {
                    // Navigator.pushNamed(context, '/verify');
                  },
                  child: Container(
                    width: 50,
                    margin: EdgeInsets.only(top: 0, left: 0, right: 0),
                    padding: EdgeInsets.symmetric(vertical: 5),
                    decoration: new BoxDecoration(
                      color: ColorsX.greenish,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                          topRight: Radius.circular(3)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(buttonText,
                            style: TextStyle(
                              fontSize: 12,
                              color: ColorsX.white,
                              fontWeight: FontWeight.w700,
                            )),
                      ],
                    ),
                  ),
                )),
            _containerStyling(
                bottomContainerRowValue1,
                4.0,
                11,
                FontWeight.w700,
                bottomContainerRowValue2,
                bottomContainerRowValue3,
                days,
                distance,
                time),
            // _containerStyling("4.0",4.0,14, FontWeight.w400),
          ],
        ),
      ),
    );
  }

  Widget _containerStyling(
      String? text,
      double rating,
      double fontSize,
      FontWeight fontWeight,
      String? ratings,
      String? address,
      String days,
      String distance,
      String time) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        height: SizeConfig.blockSizeVertical * 13,
        margin: EdgeInsets.only(top: 150),
        decoration: BoxDecoration(
          color: ColorsX.white,
          border: Border.all(color: ColorsX.greyBackground, width: 2),
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(10),
              bottomRight: Radius.circular(10)),
        ), // _PopularRowItemOfText("Looks Unisex Saloon", 4.0, 14, FontWeight.w700),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              // height: 40,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(child: _PopularRowItemOfText(text, fontSize, fontWeight)),
                  _starIcon(),
                  _PopularRowItemOfText(ratings, fontSize, FontWeight.w400),
                  SizedBox(
                    width: 5,
                  )
                ],
              ),
            ),
            // Container(
            //   height: 20,
            //   margin: EdgeInsets.only(left: 10),
            //   child: Text(
            //     '$bottomContainerRowValue3',
            //     style: TextStyle(
            //         color: ColorsX.subBlack,
            //         fontSize: 12,
            //         fontWeight: FontWeight.w400),
            //   ),
            // ),

            Container(
              //height: 40,
              //color: Colors.red,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Location_color_ic)),
                        Expanded(child: _PopularRowItemOfText(address, fontSize, fontWeight)),
                      ],
                    ),
                  ),
                  // Expanded(child: SizedBox()),
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Date_color_ic)),
                        _PopularRowItemOfText(days, fontSize, FontWeight.w400),
                      ],
                    ),
                  ),
                  // SizedBox(
                  //   width: 5,
                  // )
                ],
              ),
            ),
            Container(
              //height: 40,
              //color: Colors.red,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Distance_color_ic)),
                        _PopularRowItemOfText(
                            distance + "km away", fontSize, fontWeight),
                      ],
                    ),
                  ),
                  // Expanded(child: SizedBox()),
                  Expanded(
                    child: Row(
                      children: [
                        Container(
                            padding: EdgeInsets.only(
                                left: SizeConfig.marginVerticalXsmall,
                                top: SizeConfig.marginVerticalSmall,
                                bottom: SizeConfig.marginVerticalXsmall),
                            child: Image.asset(AppImages.Clock_color_ic)),
                        _PopularRowItemOfText(time, fontSize, FontWeight.w400),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _starIcon() {
    return Container(
      margin: EdgeInsets.only(top: 0),
      child: Icon(
        Icons.star,
        color: ColorsX.yellow,
      ),
    );
  }

  Widget _PopularRowItemOfText(
      String? text1, double fontSize, FontWeight fontWeight) {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: SizeConfig.marginVerticalXsmall,
          vertical: SizeConfig.marginVerticalXsmall),
      child: Text(
        '${text1}',
        style: TextStyle(
            color: ColorsX.subBlack,
            fontWeight: fontWeight,
            fontSize: fontSize),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }
// void cachedImage(String url){
//   CachedNetworkImage(
//     imageUrl: "http://via.placeholder.com/200x150",
//     imageBuilder: (context, imageProvider) => Container(
//       decoration: BoxDecoration(
//         image: DecorationImage(
//             image: imageProvider,
//             fit: BoxFit.cover,
//             colorFilter:
//             ColorFilter.mode(Colors.red, BlendMode.colorBurn)),
//       ),
//     ),
//     placeholder: (context, url) => CircularProgressIndicator(),
//     errorWidget: (context, url, error) => Icon(Icons.error),
//   );
// }
}
