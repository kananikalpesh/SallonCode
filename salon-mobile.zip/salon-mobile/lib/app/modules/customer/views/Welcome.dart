// ignore_for_file: file_names

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/modules/customer/controllers/custome_home_controller.dart';
import 'package:saloon_app/app/modules/customer/controllers/user-profile-ctl.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/AppointmentDetails.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/appointments_wrapper.dart';
import 'package:saloon_app/app/modules/customer/views/bottom_navigation_bar.dart';
import 'package:saloon_app/app/modules/customer/views/chat/chat_list.dart';
import 'package:saloon_app/app/modules/customer/views/customer_home_screens.dart';
import 'package:saloon_app/app/modules/customer/views/header_welcome.dart';
import 'package:saloon_app/app/modules/customer/views/home/home_wrapper.dart';
import 'package:saloon_app/app/modules/customer/views/profile/my_profile.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/view_all_saloon.dart';
import 'package:saloon_app/app/modules/customer/views/search_screen.dart';
import 'package:saloon_app/app/modules/login/views/signup_screen.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/gv.dart';

import 'appointments/my_appointments.dart';

class WelcomeCustomer extends GetView<CustomerHomeController> {
  //final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  final white = Colors.white;
  //String _value = 'Home';
  List<Widget> screenList = [
    MyProfile(),
    CustomerHomeScreen(),
    CustomerHomeScreen(),
    ChatList(),
    AppointmentDetails(),
  ];

  UserProfileCtl userProfileCtl = Get.find();

  //  List<GlobalKey<NavigatorState>> navigationKeys = [
  //   GlobalKey<NavigatorState>(),
  //   GlobalKey<NavigatorState>(),
  //   GlobalKey<NavigatorState>(),
  //   GlobalKey<NavigatorState>(),
  // ];
  void searching() {
    controller.currentScreenIndex.value = 0;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // print("Back Button pressed");
        if (controller.currentScreenIndex.value == 4) {
          Get.back(id: 0);

          return await Get.keys[AppointmentNavigation.id]!.currentState!
              .maybePop();
        } else if (controller.currentScreenIndex.value == 2) {
          // var b= await Get.keys[HomeNavigation.id]!.currentState!.maybePop();
          // print(b);
          Get.back(id: 2);
          //  return await Get.keys[HomeNavigation.id]!.currentState!.maybePop();
          //  return await Get.nestedKey(HomeNavigation.id)!.currentState!.maybePop();

          return false;

          // return await Get.keys[HomeNavigation.id]!.currentState!
          //     .maybePop();
        } else {
          return true;
        }
      },
      child: Scaffold(
        body: Obx(() {
          if (controller.currentScreenIndex.value == 4) {
            return AppointmentWrapper();
          } else if (controller.currentScreenIndex.value == 2) {
            return HomeWrapper();
          }  else if (controller.currentScreenIndex.value == 0) {
            userProfileCtl.getSpecificUserDetails();
            return MyProfile();
          } else if (controller.currentScreenIndex.value == 5) {
            GV.isFromFavorite=true;
            return ViewAllSaloon();
          } else {
            return screenList[controller.currentScreenIndex.value];
          }
        }),
        bottomNavigationBar: _bottomNavigationBar(),
      ),
    );
  }


  Widget _bottomNavigationBar() {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: ColorsX.white,
        border: Border.all(color: ColorsX.greyBackground, width: 2),
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20), topRight: Radius.circular(20)),
      ),
      child: ListView(
        //scrollDirection: Axis.horizontal,
        children: [
          Obx(
            () => Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                SizedBox(
                  width: 15,
                ),
                Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () => (controller.currentScreenIndex.value = 0),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Image.asset("assets/images/profile.png",
                              fit: BoxFit.contain,
                              color: controller.currentScreenIndex.value == 0
                                  ? ColorsX.blue_button_color
                                  : ColorsX.subBlack),
                        ),
                      ),
                      GestureDetector(
                        onTap: () => controller.currentScreenIndex.value = 0,
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Text("Profile",
                              style: TextStyle(
                                  color:
                                      controller.currentScreenIndex.value == 0
                                          ? ColorsX.blue_button_color
                                          : ColorsX.subBlack,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w400)),
                        ),
                      ),
                    ],
                  ),
                  margin: EdgeInsets.only(top: 5),
                ),
                SizedBox(
                  width: 15,
                ),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () => controller.currentScreenIndex.value = 5,
                        child: Align(
                            alignment: Alignment.topCenter,
                            child: Image.asset("assets/images/favorite.png",
                                fit: BoxFit.contain,
                                color: controller.currentScreenIndex.value == 5
                                    ? ColorsX.blue_button_color
                                    : ColorsX.subBlack)),
                      ),
                      GestureDetector(
                        onTap: () => controller.currentScreenIndex.value = 1,
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Text("Favourite",
                              style: TextStyle(
                                  color:
                                      controller.currentScreenIndex.value == 1
                                          ? ColorsX.blue_button_color
                                          : ColorsX.subBlack,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w400)),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 15,
                ),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        // onTap: () => controller.currentScreenIndex.value = 2,
                        onTap: () {
                          controller.selectHomeScreen();
                          controller.currentScreenIndex.value = 2;
                        },
                        child: Align(
                            alignment: Alignment.topCenter,
                            child: Image.asset("assets/images/home.png",
                                fit: BoxFit.contain,
                                color: controller.currentScreenIndex.value == 2
                                    ? ColorsX.blue_button_color
                                    : ColorsX.subBlack)),
                      ),
                      GestureDetector(
                        // onTap: () => controller.currentScreenIndex.value = 2,
                        onTap: () {
                          controller.selectHomeScreen();
                          controller.currentScreenIndex.value = 2;
                        },
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Text("Home",
                              style: TextStyle(
                                  color:
                                      controller.currentScreenIndex.value == 2
                                          ? ColorsX.blue_button_color
                                          : ColorsX.subBlack,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w400)),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 15,
                ),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        onTap: () => controller.currentScreenIndex.value = 3,
                        child: Align(
                            alignment: Alignment.topCenter,
                            child: Image.asset("assets/images/message.png",
                                fit: BoxFit.contain,
                                color: controller.currentScreenIndex.value == 3
                                    ? ColorsX.blue_button_color
                                    : ColorsX.subBlack)),
                      ),
                      GestureDetector(
                        onTap: () => controller.currentScreenIndex.value = 3,
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Text("Messages",
                              style: TextStyle(
                                  color:
                                      controller.currentScreenIndex.value == 3
                                          ? ColorsX.blue_button_color
                                          : ColorsX.subBlack,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w400)),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 15,
                ),
                Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        // onTap: () => controller.currentScreenIndex.value = 4,
                        onTap: () async {
                          controller.currentScreenIndex.value = 4;
                        },
                        child: Align(
                            alignment: Alignment.topCenter,
                            child: Image.asset("assets/images/appoint.png",
                                fit: BoxFit.contain,
                                color: controller.currentScreenIndex.value == 4
                                    ? ColorsX.blue_button_color
                                    : ColorsX.subBlack)),
                      ),
                      GestureDetector(
                        onTap: () => controller.currentScreenIndex.value = 4,
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Text("Appointments",
                              style: TextStyle(
                                  color:
                                      controller.currentScreenIndex.value == 4
                                          ? ColorsX.blue_button_color
                                          : ColorsX.subBlack,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w400)),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 15,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
  // Future<void> progressDilog() async {
  // final _dashboardItemProvider = DashboardItemProvider();
  //   Functions.showProgressDialog(context, "Loading Data", "Please wait. This may take few moments");
  //   Functions.progressDialog.show();
  //   final res = await _dashboardItemProvider.saloonDashboardItem();
  //   // await Future.delayed(Duration(seconds: 3)).then((value) => Functions.progressDialog.dismiss());
  //   Functions.progressDialog.dismiss();
  //   setState(() {
  //     loadingdone = true;
  //   });
  //   if(res is ErrorMessage){
  //     if(res.error){
  //       print("DASHBOARD ITEM UI ${res.msg}");
  //       showPopUp(context, 'Error', res.msg, "OK",false);
  //     }
  //     else{
  //
  //     }
  //   }else{
  //     if(res is DashboardItem){
  //       if(res !=null){
  //         print("DASHBOARD_RESPONSE_HERE${res.popular}");
  //       }
  //       else{
  //         print("response issue");
  //       }
  //     }
  //   }
  // }
  //
  // void showPopUp(BuildContext context,String title, String content,String ok, bool status){
  //   animatedDialog.showAnimatedDialog(
  //     context: context,
  //     barrierDismissible: true,
  //     builder: (BuildContext context) {
  //       return animatedDialog.ClassicGeneralDialogWidget(
  //         titleText: title,
  //         contentText: content,
  //         positiveText: ok,
  //         onPositiveClick: () {
  //           if (status==false) {
  //             Navigator.of(context).pop();
  //           }
  //           else {
  //             // Navigator.of(context).push(MaterialPageRoute(builder:(context)=>OTPCode(phone: _phoneController.text)));
  //             // Navigator.pushNamed(context, '/continue');
  //           }
  //         },
  //       );
  //     },
  //     animationType: animatedDialog.DialogTransitionType.fade,
  //     curve: Curves.fastOutSlowIn,
  //     duration: Duration(seconds: 1),
  //   );
  // }
}
