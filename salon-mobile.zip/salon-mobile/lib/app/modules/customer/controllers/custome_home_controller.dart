import 'dart:async';

import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:saloon_app/app/data/model/customer/saloon-item-model.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/appointments_wrapper.dart';
import 'package:saloon_app/app/modules/customer/views/home/home_wrapper.dart';

class CustomerHomeController extends GetxController {
  //TODO: Implement HomeController

  final count = 0.obs;
  var currentScreenIndex = 2.obs;
  var homecurrentScreenIndex = 0.obs;
  double offset = 0.005;
  double userLat = 0.0;
  double userLog = 0.0;
  String userAddress = '';
  var mapCTL;
  CameraPosition userLocation = CameraPosition(
    target: LatLng(0.0, 0.0),
    zoom: 14.4746,
  );
  Map<MarkerId, Marker> markers =
      <MarkerId, Marker>{}.obs; // CLASS MEMBER, MAP OF MARKS

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

  void increment() => count.value++;

  Future<void> selectAppointment() async {
    // check if current route is settings

    try {
      // try to pop e.g. current route in settings is the detail
      await Get.keys[AppointmentNavigation.id]!.currentState!.maybePop();
    } catch (e) {
      // error
    }
  }

  Future<void> selectHomeScreen() async {
    // check if current route is settings

    try {
      // try to pop e.g. current route in settings is the detail
      await Get.keys[HomeNavigation.id]!.currentState!.maybePop();
    } catch (e) {
      // error
    }
  }

  void setUserLocation(double lat, double log) {
    userLocation = CameraPosition(
      target: LatLng(lat, log),
      zoom: 14.4746,
    );
    addMarker(lat, log, 'User', 'You');
  }

  void addMarker(double lat, double log, String id, String name) {
    final MarkerId markerId = MarkerId(id);
    // creating a new MARKER
    var marker = Marker(
        markerId: markerId,
        position: LatLng(
          lat,
          log,
        ));
    markers[markerId] = marker;
    // addSaloonMarker(lat,log,  id,name);
  }

  void addSaloonMarker(SaloonItemsModel saloonItemsModel) {
    if (saloonItemsModel.top != null) {
      for (var s in saloonItemsModel.top!) {
        final MarkerId markerId = MarkerId('${s.id}');
        // creating a new MARKER
        var marker = Marker(
          markerId: markerId,
          position: LatLng(
            s.address?.coordinates[1]??0,
            s.address?.coordinates[0]??0,
          ),
          infoWindow: InfoWindow(title: '${s.name}'),
          icon:
              BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
        );
        markers[markerId] = marker;
      }
    }
    print("Marker Count ${markers.length}");
  }

  void updatePosition(CameraPosition position) {
    ;
    final MarkerId markerId = MarkerId('User');
    print(
        "Marker Tapped........${LatLng(position.target.latitude, position.target.longitude)}");
    markers.clear();
    var marker = Marker(
        draggable: true,
        consumeTapEvents: true,
        markerId: markerId,
        position: LatLng(
            position.target.latitude + offset, position.target.longitude),
        onDragEnd: ((newPosition) {
          print("New LAt ${newPosition.latitude}");
          print(newPosition.longitude);
        }));
    markers[markerId] = marker;
    // LatLng camera = new LatLng(position.target.latitude+offset , position.target.longitude);
    // mapCTL.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
    //     target:camera,
    //     zoom: 17.0)));
  }
}
