import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-login-ctl.dart';
import 'package:saloon_app/app/modules/admin/controllers/login/admin-signup-ctl.dart';
import 'package:saloon_app/app/modules/login/controllers/login-controller.dart';


class LoginBinding extends Bindings {
  @override
  void dependencies() {

    Get.lazyPut<LoginController>(
          () => LoginController(),
    );
    Get.lazyPut<AdminLoginController>(
          () => AdminLoginController(),
    );
    Get.lazyPut<AdminSignUpCTL>(
          () => AdminSignUpCTL(),
    );
  }
}
