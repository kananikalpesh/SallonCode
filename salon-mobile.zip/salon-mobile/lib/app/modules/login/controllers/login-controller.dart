import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/login.dart';
import 'package:saloon_app/app/data/services/authApi.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class LoginController extends GetxController {
  final authApi = AuthApi();
  final emailCTL = TextEditingController();
  final passwordCTL = TextEditingController();
  LoginResponse? loginResponse;
  ErrorResponse? errorResponse;
  RxBool isDataLoaded = false.obs;

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }
  Future<bool> loginUser({required Map<String, dynamic> apiParams, required BuildContext context}) async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    final res = await authApi.userLogin(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is LoginResponse) {
      loginResponse = res;
      if (res.token != null) {
        print('token' "${res.token}");
        AppStrings.tokenOfCurrentUser="${res.token}";
        AppStrings.userId = "${res.user?.id}";
      }
      print('ADD MEMBER SUCCESS RESPONSE FOUND');
      isDataLoaded.toggle();
      return true;
    } else if (res is ErrorResponse) {
      print('ADD MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      if(errorResponse!.msg.toString().contains("Verify OTP First")){
        String msgToShow = errorResponse!.msg.toString().split(" - ")[0];
        String valueToPass = errorResponse!.msg.toString().split(" - ")[1];
        print(msgToShow);
        print(valueToPass);
        Functions.showErrorDialogForOtp(
          title: "Error",
          msg: msgToShow,
          number: valueToPass,
          context: context
        );
      }
      else{
        Functions.showErrorDialog(
          title: "Error",
          msg: "${errorResponse?.msg}",
            isSuccess:false
        );
        print("${errorResponse?.msg}");
      }
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);

      Functions.showErrorDialog(
        title: "Error",
        msg: AppStrings.slowInternet,
          isSuccess:false
      );
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet

      Functions.showErrorDialog(
        title: "Error",
        msg: AppStrings.noInternet,
          isSuccess:false
      );
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);

      Functions.showErrorDialog(
        title: "Error",
        msg: AppStrings.error,
          isSuccess:false
      );
      Functions.showToast(AppStrings.error);
    }
    return false;
  }
  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
