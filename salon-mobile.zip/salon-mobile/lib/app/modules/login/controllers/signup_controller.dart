import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/services/authApi.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class SignUpCTL extends GetxController {
  var _authApi = AuthApi();
  TextEditingController emailController = TextEditingController();
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController dobCTL = TextEditingController();
  String dob = '';

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }
  Future<bool> userSignUp({required Map<String, dynamic> apiParams}) async {
    Functions.showProgressLoader("Please Wait");

    final res = await _authApi.userSignUp(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is ErrorResponse) {
      return true;
    }  else if (res == ExceptionCode.timeOut) {
      Functions.showErrorDialog(
        title: "Error",
        msg: "Connection Timeout",
          isSuccess:false
      );
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      Functions.showErrorDialog(
        title: "Error",
        msg: AppStrings.noInternet,
          isSuccess:false
      );
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showErrorDialog(
        title: "Error",
        msg: AppStrings.error,
          isSuccess:false

      );
      return false;
    }
    return false;
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
