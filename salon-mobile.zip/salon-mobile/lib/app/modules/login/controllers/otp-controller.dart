import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/login.dart';
import 'package:saloon_app/app/data/services/authApi.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'package:saloon_app/app/utils/common_functions.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class OTPController extends GetxController {
  final authApi = AuthApi();

  LoginResponse? loginResponse;
  ErrorResponse? errorResponse;
  RxBool isDataLoaded = false.obs;

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }
  Future<bool> loginUser({required Map<String, dynamic> apiParams}) async {
    Functions.showProgressLoader("Please Wait");

    isDataLoaded = false.obs;
    final res = await authApi.userLogin(apiParams: apiParams);
    print(' CTL RESPONSE${res}');
    Functions.hideProgressLoader();
    if (res is LoginResponse) {
      loginResponse = res;
      print('ADD MEMBER SUCCESS RESPONSE FOUND');
      isDataLoaded.toggle();
      return true;
    } else if (res is ErrorResponse) {
      print('ADD MEMBER ERROR RESPONSE FOUND');
      errorResponse = res;
      Functions.showErrorDialog(
        title: "Error",
        msg: "${errorResponse?.msg}",
          isSuccess:false
      );
      return false;
    } else if (res == ExceptionCode.timeOut) {
      print(res);
      Functions.showToast(AppStrings.slowInternet);
      //slow internet
    } else if (res == ExceptionCode.noInternet) {
      //no internet
      print(res);
      Functions.showToast(AppStrings.noInternet);
    } else if (res == ExceptionCode.error) {
      //server error
      print(res);
      Functions.showToast(AppStrings.error);
    }
    return false;
  }
  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
