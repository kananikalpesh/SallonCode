import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/size_config.dart';

class ForgotPassword extends StatelessWidget {
  TextEditingController _phoneController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: ColorsX.white,
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: ColorsX.subBlack),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Container(
          color: ColorsX.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Align(
                alignment: Alignment.topCenter,
                child: Text(
                  "Forgot Password",
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 30,
                      color: ColorsX.blue_text_color),
                ),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  width: 250,
                  margin: EdgeInsets.only(left: 30, right: 30, top: 20),
                  child: Text(
                    "Please enter your email address. You will receive a code to create a new password via email.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                        color: ColorsX.subBlack),
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.only(left: 5, right: 5),
                decoration: new BoxDecoration(
                    color: ColorsX.greyBackground,
                    borderRadius: BorderRadius.all(Radius.circular(10))),
                margin: EdgeInsets.only(top: 50, right: 30, left: 30),
                child: TextFormField(
                  style: TextStyle(color: ColorsX.myblack),
                  keyboardType: TextInputType.phone,
                  obscureText: false,
                  controller: _phoneController,
                  // validator: (String value) => value.length < 10
                  //     ? 'Çharacter Length Must Be 10 Character Long'
                  //     : null,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please Enter Phone number';
                    }
                    return null;
                  },
                  minLines: 1, //Normal textInputField will be disp
                  decoration: InputDecoration(
                    enabledBorder: InputBorder.none,
                    contentPadding: EdgeInsets.only(top: 15),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide.none,
                    ),
                    prefixIcon: Image.asset(
                      "assets/images/phone.png",
                      height: 20,
                      width: 20,
                    ),
                    hintText: "Your Phone Number",
                    hintStyle: TextStyle(color: ColorsX.subBlack),
                    // labelStyle: TextStyle(
                    //     fontSize: 13,
                    //     color: ColorsX.white,
                    //     fontWeight: FontWeight.bold),
                    // labelText: 'Email',
                  ),
                ),
              ),
              Align(
                  alignment: Alignment.topCenter,
                  child: GestureDetector(
                    onTap: () {
                      // cancellationAlert(context);
                      // Navigator.pushNamed(context, '/ConnectWith');
                      forgotPassword(context);
                    },
                    child: Container(
                      margin: EdgeInsets.only(top: 50, left: 30, right: 30),
                      width: SizeConfig.screenWidth,
                      padding: EdgeInsets.symmetric(vertical: 15),
                      decoration: new BoxDecoration(
                        color: ColorsX.blue_button_color,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text("Reset Password",
                              style: TextStyle(
                                fontSize: 16,
                                color: ColorsX.white,
                                fontWeight: FontWeight.w700,
                              )),
                        ],
                      ),
                    ),
                  ))
            ],
          )),
    );
  }

  Widget? cancellationAlert(BuildContext context) {
    Dialog errorDialog = Dialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0)), //this right here
      child: Container(
        height: SizeConfig.screenHeight * .45,
        width: SizeConfig.screenWidth * .90,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              "assets/images/forget.png",
              height: 80,
              width: 80,
            ),
            Padding(
              padding: EdgeInsets.symmetric(
                  vertical: 10, horizontal: SizeConfig.blockSizeHorizontal),
              child: Text(
                "Code has been sent to reset a new password",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Color(0xff707070),
                    fontWeight: FontWeight.w700,
                    fontSize: 20),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 15, right: 15),
              child: RichText(
                text: TextSpan(
                  text: 'You'
                      '\'ll shortly receive an email with a code to setup a new password',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: ColorsX.subBlack),
                ),
              ),
            ),
            DialogButton(context),
            // _rowItemForHeaderText("Go to Booking", 14, FontWeight.w600, 0xff70b4ff, 0, 0, 0)

            // Padding(padding: EdgeInsets.only(top: 50.0)),
            // FlatButton(onPressed: (){
            //   Navigator.of(context).pop();
            // },
            //     child: Text('Got It!', style: TextStyle(color: Colors.purple, fontSize: 18.0),))
          ],
        ),
      ),
    );
    showDialog(
        context: context, builder: (BuildContext context) => errorDialog);
  }

  Widget DialogButton(BuildContext context) {
    return Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: () {
            // Navigator.of(context).push(MaterialPageRoute(builder:(context)=>OTPCode(phone: _phoneController.text)));
            // getAlertBox(context);
          },
          child: Container(
            margin: EdgeInsets.only(top: 25, bottom: 15, left: 15, right: 15),
            width: SizeConfig.screenWidth,
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: new BoxDecoration(
              color: ColorsX.blue_gradient_dark,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  child: Text("Done",
                      style: TextStyle(
                        fontSize: 16,
                        color: ColorsX.white,
                        fontWeight: FontWeight.w700,
                      )),
                ),
              ],
            ),
          ),
        ));
  }

  void forgotPassword(BuildContext context) async {
    cancellationAlert(context);

    // final _authApiProvider = AuthProvider();
    // String phone = _phoneController.text;
    // Map otpMap = Map();
    // otpMap['mobile_number'] = phone;
    // print(otpMap);
    // Functions.showProgressLoader("Please wait");
    // final res = await _authApiProvider.forgotPassword(phone);
    // Functions.hideProgressLoader();
    // // SmartDialog.dismiss();
    // if(res is ErrorMessage) {
    //   if (res.error == true) {
    //     print("OTP response from UI ${res.msg}");
    //     showPopUp(context, 'Error', res.msg, "OK", false,);
    //   } else {
    //     print(res.msg);
    //     cancellationAlert(context);
    //   }
    // }
    // }else{
    //   if(res is OtpVerificationResponse) {
    //     // print("OTP response from UI ${res.msg}");
    //     // showPopUp(context, 'Error', res.token, "OK",false);
    //     if (res != null && res.token!=null) {
    //       print('token');
    //       SharedPreferences prefs = await SharedPreferences.getInstance();
    //       UserPreferences().userToken=res.token;
    //       UserPreferences().userName=res.data.name;
    //       UserPreferences().userID=res.data.id;
    //       // UserPreferences().userMobileNumber=res.token;
    //
    //       print("USER TOKEN ${UserPreferences().userToken}");
    //       Navigator.pushNamed(context, '/continue');
    //     }
    //   }
    //   else{
    //
    //   }
    // }
  }
  // _displayErrorMotionToast(BuildContext context, String title, String description) {
  //   MotionToast.error(
  //     title: title,
  //     titleStyle: TextStyle(fontWeight: FontWeight.bold),
  //     description: description,
  //     animationType: ANIMATION.FROM_LEFT,
  //     position: MOTION_TOAST_POSITION.TOP,
  //     width: SizeConfig.screenWidth,
  //   ).show(context);
  // }

  // void showPopUp(BuildContext context,String title, String content,String ok, bool status){
  //   animatedDialog.showAnimatedDialog(
  //     context: context,
  //     barrierDismissible: true,
  //     builder: (BuildContext context) {
  //       return animatedDialog.ClassicGeneralDialogWidget(
  //         titleText: title,
  //         contentText: content,
  //         positiveText: ok,
  //         onPositiveClick: () {
  //           if (status==false) {
  //             Navigator.of(context).pop();
  //           }
  //           else {
  //             // Navigator.of(context).push(MaterialPageRoute(builder:(context)=>OTPCode(phone: _phoneController.text)));
  //             Navigator.pushNamed(context, '/continue');
  //           }
  //         },
  //       );
  //     },
  //     animationType: animatedDialog.DialogTransitionType.fade,
  //     curve: Curves.fastOutSlowIn,
  //     duration: Duration(seconds: 1),
  //   );
  // }

}
