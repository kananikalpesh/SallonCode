import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:saloon_app/app/routes/app_pages.dart';
import 'package:saloon_app/app/socials/Authenticate.dart';
import 'package:saloon_app/app/utils/colors.dart';
import 'package:saloon_app/app/utils/images.dart';
import 'package:saloon_app/app/utils/size_config.dart';


class MainContinueAs extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            child: Image.asset(AppImages.Dark_Girl_bg2, fit: BoxFit.cover,),
          ),
          Container(
            height: 100,
            width: 100,
            margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth,top: SizeConfig.screenHeight*.38),
            child: Image.asset(AppImages.Splash_logo, fit: BoxFit.cover,),
          ),
          Container(
            height: 40,
            width: 140,
            margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth,top: SizeConfig.screenHeight*.53),
            child: Image.asset(AppImages.Big_log, fit: BoxFit.cover,),
          ),
          textWidgets("Book an appointment for Salon, Spa & Barber", 20, context),
          getRowElement("Continue as Customer", context, SizeConfig.screenHeight*.70,0xffffffff,0xff606060),
          getRowElement("Continue as Saloon", context, SizeConfig.screenHeight*.78,0xff70b4ff,0xffffffff),
          // getRowElement("assets/images/apple.png", "Connect with Apple", context, SizeConfig.screenHeight*.86,0xff4B4949,0xffffffff),
          Align(
              alignment: Alignment.center,
              child: GestureDetector(
                onTap: (){
                  // Get.toNamed(Routes.CONNECT_WITH);
                  Navigator.pushNamed(context, '/login');
                },
                child: Container(
                    margin: EdgeInsets.only(top: SizeConfig.screenHeight*.93),
                    child: RichText(
                      text: TextSpan(
                        text: 'Powered by IvylabTechnologies@2021',
                        style: TextStyle(fontSize: 16,fontWeight: FontWeight.w400, color: ColorsX.white),
                        children: const <TextSpan>[
                          // TextSpan(text: 'Sign In', style: TextStyle(fontSize: 16,fontWeight: FontWeight.w400, color: ColorsX.blue_gradient_dark)),
                        ],
                      ),
                    )
                ),
              )
          ),
        ],
      ),
    );
  }

  Widget getRowElement( String value, BuildContext context, double top, int colorCode, int textColor){
    return GestureDetector(
      onTap: (){
        if(value.contains("Customer"))
          {//Navigator.pushNamed(context, '/asCustomer');
            // Get.toNamed(Routes.CONNECT_WITH);
            // Authentication();
            Get.toNamed(Routes.LOGIN_SCREEN);
          }
        else
          {// Navigator.push(context, MaterialPageRoute(builder: (context) => SaloonDashBoard("assets/images/home_dash.png"),));
          // Navigator.pushNamed(context, '/saloonDashboard');
          Get.toNamed(Routes.SALOON_CONTINUE_AS_SCREEN);}

      },
        child: Container(
            margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth, right: SizeConfig.tenPercentWidth, top: top),
            padding: EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
                color: Color(colorCode),
                borderRadius: BorderRadius.all(Radius.circular(10))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Color(textColor)),),
                SizedBox(),
              ],
            )
        ),
    );
  }

  Widget textWidgets(String value, double fontSize, BuildContext context){
    return Container(
      margin: EdgeInsets.only(left: SizeConfig.tenPercentWidth,top: SizeConfig.screenHeight*.60, right: SizeConfig.tenPercentWidth),
      child: Text(value, style: TextStyle(color: ColorsX.white, fontWeight: FontWeight.w700, fontSize: fontSize),),
    );
  }
}