// To parse this JSON data, do
//
//     final designationRes = designationResFromJson(jsonString);

import 'dart:convert';

DesignationRes designationResFromJson(String str) =>
    DesignationRes.fromJson(json.decode(str));

String designationResToJson(DesignationRes data) => json.encode(data.toJson());

class DesignationRes {
  DesignationRes({
    this.error,
    this.data,
  });

  bool? error;
  List<Datum>? data;

  factory DesignationRes.fromJson(Map<String, dynamic> json) => DesignationRes(
        error: json["Error"] == null ? null : json["Error"],
        data: json["Data"] == null
            ? null
            : List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Error": error == null ? null : error,
        "Data": data == null
            ? null
            : List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    this.id,
    this.title,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  String? id;
  String? title;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["_id"] == null ? null : json["_id"],
        title: json["title"] == null ? null : json["title"],
        createdAt: json["createdAt"] == null
            ? null
            : DateTime.parse(json["createdAt"]),
        updatedAt: json["updatedAt"] == null
            ? null
            : DateTime.parse(json["updatedAt"]),
        v: json["__v"] == null ? null : json["__v"],
      );

  Map<String, dynamic> toJson() => {
        "_id": id == null ? null : id,
        "title": title == null ? null : title,
        "createdAt": createdAt == null ? null : createdAt?.toIso8601String(),
        "updatedAt": updatedAt == null ? null : updatedAt?.toIso8601String(),
        "__v": v == null ? null : v,
      };
}
