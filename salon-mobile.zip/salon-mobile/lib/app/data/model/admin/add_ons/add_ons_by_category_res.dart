// To parse this JSON data, do
//
//     final addOnsByCategoryRes = addOnsByCategoryResFromJson(jsonString);

import 'dart:convert';

AddOnsByCategoryRes addOnsByCategoryResFromJson(String str) => AddOnsByCategoryRes.fromJson(json.decode(str));

String addOnsByCategoryResToJson(AddOnsByCategoryRes data) => json.encode(data.toJson());

class AddOnsByCategoryRes {
  AddOnsByCategoryRes({
    this.products,
    this.error,
    this.count
  });

  List<Product>? products;
  bool? error;
  int? count;

  factory AddOnsByCategoryRes.fromJson(Map<String, dynamic> json) => AddOnsByCategoryRes(
    products: json["Products"] == null ? null : List<Product>.from(json["Products"].map((x) => Product.fromJson(x))),
    error: json["Error"] == null ? null : json["Error"],
    count: json["Count"] == null ? null : json["Count"],
  );

  Map<String, dynamic> toJson() => {
    "Products": products == null ? null : List<dynamic>.from(products!.map((x) => x.toJson())),
    "Error": error == null ? null : error,
    "Count": count == null ? null : count,
  };
}

class Product {
  Product({
    this.photos,
    this.colors,
    this.quantity,
    this.quantitySold,
    this.rating,
    this.reviews,
    this.approved,
    this.deleted,
    this.available,
    this.id,
    this.saloon,
    this.name,
    this.category,
    this.description,
    this.brandName,
    this.price,
    this.date,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.profilePic,
  });

  List<String>? photos;
  List<dynamic>? colors;
  int? quantity;
  int? quantitySold;
  int? rating;
  int? reviews;
  bool? approved;
  bool? deleted;
  bool? available;
  String? id;
  String? saloon;
  String? name;
  Category? category;
  String? description;
  String? brandName;
  int? price;
  DateTime? date;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  String? profilePic;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    photos: json["Photos"] == null ? null : List<String>.from(json["Photos"].map((x) => x)),
    colors: json["Colors"] == null ? null : List<dynamic>.from(json["Colors"].map((x) => x)),
    quantity: json["Quantity"] == null ? null : json["Quantity"],
    quantitySold: json["Quantity_Sold"] == null ? null : json["Quantity_Sold"],
    rating: json["Rating"] == null ? null : json["Rating"],
    reviews: json["Reviews"] == null ? null : json["Reviews"],
    approved: json["Approved"] == null ? null : json["Approved"],
    deleted: json["Deleted"] == null ? null : json["Deleted"],
    available: json["Available"] == null ? null : json["Available"],
    id: json["_id"] == null ? null : json["_id"],
    saloon: json["Saloon"] == null ? null : json["Saloon"],
    name: json["Name"] == null ? null : json["Name"],
    category: json["Category"] == null ? null : Category.fromJson(json["Category"]),
    description: json["Description"] == null ? null : json["Description"],
    brandName: json["Brand_Name"] == null ? null : json["Brand_Name"],
    price: json["Price"] == null ? null : json["Price"],
    date: json["date"] == null ? null : DateTime.parse(json["date"]),
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
    profilePic: json["Profile_Pic"] == null ? null : json["Profile_Pic"],
  );

  Map<String, dynamic> toJson() => {
    "Photos": photos == null ? null : List<dynamic>.from(photos!.map((x) => x)),
    "Colors": colors == null ? null : List<dynamic>.from(colors!.map((x) => x)),
    "Quantity": quantity == null ? null : quantity,
    "Quantity_Sold": quantitySold == null ? null : quantitySold,
    "Rating": rating == null ? null : rating,
    "Reviews": reviews == null ? null : reviews,
    "Approved": approved == null ? null : approved,
    "Deleted": deleted == null ? null : deleted,
    "Available": available == null ? null : available,
    "_id": id == null ? null : id,
    "Saloon": saloon == null ? null : saloon,
    "Name": name == null ? null : name,
    "Category": category == null ? null : category,
    "Description": description == null ? null : description,
    "Brand_Name": brandName == null ? null : brandName,
    "Price": price == null ? null : price,
    "date": date == null ? null : date?.toIso8601String(),
    "createdAt": createdAt == null ? null : createdAt?.toIso8601String(),
    "updatedAt": updatedAt == null ? null : updatedAt?.toIso8601String(),
    "__v": v == null ? null : v,
    "Profile_Pic": profilePic == null ? null : profilePic,
  };

}
class Category {
  Category({
    this.status,
    this.id,
    this.title,
    this.description,
    this.backgroundPic,
    this.icon,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  bool? status;
  String? id;
  String? title;
  String? description;
  String? backgroundPic;
  String? icon;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  factory Category.fromJson(Map<String, dynamic> json) => Category(
    status: json["status"] == null ? null : json["status"],
    id: json["_id"] == null ? null : json["_id"],
    title: json["title"] == null ? null : json["title"],
    description: json["description"] == null ? null : json["description"],
    backgroundPic: json["Background_Pic"] == null ? null : json["Background_Pic"],
    icon: json["Icon"] == null ? null : json["Icon"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
  );


}
