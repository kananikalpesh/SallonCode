// To parse this JSON data, do
//
//     final addServiceRes = addServiceResFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

AddServiceRes addServiceResFromJson(String str) => AddServiceRes.fromJson(json.decode(str));

String addServiceResToJson(AddServiceRes data) => json.encode(data.toJson());

class AddServiceRes {
  AddServiceRes({
    required this.data,
    required this.error,
  });

  Data data;
  bool error;

  factory AddServiceRes.fromJson(Map<String, dynamic> json) => AddServiceRes(
    data: Data.fromJson(json["data"]),
    error: json["Error"],
  );

  Map<String, dynamic> toJson() => {
    "data": data.toJson(),
    "Error": error,
  };
}

class Data {
  Data({
    required this.prefix,
    required this.status,
    required this.id,
    required this.name,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.category,
    required this.saloon,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  String prefix;
  bool status;
  String id;
  String name;
  String description;
  String timeRequired;
  int price;
  String category;
  String saloon;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    prefix: json["Prefix"],
    status: json["Status"],
    id: json["_id"],
    name: json["Name"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    category: json["Category"],
    saloon: json["Saloon"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "Prefix": prefix,
    "Status": status,
    "_id": id,
    "Name": name,
    "Description": description,
    "Time_required": timeRequired,
    "Price": price,
    "Category": category,
    "Saloon": saloon,
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
  };
}
