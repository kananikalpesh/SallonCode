// To parse this JSON data, do
//
//     final saloonBookingRes = saloonBookingResFromJson(jsonString?);

import 'dart:convert';

import 'package:saloon_app/app/data/model/customer/core_entity/time_slot.dart';

SaloonBookingRes saloonBookingResFromJson(String str) => SaloonBookingRes.fromJson(json.decode(str));


class SaloonBookingRes {
  SaloonBookingRes({
    this.error,
    this.data,
  });

  bool? error;
  List<Datum>? data;

  factory SaloonBookingRes.fromJson(Map<String?, dynamic> json) => SaloonBookingRes(
    error: json["Error"] == null ? null : json["Error"],
    data: json["Data"] == null ? null : List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );
}

class Datum {
  Datum({
    this.status,
    this.payment,
    this.paymentType,
    this.id,
    this.saloon,
    this.services,
    this.products,
    this.staff,
    this.appointmentDate,
    this.timeSlot,
    this.totalPrice,
    this.appointmentId,
    this.user,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  String? status;
  String? payment;
  String? paymentType;
  String? id;
  Saloon? saloon;
  Services? services;
  List<ProductElement>? products;
  Staff? staff;
  DateTime? appointmentDate;
  String? timeSlot;
  int? totalPrice;
  String? appointmentId;
  User? user;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  factory Datum.fromJson(Map<String?, dynamic> json) => Datum(
    status: json["Status"] == null ? null : json["Status"],
    payment: json["Payment"] == null ? null : json["Payment"],
    paymentType: json["Payment_Type"] == null ? null : json["Payment_Type"],
    id: json["_id"] == null ? null : json["_id"],
    saloon: json["Saloon"] == null ? null : Saloon.fromJson(json["Saloon"]),
    services: json["Services"] == null ? null : Services.fromJson(json["Services"]),
    products: json["Products"] == null ? null : List<ProductElement>.from(json["Products"].map((x) => ProductElement.fromJson(x))),
    staff: json["Staff"] == null ? null : Staff.fromJson(json["Staff"]),
    appointmentDate: json["Appointment_Date"] == null ? null : DateTime?.parse(json["Appointment_Date"]),
    timeSlot: json["Time_Slot"] == null ? null : json["Time_Slot"],
    totalPrice: json["Total_Price"] == null ? null : json["Total_Price"],
    appointmentId: json["Appointment_Id"] == null ? null : json["Appointment_Id"],
    user: json["User"] == null ? null : User.fromJson(json["User"]),
    createdAt: json["createdAt"] == null ? null : DateTime?.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime?.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
  );

}

class ProductElement {
  ProductElement({
    this.id,
    this.product,
    this.quantity,
  });

  String? id;
  ProductProduct? product;
  int? quantity;

  factory ProductElement.fromJson(Map<String?, dynamic> json) => ProductElement(
    id: json["_id"] == null ? null : json["_id"],
    product: json["Product"] == null ? null : ProductProduct.fromJson(json["Product"]),
    quantity: json["Quantity"] == null ? null : json["Quantity"],
  );

}

class ProductProduct {
  ProductProduct({
    this.photos,
    this.colors,
    this.quantity,
    this.quantitySold,
    this.rating,
    this.reviews,
    this.approved,
    this.deleted,
    this.available,
    this.id,
    this.name,
    this.description,
    this.category,
    this.saloon,
    this.price,
    this.date,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.profilePic,
  });

  List<String?>? photos;
  List<String?>? colors;
  int? quantity;
  int? quantitySold;
  int? rating;
  int? reviews;
  bool? approved;
  bool? deleted;
  bool? available;
  String? id;
  String? name;
  String? description;
  String? category;
  String? saloon;
  int? price;
  DateTime? date;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  String? profilePic;

  factory ProductProduct.fromJson(Map<String?, dynamic> json) => ProductProduct(
    photos: json["Photos"] == null ? null : List<String?>.from(json["Photos"].map((x) => x)),
    colors: json["Colors"] == null ? null : List<String?>.from(json["Colors"].map((x) => x)),
    quantity: json["Quantity"] == null ? null : json["Quantity"],
    quantitySold: json["Quantity_Sold"] == null ? null : json["Quantity_Sold"],
    rating: json["Rating"] == null ? null : json["Rating"],
    reviews: json["Reviews"] == null ? null : json["Reviews"],
    approved: json["Approved"] == null ? null : json["Approved"],
    deleted: json["Deleted"] == null ? null : json["Deleted"],
    available: json["Available"] == null ? null : json["Available"],
    id: json["_id"] == null ? null : json["_id"],
    name: json["Name"] == null ? null : json["Name"],
    description: json["Description"] == null ? null : json["Description"],
    category: json["Category"] == null ? null : json["Category"],
    saloon: json["Saloon"] == null ? null : json["Saloon"],
    price: json["Price"] == null ? null : json["Price"],
    date: json["date"] == null ? null : DateTime?.parse(json["date"]),
    createdAt: json["createdAt"] == null ? null : DateTime?.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime?.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
    profilePic: json["Profile_Pic"] == null ? null : json["Profile_Pic"],
  );

}

class Saloon {
  Saloon({
    this.address,
    this.photos,
    this.services,
    this.rating,
    this.reviews,
    this.bookingsLeft,
    this.bookingsUsed,
    this.status,
    this.approved,
    this.id,
    this.name,
    this.email,
    this.mobileNumber,
    this.category,
    this.password,
    this.profilePic,
    this.registerDate,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.aboutUs,
    this.description,
    this.businessType,
    this.closeTime,
    this.openTime,
  });

  Address? address;
  List<String?>? photos;
  List<String?>? services;
  int? rating;
  int? reviews;
  int? bookingsLeft;
  int? bookingsUsed;
  bool? status;
  bool? approved;
  String? id;
  String? name;
  String? email;
  String? mobileNumber;
  String? category;
  String? password;
  String? profilePic;
  DateTime? registerDate;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  String? aboutUs;
  String? description;
  String? businessType;
  String? closeTime;
  String? openTime;

  factory Saloon.fromJson(Map<String?, dynamic> json) => Saloon(
    address: json["Address"] == null ? null : Address.fromJson(json["Address"]),
    photos: json["Photos"] == null ? null : List<String?>.from(json["Photos"].map((x) => x)),
    services: json["Services"] == null ? null : List<String?>.from(json["Services"].map((x) => x)),
    rating: json["Rating"] == null ? null : json["Rating"],
    reviews: json["Reviews"] == null ? null : json["Reviews"],
    bookingsLeft: json["Bookings_Left"] == null ? null : json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"] == null ? null : json["Bookings_Used"],
    status: json["status"] == null ? null : json["status"],
    approved: json["approved"] == null ? null : json["approved"],
    id: json["_id"] == null ? null : json["_id"],
    name: json["Name"] == null ? null : json["Name"],
    email: json["Email"] == null ? null : json["Email"],
    mobileNumber: json["Mobile_number"] == null ? null : json["Mobile_number"],
    category: json["Category"] == null ? null : json["Category"],
    password: json["Password"] == null ? null : json["Password"],
    profilePic: json["Profile_Pic"] == null ? null : json["Profile_Pic"],
    registerDate: json["Register_date"] == null ? null : DateTime?.parse(json["Register_date"]),
    createdAt: json["createdAt"] == null ? null : DateTime?.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime?.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
    aboutUs: json["About_Us"] == null ? null : json["About_Us"],
    description: json["Description"] == null ? null : json["Description"],
    businessType: json["Business_Type"] == null ? null : json["Business_Type"],
    closeTime: json["Close_Time"] == null ? null : json["Close_Time"],
    openTime: json["Open_Time"] == null ? null : json["Open_Time"],
  );

}

class Address {
  Address({
    this.type,
    this.coordinates,
    this.address,
    this.city,
    this.state,
  });

  String? type;
  List<double>? coordinates;
  String? address;
  String? city;
  String? state;

  factory Address.fromJson(Map<String?, dynamic> json) => Address(
    type: json["type"] == null ? null : json["type"],
    coordinates: json["coordinates"] == null ? null : List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"] == null ? null : json["Address"],
    city: json["City"] == null ? null : json["City"],
    state: json["State"] == null ? null : json["State"],
  );

}

class Services {
  Services({
    this.prefix,
    this.profilePic,
    this.status,
    this.id,
    this.saloon,
    this.name,
    this.category,
    this.description,
    this.timeRequired,
    this.price,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  String? prefix;
  String? profilePic;
  bool? status;
  String? id;
  String? saloon;
  String? name;
  String? category;
  String? description;
  String? timeRequired;
  int? price;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  factory Services.fromJson(Map<String?, dynamic> json) => Services(
    prefix: json["Prefix"] == null ? null : json["Prefix"],
    profilePic: json["Profile_pic"] == null ? null : json["Profile_pic"],
    status: json["Status"] == null ? null : json["Status"],
    id: json["_id"] == null ? null : json["_id"],
    saloon: json["Saloon"] == null ? null : json["Saloon"],
    name: json["Name"] == null ? null : json["Name"],
    category: json["Category"] == null ? null : json["Category"],
    description: json["Description"] == null ? null : json["Description"],
    timeRequired: json["Time_required"] == null ? null : json["Time_required"],
    price: json["Price"] == null ? null : json["Price"],
    createdAt: json["createdAt"] == null ? null : DateTime?.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime?.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
  );

}

class Staff {
  Staff({
    this.photos,
    this.rating,
    this.services,
    this.deleted,
    this.id,
    this.name,
    this.email,
    this.password,
    this.age,
    this.gender,
    this.designation,
    this.saloon,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.timeSlots,
  });

  List<String?>? photos;
  int? rating;
  List<String?>? services;
  bool? deleted;
  String? id;
  String? name;
  String? email;
  String? password;
  String? age;
  String? gender;
  String? designation;
  String? saloon;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  List<TimeSlot>? timeSlots;

  factory Staff.fromJson(Map<String?, dynamic> json) => Staff(
    photos: json["Photos"] == null ? null : List<String?>.from(json["Photos"].map((x) => x)),
    rating: json["Rating"] == null ? null : json["Rating"],
    services: json["Services"] == null ? null : List<String?>.from(json["Services"].map((x) => x)),
    deleted: json["Deleted"] == null ? null : json["Deleted"],
    id: json["_id"] == null ? null : json["_id"],
    name: json["Name"] == null ? null : json["Name"],
    email: json["Email"] == null ? null : json["Email"],
    password: json["Password"] == null ? null : json["Password"],
    age: json["Age"] == null ? null : json["Age"],
    gender: json["Gender"] == null ? null : json["Gender"],
    designation: json["Designation"] == null ? null : json["Designation"],
    saloon: json["Saloon"] == null ? null : json["Saloon"],
    createdAt: json["createdAt"] == null ? null : DateTime?.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime?.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
    timeSlots: json["Time_Slots"] == null ? null : List<TimeSlot>.from(json["Time_Slots"].map((x) => TimeSlot.fromJson(x))),
  );

}

class User {
  User({
    this.rating,
    this.role,
    this.favouriteProducts,
    this.favouriteSaloons,
    this.status,
    this.id,
    this.name,
    this.email,
    this.password,
    this.mobileNumber,
    this.dob,
    this.registerDate,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.otp,
    this.profilePic,
  });

  int? rating;
  String? role;
  List<dynamic>? favouriteProducts;
  List<String?>? favouriteSaloons;
  bool? status;
  String? id;
  String? name;
  String? email;
  String? password;
  String? mobileNumber;
  String? dob;
  DateTime? registerDate;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  int? otp;
  String? profilePic;

  factory User.fromJson(Map<String?, dynamic> json) => User(
    rating: json["Rating"] == null ? null : json["Rating"],
    role: json["role"] == null ? null : json["role"],
    favouriteProducts: json["FavouriteProducts"] == null ? null : List<dynamic>.from(json["FavouriteProducts"].map((x) => x)),
    favouriteSaloons: json["FavouriteSaloons"] == null ? null : List<String?>.from(json["FavouriteSaloons"].map((x) => x)),
    status: json["status"] == null ? null : json["status"],
    id: json["_id"] == null ? null : json["_id"],
    name: json["name"] == null ? null : json["name"],
    email: json["email"] == null ? null : json["email"],
    password: json["password"] == null ? null : json["password"],
    mobileNumber: json["mobile_number"] == null ? null : json["mobile_number"],
    dob: json["DOB"] == null ? null : json["DOB"],
    registerDate: json["register_date"] == null ? null : DateTime?.parse(json["register_date"]),
    createdAt: json["createdAt"] == null ? null : DateTime?.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime?.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
    otp: json["otp"] == null ? null : json["otp"],
    profilePic: json["Profile_Pic"] == null ? null : json["Profile_Pic"],
  );

}
