// To parse this JSON data, do
//
//     final sendReview = sendReviewFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

SendReview sendReviewFromJson(String str) => SendReview.fromJson(json.decode(str));

String sendReviewToJson(SendReview data) => json.encode(data.toJson());

class SendReview {
  SendReview({
    required this.msg,
    required this.error,
    required this.data,
  });

  String msg;
  bool error;
  Data data;

  factory SendReview.fromJson(Map<String, dynamic> json) => SendReview(
    msg: json["msg"],
    error: json["Error"],
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "msg": msg,
    "Error": error,
    "Data": data.toJson(),
  };
}

class Data {
  Data({
    required this.approved,
    required this.id,
    required this.saloon,
    required this.rating,
    required this.user,
    required this.description,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  bool approved;
  String id;
  String saloon;
  dynamic rating;
  String user;
  String description;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    approved: json["approved"],
    id: json["_id"],
    saloon: json["Saloon"],
    rating: json["Rating"],
    user: json["User"],
    description: json["Description"],
    date: DateTime.parse(json["date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "approved": approved,
    "_id": id,
    "Saloon": saloon,
    "Rating": rating,
    "User": user,
    "Description": description,
    "date": date.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
  };
}
