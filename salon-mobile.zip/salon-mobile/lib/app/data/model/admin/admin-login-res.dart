// To parse this JSON data, do
//
//     final adminLoginRes = adminLoginResFromJson(jsondynamic);

import 'package:meta/meta.dart';
import 'dart:convert';

AdminLoginRes adminLoginResFromJson(dynamic str) =>
    AdminLoginRes.fromJson(json.decode(str));

dynamic adminLoginResToJson(AdminLoginRes data) => json.encode(data.toJson());

class AdminLoginRes {
  AdminLoginRes({
    required this.error,
    required this.msg,
    required this.status,
    required this.token,
    required this.saloon,
  });

  bool error;
  dynamic msg;
  bool status;
  dynamic token;
  AdminLoginResSaloon saloon;

  factory AdminLoginRes.fromJson(Map<dynamic, dynamic> json) => AdminLoginRes(
        error: json["Error"],
        msg: json["msg"],
        status: json["status"],
        token: json["token"],
        saloon: AdminLoginResSaloon.fromJson(json["saloon"]),
      );

  Map<dynamic, dynamic> toJson() => {
        "Error": error,
        "msg": msg,
        "status": status,
        "token": token,
        "saloon": saloon.toJson(),
      };
}

class AdminLoginResSaloon {
  AdminLoginResSaloon({
    required this.id,
    required this.name,
    required this.email,
    required this.services,
    required this.saloon,
    required this.role,
  });

  dynamic id;
  dynamic name;
  dynamic email;
  List<dynamic> services;
  SaloonSaloon saloon;
  dynamic role;

  factory AdminLoginResSaloon.fromJson(Map<dynamic, dynamic> json) =>
      AdminLoginResSaloon(
        id: json["id"],
        name: json["name"],
        email: json["email"],
        services: List<dynamic>.from(json["services"].map((x) => x)),
        saloon: SaloonSaloon.fromJson(json["saloon"]),
        role: json["role"],
      );

  Map<dynamic, dynamic> toJson() => {
        "id": id,
        "name": name,
        "email": email,
        "services": List<dynamic>.from(services.map((x) => x)),
        "saloon": saloon.toJson(),
        "role": role,
      };
}

class SaloonSaloon {
  SaloonSaloon({
    required this.address,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.profilePic,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
  });

  Address? address;
  List<dynamic> photos;
  List<dynamic> services;
  int rating;
  int reviews;
  int bookingsLeft;
  int bookingsUsed;
  bool status;
  bool approved;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic mobileNumber;
  dynamic category;
  dynamic password;
  dynamic profilePic;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic aboutUs;
  dynamic description;
  dynamic businessType;
  dynamic closeTime;
  dynamic openTime;

  factory SaloonSaloon.fromJson(Map<dynamic, dynamic> json) => SaloonSaloon(
        address:
            json["Address"] == null ? null : Address.fromJson(json["Address"]),
        photos: List<dynamic>.from(json["Photos"].map((x) => x)),
        services: List<dynamic>.from(json["Services"].map((x) => x)),
        rating: json["Rating"],
        reviews: json["Reviews"],
        bookingsLeft: json["Bookings_Left"],
        bookingsUsed: json["Bookings_Used"],
        status: json["status"],
        approved: json["approved"],
        id: json["_id"],
        name: json["Name"],
        email: json["Email"],
        mobileNumber: json["Mobile_number"],
        category: json["Category"],
        password: json["Password"],
        profilePic: json["Profile_Pic"],
        registerDate: DateTime.parse(json["Register_date"]),
        createdAt: DateTime.parse(json["createdAt"]),
        updatedAt: DateTime.parse(json["updatedAt"]),
        v: json["__v"],
        aboutUs: json["About_Us"],
        description: json["Description"],
        businessType: json["Business_Type"],
        closeTime: json["Close_Time"],
        openTime: json["Open_Time"],
      );

  Map<dynamic, dynamic> toJson() => {
        "Address": address!.toJson(),
        "Photos": List<dynamic>.from(photos.map((x) => x)),
        "Services": List<dynamic>.from(services.map((x) => x)),
        "Rating": rating,
        "Reviews": reviews,
        "Bookings_Left": bookingsLeft,
        "Bookings_Used": bookingsUsed,
        "status": status,
        "approved": approved,
        "_id": id,
        "Name": name,
        "Email": email,
        "Mobile_number": mobileNumber,
        "Category": category,
        "Password": password,
        "Profile_Pic": profilePic,
        "Register_date": registerDate,
        "createdAt": createdAt,
        "updatedAt": updatedAt,
        "__v": v,
        "About_Us": aboutUs,
        "Description": description,
        "Business_Type": businessType,
        "Close_Time": closeTime,
        "Open_Time": openTime,
      };
}

class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });

  dynamic type;
  List<double> coordinates;
  dynamic address;
  dynamic city;
  dynamic state;

  factory Address.fromJson(Map<dynamic, dynamic> json) => Address(
        type: json["type"],
        coordinates:
            List<double>.from(json["coordinates"].map((x) => x.toDouble())),
        address: json["Address"],
        city: json["City"],
        state: json["State"],
      );

  Map<dynamic, dynamic> toJson() => {
        "type": type,
        "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
        "Address": address,
        "City": city,
        "State": state,
      };
}
