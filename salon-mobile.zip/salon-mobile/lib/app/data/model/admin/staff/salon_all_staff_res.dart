// To parse this JSON data, do
//
//     final saloonAllStaff = saloonAllStaffFromJson(jsonString);

import 'dart:convert';

SaloonAllStaff saloonAllStaffFromJson(String str) => SaloonAllStaff.fromJson(json.decode(str));


class SaloonAllStaff {
  SaloonAllStaff({
    this.error,
    this.data,
  });

  bool? error;
  List<Datum>? data;

  factory SaloonAllStaff.fromJson(Map<String, dynamic> json) => SaloonAllStaff(
    error: json["Error"] == null ? null : json["Error"],
    data: json["Data"] == null ? null : List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );

}

class Datum {
  Datum({
    this.photos,
    this.rating,
    this.services,
    this.deleted,
    this.id,
    this.name,
    this.email,
    this.password,
    this.age,
    this.gender,
    this.designation,
    this.staffPic,
    this.saloon,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.timeSlots,
  });

  List<String>? photos;
  int? rating;
  List<Service>? services;
  bool? deleted;
  String? id;
  String? name;
  String? email;
  String? password;
  String? age;
  String? gender;
  String? designation;
  String? staffPic;
  String? saloon;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  List<TimeSlot>? timeSlots;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    photos: json["Photos"] == null ? null : List<String>.from(json["Photos"].map((x) => x)),
    rating: json["Rating"] == null ? null : json["Rating"],
    services: json["Services"] == null ? null : List<Service>.from(json["Services"].map((x) => Service.fromJson(x))),
    deleted: json["Deleted"] == null ? null : json["Deleted"],
    id: json["_id"] == null ? null : json["_id"],
    name: json["Name"] == null ? null : json["Name"],
    email: json["Email"] == null ? null : json["Email"],
    password: json["Password"] == null ? null : json["Password"],
    staffPic: json["Staff_pic"] == null ? null: json["Staff_pic"],
    age: json["Age"] == null ? null : json["Age"],
    gender: json["Gender"] == null ? null : json["Gender"],
    designation: json["Designation"] == null ? null : json["Designation"],
    saloon: json["Saloon"] == null ? null : json["Saloon"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
    timeSlots: json["Time_Slots"] == null ? null : List<TimeSlot>.from(json["Time_Slots"].map((x) => TimeSlot.fromJson(x))),
  );

}

class Service {
  Service({
    this.prefix,
    this.profilePic,
    this.status,
    this.id,
    this.saloon,
    this.name,
    this.category,
    this.description,
    this.timeRequired,
    this.price,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  String? prefix;
  String? profilePic;
  bool? status;
  String? id;
  String? saloon;
  String? name;
  String? category;
  String? description;
  String? timeRequired;
  int? price;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  factory Service.fromJson(Map<String, dynamic> json) => Service(
    prefix: json["Prefix"] == null ? null : json["Prefix"],
    profilePic: json["Profile_pic"] == null ? null : json["Profile_pic"],
    status: json["Status"] == null ? null : json["Status"],
    id: json["_id"] == null ? null : json["_id"],
    saloon: json["Saloon"] == null ? null : json["Saloon"],
    name: json["Name"] == null ? null : json["Name"],
    category: json["Category"] == null ? null : json["Category"],
    description: json["Description"] == null ? null : json["Description"],
    timeRequired: json["Time_required"] == null ? null : json["Time_required"],
    price: json["Price"] == null ? null : json["Price"],
    createdAt: json["createdAt"] == null ? null : DateTime.parse(json["createdAt"]),
    updatedAt: json["updatedAt"] == null ? null : DateTime.parse(json["updatedAt"]),
    v: json["__v"] == null ? null : json["__v"],
  );


}

class TimeSlot {
  TimeSlot({
    this.day,
    this.startTime,
    this.endTime,
    this.slotTime,
    this.slotInterval,
  });

  String? day;
  String? startTime;
  String? endTime;
  String? slotTime;
  String? slotInterval;

  factory TimeSlot.fromJson(Map<String, dynamic> json) => TimeSlot(
    day: json["day"] == null ? null : json["day"],
    startTime: json["start_time"] == null ? null : json["start_time"],
    endTime: json["end_time"] == null ? null : json["end_time"],
    slotTime: json["slot_time"] == null ? null : json["slot_time"],
    slotInterval: json["slot_interval"] == null ? null : json["slot_interval"],
  );

  Map<String, dynamic> toJson() => {
    "day": day == null ? null : day,
    "start_time": startTime == null ? null : startTime,
    "end_time": endTime == null ? null : endTime,
    "slot_time": slotTime == null ? null : slotTime,
    "slot_interval": slotInterval == null ? null : slotInterval,
  };
}
