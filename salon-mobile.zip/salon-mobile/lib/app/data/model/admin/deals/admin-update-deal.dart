// To parse this JSON data, do
//
//     final adminUpdateDealRes = adminUpdateDealResFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

AdminUpdateDealRes adminUpdateDealResFromJson(String str) => AdminUpdateDealRes.fromJson(json.decode(str));

String adminUpdateDealResToJson(AdminUpdateDealRes data) => json.encode(data.toJson());

class AdminUpdateDealRes {
  AdminUpdateDealRes({
    required this.error,
    required this.msg,
    required this.data,
  });

  bool error;
  String msg;
  Data data;

  factory AdminUpdateDealRes.fromJson(Map<String, dynamic> json) => AdminUpdateDealRes(
    error: json["Error"],
    msg: json["msg"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "Error": error,
    "msg": msg,
    "data": data.toJson(),
  };
}

class Data {
  Data({
    required this.price,
    required this.approved,
    required this.status,
    required this.id,
    required this.couponName,
    required this.couponCode,
    required this.category,
    required this.minPrice,
    required this.percentage,
    required this.startDate,
    required this.endDate,
    required this.service,
    required this.description,
    required this.saloon,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  int price;
  bool approved;
  String status;
  String id;
  String couponName;
  String couponCode;
  String category;
  int minPrice;
  int percentage;
  DateTime startDate;
  DateTime endDate;
  String service;
  String description;
  String saloon;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    price: json["Price"],
    approved: json["Approved"],
    status: json["Status"],
    id: json["_id"],
    couponName: json["Coupon_name"],
    couponCode: json["Coupon_code"],
    category: json["Category"],
    minPrice: json["Min_Price"],
    percentage: json["Percentage"],
    startDate: DateTime.parse(json["Start_Date"]),
    endDate: DateTime.parse(json["End_Date"]),
    service: json["Service"],
    description: json["Description"],
    saloon: json["Saloon"],
    date: DateTime.parse(json["Date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "Price": price,
    "Approved": approved,
    "Status": status,
    "_id": id,
    "Coupon_name": couponName,
    "Coupon_code": couponCode,
    "Category": category,
    "Min_Price": minPrice,
    "Percentage": percentage,
    "Start_Date": "${startDate.year.toString().padLeft(4, '0')}-${startDate.month.toString().padLeft(2, '0')}-${startDate.day.toString().padLeft(2, '0')}",
    "End_Date": "${endDate.year.toString().padLeft(4, '0')}-${endDate.month.toString().padLeft(2, '0')}-${endDate.day.toString().padLeft(2, '0')}",
    "Service": service,
    "Description": description,
    "Saloon": saloon,
    "Date": date.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
  };
}
