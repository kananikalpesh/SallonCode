// To parse this JSON data, do
//
//     final adminGetCouponsRes = adminGetCouponsResFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

AdminGetCouponsRes adminGetCouponsResFromJson(String str) => AdminGetCouponsRes.fromJson(json.decode(str));

String adminGetCouponsResToJson(AdminGetCouponsRes data) => json.encode(data.toJson());

class AdminGetCouponsRes {
  AdminGetCouponsRes({
    required this.error,
    required this.data,
  });

  bool error;
  List<Datum> data;

  factory AdminGetCouponsRes.fromJson(Map<String, dynamic> json) => AdminGetCouponsRes(
    error: json["Error"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Error": error,
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.price,
    required this.approved,
    required this.status,
    required this.id,
    required this.couponName,
    required this.couponCode,
    required this.category,
    required this.minPrice,
    required this.percentage,
    required this.startDate,
    required this.endDate,
    required this.service,
    required this.description,
    required this.saloon,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  dynamic price;
  bool approved;
  String status;
  String id;
  String couponName;
  String couponCode;
  String category;
  dynamic minPrice;
  dynamic percentage;
  String startDate;
  String endDate;
  Service service;
  String description;
  Saloon saloon;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    price: json["Price"],
    approved: json["Approved"],
    status: json["Status"],
    id: json["_id"],
    couponName: json["Coupon_name"],
    couponCode: json["Coupon_code"],
    category: json["Category"],
    minPrice: json["Min_Price"],
    percentage: json["Percentage"],
    startDate: (json["Start_Date"]),
    endDate: (json["End_Date"]),
    service: Service.fromJson(json["Service"]),
    description: json["Description"],
    saloon: Saloon.fromJson(json["Saloon"]),
    date: DateTime.parse(json["Date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "Price": price,
    "Approved": approved,
    "Status": status,
    "_id": id,
    "Coupon_name": couponName,
    "Coupon_code": couponCode,
    "Category": category,
    "Min_Price": minPrice,
    "Percentage": percentage,
    "Start_Date": startDate,
    "End_Date": endDate,
    "Service": service.toJson(),
    "Description": description,
    "Saloon": saloon.toJson(),
    "Date": date.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
  };
}

class Saloon {
  Saloon({
    required this.address,
    required this.profilePic,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
  });

  Address address;
  String profilePic;
  List<String> photos;
  List<String> services;
  dynamic rating;
  dynamic reviews;
  dynamic bookingsLeft;
  dynamic bookingsUsed;
  bool status;
  bool approved;
  String id;
  String name;
  String email;
  String mobileNumber;
  String category;
  String password;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;
  String aboutUs;
  String description;
  String businessType;
  String closeTime;
  String openTime;

  factory Saloon.fromJson(Map<String, dynamic> json) => Saloon(
    address: Address.fromJson(json["Address"]),
    profilePic: json["Profile_Pic"],
    photos: List<String>.from(json["Photos"].map((x) => x)),
    services: List<String>.from(json["Services"].map((x) => x)),
    rating: json["Rating"],
    reviews: json["Reviews"],
    bookingsLeft: json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"],
    status: json["status"],
    approved: json["approved"],
    id: json["_id"],
    name: json["Name"],
    email: json["Email"],
    mobileNumber: json["Mobile_number"],
    category: json["Category"],
    password: json["Password"],
    registerDate: DateTime.parse(json["Register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    aboutUs: json["About_Us"],
    description: json["Description"],
    businessType: json["Business_Type"],
    closeTime: json["Close_Time"],
    openTime: json["Open_Time"],
  );

  Map<String, dynamic> toJson() => {
    "Address": address.toJson(),
    "Profile_Pic": profilePic,
    "Photos": List<dynamic>.from(photos.map((x) => x)),
    "Services": List<dynamic>.from(services.map((x) => x)),
    "Rating": rating,
    "Reviews": reviews,
    "Bookings_Left": bookingsLeft,
    "Bookings_Used": bookingsUsed,
    "status": status,
    "approved": approved,
    "_id": id,
    "Name": name,
    "Email": email,
    "Mobile_number": mobileNumber,
    "Category": category,
    "Password": password,
    "Register_date": registerDate.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
    "About_Us": aboutUs,
    "Description": description,
    "Business_Type": businessType,
    "Close_Time": closeTime,
    "Open_Time": openTime,
  };
}

class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });

  String type;
  List<double> coordinates;
  String address;
  String city;
  String state;

  factory Address.fromJson(Map<String, dynamic> json) => Address(
    type: json["type"],
    coordinates: List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"],
    city: json["City"],
    state: json["State"],
  );

  Map<String, dynamic> toJson() => {
    "type": type,
    "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
    "Address": address,
    "City": city,
    "State": state,
  };
}

class Service {
  Service({
    required this.prefix,
    required this.profilePic,
    required this.status,
    required this.id,
    required this.saloon,
    required this.name,
    required this.category,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  String prefix;
  String profilePic;
  bool status;
  String id;
  String saloon;
  String name;
  String category;
  String description;
  String timeRequired;
  dynamic price;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;

  factory Service.fromJson(Map<String, dynamic> json) => Service(
    prefix: json["Prefix"],
    profilePic: json["Profile_pic"],
    status: json["Status"],
    id: json["_id"],
    saloon: json["Saloon"],
    name: json["Name"],
    category: json["Category"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "Prefix": prefix,
    "Profile_pic": profilePic,
    "Status": status,
    "_id": id,
    "Saloon": saloon,
    "Name": name,
    "Category": category,
    "Description": description,
    "Time_required": timeRequired,
    "Price": price,
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
  };
}
