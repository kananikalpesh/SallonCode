// To parse this JSON data, do
//
//     final adminUpdateSaloonRes = adminUpdateSaloonResFromJson(jsondynamic);

import 'package:meta/meta.dart';
import 'dart:convert';

AdminUpdateSaloonRes adminUpdateSaloonResFromJson(dynamic str) => AdminUpdateSaloonRes.fromJson(json.decode(str));


class AdminUpdateSaloonRes {
  AdminUpdateSaloonRes({
    required this.error,
    required this.msg,
    required this.data,
  });

  bool error;
  dynamic msg;
  Data data;

  factory AdminUpdateSaloonRes.fromJson(Map<dynamic, dynamic> json) => AdminUpdateSaloonRes(
    error: json["Error"],
    msg: json["Msg"],
    data: Data.fromJson(json["data"]),
  );

}

class Data {
  Data({
    required this.address,
    required this.profilePic,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
  });

  Address address;
  dynamic profilePic;
  List<dynamic> photos;
  List<Service> services;
  int rating;
  int reviews;
  int bookingsLeft;
  int bookingsUsed;
  bool status;
  bool approved;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic mobileNumber;
  dynamic category;
  dynamic password;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic aboutUs;
  dynamic description;
  dynamic businessType;
  dynamic closeTime;
  dynamic openTime;

  factory Data.fromJson(Map<dynamic, dynamic> json) => Data(
    address: Address.fromJson(json["Address"]),
    profilePic: json["Profile_Pic"],
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    services: List<Service>.from(json["Services"].map((x) => Service.fromJson(x))),
    rating: json["Rating"],
    reviews: json["Reviews"],
    bookingsLeft: json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"],
    status: json["status"],
    approved: json["approved"],
    id: json["_id"],
    name: json["Name"],
    email: json["Email"],
    mobileNumber: json["Mobile_number"],
    category: json["Category"],
    password: json["Password"],
    registerDate: DateTime.parse(json["Register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    aboutUs: json["About_Us"],
    description: json["Description"],
    businessType: json["Business_Type"],
    closeTime: json["Close_Time"],
    openTime: json["Open_Time"],
  );

}

class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });

  dynamic type;
  List<double> coordinates;
  dynamic address;
  dynamic city;
  dynamic state;

  factory Address.fromJson(Map<dynamic, dynamic> json) => Address(
    type: json["type"],
    coordinates: List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"],
    city: json["City"],
    state: json["State"],
  );

  Map<dynamic, dynamic> toJson() => {
    "type": type,
    "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
    "Address": address,
    "City": city,
    "State": state,
  };
}

class Service {
  Service({
    required this.prefix,
    required this.profilePic,
    required this.status,
    required this.id,
    required this.saloon,
    required this.name,
    required this.category,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  dynamic prefix;
  dynamic profilePic;
  bool status;
  dynamic id;
  dynamic saloon;
  dynamic name;
  dynamic category;
  dynamic description;
  dynamic timeRequired;
  int price;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Service.fromJson(Map<dynamic, dynamic> json) => Service(
    prefix: json["Prefix"],
    profilePic: json["Profile_pic"],
    status: json["Status"],
    id: json["_id"],
    saloon: json["Saloon"],
    name: json["Name"],
    category: json["Category"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );
}
