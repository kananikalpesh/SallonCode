// To parse this JSON data, do
//
//     final myAppointment = myAppointmentFromJson(jsondynamic);

import 'package:meta/meta.dart';
import 'dart:convert';

import 'package:saloon_app/app/data/model/customer/core_entity/time_slot.dart';

MyAppointment myAppointmentFromJson(dynamic str) => MyAppointment.fromJson(json.decode(str));

class MyAppointment {
  MyAppointment({
    required this.error,
    required this.data,
  });

  bool error;
  List<Datum> data;

  factory MyAppointment.fromJson(Map<dynamic, dynamic> json) => MyAppointment(
    error: json["Error"],
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );
}

class Datum {
  Datum({
    required this.status,
    required this.payment,
    required this.paymentType,
    required this.id,
    required this.saloon,
    required this.services,
    required this.products,
    required this.staff,
    required this.appointmentDate,
    required this.timeSlot,
    required this.totalPrice,
    required this.appointmentId,
    required this.user,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  dynamic status;
  dynamic payment;
  dynamic paymentType;
  dynamic id;
  Saloon? saloon;
  Services? services;
  List<ProductElement>? products;
  Staff? staff;
  dynamic appointmentDate;
  dynamic timeSlot;
  dynamic totalPrice;
  dynamic appointmentId;
  dynamic user;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Datum.fromJson(Map<dynamic, dynamic> json) => Datum(
    status: json["Status"],
    payment: json["Payment"],
    paymentType: json["Payment_Type"],
    id: json["_id"],
    saloon:json["Saloon"]==null?null: Saloon?.fromJson(json["Saloon"]),
    services:json["Services"]==null?null: Services?.fromJson(json["Services"]),
    products:json["Products"]==null?null: List<ProductElement>.from(json["Products"].map((x) => ProductElement?.fromJson(x))),
    staff:json["Staff"]==null?null: Staff?.fromJson(json["Staff"]),
    appointmentDate: json["Appointment_Date"]==null?null:DateTime.parse(json["Appointment_Date"]),
    timeSlot: json["Time_Slot"],
    totalPrice: json["Total_Price"],
    appointmentId: json["Appointment_Id"],
    user: json["User"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );
}

class ProductElement {
  ProductElement({
    required this.id,
    required this.product,
    required this.quantity,
  });

  dynamic id;
  ProductProduct? product;
  int quantity;

  factory ProductElement.fromJson(Map<dynamic, dynamic> json) => ProductElement(
    id: json["_id"],
    product:json["Product"]==null?null: ProductProduct.fromJson(json["Product"]),
    quantity: json["Quantity"],
  );

}

class ProductProduct {
  ProductProduct({
    required this.photos,
    required this.colors,
    required this.quantity,
    required this.quantitySold,
    required this.rating,
    required this.reviews,
    required this.approved,
    required this.deleted,
    required this.available,
    required this.id,
    required this.saloon,
    required this.name,
    required this.category,
    required this.description,
    required this.brandName,
    required this.price,
    required this.profilePic,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  List<dynamic> photos;
  List<dynamic> colors;
  dynamic quantity;
  dynamic quantitySold;
  dynamic rating;
  dynamic reviews;
  bool approved;
  bool deleted;
  bool available;
  dynamic id;
  dynamic saloon;
  dynamic name;
  dynamic category;
  dynamic description;
  dynamic brandName;
  dynamic price;
  dynamic profilePic;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory ProductProduct.fromJson(Map<dynamic, dynamic> json) => ProductProduct(
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    colors: List<dynamic>.from(json["Colors"].map((x) => x)),
    quantity: json["Quantity"],
    quantitySold: json["Quantity_Sold"],
    rating: json["Rating"],
    reviews: json["Reviews"],
    approved: json["Approved"],
    deleted: json["Deleted"],
    available: json["Available"],
    id: json["_id"],
    saloon: json["Saloon"],
    name: json["Name"],
    category: json["Category"],
    description: json["Description"],
    brandName: json["BrandName"],
    price: json["Price"],
    profilePic: json["Profile_Pic"],
    date: DateTime.parse(json["date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}

class Saloon {
  Saloon({
    required this.address,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.profilePic,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
  });

  Address address;
  List<dynamic> photos;
  List<dynamic> services;
  dynamic rating;
  dynamic reviews;
  dynamic bookingsLeft;
  dynamic bookingsUsed;
  bool status;
  bool approved;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic mobileNumber;
  dynamic category;
  dynamic password;
  dynamic profilePic;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic aboutUs;
  dynamic description;
  dynamic businessType;
  dynamic closeTime;
  dynamic openTime;

  factory Saloon.fromJson(Map<dynamic, dynamic> json) => Saloon(
    address: Address.fromJson(json["Address"]),
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    services: List<dynamic>.from(json["Services"].map((x) => x)),
    rating: json["Rating"],
    reviews: json["Reviews"],
    bookingsLeft: json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"],
    status: json["status"],
    approved: json["approved"],
    id: json["_id"],
    name: json["Name"],
    email: json["Email"],
    mobileNumber: json["Mobile_number"],
    category: json["Category"],
    password: json["Password"],
    profilePic: json["Profile_Pic"],
    registerDate: DateTime.parse(json["Register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    aboutUs: json["About_Us"],
    description: json["Description"],
    businessType: json["Business_Type"],
    closeTime: json["Close_Time"],
    openTime: json["Open_Time"],
  );

}

class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });

  dynamic type;
  List<double> coordinates;
  dynamic address;
  dynamic city;
  dynamic state;

  factory Address.fromJson(Map<dynamic, dynamic> json) => Address(
    type: json["type"],
    coordinates: List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"],
    city: json["City"],
    state: json["State"],
  );

  Map<dynamic, dynamic> toJson() => {
    "type": type,
    "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
    "Address": address,
    "City": city,
    "State": state,
  };
}

class Services {
  Services({
    required this.prefix,
    required this.status,
    required this.id,
    required this.name,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.profilePic,
  });

  dynamic prefix;
  bool status;
  dynamic id;
  dynamic name;
  dynamic description;
  dynamic timeRequired;
  dynamic price;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic profilePic;

  factory Services.fromJson(Map<dynamic, dynamic> json) => Services(
    prefix: json["Prefix"],
    status: json["Status"],
    id: json["_id"],
    name: json["Name"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    profilePic: json["Profile_pic"],
  );
}

class Staff {
  Staff({
    required this.photos,
    required this.rating,
    required this.services,
    required this.deleted,
    required this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.age,
    required this.gender,
    required this.designation,
    required this.saloon,
    required this.timeSlots,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.staffPic,
  });

  List<dynamic> photos;
  int rating;
  List<dynamic> services;
  bool deleted;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic password;
  dynamic age;
  dynamic gender;
  dynamic designation;
  dynamic saloon;
  List<TimeSlot> timeSlots;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic staffPic;

  factory Staff.fromJson(Map<dynamic, dynamic> json) => Staff(
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    rating: json["Rating"],
    services: List<dynamic>.from(json["Services"].map((x) => x)),
    deleted: json["Deleted"],
    id: json["_id"],
    name: json["Name"],
    email: json["Email"],
    password: json["Password"],
    age: json["Age"],
    gender: json["Gender"],
    designation: json["Designation"],
    saloon: json["Saloon"],
    timeSlots: List<TimeSlot>.from(json["Time_Slots"].map((x) => TimeSlot.fromJson(x))),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    staffPic: json["Staff_pic"],
  );
}

