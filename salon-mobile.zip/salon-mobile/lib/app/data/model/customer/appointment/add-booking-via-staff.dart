// To parse this JSON data, do
//
//     final addBookingViaStaff = addBookingViaStaffFromJson(jsondynamic);

import 'package:meta/meta.dart';
import 'dart:convert';

AddBookingViaStaff addBookingViaStaffFromJson(dynamic str) => AddBookingViaStaff.fromJson(json.decode(str));


class AddBookingViaStaff {
  AddBookingViaStaff({
    required this.msg,
    required this.success,
    required this.book,
    required this.error,
  });

  dynamic msg;
  bool success;
  Book book;
  bool error;

  factory AddBookingViaStaff.fromJson(Map<dynamic, dynamic> json) => AddBookingViaStaff(
    msg: json["msg"],
    success: json["success"],
    book: Book.fromJson(json["book"]),
    error: json["Error"],
  );

}

class Book {
  Book({
    required this.status,
    required this.payment,
    required this.paymentType,
    required this.id,
    required this.saloon,
    required this.services,
    required this.products,
    required this.staff,
    required this.appointmentDate,
    required this.timeSlot,
    required this.totalPrice,
    required this.appointmentId,
    required this.user,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  dynamic status;
  dynamic payment;
  dynamic paymentType;
  dynamic id;
  dynamic saloon;
  dynamic services;
  List<Product> products;
  dynamic staff;
  dynamic appointmentDate;
  dynamic timeSlot;
  int totalPrice;
  dynamic appointmentId;
  dynamic user;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Book.fromJson(Map<dynamic, dynamic> json) => Book(
    status: json["Status"],
    payment: json["Payment"],
    paymentType: json["Payment_Type"],
    id: json["_id"],
    saloon: json["Saloon"],
    services: json["Services"],
    products: List<Product>.from(json["Products"].map((x) => Product.fromJson(x))),
    staff: json["Staff"],
    appointmentDate: DateTime.parse(json["Appointment_Date"]),
    timeSlot: json["Time_Slot"],
    totalPrice: json["Total_Price"],
    appointmentId: json["Appointment_Id"],
    user: json["User"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}

class Product {
  Product({
    required this.id,
    required this.product,
    required this.quantity,
  });

  dynamic id;
  dynamic product;
  int quantity;

  factory Product.fromJson(Map<dynamic, dynamic> json) => Product(
    id: json["_id"],
    product: json["Product"],
    quantity: json["Quantity"],
  );

  Map<dynamic, dynamic> toJson() => {
    "_id": id,
    "Product": product,
    "Quantity": quantity,
  };
}
