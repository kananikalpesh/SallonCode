// To parse this JSON data, do
//
//     final saloonDetailsModel = saloonDetailsModelFromJson(jsondynamic);

import 'package:get/get.dart';
import 'package:meta/meta.dart';
import 'dart:convert';

import 'core_entity/designation_model.dart';
import 'core_entity/time_slot.dart';

SaloonDetailsModel saloonDetailsModelFromJson(dynamic str) => SaloonDetailsModel.fromJson(json.decode(str));


class SaloonDetailsModel {
  SaloonDetailsModel({
    required this.error,
    required this.products,
    required this.saloon,
    required this.services,
    required this.staff,
    required this.reviews,
    required this.coupons,
  });

  bool error;
  List<Product>? products;
  Saloon? saloon;
  List<SaloonDetailsModelService>? services;
  List<Staff>? staff;
  List<Review>? reviews;
  List<Coupon>? coupons;

  factory SaloonDetailsModel.fromJson(Map<dynamic, dynamic> json) => SaloonDetailsModel(
    error: json["Error"],
    products:json["Products"]==null?null:List<Product>.from(json["Products"].map((x) => Product.fromJson(x))),
    saloon: json["Saloon"]==null?null:Saloon.fromJson(json["Saloon"]),
    services: json["Services"]==null?null:List<SaloonDetailsModelService>.from(json["Services"].map((x) => SaloonDetailsModelService.fromJson(x))),
    staff: json["Staff"]==null?null:List<Staff>.from(json["Staff"].map((x) => Staff.fromJson(x))),
    reviews: json["Reviews"]==null?null:List<Review>.from(json["Reviews"].map((x) => Review.fromJson(x))),
    coupons: json["Coupons"]==null?null:List<Coupon>.from(json["Coupons"].map((x) => Coupon.fromJson(x))),
  );

}

class Coupon {
  Coupon({
    required this.price,
    required this.approved,
    required this.status,
    required this.id,
    required this.couponName,
    required this.startDate,
    required this.service,
    required this.endDate,
    required this.minPrice,
    required this.percentage,
    required this.couponCode,
    required this.description,
    required this.saloon,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.category,
  });

  dynamic price;
  bool approved;
  dynamic status;
  dynamic id;
  dynamic couponName;
  dynamic startDate;
  Service service;
  dynamic endDate;
  dynamic minPrice;
  dynamic percentage;
  dynamic couponCode;
  dynamic description;
  dynamic saloon;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic category;

  factory Coupon.fromJson(Map<dynamic, dynamic> json) => Coupon(
    price: json["Price"],
    approved: json["Approved"],
    status: json["Status"],
    id: json["_id"],
    couponName: json["Coupon_name"],
    startDate: json["Start_Date"],
    service: Service.fromJson(json["Service"]),
    endDate: json["End_Date"],
    minPrice: json["Min_Price"] == null ? null : json["Min_Price"],
    percentage: json["Percentage"],
    couponCode: json["Coupon_code"] == null ? null : json["Coupon_code"],
    description: json["Description"],
    saloon: json["Saloon"],
    date: DateTime.parse(json["Date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    category: json["Category"] == null ? null : json["Category"],
  );

}

class Service {
  Service({
    required this.prefix,
    required this.profilePic,
    required this.status,
    required this.id,
    required this.saloon,
    required this.name,
    required this.category,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  dynamic prefix;
  dynamic profilePic;
  bool status;
  dynamic id;
  dynamic saloon;
  dynamic name;
  dynamic category;
  dynamic description;
  dynamic timeRequired;
  dynamic price;
  DateTime createdAt;
  DateTime updatedAt;
  RxBool isChecked = false.obs;
  int v;

  factory Service.fromJson(Map<dynamic, dynamic> json) => Service(
    prefix: json["Prefix"],
    profilePic: json["Profile_pic"],
    status: json["Status"],
    id: json["_id"],
    saloon: json["Saloon"],
    name: json["Name"],
    category: json["Category"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}

class Product {
  Product({
    required this.products,
    required this.category,
  });

  List<ProductElement> products;
  Category category;

  factory Product.fromJson(Map<dynamic, dynamic> json) => Product(
    products: List<ProductElement>.from(json["products"].map((x) => ProductElement.fromJson(x))),
    category: Category.fromJson(json["Category"]),
  );

}

class Category {
  Category({
    required this.status,
    required this.id,
    required this.title,
    required this.description,
    required this.backgroundPic,
    required this.icon,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  bool status;
  dynamic id;
  dynamic title;
  dynamic description;
  dynamic backgroundPic;
  dynamic icon;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Category.fromJson(Map<dynamic, dynamic> json) => Category(
    status: json["status"],
    id: json["_id"],
    title: json["title"],
    description: json["description"],
    backgroundPic: json["Background_Pic"],
    icon: json["Icon"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}

class ProductElement {
  ProductElement({
    required this.photos,
    required this.colors,
    required this.quantity,
    required this.quantitySold,
    required this.rating,
    required this.reviews,
    required this.approved,
    required this.deleted,
    required this.available,
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.saloon,
    required this.price,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.profilePic,
    required this.brandName,
  });

  List<dynamic> photos;
  List<dynamic> colors;
  dynamic quantity;
  dynamic quantitySold;
  dynamic rating;
  dynamic reviews;
  bool approved;
  bool deleted;
  bool available;
  dynamic id;
  dynamic name;
  dynamic description;
  dynamic category;
  dynamic saloon;
  dynamic price;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic profilePic;
  dynamic brandName;
  RxBool isChecked = false.obs;

  factory ProductElement.fromJson(Map<dynamic, dynamic> json) => ProductElement(
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    colors: List<dynamic>.from(json["Colors"].map((x) => x)),
    quantity: json["Quantity"],
    quantitySold: json["Quantity_Sold"],
    rating: json["Rating"],
    reviews: json["Reviews"],
    approved: json["Approved"],
    deleted: json["Deleted"],
    available: json["Available"],
    id: json["_id"],
    name: json["Name"],
    description: json["Description"],
    category: json["Category"],
    saloon: json["Saloon"],
    price: json["Price"],
    date: DateTime.parse(json["date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    profilePic: json["Profile_Pic"],
    brandName: json["BrandName"] == null ? null : json["BrandName"],
  );

}

class Review {
  Review({
    required this.approved,
    required this.id,
    required this.saloon,
    required this.rating,
    required this.user,
    required this.description,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  bool approved;
  dynamic id;
  dynamic saloon;
  dynamic rating;
  User user;
  dynamic description;
  DateTime date;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Review.fromJson(Map<dynamic, dynamic> json) => Review(
    approved: json["approved"],
    id: json["_id"],
    saloon: json["Saloon"],
    rating: json["Rating"],
    user: User.fromJson(json["User"]),
    description: json["Description"],
    date: DateTime.parse(json["date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}

class User {
  User({
    required this.rating,
    required this.role,
    required this.favouriteProducts,
    required this.favouriteSaloons,
    required this.status,
    required this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.mobileNumber,
    required this.dob,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.otp,
    required this.profilePic,
  });

  dynamic rating;
  dynamic role;
  List<dynamic> favouriteProducts;
  List<dynamic> favouriteSaloons;
  bool status;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic password;
  dynamic mobileNumber;
  dynamic dob;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  int otp;
  dynamic profilePic;

  factory User.fromJson(Map<dynamic, dynamic> json) => User(
    rating: json["Rating"],
    role: json["role"],
    favouriteProducts: List<dynamic>.from(json["FavouriteProducts"].map((x) => x)),
    favouriteSaloons: List<dynamic>.from(json["FavouriteSaloons"].map((x) => x)),
    status: json["status"],
    id: json["_id"],
    name: json["name"],
    email: json["email"],
    password: json["password"],
    mobileNumber: json["mobile_number"],
    dob: json["DOB"],
    registerDate: DateTime.parse(json["register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    otp: json["otp"],
    profilePic: json["Profile_Pic"],
  );

}

class Saloon {
  Saloon({
    required this.address,
    required this.profilePic,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
  });

  Address? address;
  dynamic profilePic;
  List<dynamic> photos;
  List<Service> services;
  dynamic rating;
  dynamic reviews;
  dynamic bookingsLeft;
  dynamic bookingsUsed;
  bool status;
  bool approved;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic mobileNumber;
  dynamic category;
  dynamic password;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic aboutUs;
  dynamic description;
  dynamic businessType;
  dynamic closeTime;
  dynamic openTime;

  factory Saloon.fromJson(Map<dynamic, dynamic> json) => Saloon(
    address: json["Address"]==null?null:Address.fromJson(json["Address"]),
    profilePic: json["Profile_Pic"],
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    services: List<Service>.from(json["Services"].map((x) => Service.fromJson(x))),
    rating: json["Rating"],
    reviews: json["Reviews"],
    bookingsLeft: json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"],
    status: json["status"],
    approved: json["approved"],
    id: json["_id"],
    name: json["Name"],
    email: json["Email"],
    mobileNumber: json["Mobile_number"],
    category: json["Category"],
    password: json["Password"],
    registerDate: DateTime.parse(json["Register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    aboutUs: json["About_Us"],
    description: json["Description"],
    businessType: json["Business_Type"],
    closeTime: json["Close_Time"],
    openTime: json["Open_Time"],
  );

}

class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });

  dynamic type;
  List<double> coordinates;
  dynamic address;
  dynamic city;
  dynamic state;

  factory Address.fromJson(Map<dynamic, dynamic> json) => Address(
    type: json["type"],
    coordinates: List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"],
    city: json["City"],
    state: json["State"],
  );

  Map<dynamic, dynamic> toJson() => {
    "type": type,
    "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
    "Address": address,
    "City": city,
    "State": state,
  };
}

class SaloonDetailsModelService {
  SaloonDetailsModelService({
    required this.services,
    required this.category,
  });

  List<Service> services;
  Category category;

  factory SaloonDetailsModelService.fromJson(Map<dynamic, dynamic> json) => SaloonDetailsModelService(
    services: List<Service>.from(json["services"].map((x) => Service.fromJson(x))),
    category: Category.fromJson(json["Category"]),
  );

}

class Staff {
  Staff({
    required this.photos,
    required this.rating,
    required this.services,
    required this.deleted,
    required this.id,
    required this.timeSlots,
    required this.name,
    required this.email,
    required this.password,
    required this.age,
    required this.gender,
    required this.designation,
    required this.saloon,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.staffPic,
  });

  List<dynamic> photos;
  dynamic rating;
  List<Service> services;
  bool deleted;
  dynamic id;
  List<TimeSlot> timeSlots;
  dynamic name;
  dynamic email;
  dynamic password;
  dynamic age;
  dynamic gender;
  Designation? designation;
  dynamic saloon;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;
  dynamic staffPic;

  factory Staff.fromJson(Map<dynamic, dynamic> json) => Staff(
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    rating: json["Rating"],
    services: List<Service>.from(json["Services"].map((x) => Service.fromJson(x))),
    deleted: json["Deleted"],
    id: json["_id"],
    timeSlots: List<TimeSlot>.from(json["Time_Slots"].map((x) => TimeSlot.fromJson(x))),
    name: json["Name"],
    email: json["Email"],
    password: json["Password"],
    age: json["Age"],
    gender: json["Gender"],
    designation: json["Designation"] == null ? null : Designation?.fromJson(json["Designation"]),
    saloon: json["Saloon"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    staffPic: json["Staff_pic"] == null ? null : json["Staff_pic"],
  );
}

