// To parse this JSON data, do
//
//     final errorResponse = errorResponseFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

ErrorResponse errorResponseFromJson(String str) => ErrorResponse.fromJson(json.decode(str));

String errorResponseToJson(ErrorResponse data) => json.encode(data.toJson());

class ErrorResponse {
  ErrorResponse({
    required this.error,
    required this.msg,
  });

  bool error;
  dynamic msg;

  factory ErrorResponse.fromJson(Map<String, dynamic> json) => ErrorResponse(
    error: json["Error"],
    msg: json["msg"],
  );

  Map<String, dynamic> toJson() => {
    "Error": error,
    "msg": msg,
  };
}
