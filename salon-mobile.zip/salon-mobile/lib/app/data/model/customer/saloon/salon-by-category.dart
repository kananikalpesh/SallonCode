// To parse this JSON data, do
//
//     final saloonsByCategory = saloonsByCategoryFromJson(jsondynamic);

import 'package:meta/meta.dart';
import 'dart:convert';

SaloonsByCategory saloonsByCategoryFromJson(dynamic str) => SaloonsByCategory.fromJson(json.decode(str));


class SaloonsByCategory {
  SaloonsByCategory({
    required this.error,
    required this.data,
  });

  bool error;
  List<Datum> data;

  factory SaloonsByCategory.fromJson(Map<dynamic, dynamic> json) => SaloonsByCategory(
    error: json["Error"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

}

class Datum {
  Datum({
    required this.address,
    required this.profilePic,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
    required this.companyRegistrationNumber,
    required this.otp,
  });

  Address address;
  dynamic profilePic;
  List<dynamic> photos;
  List<dynamic> services;
  dynamic rating;
  dynamic reviews;
  dynamic bookingsLeft;
  dynamic bookingsUsed;
  bool status;
  bool approved;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic mobileNumber;
  Category category;
  dynamic password;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;
  dynamic aboutUs;
  dynamic description;
  dynamic businessType;
  dynamic closeTime;
  dynamic openTime;
  dynamic companyRegistrationNumber;
  dynamic otp;

  factory Datum.fromJson(Map<dynamic, dynamic> json) => Datum(
    address: Address.fromJson(json["Address"]),
    profilePic: json["Profile_Pic"],
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    services: List<dynamic>.from(json["Services"].map((x) => x)),
    rating: json["Rating"],
    reviews: json["Reviews"],
    bookingsLeft: json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"],
    status: json["status"],
    approved: json["approved"],
    id: json["_id"],
    name: json["Name"],
    email: json["Email"],
    mobileNumber: json["Mobile_number"],
    category: Category.fromJson(json["Category"]),
    password: json["Password"],
    registerDate: DateTime.parse(json["Register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    aboutUs: json["About_Us"] == null ? null : json["About_Us"],
    description: json["Description"] == null ? null : json["Description"],
    businessType: json["Business_Type"],
    closeTime: json["Close_Time"],
    openTime: json["Open_Time"],
    companyRegistrationNumber: json["Company_Registration_Number"] == null ? null : json["Company_Registration_Number"],
    otp: json["otp"] == null ? null : json["otp"],
  );

}

class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });

  dynamic type;
  List<double> coordinates;
  dynamic address;
  dynamic city;
  dynamic state;

  factory Address.fromJson(Map<dynamic, dynamic> json) => Address(
    type: json["type"],
    coordinates: List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"],
    city: json["City"],
    state: json["State"],
  );

  Map<dynamic, dynamic> toJson() => {
    "type": type,
    "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
    "Address": address,
    "City": city,
    "State": state,
  };
}

class Category {
  Category({
    required this.status,
    required this.id,
    required this.title,
    required this.description,
    required this.backgroundPic,
    required this.icon,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  bool status;
  dynamic id;
  dynamic title;
  dynamic description;
  dynamic backgroundPic;
  dynamic icon;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;

  factory Category.fromJson(Map<dynamic, dynamic> json) => Category(
    status: json["status"],
    id: json["_id"],
    title: json["title"],
    description: json["description"],
    backgroundPic: json["Background_Pic"],
    icon: json["Icon"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}
