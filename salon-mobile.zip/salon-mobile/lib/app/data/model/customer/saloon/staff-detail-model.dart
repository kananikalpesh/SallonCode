// To parse this JSON data, do
//
//     final staffDetailModel = staffDetailModelFromJson(jsondynamic);
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:meta/meta.dart';
import 'dart:convert';
StaffDetailModel staffDetailModelFromJson(dynamic str) => StaffDetailModel.fromJson(json.decode(str));

class StaffDetailModel {
  StaffDetailModel({
    required this.error,
    required this.data,
  });
  bool error;
  Data data;
  factory StaffDetailModel.fromJson(Map<dynamic, dynamic> json) => StaffDetailModel(
    error: json["Error"],
    data: Data.fromJson(json["Data"]),
  );
}
class Data {
  Data({
    required this.photos,
    required this.rating,
    required this.services,
    required this.deleted,
    required this.id,
    required this.timeSlots,
    required this.name,
    required this.email,
    required this.password,
    required this.age,
    required this.gender,
    required this.designation,
    required this.saloon,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.slots,
  });
  List<dynamic>? photos;
  int rating;
  List<Service> services;
  bool deleted;
  dynamic id;
  List<TimeSlot> timeSlots;
  dynamic name;
  dynamic email;
  dynamic password;
  dynamic age;
  dynamic gender;
  Designation designation;
  Saloon saloon;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  List<Slot> slots;
  factory Data.fromJson(Map<dynamic, dynamic> json) => Data(
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    rating: json["Rating"],
    services: List<Service>.from(json["Services"].map((x) => Service.fromJson(x))),
    deleted: json["Deleted"],
    id: json["_id"],
    timeSlots: List<TimeSlot>.from(json["Time_Slots"].map((x) => TimeSlot.fromJson(x))),
    name: json["Name"],
    email: json["Email"],
    password: json["Password"],
    age: json["Age"],
    gender: json["Gender"],
    designation: Designation.fromJson(json["Designation"]),
    saloon: Saloon.fromJson(json["Saloon"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    slots: List<Slot>.from(json["Slots"].map((x) => Slot.fromJson(x))),
  );
}
class BookedSlot {
  BookedSlot({
    required this.timeSlot,
  });
  dynamic timeSlot;
  factory BookedSlot.fromJson(Map<dynamic, dynamic> json) => BookedSlot(
    timeSlot: json["Time_Slot"],
  );
  Map<dynamic, dynamic> toJson() => {
    "Time_Slot": timeSlot,
  };
}
class Designation {
  Designation({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });
  dynamic id;
  dynamic title;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  factory Designation.fromJson(Map<dynamic, dynamic> json) => Designation(
    id: json["_id"],
    title: json["title"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );
}
class Saloon {
  Saloon({
    required this.address,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.profilePic,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
  });
  Address address;
  List<dynamic> photos;
  List<dynamic> services;
  int rating;
  int reviews;
  int bookingsLeft;
  int bookingsUsed;
  bool status;
  bool approved;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic mobileNumber;
  dynamic category;
  dynamic password;
  dynamic profilePic;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic aboutUs;
  dynamic description;
  dynamic businessType;
  dynamic closeTime;
  dynamic openTime;
  factory Saloon.fromJson(Map<dynamic, dynamic> json) => Saloon(
    address: Address.fromJson(json["Address"]),
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    services: List<dynamic>.from(json["Services"].map((x) => x)),
    rating: json["Rating"],
    reviews: json["Reviews"],
    bookingsLeft: json["Bookings_Left"],
    bookingsUsed: json["Bookings_Used"],
    status: json["status"],
    approved: json["approved"],
    id: json["_id"],
    name: json["Name"],
    email: json["Email"],
    mobileNumber: json["Mobile_number"],
    category: json["Category"],
    password: json["Password"],
    profilePic: json["Profile_Pic"],
    registerDate: DateTime.parse(json["Register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    aboutUs: json["About_Us"],
    description: json["Description"],
    businessType: json["Business_Type"],
    closeTime: json["Close_Time"],
    openTime: json["Open_Time"],
  );
}
class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });
  dynamic type;
  List<double> coordinates;
  dynamic address;
  dynamic city;
  dynamic state;
  factory Address.fromJson(Map<dynamic, dynamic> json) => Address(
    type: json["type"],
    coordinates: List<double>.from(json["coordinates"].map((x) => x.toDouble())),
    address: json["Address"],
    city: json["City"],
    state: json["State"],
  );
  Map<dynamic, dynamic> toJson() => {
    "type": type,
    "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
    "Address": address,
    "City": city,
    "State": state,
  };
}
class Service {
  Service({
    required this.prefix,
    required this.status,
    required this.id,
    required this.name,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.packageImage,
  });
  dynamic prefix;
  bool status;
  dynamic id;
  dynamic name;
  dynamic description;
  dynamic timeRequired;
  int price;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  dynamic packageImage;
  RxBool isChecked = false.obs;
  factory Service.fromJson(Map<dynamic, dynamic> json) => Service(
    prefix: json["Prefix"],
    status: json["Status"],
    id: json["_id"],
    name: json["Name"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    packageImage: json["package_image"],
  );
}
class Slot {
  Slot({
    required this.timeSlotStart,
    required this.timeSlotEnd,
    required this.IsBooked,
  });
  dynamic timeSlotStart;
  dynamic timeSlotEnd;
  dynamic IsBooked;
  RxBool isSelected=false.obs;


  factory Slot.fromJson(Map<dynamic, dynamic> json) => Slot(
    timeSlotStart: json["timeSlotStart"],
    timeSlotEnd: json["timeSlotEnd"],
    IsBooked: json["IsBooked"],
  );
  Map<dynamic, dynamic> toJson() => {
    "timeSlotStart": timeSlotStart,
    "timeSlotEnd": timeSlotEnd,
    "IsBooked": IsBooked,
  };
}
class TimeSlot {
  TimeSlot({
    required this.day,
    required this.startTime,
    required this.endTime,
    required this.slotTime,
    required this.slotInterval,
  });
  dynamic day;
  dynamic startTime;
  dynamic endTime;
  dynamic slotTime;
  dynamic slotInterval;
  factory TimeSlot.fromJson(Map<dynamic, dynamic> json) => TimeSlot(
    day: json["day"],
    startTime: json["start_time"],
    endTime: json["end_time"],
    slotTime: json["slot_time"],
    slotInterval: json["slot_interval"],
  );
  Map<dynamic, dynamic> toJson() => {
    "day": day,
    "start_time": startTime,
    "end_time": endTime,
    "slot_time": slotTime,
    "slot_interval": slotInterval,
  };
}