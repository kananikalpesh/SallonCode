
class User {
  User({
    required this.rating,
    required this.role,
    required this.favouriteProducts,
    required this.favouriteSaloons,
    required this.status,
    required this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.mobileNumber,
    required this.dob,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.otp,
    required this.profilePic,
  });

  int rating;
  dynamic role;
  List<dynamic> favouriteProducts;
  List<dynamic> favouriteSaloons;
  bool status;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic password;
  dynamic mobileNumber;
  dynamic dob;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  int otp;
  dynamic profilePic;

  factory User.fromJson(Map<dynamic, dynamic> json) => User(
    rating: json["Rating"],
    role: json["role"],
    favouriteProducts: List<dynamic>.from(json["FavouriteProducts"].map((x) => x)),
    favouriteSaloons: List<dynamic>.from(json["FavouriteSaloons"].map((x) => x)),
    status: json["status"],
    id: json["_id"],
    name: json["name"],
    email: json["email"],
    password: json["password"],
    mobileNumber: json["mobile_number"],
    dob: json["DOB"],
    registerDate: DateTime.parse(json["register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    otp: json["otp"],
    profilePic: json["Profile_Pic"],
  );

  Map<dynamic, dynamic> toJson() => {
    "Rating": rating,
    "role": role,
    "FavouriteProducts": List<dynamic>.from(favouriteProducts.map((x) => x)),
    "FavouriteSaloons": List<dynamic>.from(favouriteSaloons.map((x) => x)),
    "status": status,
    "_id": id,
    "name": name,
    "email": email,
    "password": password,
    "mobile_number": mobileNumber,
    "DOB": dob,
    "register_date": registerDate,
    "createdAt": createdAt,
    "updatedAt": updatedAt,
    "__v": v,
    "otp": otp,
    "Profile_Pic": profilePic,
  };
}