
import 'package:saloon_app/app/data/model/customer/core_entity/service_model.dart';
import 'package:saloon_app/app/data/model/customer/core_entity/time_slot.dart';

import '../get-saloon-details-model.dart';
import 'designation_model.dart';

class Staff {
  Staff({
    required this.photos,
    required this.rating,
    required this.services,
    required this.deleted,
    required this.id,
    required this.timeSlots,
    required this.name,
    required this.email,
    required this.password,
    required this.age,
    required this.gender,
    required this.designation,
    required this.saloon,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  List<dynamic> photos;
  int rating;
  List<SaloonService> services;
  bool deleted;
  dynamic id;
  List<TimeSlot> timeSlots;
  dynamic name;
  dynamic email;
  dynamic password;
  dynamic age;
  dynamic gender;
  Designation? designation;
  dynamic saloon;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Staff.fromJson(Map<dynamic, dynamic> json) => Staff(
    photos: List<dynamic>.from(json["Photos"].map((x) => x)),
    rating: json["Rating"],
    services: List<SaloonService>.from(json["Services"].map((x) => SaloonService.fromJson(x))),
    deleted: json["Deleted"],
    id: json["_id"],
    timeSlots: List<TimeSlot>.from(json["Time_Slots"].map((x) => TimeSlot.fromJson(x))),
    name: json["Name"],
    email: json["Email"],
    password: json["Password"],
    age: json["Age"],
    gender: json["Gender"],
    designation: json["Designation"] == null ? null : Designation.fromJson(json["Designation"]),
    saloon: json["Saloon"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}
