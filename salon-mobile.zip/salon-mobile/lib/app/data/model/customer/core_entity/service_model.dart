class SaloonService {
  SaloonService({
    required this.prefix,
    required this.status,
    required this.id,
    required this.name,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.profilePic,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.packageImage,
  });

  dynamic prefix;
  bool status;
  dynamic id;
  dynamic name;
  dynamic description;
  dynamic timeRequired;
  dynamic price;
  dynamic profilePic;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;
  dynamic packageImage;

  factory SaloonService.fromJson(Map<dynamic, dynamic> json) => SaloonService(
    prefix: json["Prefix"],
    status: json["Status"],
    id: json["_id"],
    name: json["Name"],
    description: json["Description"],
    timeRequired: json["Time_required"],
    price: json["Price"],
    profilePic: json["Profile_pic"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    packageImage: json["package_image"],
  );

}

