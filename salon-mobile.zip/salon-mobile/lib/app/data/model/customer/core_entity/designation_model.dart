class Designation {
  Designation({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
  });

  dynamic id;
  dynamic title;
  DateTime createdAt;
  DateTime updatedAt;
  int v;

  factory Designation.fromJson(Map<dynamic, dynamic> json) => Designation(
    id: json["_id"],
    title: json["title"],
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
  );

}

