// To parse this JSON data, do
//
//     final saloonItemsModel = saloonItemsModelFromJson(jsondynamic);

import 'package:get/get.dart';
import 'package:meta/meta.dart';
import 'dart:convert';

SaloonItemsModel saloonItemsModelFromJson(dynamic str) =>
    SaloonItemsModel.fromJson(json.decode(str));

class SaloonItemsModel {
  SaloonItemsModel({
    required this.error,
    required this.popular,
    required this.favorite,
    required this.top,
    required this.deals,
    required this.categories,
  });

  bool? error;
  List<Popular>? popular;
  List<Favorite>? favorite;
  List<Popular>? top;
  List<Deal>? deals;
  List<Category>? categories;

  factory SaloonItemsModel.fromJson(Map<dynamic, dynamic> json) =>
      SaloonItemsModel(
        error: json["Error"]==null?null:json["Error"],
        popular: json["Popular"] == null
            ? null
            : List<Popular>.from(
                json["Popular"].map((x) => Popular.fromJson(x))),
        favorite: json["Favorite"] == null
            ? null
            : List<Favorite>.from(
                json["Favorite"].map((x) => Favorite.fromJson(x))),
        top: json["Top"] == null
            ? null
            : List<Popular>.from(json["Top"].map((x) => Popular.fromJson(x))),
        deals: json["Deals"] == null
            ? null
            : List<Deal>.from(json["Deals"].map((x) => Deal.fromJson(x))),
        categories: json["Categories"] == null
            ? null
            : List<Category>.from(
                json["Categories"].map((x) => Category.fromJson(x))),
      );
}

class Category {
  Category({
    required this.id,
    required this.title,
    required this.backgroundPic,
    required this.icon,
  });

  dynamic id;
  dynamic title;
  dynamic backgroundPic;
  dynamic icon;
  RxBool isSelected = false.obs;

  factory Category.fromJson(Map<dynamic, dynamic> json) => Category(
        id: json["_id"],
        title: json["title"],
        backgroundPic: json["Background_Pic"],
        icon: json["Icon"],
      );

  Map<dynamic, dynamic> toJson() => {
        "_id": id,
        "title": title,
        "Background_Pic": backgroundPic,
        "Icon": icon,
      };
}

class Deal {
  Deal({
    required this.price,
    required this.approved,
    required this.status,
    required this.id,
    required this.user,
    required this.saloon,
    required this.couponName,
    required this.minPrice,
    required this.percentage,
    required this.usage,
    required this.couponCode,
    required this.expiry,
    required this.date,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.service,
    required this.startDate,
    required this.description,
    required this.endDate,
  });

  dynamic price;
  bool approved;
  dynamic status;
  dynamic id;
  List<dynamic>? user;
  dynamic saloon;
  dynamic couponName;
  dynamic minPrice;
  dynamic percentage;
  dynamic usage;
  dynamic couponCode;
  dynamic expiry;
  DateTime? date;
  DateTime? createdAt;
  DateTime? updatedAt;
  dynamic v;
  Service service;
  DateTime? startDate;
  dynamic description;
  DateTime? endDate;

  factory Deal.fromJson(Map<dynamic, dynamic> json) => Deal(
        price: json["Price"],
        approved: json["Approved"],
        status: json["Status"],
        id: json["_id"],
        user: json["User"] == null
            ? null
            : List<dynamic>.from(json["User"].map((x) => x)),
        saloon: json["Saloon"],
        couponName: json["Coupon_name"],
        minPrice: json["Min_Price"] == null ? null : json["Min_Price"],
        percentage: json["Percentage"],
        usage: json["Usage"] == null ? null : json["Usage"],
        couponCode: json["Coupon_code"],
        expiry: json["Expiry"] == null ? null : DateTime.parse(json["Expiry"]),
        date: DateTime.parse(json["Date"]),
        createdAt: DateTime.parse(json["createdAt"]),
        updatedAt: DateTime.parse(json["updatedAt"]),
        v: json["__v"],
        service: Service.fromJson(json["Service"]),
        startDate: json["Start_Date"] == null
            ? null
            : DateTime.parse(json["Start_Date"]),
        description: json["Description"] == null ? null : json["Description"],
        endDate:
            json["End_Date"] == null ? null : DateTime.parse(json["End_Date"]),
      );
}

class Service {
  Service({
    required this.prefix,
    required this.status,
    required this.id,
    required this.name,
    required this.description,
    required this.timeRequired,
    required this.price,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.packageImage,
  });

  dynamic prefix;
  bool status;
  dynamic id;
  dynamic name;
  dynamic description;
  dynamic timeRequired;
  dynamic price;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;
  dynamic packageImage;

  factory Service.fromJson(Map<dynamic, dynamic> json) => Service(
        prefix: json["Prefix"],
        status: json["Status"],
        id: json["_id"],
        name: json["Name"],
        description: json["Description"],
        timeRequired: json["Time_required"],
        price: json["Price"],
        createdAt: DateTime.parse(json["createdAt"]),
        updatedAt: DateTime.parse(json["updatedAt"]),
        v: json["__v"],
        packageImage: json["package_image"],
      );
}

class Favorite {
  Favorite({
    required this.address,
    required this.photos,
    required this.services,
    required this.rating,
    required this.reviews,
    required this.bookingsLeft,
    required this.bookingsUsed,
    required this.status,
    required this.approved,
    required this.id,
    required this.name,
    required this.email,
    required this.mobileNumber,
    required this.category,
    required this.password,
    required this.profilePic,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.aboutUs,
    required this.description,
    required this.businessType,
    required this.closeTime,
    required this.openTime,
  });

  Address? address;
  List<dynamic> photos;
  List<dynamic> services;
  dynamic rating;
  dynamic reviews;
  dynamic bookingsLeft;
  dynamic bookingsUsed;
  bool status;
  bool approved;
  dynamic id;
  dynamic name;
  dynamic email;
  dynamic mobileNumber;
  dynamic category;
  dynamic password;
  dynamic profilePic;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic v;
  dynamic aboutUs;
  dynamic description;
  dynamic businessType;
  dynamic closeTime;
  dynamic openTime;

  factory Favorite.fromJson(Map<dynamic, dynamic> json) => Favorite(
        address: json["Address"]==null?null:Address.fromJson(json["Address"]),
        photos: List<dynamic>.from(json["Photos"].map((x) => x)),
        services: List<dynamic>.from(json["Services"].map((x) => x)),
        rating: json["Rating"],
        reviews: json["Reviews"],
        bookingsLeft: json["Bookings_Left"],
        bookingsUsed: json["Bookings_Used"],
        status: json["status"],
        approved: json["approved"],
        id: json["_id"],
        name: json["Name"],
        email: json["Email"],
        mobileNumber: json["Mobile_number"],
        category: json["Category"],
        password: json["Password"],
        profilePic: json["Profile_Pic"],
        registerDate: DateTime.parse(json["Register_date"]),
        createdAt: DateTime.parse(json["createdAt"]),
        updatedAt: DateTime.parse(json["updatedAt"]),
        v: json["__v"],
        aboutUs: json["About_Us"],
        description: json["Description"],
        businessType: json["Business_Type"],
        closeTime: json["Close_Time"],
        openTime: json["Open_Time"],
      );
}

class Address {
  Address({
    required this.type,
    required this.coordinates,
    required this.address,
    required this.city,
    required this.state,
  });

  dynamic type;
  List<double> coordinates;
  dynamic address;
  dynamic city;
  dynamic state;

  factory Address.fromJson(Map<dynamic, dynamic> json) => Address(
        type: json["type"],
        coordinates:
            List<double>.from(json["coordinates"].map((x) => x.toDouble())),
        address: json["Address"],
        city: json["City"],
        state: json["State"],
      );

  Map<dynamic, dynamic> toJson() => {
        "type": type,
        "coordinates": List<dynamic>.from(coordinates.map((x) => x)),
        "Address": address,
        "City": city,
        "State": state,
      };
}

class Popular {
  Popular({
    required this.address,
    required this.rating,
    required this.id,
    required this.name,
    required this.profilePic,
    required this.closeTime,
    required this.openTime,
  });

  Address? address;
  dynamic rating;
  dynamic id;
  dynamic name;
  dynamic profilePic;
  dynamic closeTime;
  dynamic openTime;

  factory Popular.fromJson(Map<dynamic, dynamic> json) => Popular(
        address: json["Address"]==null?null:Address.fromJson(json["Address"]),
        rating: json["Rating"],
        id: json["_id"],
        name: json["Name"],
        profilePic: json["Profile_Pic"],
        closeTime: json["Close_Time"],
        openTime: json["Open_Time"],
      );

  Map<dynamic, dynamic> toJson() => {
        "Address": address!.toJson(),
        "Rating": rating,
        "_id": id,
        "Name": name,
        "Profile_Pic": profilePic,
        "Close_Time": closeTime,
        "Open_Time": openTime,
      };
}
