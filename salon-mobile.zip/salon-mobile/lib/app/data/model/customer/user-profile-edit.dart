// To parse this JSON data, do
//
//     final editUserProfileModel = editUserProfileModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

EditUserProfileModel editUserProfileModelFromJson(String str) => EditUserProfileModel.fromJson(json.decode(str));

String editUserProfileModelToJson(EditUserProfileModel data) => json.encode(data.toJson());

class EditUserProfileModel {
  EditUserProfileModel({
    required this.error,
    required this.msg,
    required this.data,
  });

  bool error;
  String msg;
  Data data;

  factory EditUserProfileModel.fromJson(Map<String, dynamic> json) => EditUserProfileModel(
    error: json["Error"],
    msg: json["Msg"],
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Error": error,
    "Msg": msg,
    "Data": data.toJson(),
  };
}

class Data {
  Data({
    required this.rating,
    required this.role,
    required this.favouriteProducts,
    required this.favouriteSaloons,
    required this.status,
    required this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.mobileNumber,
    required this.dob,
    required this.registerDate,
    required this.createdAt,
    required this.updatedAt,
    required this.v,
    required this.otp,
    required this.profilePic,
  });

  int rating;
  String role;
  List<dynamic> favouriteProducts;
  List<String> favouriteSaloons;
  bool status;
  String id;
  String name;
  String email;
  String password;
  String mobileNumber;
  String dob;
  DateTime registerDate;
  DateTime createdAt;
  DateTime updatedAt;
  int v;
  int otp;
  String profilePic;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    rating: json["Rating"],
    role: json["role"],
    favouriteProducts: List<dynamic>.from(json["FavouriteProducts"].map((x) => x)),
    favouriteSaloons: List<String>.from(json["FavouriteSaloons"].map((x) => x)),
    status: json["status"],
    id: json["_id"],
    name: json["name"],
    email: json["email"],
    password: json["password"],
    mobileNumber: json["mobile_number"],
    dob: json["DOB"],
    registerDate: DateTime.parse(json["register_date"]),
    createdAt: DateTime.parse(json["createdAt"]),
    updatedAt: DateTime.parse(json["updatedAt"]),
    v: json["__v"],
    otp: json["otp"],
    profilePic: json["Profile_Pic"],
  );

  Map<String, dynamic> toJson() => {
    "Rating": rating,
    "role": role,
    "FavouriteProducts": List<dynamic>.from(favouriteProducts.map((x) => x)),
    "FavouriteSaloons": List<dynamic>.from(favouriteSaloons.map((x) => x)),
    "status": status,
    "_id": id,
    "name": name,
    "email": email,
    "password": password,
    "mobile_number": mobileNumber,
    "DOB": dob,
    "register_date": registerDate.toIso8601String(),
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "__v": v,
    "otp": otp,
    "Profile_Pic": profilePic,
  };
}
