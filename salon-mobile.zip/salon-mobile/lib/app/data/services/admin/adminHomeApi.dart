import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:saloon_app/app/data/model/admin/add-service-response.dart';
import 'package:saloon_app/app/data/model/admin/admin-get-categorized-services-res.dart';
import 'package:saloon_app/app/data/model/admin/admin-login-res.dart';
import 'package:saloon_app/app/data/model/admin/admin-otp-verify-res.dart';
import 'package:saloon_app/app/data/model/admin/admin-update-saloon.dart';
import 'package:saloon_app/app/data/model/admin/admin_analaytics_res.dart';
import 'package:saloon_app/app/data/model/admin/customers/admin-add-customers.dart';
import 'package:saloon_app/app/data/model/admin/customers/admin-all-customers.dart';
import 'package:saloon_app/app/data/model/admin/deals/admin-deals-response.dart';
import 'package:saloon_app/app/data/model/admin/deals/admin-get-coupons-resp.dart';
import 'package:saloon_app/app/data/model/admin/deals/admin-update-deal.dart';
import 'package:saloon_app/app/data/model/admin/get-service-names.dart';
import 'package:saloon_app/app/data/model/customer/appointment/add-booking-via-staff.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/data/model/customer/filter_category_res.dart';
import 'package:saloon_app/app/data/model/customer/get-saloon-details-model.dart';
import 'package:saloon_app/app/data/model/customer/saloon-item-model.dart';
import 'package:saloon_app/app/data/model/customer/saloon/all_favorite_saloon.dart';
import 'package:saloon_app/app/data/model/customer/saloon/all_top_saloon.dart';
import 'package:saloon_app/app/data/model/customer/saloon/staff-detail-model.dart';
import 'package:saloon_app/app/data/model/customer/special_offer.dart';
import 'package:saloon_app/app/data/model/customer/user-profile-edit.dart';
import 'package:path/path.dart';
import 'package:saloon_app/app/data/model/customer/user-profile.dart';
import 'package:saloon_app/app/utils/app-strings.dart';
import 'dart:io';

import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart';
import 'package:async/async.dart';

class AdminHomeApi {

  Future<dynamic> adminSignUp({required Map<String, dynamic> apiParams}) async {
    var res;
    try {
      final response = await http
          .post(
        Uri.parse('${AppUrls.BASE_URL}/addsaloon'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(apiParams),
      )
          .timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('Signup response: ${response.statusCode}');
      print('Signup response: ${response.body}');
      if (response.statusCode == 200) {
        res = errorResponseFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print (e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print (e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      print (e);
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> userSignUp({required Map<String, dynamic> apiParams}) async {
    var res;
    try {
      final response = await http
          .post(
        Uri.parse('${AppUrls.BASE_URL}/adminusersignup'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(apiParams),
      )
          .timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('Signup response: ${response.statusCode}');
      print('Signup response: ${response.body}');
      if (response.statusCode == 200) {
        res = adminAddCustomersResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print(e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> getSaloonAllDeals(
      {required int page, required int Limit }) async {
    print('getSaloonAllDeals: started...');

    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getcoupons'),
        body: jsonEncode({'Page': page, 'Limit': Limit}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getcoupons: ${response.statusCode}');
      print('getcoupons: ${response.body}');
      if (response.statusCode == 200) {
        res = adminGetCouponsResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print(res);

      print("this is url ${AppUrls.BASE_URL}/getcoupons");
      return res;
    } on TimeoutException catch (e) {
      print('Error : $e');
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print('Error : $e');
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> adminGetAllCustomers({required Map<String, dynamic> apiParams}) async {
    var res;
    try {
      final response = await http
          .post(
        Uri.parse('${AppUrls.BASE_URL}/getallcustomers'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(apiParams),
      )
          .timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('Signup response: ${response.statusCode}');
      print('Signup response: ${response.body}');
      if (response.statusCode == 200) {
        res = adminAllCustomersResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/getallcustomers");
      return res;
    } on TimeoutException catch (e) {
      print (e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print (e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      print (e);
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> otpVerifyFirstTime({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 40 ;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/otpverification'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(apiParams),
      ).timeout(Duration(seconds: timeout));
      // 1458
      print('otpverification response: ${response.statusCode}');
      print('otpverification response: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        // res = otpVerificationResponseFromJson(response.body);
      } else{
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/otpverification");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException catch (e) {
      print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> adminotpVerifyFirstTime({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 40 ;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/saloonotpverification'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(apiParams),
      ).timeout(Duration(seconds: timeout));
      // 1458
      print('otpverification response: ${response.statusCode}');
      print('otpverification response: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = adminOtpVerifyResponseFromJson(response.body);
      } else{
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/saloonotpverification");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException catch (e) {
      print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> resendOtp({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 40 ;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/resendotpmobile'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(apiParams),
      ).timeout(Duration(seconds: timeout));
      // 1458
      print('RESEND OTP response: ${response.statusCode}');
      print('RESEND OTP response: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = errorResponseFromJson(response.body);
      } else{
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/resendotpmobile");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException catch (e) {
      print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> adminLogin({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 40;
    try {
      final response = await http
          .post(
        Uri.parse('${AppUrls.BASE_URL}/adminsignin'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(apiParams),
      )
          .timeout(Duration(seconds: timeout));
      // 1458
      print('LOGIN response: ${response.statusCode}');
      print('LOGIN response: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = adminLoginResFromJson(response.body);
      } else{
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/adminsignin");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException catch (e) {
      print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getFilterCategories() async {
    var res;
    int timeout = 40;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/getcategories'),
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('getcategories: ${response.statusCode}');
      print('getcategories: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = filterCategoryResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getAdminAllServices() async {
    var res;
    int timeout = 40;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/getcategorizedservices'),
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('getcategorizedservices: ${response.statusCode}');
      print('getcategorizedservices: ${response.body}');
      print('${AppUrls.BASE_URL}/getcategorizedservices');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = getCategorizedServicesResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getAdminAnalytics() async {
    var res;
    int timeout = 40;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/analytics'),
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('analytics: ${response.statusCode}');
      print('analytics: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = adminAnalyticsResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getAllServicesNames() async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getservices'),
        body: ""
        // headers: {
        //   HttpHeaders.authorizationHeader:
        //   'Bearer ${AppStrings.tokenOfAdminUser}'
        // },
      ).timeout(Duration(seconds: timeout));
      print('getservices: ${response.statusCode}');
      print('getservices: ${response.body}');
      print('${AppUrls.BASE_URL}/getservices');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = getServiceNamesFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> saloonDashboardItem(String search) async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getDashboardItem'),
        body: {"Search": search},
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      // 1458
      print('DASHBOARD ITEM: ${response.statusCode}');
      print('DASHBOARD ITEM: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = saloonItemsModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/getDashboardItem");
      return res;
    } on TimeoutException catch (e) {
      return ('Slow Internet try again');
    } on SocketException {
      return ('No internet');
    } on Error catch (e) {
      return ('$e');
    }
  }

  Future<dynamic> addFavouriteSaloons({required String id}) async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/addfavouritesaloon'),
        body: {
          "Saloon_Id": id
        },
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      // 1458
      print('Favourite Saloon: ${response.statusCode}');
      print('Favourite Saloon: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = errorResponseFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/addfavouritesaloon");
      return res;
    } on TimeoutException catch (e) {
      return ('Slow Internet try again');
    } on SocketException {
      return ('No internet');
    } on Error catch (e) {
      return ('$e');
    }
  }

  Future<dynamic> getSpecificSaloonDetails(String saloon) async {
    print(saloon);
    var res;
    int timeout = 40;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/getsaloon/$saloon'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      ).timeout(Duration(seconds: timeout));
      print('getSpecificSaloonDetails: ${response.statusCode}');
      print('getSpecificSaloonDetails: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = saloonDetailsModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/getsaloon/$saloon");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getSpecificUserDetails() async {
    var res;
    int timeout = 40;
    try {
      final response = await http.get(
        Uri.parse('${AppUrls.BASE_URL}/getuserdetails'),
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('getSpecificSaloonDetails: ${response.statusCode}');
      print('getSpecificSaloonDetails: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = userProfileModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/getuserdetails");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> editSpecificUserDetails({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/updateuserdetails'),
          headers: {
            HttpHeaders.authorizationHeader:
            'Bearer ${AppStrings.tokenOfCurrentUser}'
          },body: (apiParams)
      ).timeout(Duration(seconds: timeout));
      print('getSpecificSaloonDetails: ${response.statusCode}');
      print('getSpecificSaloonDetails: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = editUserProfileModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/updateuserdetails");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> editSpecificUserDetailswithImages({required Map<String, String> apiParams, required var image}) async {
    try {

      print('Sending Data : $apiParams');
      print('Token ${AppStrings.tokenOfCurrentUser}');
      var stream = http.ByteStream(DelegatingStream.typed(image.openRead()));
      // get file length
      var length = await image.length(); //imageFile is your image file
      Map<String, String> headers = {
        HttpHeaders.authorizationHeader:
        "Bearer ${AppStrings.tokenOfCurrentUser}"
      }; // ignore this headers if there is no authentication
      // create multipart request
      var request = http.MultipartRequest("POST", Uri.parse('${AppUrls.BASE_URL}/updateuserdetails'));
      // multipart that takes file
      String file_path = basename(image.path);
      var multipartFileSign =
      http.MultipartFile('Profile_Pic', stream, length, filename: file_path);

      request.headers.addAll(headers);
      request.files.add(multipartFileSign);
      request.fields.addAll(apiParams);
      //add headers
      // send
      var res = await http.Response.fromStream(
        await request.send().timeout(
          Duration(seconds: 60),
        ),
      );

      print('API RESPONSE ${res.body}');

      if (res.statusCode == 200) {
        print("200 status code");
        print (res);
        return editUserProfileModelFromJson(res.body);
      } else if (res.statusCode == 401) {
        print("401 status code");
        print (res.body);
        return errorResponseFromJson(res.body);
      }

    } on TimeoutException catch (e) {
      print(e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print(e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print(e);
      return ExceptionCode.error;
    }
  }

  Future<dynamic> saloonAddBookingViaStaff({required Map<String, dynamic> apiParams, required BuildContext context}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(apiParams)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/addbooking'),
          headers: {
            HttpHeaders.authorizationHeader:
            'Bearer ${AppStrings.tokenOfCurrentUser}'
          },body: apiParams
      ).timeout(Duration(seconds: timeout));
      print('saloonAddBookingViaStaffResponse: ${response.statusCode}');
      print('saloonAddBookingViaStaffResponse: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = addBookingViaStaffFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/addbooking");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getAllTopSaloon(int page) async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getalltopsaloons'),
        body: jsonEncode({'page': page}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getalltopsaloons: ${response.statusCode}');
      print('getalltopsaloons: ${response.body}');
      if (response.statusCode == 200) {
        res = topSaloonModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> getAllOffers(int page) async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getcoupons'),
        body: jsonEncode({'page': page}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getalltopsaloons: ${response.statusCode}');
      print('getalltopsaloons: ${response.body}');
      if (response.statusCode == 200) {
        res = specialOfferModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> getFavoriteSaloon(int page) async {
    var res;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getfavsaloons'),
        body: jsonEncode({'page': page}),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: ExceptionCode.timeOut30));
      print('getalltopsaloons: ${response.statusCode}');
      print('getalltopsaloons: ${response.body}');
      if (response.statusCode == 200) {
        res = favoriteSaloonModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print('Error : $e');
      return ExceptionCode.exception;
    }
  }

  Future<dynamic> getSpecificStaffDetails({required String date, required String id}) async {
    // print(staffId);
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/staffdetail'),
        body: {
          "id" : id,
          "date" : date
        },
        headers: {
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('getSpecificStaffDetails: ${response.statusCode}');
      print('getSpecificStaffDetails: ${response.body}');
      if (response.statusCode == 200) {
        // print(response.body.toString());
        res = staffDetailModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/staffdetail");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getFilteredSaloon({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/saloonfilter'),
        body: jsonEncode(apiParams),
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          HttpHeaders.authorizationHeader:
          'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      // 1458
      print('saloonfilter ITEM: ${response.statusCode}');
      print('saloonfilter ITEM: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = saloonItemsModelFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }

      print("this is url ${AppUrls.BASE_URL}/getDashboardItem");
      return res;
    } on TimeoutException catch (e) {
      return ('Slow Internet try again');
    } on SocketException {
      return ('No internet');
    } on Error catch (e) {
      return ('$e');
    }
  }

  Future<dynamic> adminAddService({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(apiParams)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/addservices'),
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonEncode(apiParams)
      ).timeout(Duration(seconds: timeout));
      print('addservices: ${response.statusCode}');
      print('addservices: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = addServiceResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/addservices");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> adminAddDeal({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(apiParams)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/adminaddcoupon'),
          headers: {
            HttpHeaders.authorizationHeader:
            'Bearer ${AppStrings.tokenOfCurrentUser}'
          },
          body: apiParams
      ).timeout(Duration(seconds: timeout));
      print('adminaddcoupon: ${response.statusCode}');
      print('adminaddcoupon: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = adminAddDealResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/adminaddcoupon");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> adminUpdatedDeal({required Map<String, dynamic> apiParams}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(apiParams)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/updatecoupon'),
          headers: {
            HttpHeaders.authorizationHeader:
            'Bearer ${AppStrings.tokenOfCurrentUser}'
          },
          body: apiParams
      ).timeout(Duration(seconds: timeout));
      print('updatecoupon: ${response.statusCode}');
      print('updatecoupon: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = adminUpdateDealResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/updatecoupon");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> adminDeleteDeal({String? id}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(id)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/deletecoupon'),
          headers: {
            HttpHeaders.authorizationHeader:
            'Bearer ${AppStrings.tokenOfCurrentUser}'
          },
          body: {"id": id}
      ).timeout(Duration(seconds: timeout));
      print('deletecoupon: ${response.statusCode}');
      print('deletecoupon: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = errorResponseFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/deletecoupon");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> adminUpdateSaloon({required Map<String, String> apiParams}) async {
    var res;
    int timeout = 60;
    print("map received ${jsonEncode(apiParams)}");
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/updatesaloon'),
          headers: <String, String>{
            // 'Content-Type': 'application/json; charset=UTF-8',
          },
          body: apiParams
      ).timeout(Duration(seconds: timeout));
      print('updatesaloon: ${response.statusCode}');
      print('updatesaloon: ${response.body}');
      if (response.statusCode == 200) {
        print(response.body.toString());
        res = adminUpdateSaloonResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      print("this is url ${AppUrls.BASE_URL}/updatesaloon");
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic>? adminUpdateSaloonWithImage({required Map<String, String> apiParams, required var image}) async {
    try {

      print('Sending Data : $apiParams');
      print('Token ${AppStrings.tokenOfCurrentUser}');
      var stream = http.ByteStream(DelegatingStream.typed(image.openRead()));
      // get file length
      var length = await image.length(); //imageFile is your image file
      Map<String, String> headers = {
        // HttpHeaders.authorizationHeader:
        // "Bearer ${AppStrings.tokenOfCurrentUser}"
      }; // ignore this headers if there is no authentication
      // create multipart request
      var request = http.MultipartRequest("POST", Uri.parse('${AppUrls.BASE_URL}/updatesaloon'),);
      // multipart that takes file
      String file_path = basename(image.path);
      var multipartFileSign =
      http.MultipartFile('Profile_Pic', stream, length, filename: file_path);

      request.headers.addAll(headers);
      request.files.add(multipartFileSign);
      request.fields.addAll(apiParams);
      //add headers
      // send
      var res = await http.Response.fromStream(
        await request.send().timeout(
          Duration(seconds: 60),
        ),
      );

      print('API RESPONSE ${res.body}');

      if (res.statusCode == 200) {
        print("200 status code");
        print (res);
        return adminUpdateSaloonResFromJson(res.body);
      } else if (res.statusCode == 401) {
        print("401 status code");
        print (res.body);
        return errorResponseFromJson(res.body);
      }
      else{
        print(res.statusCode);
        print("cover photo error");
      }

    } on TimeoutException catch (e) {
      print(e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print(e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print(e);
      return ExceptionCode.error;
    }
  }

  Future<dynamic>? adminUpdateSaloonWithCoverImage({required Map<String, String> apiParams, List<File>? image}) async {
    try {

      print('Sending Data : $apiParams');
      print('Token ${AppStrings.tokenOfCurrentUser}');
      var stream = http.ByteStream(DelegatingStream.typed(image!.elementAt(0).openRead()));
      // get file length
      var length = await image.elementAt(0).length(); //imageFile is your image file
      Map<String, String> headers = {
        // HttpHeaders.authorizationHeader:
        // "Bearer ${AppStrings.tokenOfCurrentUser}"
      }; // ignore this headers if there is no authentication
      // create multipart request
      var request = http.MultipartRequest("POST", Uri.parse('${AppUrls.BASE_URL}/updatesaloon'),);
      // multipart that takes file
      String file_path = basename(image.elementAt(0).path);
      var multipartFileSign =
      http.MultipartFile('Photos', stream, length, filename: file_path);

      request.headers.addAll(headers);
      request.files.add(multipartFileSign);
      request.fields.addAll(apiParams);
      //add headers
      // send
      var res = await http.Response.fromStream(
        await request.send().timeout(
          Duration(seconds: 60),
        ),
      );

      print('API RESPONSE ${res.body}');

      if (res.statusCode == 200) {
        print("200 status code");
        print (res);
        return adminUpdateSaloonResFromJson(res.body);
      } else if (res.statusCode == 401) {
        print("401 status code");
        print (res.body);
        return errorResponseFromJson(res.body);
      }
      else{
        print(res.statusCode);
        print("cover photo error");
      }

    } on TimeoutException catch (e) {
      print(e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print(e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print(e);
      return ExceptionCode.error;
    }
  }



}

