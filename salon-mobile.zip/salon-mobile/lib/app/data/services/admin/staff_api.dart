import 'dart:convert';

import 'package:saloon_app/app/data/model/admin/designation_res.dart';
import 'package:saloon_app/app/data/model/admin/staff/salon_all_staff_res.dart';
import 'package:saloon_app/app/data/model/admin/staff/specific_staff_all_booking.dart';
import 'package:saloon_app/app/data/model/customer/error-response.dart';
import 'package:saloon_app/app/utils/app-strings.dart';

import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path/path.dart';
import 'package:async/async.dart';
import 'package:saloon_app/app/utils/app_urls.dart';
import 'package:saloon_app/app/utils/exceptionCode.dart';

class StaffApi {
  Future<dynamic> addEmployee(
      {required Map<String, String> apiParams, required File? image}) async {
    try {
      print('Sending Data : $apiParams');
      print('Sending Data : ${image?.length}');
      print('Token ${AppStrings.tokenOfCurrentUser}');
      Map<String, String> headers = {
        HttpHeaders.authorizationHeader:
            "Bearer ${AppStrings.tokenOfCurrentUser}"
      }; // ignore this headers if there is no authentication
      // create multipart request
      var request = http.MultipartRequest(
          "POST", Uri.parse('${AppUrls.BASE_URL}/addstaff'));

      var imageStream, imageLength, multipartFile;
      String file_path;

      if (image != null) {
        //imageFile is your image file
        imageStream = http.ByteStream(DelegatingStream.typed(image.openRead()));
        // get file length
        imageLength = await image.length();
        file_path = basename(image.path);
        // multipart that takes file
        multipartFile = http.MultipartFile(
            'Staff_pic', imageStream, imageLength,
            filename: file_path);
        request.files.add(multipartFile);
      }

      request.headers.addAll(headers);
      request.fields.addAll(apiParams);
      //add headers
      // send
      var res = await http.Response.fromStream(
        await request.send().timeout(
              Duration(seconds: 120),
            ),
      );

      print('API RESPONSE ${res.statusCode}');
      print('API RESPONSE ${res.body}');

      if (res.statusCode == 200) {
        print("200 status code");
        print(res);
        return ExceptionCode.success;
      } else if (res.statusCode == 201) {
        print("401 status code");
        print(res.body);
        return errorResponseFromJson(res.body);
      } else if (res.statusCode == 400) {
        print("401 status code");
        print(res.body);
        return errorResponseFromJson(res.body);
      }
    } on TimeoutException catch (e) {
      print(e);
      return ExceptionCode.timeOut;
    } on SocketException catch (e) {
      print(e);
      return ExceptionCode.noInternet;
    } on Error catch (e) {
      print(e);
      return ExceptionCode.error;
    }
  }

  Future<dynamic> getDesignations() async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
        Uri.parse('${AppUrls.BASE_URL}/getdesignations'),
        headers: {
          HttpHeaders.authorizationHeader:
              'Bearer ${AppStrings.tokenOfCurrentUser}'
        },
      ).timeout(Duration(seconds: timeout));
      print('getdesignations: ${response.statusCode}');
      print('getdesignations: ${response.body}');
      if (response.statusCode == 200) {
        res = designationResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> getSaloonAllStaff(
      [String search = '', String designation = '', int page = 1]) async {
    var res;
    int timeout = 40;
    try {
      final response = await http
          .post(Uri.parse('${AppUrls.BASE_URL}/filtersaloonallstaff'),
              headers: {
                HttpHeaders.authorizationHeader:
                    'Bearer ${AppStrings.tokenOfCurrentUser}'
              },
              body: jsonEncode(
                  {'Search': search, 'Designation': designation, 'Page': page}))
          .timeout(Duration(seconds: timeout));
      print('filtersaloonallstaff: ${response.statusCode}');
      print('filtersaloonallstaff: ${response.body}');
      if (response.statusCode == 200) {
        res = saloonAllStaffFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }

  Future<dynamic> specificStaffAllBooking({required String staffId}) async {
    var res;
    int timeout = 40;
    try {
      final response = await http.post(
          Uri.parse('${AppUrls.BASE_URL}/specificstaffallbookingbysaloon'),
          headers: {
            HttpHeaders.authorizationHeader:
                'Bearer ${AppStrings.tokenOfCurrentUser}'
          },
          body: {
            'staff_id': staffId
          }).timeout(Duration(seconds: timeout));
      print('specificstaffallbookingbysaloon: ${response.statusCode}');
      print('specificstaffallbookingbysaloon: ${response.body}');
      if (response.statusCode == 200) {
        res = specificStaffAllBookingResFromJson(response.body);
      } else {
        res = errorResponseFromJson(response.body);
      }
      return res;
    } on TimeoutException catch (e) {
      print(e);
      return ('Slow Internet try again');
    } on SocketException {
      // print(e);
      return ('No internet');
    } on Error catch (e) {
      print(e);
      return ('$e');
    }
  }
}
