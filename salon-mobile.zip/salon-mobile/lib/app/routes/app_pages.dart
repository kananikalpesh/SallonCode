import 'package:get/get.dart';
import 'package:saloon_app/app/modules/admin/bindings/addOn_binding.dart';
import 'package:saloon_app/app/modules/admin/bindings/admin_binding.dart';
import 'package:saloon_app/app/modules/admin/bindings/choose_customer_binding.dart';
import 'package:saloon_app/app/modules/admin/bindings/saloon_appointment_binding.dart';
import 'package:saloon_app/app/modules/admin/controllers/choose-customer-ctl.dart';
import 'package:saloon_app/app/modules/admin/views/add-customer.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/add-on-detail.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/add-ons-screen.dart';
import 'package:saloon_app/app/modules/admin/views/add-ons-tabs-all-screens/new-add-on.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-book-appointment-two.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-booking-detail-second.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-booking-detail1.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-select-add-ons.dart';
import 'package:saloon_app/app/modules/admin/views/admin-add-slot/admin-select-services.dart';
import 'package:saloon_app/app/modules/admin/views/appointments/saloon_appointment_view.dart';
import 'package:saloon_app/app/modules/admin/views/appointments/saloon_request_detail.dart';
import 'package:saloon_app/app/modules/admin/views/calendar_settings.dart';
import 'package:saloon_app/app/modules/admin/views/calender_screens/calendar_settings.dart';
import 'package:saloon_app/app/modules/admin/views/choose-customer.dart';
import 'package:saloon_app/app/modules/admin/views/login/admin-login.dart';
import 'package:saloon_app/app/modules/admin/views/login/saloon-sign-up.dart';
import 'package:saloon_app/app/modules/admin/views/saloon_dashboard.dart';
import 'package:saloon_app/app/modules/admin/views/all_graphs.dart';
import 'package:saloon_app/app/modules/customer/bindings/about-saloon-binding.dart';
import 'package:saloon_app/app/modules/customer/bindings/appointment_binding.dart';
import 'package:saloon_app/app/modules/customer/bindings/customer_home_binding.dart';
import 'package:saloon_app/app/modules/customer/bindings/filter_binding.dart';
import 'package:saloon_app/app/modules/customer/views/Welcome.dart';
import 'package:saloon_app/app/modules/customer/views/appointments/appointment_content_two.dart';
import 'package:saloon_app/app/modules/customer/views/offer_packages/view_all_packages.dart';
import 'package:saloon_app/app/modules/customer/views/profile/edit-profile.dart';
import 'package:saloon_app/app/modules/customer/views/profile/my_profile.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/saloon.dart';
import 'package:saloon_app/app/modules/customer/views/chat/chat_detail.dart';
import 'package:saloon_app/app/modules/customer/views/filters.dart';
import 'package:saloon_app/app/modules/customer/views/notifications/notifications.dart';
import 'package:saloon_app/app/modules/customer/views/reservation_screens/booking_detail1.dart';
import 'package:saloon_app/app/modules/customer/views/reservation_screens/booking_detail2.dart';
import 'package:saloon_app/app/modules/customer/views/reservation_screens/payement_methods.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/select_add_ons.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/select_services.dart';
import 'package:saloon_app/app/modules/customer/views/saloon_profile/view_all_saloon.dart';
import 'package:saloon_app/app/modules/customer/views/transections/transection_detail.dart';
import 'package:saloon_app/app/modules/customer/views/transections/transection_list.dart';

import 'package:saloon_app/app/modules/intro_pages/views/connect_with_screen.dart';
import 'package:saloon_app/app/modules/intro_pages/views/intro_screen.dart';
import 'package:saloon_app/app/modules/intro_pages/views/splash_screen.dart';
import 'package:saloon_app/app/modules/login/bindings/home_binding.dart';
import 'package:saloon_app/app/modules/login/bindings/login-bindings.dart';
import 'package:saloon_app/app/modules/login/bindings/otp_binding.dart';
import 'package:saloon_app/app/modules/login/views/forgot_password_screen.dart';
import 'package:saloon_app/app/modules/login/views/login.dart';
import 'package:saloon_app/app/modules/login/views/main_continue_as.dart';
import 'package:saloon_app/app/modules/login/views/otp_code.dart';
import 'package:saloon_app/app/modules/login/views/saloon_continue_as.dart';
import 'package:saloon_app/app/modules/login/views/signup_screen.dart';
import 'package:saloon_app/app/modules/staff/bindings/staff-binding/staff-login-binding.dart';
import 'package:saloon_app/app/modules/staff/views/staff-login.dart';
import 'package:saloon_app/app/modules/staff/views/staff_all_bookigs.dart';
import 'package:saloon_app/app/modules/staff/views/staff_booking_details.dart';
import 'package:saloon_app/app/modules/staff/views/staff_calender_main.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.SPLASH_SCREEN;

  //  static const INITIAL = Routes.WELCOME_CUSTOMER_SCREEN;
  static final routes = [
    GetPage(
      name: _Paths.SPLASH_SCREEN,
      page: () => SplashScreen(),
    ),
    GetPage(
      name: _Paths.INTRO_SCREEN,
      page: () => IntroScreen(),
    ),
    GetPage(
      name: _Paths.CONNECT_WITH,
      page: () => ConnectWith(),
    ),
    GetPage(
      name: _Paths.LOGIN_SCREEN,
      page: () => Login(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: _Paths.StaffLogin,
      page: () => StaffLogin(),
      binding: StaffLoginBinding(),
    ),   GetPage(
      name: _Paths.STAFF_MAIN_DAISHBOARD,
      page: () => StaffCalenderMainScreen(),
      binding: StaffLoginBinding(),
    ),  GetPage(
      name: _Paths.STAFF_ALL_BOOKING,
      page: () => StaffAllBookingView(),
      binding: StaffLoginBinding(),
    ),GetPage(
      name: _Paths.STAFF_BOOKING_DETAILS,
      page: () => SatffBookingDetails(),
      binding: StaffLoginBinding(),
    ),
    GetPage(
      name: _Paths.FORGOT_PASSWORD_SCREEN,
      page: () => ForgotPassword(),
    ),
    GetPage(
        name: _Paths.SIGNUP_SCREEN,
        page: () => SignUp(),
        binding: SignUpBinding()),

    GetPage(
      name: _Paths.LOGIN_SCREEN_ADMIN,
      page: () => LoginAdmin(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: _Paths.SIGNUP_SCREEN_ADMIN,
      page: () => SaloonSignUp(),
      binding: LoginBinding(),
    ),
    // GetPage(
    //   name: _Paths.OTP_SCREEN,
    //   page: () => OTPCode(),
    //   binding: OTPBinding(),
    // ),
    GetPage(
      name: _Paths.MAIN_CONTINUE_AS_SCREEN,
      page: () => MainContinueAs(),
    ),
    GetPage(
      name: _Paths.SALOON_CONTINUE_AS_SCREEN,
      page: () => SaloonContinueAs(),
    ),
    GetPage(
      name: _Paths.VIEW_ALL_SALOONS_SCREEN,
      page: () => ViewAllSaloon(),
    ), GetPage(
      name: _Paths.VIEW_ALL_OFFER_SCREEN,
      page: () => ViewAllOffers(),
    ),
    GetPage(
      name: _Paths.WELCOME_aboutSaloon,
      page: () => Saloon(),
      binding: AboutSaloonBinding(),
    ),
    GetPage(
      name: _Paths.appointment_content_two,
      page: () => AppointmentContentTwo(),
    ),
    GetPage(
      name: _Paths.WELCOME_CUSTOMER_SCREEN,
      page: () => WelcomeCustomer(),
      binding: CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.CHAT_DETAIL,
      page: () => ChatWithSaloon(),
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.CUSTOMER_FILTER,
      page: () => Filters(),
      binding: FilterBinding()
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.NOTIFICATION_SCREEN,
      page: () => Notifications(),
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.BOOKING_DETAIL_FIRST,
      page: () => BookingDetailsFirst(),
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.BOOKING_DETAIL_SECOND,
      page: () => BookingDetailsSecond(),
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.PAYEMENT_METHODS,
      page: () => PayementMethods(),
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.TRANSECTION_DETAIL,
      page: () => TransectionDetail(),
      binding:AppointmentBinding(),
    ),
    GetPage(
      name: _Paths.TRANSECTION_LIST,
      page: () => TransectionList(),
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.SELECT_SERVICES,
      page: () => SelectServices(),
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.SELECT_ADD_ONS,
      page: () => SelectAddOns(),
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.all_graphs,
      page: () => AllGraphs(),
      // binding:CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.ADMIN_MAIN_DAISHBOARD,
      page: () => SaloonDashBoard(),
      binding: AdminBinding(),
    ),
    GetPage(
      name: _Paths.my_profile,
      page: () => MyProfile(),
      binding: CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.edit_my_profile,
      page: () => EditProfile(),
      binding: CustomerHomeBinding(),
    ),
    GetPage(
      name: _Paths.appointments,
      page: () => SaloonAppointmentView(),
      binding: SaloonAppointmentBinding()
    ),
    GetPage(
      name: _Paths.saloon_request_detail,
      page: () => SaloonRequestDetail(),
      binding: SaloonAppointmentBinding()
    ),
    GetPage(
      name: _Paths.add_ons_screen,
      page: () => AddOnsScreen(),
      binding: AddOnBinding()
    ),
    GetPage(
      name: _Paths.add_ons_detail,
      page: () => AddOnDetail(),
    ),
    GetPage(
      name: _Paths.new_add_on,
      page: () => NewAddOn(),
        binding: AddOnBinding()
    ),
    GetPage(
      name: _Paths.choose_customer,
      page: () => ChooseCustomer(),
        binding: ChooseCustomerBinding()
    ),
    GetPage(
      name: _Paths.add_customer,
      page: () => AddCustomer(),
        binding: ChooseCustomerBinding()
    ),
    GetPage(
      name: _Paths.AdminSelectServices,
      page: () => AdminSelectServices(),
        binding: ChooseCustomerBinding()
    ),
    GetPage(
      name: _Paths.AdminSelectAddOns,
      page: () => AdminSelectAddOns(),
        binding: ChooseCustomerBinding()
    ),
    GetPage(
      name: _Paths.AdminBookAppointmentTwo,
      page: () => AdminBookAppointmentTwo(),
        binding: ChooseCustomerBinding()
    ),
    GetPage(
      name: _Paths.AdminBookingDetailsFirst,
      page: () => AdminBookingDetailsFirst(),
        binding: ChooseCustomerBinding()
    ),
    GetPage(
      name: _Paths.AdminBookingDetailsSecond,
      page: () => AdminBookingDetailsSecond(),
        binding: ChooseCustomerBinding()
    ),
  ];
}
